﻿angular.module("app").service('membershipSrvc', ['$http', function ($http) {

    //Service created  for pricing table
    this.memberPricingTbl = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/membership/premiumprices";
        GetServiceByURL($http, url, funCallBack);
    }
    //end

    //Service created  for premium membership
    this.memberPremiumTbl = function (funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/membership/onlypremiumfeatures/";
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    //end

    //Service Cancel premium membership
    this.cancelPremiumPlan = function (mId, vKey,funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/pmthlpr/cancelsub/" + mId + "/" + vKey;
        GetServiceByURL($http, liveUrl, funCallBack);
        //var liveUrl = getApiDomainUrl() + "/api/bt/rectrnscncl/" + mId
       // PostServiceByURL($http, liveUrl, "", funCallBack)
    }
        //end
}]);