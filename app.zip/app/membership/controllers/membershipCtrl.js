﻿angular.module("app").controller('membershipCtrl', ['getSessionSrvc', "$scope", "$rootScope", "$window", "$location","$timeout", "membershipSrvc", "cmnSrvc", function (getSessionSrvc, $scope,$rootScope, $window, $location,$timeout, membershipSrvc, cmnSrvc) {

    var vm = this;
    var timezone = function () { return getSessionSrvc.p_tz(); };
    var zone = function () { return getTimeZoneById(timezone()); };
    if (getSessionSrvc.p_mId()) {
        vm.memId = getSessionSrvc.p_mId();
        vm.firstName = getSessionSrvc.p_fn();
            cmnSrvc.getMSSP(vm.memId, function (response, status) {
                if (status == 200) {
                    cmnSrvc.sessionUpdate(response);
                    setUiComponentInfo(response);
                }
            });
    }
    
   // showing the Divs as per the Premium status of a member
    function setUiComponentInfo(goPrmInfo) {
        if (!goPrmInfo.sId) {                                     //Not a Member 
            vm.nonMemDiv = true;
            vm.prmFtrTitle = "Join today and become a Premium Member!";
        }
        else if (goPrmInfo.sId == 1) {                         // Basic Member
            vm.BasicMemDiv = true;
            vm.premPlanMonth = goPrmInfo.currencySymbol + "" + goPrmInfo.price;
            vm.prmFtrTitle = "Premium Benefits";
            vm.planProductTxt = goPrmInfo.productText;
        }
        else if (goPrmInfo.sId == 2) {          // Premium  Member
            if (goPrmInfo.trialMember == 2) {                  // Premium Trial Member
                vm.trMemDiv = true;
                vm.premPlanMonth = goPrmInfo.currencySymbol + "" + goPrmInfo.price;
                vm.planProductTxt = goPrmInfo.productText;
            } else if (goPrmInfo.trialMember == 3) {            // Premium Recurring Member
                if (goPrmInfo.recurringPay) {
                    if (goPrmInfo.gracePeriod) vm.isGracePeriod = true; else vm.isGracePeriod = false;
                    vm.PremMemDiv = true;
                    vm.vKey = goPrmInfo.validationKey;
                    vm.paidRecurring = goPrmInfo.recurringPay;
                    vm.planProductTxt = goPrmInfo.productText;
                    vm.pageType = goPrmInfo.pgShortName;
                    if (goPrmInfo.pgShortName == 'BT') {
                        vm.btPayCard = true;
                        cardDetails();
                    } else if (goPrmInfo.pgShortName == 'BTPAYPAL') {
                         vm.btPpPayCard = true;
                    } else if (goPrmInfo.pgShortName == 'INAPPANRD' || goPrmInfo.pgShortName == 'INAPPIOS') {
                        vm.inAppdiv = true;
                    }
                } else {
                    vm.PremMemDiv = true;
                    vm.paidRecurring = false;
                }
            } else {

            }
            vm.startDate = cmnSrvc.getDate(zone(), goPrmInfo.dateTimeSubscrbSt, "membership");
            vm.endDate = cmnSrvc.getDate(zone(), goPrmInfo.dateTimeSubscrbExp, "membership");
            vm.renewDate = cmnSrvc.getDate(zone(), goPrmInfo.dateTimeSubscrbRenew, "membership");
            vm.prmFtrTitle = "Don’t forget – here are all the things you can do!";
        } else {

        }
    }

     // Getting Card Details
    function cardDetails() {
        showLoader();
        cmnSrvc.getCardDetails(vm.memId, function (response, status) {
            if (status == 200 && response) {
                if (response.CardType.toUpperCase() == "VISA") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/visaCard.png"; }
                else if (response.CardType.toUpperCase() == "AMERICAN EXPRESS") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/amexCard.png"; }
                else if (response.CardType.toUpperCase() == "MASTERCARD") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/masterCard.png"; }
                else if (response.CardType.toUpperCase() == "DISCOVER") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/DiscoverCard.png"; }
                else if (response.CardType.toUpperCase() == "JCB") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/JcbCard.png"; }
                else if (response.CardType.toUpperCase() == "DINERS CLUB") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/DinersClub.png"; }
                else { vm.cardImg = response.CardImageUrl; }
                vm.cardNo = response.MaskedNumber;
                vm.cardType = response.CardType
            }
            hideLoader();
        })
    };


    //Cancel Plan
    $rootScope.cancelPlan = function () {
        if (vm.pageType == 'INAPPANRD') {
            $rootScope.cancelledPlanDiv = true;
            $rootScope.cancelPlanErrtxt = "Something went wrong";
        } else if (vm.pageType == 'INAPPIOS') {
            $rootScope.cancelledPlanDiv = true;
            $rootScope.cancelPlanErrtxt = "Something went wrong";
        } else if (vm.pageType == 'BT' || vm.pageType == 'BTPAYPAL') {
            showLoader();
            membershipSrvc.cancelPremiumPlan(vm.memId,vm.vKey, function (response) {
                if (response) {
                    $("#cancelPlanPopUp").modal("hide");
                    if ($location.path().split("?")[0] == '/account.html') $rootScope.$emit('cancelledPlan');
                    else vm.isCancelledPlan = true;
                    vm.paidRecurring = false;
                } else {
                    //alert("Couldnt cancel the plan");
                    $rootScope.cancelledPlanDiv = true;
                    $rootScope.cancelPlanErrtxt = "Something went wrong";
                }
                hideLoader();
            });
        }
    }

   function modalpopupclose(){ $("#cancelPlanPopUp").on('hidden.bs.modal', function (e) {  $timeout(function () { $rootScope.cancelledPlanDiv = false; }, 0);});}
   modalpopupclose();
   
    //memberPremiumTbl service called for premium membership
    membershipSrvc.memberPremiumTbl(function (response, status) {
        if (status == 200 && response != null) {
            vm.premiumTbl = response;
        }
    });
    //end

    vm.bindImgSrc = function (imgPath) {
        return addCdnPath(imgPath);
    }
}]);