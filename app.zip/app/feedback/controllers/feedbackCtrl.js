﻿
/// <reference path="../../../scripts/angular.js" />

angular.module("app").controller('feedbackCtrl', ['getSessionSrvc', 'feedbackSrvc', '$rootScope', '$scope', '$timeout', '$state', function (getSessionSrvc, feedbackSrvc, $rootScope, $scope, $timeout, $state) {
    var vm = this;    
    vm.button = true;
    vm.box = false;
    vm.sent = false;
    vm.plchldr = "Describe Your Issue";
    vm.text = "";
    vm.btnval = false;
    vm.invld = "";
    function emptyhlpusImp(placeHolder, plchclr) { vm.plchldr = placeHolder; vm.text = null; vm.btnval = false; vm.invld = plchclr }
    vm.clear = function () {
        vm.plchldr = "Describe Your Issue";
        vm.text = "";
        vm.btnval = false;
        vm.invld = "";
    }
    vm.butnClk = function () {
        document.getElementById('hlpmsgwnd').className = 'hlptfxk';
        vm.button = false;
        vm.box = true;
        vm.sent = false;
    }
    vm.send = function () {
        if (vm.btnval && getSessionSrvc.p_mId()) {
            pcShowLoader("dvhlp");
            feedbackSrvc.hlpusSave(getSessionSrvc.p_mId(), vm.text, function (response, status) {
                if (response == true && status == 200) {
                    vm.button = false;
                    vm.box = false;
                    vm.sent = true;
                    document.getElementById('hlpmsgwnd').className = 'hlptfx';
                    $timeout(function () {
                        vm.sent = false;
                        vm.button = true;
                    }, 5000);
                    vm.clear();
                } else {
                    emptyhlpusImp("Oops!! something went wrong");
                }
                hideLoader();
            });
        }

    }

    vm.colpsClk = function () {
        vm.button = true;
        vm.box = false;
        vm.sent = false;
        document.getElementById('hlpmsgwnd').className = 'hlptfx';
        vm.clear();
    }

    vm.textCheck = function () {
        if (vm.text) {
            if (vm.text.length > 1000) {
                emptyhlpusImp("Must be < 1000 characters", "plhdrerr");
            }
        }
        else { emptyhlpusImp("Describe Your Issue", "plhdrerr"); }
    }

    vm.textFocus=function()
    {
        if(!vm.text)
           emptyhlpusImp("Describe Your Issue", "");
    }

    vm.textChnage = function () {

        if (!vm.text) {
            emptyhlpusImp("Describe Your Issue","");
        }
        else if (vm.text.length > 1000) {
            emptyhlpusImp("Must be < 1000 characters", "plhdrerr");
        } else {
            vm.btnval = true;
        }
    }

    function checkOffset() {
        try {
            if ($('#hlpmsgwnd').length > 0) {
                if ($('#hlpmsgwnd').offset().top + $('#hlpmsgwnd').height() >= $('#pcFtr').offset().top) {
                    $('#hlpmsgwnd').css('position', 'absolute');
                    $('#hlpmsgwnd').parent().css("margin-bottom", "40px");
                }
                if ($(document).scrollTop() + window.innerHeight < $('#pcFtr').offset().top) {
                    $('#hlpmsgwnd').css('position', 'fixed'); // restore when you scroll up        
                    $('#hlpmsgwnd').parent().css("margin-bottom", "0px");
                }
            }
        } catch (e) {
            //
        }
    }

    $(document).scroll(function () {
        checkOffset();
    });

}]);
