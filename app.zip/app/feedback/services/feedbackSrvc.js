﻿angular.module("app").service('feedbackSrvc', ['$http', function ($http) {
    this.hlpusSave = function (mId,desc, funCallBack) {
        var data = { "val": desc }
        var url = getApiDomainUrl() + "/api/dashboard/hlpusimprv/"+mId;
        PostServiceByURL($http, url, data, funCallBack);
    };
}]);