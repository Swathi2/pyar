﻿angular.module("app").controller('changeGenderCtrl', ['changeGenderSrvc', '$scope', '$state', '$location', function (changeGenderSrvc, $scope, $state, $location) {

    var vm = this;
    vm.showPage = false;

    vm.isSuccesfullyChanged = false;
    vm.isLinkTimeOut = false;
    vm.isRecurring = false;
    var reqId = $location.absUrl().split('?')[1];

    if (reqId) {
        showLoader();
        changeGenderSrvc.ApprovechangeGender(reqId, function (response, status) {
            if (response && status == 200) {
                vm.showPage = true;
                hideLoader();
                vm.genderReq = response;

                if (response.errType == "1") { $state.go('home'); }//invalid link     
                else if (response.status || response.errType == "3") { vm.isSuccesfullyChanged = true; }
                else if (response.errType == "7") { vm.isRecurring = true; }
                else if (response.errType == "2" || response.errType == "4" || response.errType == "5" || response.errType == "6" || response.errType == "8") { vm.isLinkTimeOut = true; }
                else if (response.errType == "15") { $("#ErrAlert").modal("show"); }
                else { $state.go('home'); }
            }
            else
                $state.go('home');
        });
    }

    $(document).on("click", "#errPopClose", function () {
        $("#ErrAlert").modal("hide");
        $state.go('home');
    });
}]);