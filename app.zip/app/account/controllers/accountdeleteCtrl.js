﻿angular.module("app").controller('accountdeleteCtrl', ['accountdeleteSrvc','$window', 'getSessionSrvc', 'abndnSrvc', '$location', '$timeout', function (accountdeleteSrvc, $window,getSessionSrvc, abndnSrvc, $location, $timeout) {
    var vm = this;
    var mId = getSessionSrvc.p_mId();
    var premMember = function () { return getSessionSrvc.p_sub() }; //1. Basic 2. Premium
    var trialMem = function () { return getSessionSrvc.p_subtm() };
    var urlLink = $location.absUrl().split('?')[1];
    vm.explanationPlaceHolder = "Any more comments you have for us will be greatly appreciated!";
    vm.dvAccntDel = vm.lnkExpOops = false;
    if ($window.localStorage.getItem('p_adul')) { $window.localStorage.removeItem('p_adul'); }

    if (premMember() == 2 && trialMem() == 3) vm.isPaidprm = true;

    if (urlLink) {        
        showLoader();
        accountdeleteSrvc.deleteAccountLinkCheck(mId, urlLink, function (response, status) {            
            if (status == 200) {
                if (response.status == 5 || response.status == "5") {
                    //$window.localStorage.setItem('p_adul', urlLink);
                    if (response.validLgn == false) {
                        if (mId) { abndnSrvc.rmvSsn(); }
                    }
                    else if (response.validLgn == true) {
                        vm.dvAccntDel = true;
                        vm.lnkExpOops = false;
                    }
                    hideLoader();
                }
                else {
                    hideLoader();
                    vm.dvAccntDel = false; //link expired
                    vm.lnkExpOops = true;
                }
            }
            else {
                hideLoader();                
            }
        });
    }
    else {
        $window.location.href = "/dashbaord.html";
    }


    vm.explanationChange = function () {
        if (vm.explanation && vm.explanation.length > 250) {
            vm.txtCls = "txtaraPhClr";
            vm.explanationPlaceHolder = "Please ensure that your explanation does not exceed 250 characters.";
            vm.explanation = null;
        }
        else {
            delete vm.txtCls;
            vm.explanationPlaceHolder = "Any more comments you have for us will be greatly appreciated!";
        }
    }

    vm.btnAdisable = function () {
        if (mId && vm.agree && vm.reasonModal) {
            if (vm.reasonModal == '4' && !vm.explanation) {
                vm.dsblCls = "adbtn"; return true;
            } else {
                vm.dsblCls = ""; return false;
            };
        } else {
            vm.dsblCls = "adbtn"; return true;
        };
        //if (mId && vm.agree && !vm.reasonModal  || vm.reasonModal == '4' && vm.explanation)) { vm.dsblCls = ""; return false; }
        //else { vm.dsblCls = "adbtn"; return true; }
    }

    vm.deleteAccntPerm = function () {        
        showLoader();
        var reasonText = "";
        if (vm.reasonModal == 1) reasonText = "Found my match on Pyar.com";
        else if (vm.reasonModal == 2) reasonText = "Found my match elsewhere";
        else if (vm.reasonModal == 3) reasonText = "Services were unsatisfactory";
        else if (vm.reasonModal == 4) reasonText = "Other (please explain if possible)";

        if (mId && urlLink && vm.reasonModal && vm.agree) {
            accountdeleteSrvc.deleteAccntFnl(mId, urlLink, reasonText, vm.explanation, function (response, status) {                
                if (status == 200 && response == true) {
                    $window.localStorage.setItem("acntDlt", true);
                    $timeout(function () { abndnSrvc.rmvSsn(); }, 100);
                }
                else {
                    $("#ApiErrMsg").text("Unable to process your request. Please try again later.");
                    $("#ErrAlert").modal("show"); hideLoader();
                }
            });
        }
        else {
            hideLoader();
        }
    }

}]);