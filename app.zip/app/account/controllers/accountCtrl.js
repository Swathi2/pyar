﻿angular.module("app").controller('accountCtrl', ['getSessionSrvc', 'accountSrvc', 'msgSrvc', 'abndnSrvc', 'countryIntlSrv', '$scope', '$window',  '$rootScope', '$filter', '$location', '$timeout', '$interval', '$anchorScroll',
    function (getSessionSrvc, accountSrvc, msgSrvc, abndnSrvc, countryIntlSrv, $scope, $window, $rootScope, $filter, $location, $timeout, $interval, $anchorScroll) {
        if ($location.absUrl().split('#')[1]) // when member is coming from email to change his/her Email Settings, scroll to that div.
            $timeout(function () { $anchorScroll(); }, 1000);
        tabMenu();
        //var mId = getSessionSrvc.p_mId();
      
        var vm = this;
        vm.mId = function () { return getSessionSrvc.p_mId(); }
        vm.frmfn = getSessionSrvc.p_fn(); 
        vm.frmgender = getSessionSrvc.p_gndr();
        vm.subsDate = getSessionSrvc.p_subex();
        vm.deleteAcnRsndEmlDv = false;
        //vm.memStrgClcn = getSessionSrvc.p_pgc();
        var premMember = getSessionSrvc.p_sub(); //1. Basic 2. Premium
        vm.unbind = false;
        vm.zones = getTimeZones();
        var emailSentOrNot = true;//avoid multiple mails sending
        function UrlTabOpens(stparms) {
       //  var stparms = $stateParams;
            if (stparms.tb == 'mship') { // to open Membership tab
                $("#tb2").tab("show");
                $("#tb1dv,#tb3dv").hide();
                $("#tb2dv").show();
            } else if (stparms.tb == 'privacy') {  // to open privacy tab
                $("#tb3").tab("show");
                $("#tb1dv,#tb2dv").hide();
                $("#tb3dv").show();
            } else {
                $("#tb1").tab("show");
                $("#tb2dv,#tb3dv").hide();
                $("#tb1dv").show();
            }
        }
        $scope.$watch(function () { return $location.search() }, function (params) {
            UrlTabOpens(params)
        });

        $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
            if ((vm.CurrentPassword) || (vm.password) || (vm.confirmPassword) || (vm.currentPasswordEml) || (vm.newEml) || (vm.CnfrmEml) || (vm.fName && vm.fName != vm.memNameU) || (vm.unbind && vm.unbind == true) || (vm.dateOfBirth == undefined || vm.dateOfBirth == null || vm.dateOfBirth == "")) {
                hideLoader();
                vm.toUrl = toState;
                $("#exitNavPopup").modal('show');
                $("#chatMsg").hide();//to hide chat box 
                window.history.pushState({}, '');
                event.preventDefault();
            }
        });

        vm.settingsTabClick = function ($event) {
            hideLoader();
            $location.search({ tb: 'account' });
        }
        vm.memberShipTabClick = function () {
            $location.search({ tb: 'mship' });
        }
        vm.privacyTabClick = function () {
            $location.search({ tb: 'privacy' });
            blckdMems();
        }

        function blckdMems() {  // to call getblocked members if privacy tab opened on page load
            if (!vm.isPrvcyOpned) {
                GetBlockedMembs(vm.pgNo, vm.pgSize, false);
                vm.isPrvcyOpned = true;
            };
        }
        vm.exitNavYes = function () {
            $window.location.href = vm.toUrl.url;
        }
        vm.exitNavNo = function () {
            hideLoader();
        }
        vm.loginType = getSessionSrvc.p_lt();
        if (vm.loginType == 1)
            vm.isPyrUsr = true;

        //vm.memStrgClcn="584d9eef";
        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BIND TEH USER DETAILS  STARTS  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/

        getProfileInfo(function (response) {
            //response = response.Result;
            vm.memPrflResponse = response;
            BindNotificationSettings();
            //General            
            vm.setTimeZone = response.timeZone;
            //vm.TimeZoneLst = response.TimeZoneLst;
            vm.TimeZoneLst = $filter("orderBy")(vm.zones, 'GMT');
            bindTimeZone(vm.TimeZoneLst, response.timeZone, function (timezoneResponse) {
                vm.timeZone = timezoneResponse;
            });
            vm.units = response.units;
            //Security
            vm.email = response.email;
            //Profile
            //vm.selGender = response.gender == true ? 1 : 0;
            vm.gender = response.gender ? "Male" : "Female";
            vm.selPrefGender = response.genderPref == true ? 1 : 0;
            vm.genderPref = response.genderPref ? "Male" : "Female";
            vm.cityId = response.cityId;
            vm.cityName = response.city;
            vm.dateOfBirth = $filter('date')(new Date(response.dob), 'MM/dd/yyyy');//setDOB(response.dob);
            vm.cntryId = response.countryId;

            $timeout(function () {
                countryIntlSrv.BindIntelligence();
                if (response.countryId != null && response.cityId != null)
                    countryIntlSrv.BindCity('txtAccCurrLocCity', 'dvAccCurrLoc', response.countryId, response.cityId);

            }, 100);


            //function for change name date geeting & add 90 days
            var CNameDaysDiff = function (date2) {
                CurDate = new Date();
                cNmDt = new Date(date2);
                cNmDt.setDate(cNmDt.getDate() + 90);
                return Math.floor((Date.UTC(cNmDt.getFullYear(), cNmDt.getMonth(), cNmDt.getDate()) - Date.UTC(CurDate.getFullYear(), CurDate.getMonth(), CurDate.getDate())) / (1000 * 60 * 60 * 24));
            }
            vm.fNameAltrDt = CNameDaysDiff(response.fNameAltrDt);
            vm.fNameAltrDt > 0 ? vm.ChngNmeCls = "acndsblnme" : delete vm.ChngNmeCls;
            vm.fNameAltrDt == 1 ? vm.dayTxt = "day" : vm.dayTxt = "days";

            //Privacy Profile
            vm.memName = captlFname(response.firstName);
            vm.memNameU = captlFname(response.firstName);
            //vm.countriesDdl = response.CountriesLst;
            if (premMember == 1) {
                vm.InvisibleBrowsing = false;
            }
            else {
                vm.InvisibleBrowsing = vm.invBrsng = response.InvisibleBrowsing == null ? false : response.InvisibleBrowsing;
            }
            vm.tempProfileHide = response.tempProfileHide;
            vm.profileImageSrc = updateImgVersion(setprofileImage(vm.memPrflResponse.profilePic, vm.memPrflResponse.gender));
            if ($("a#tb3").closest("li").hasClass("active")) blckdMems(); // check if privacy tab has active class on load
            vm.dvpgVisble = true;
            hideLoader();
        });

        function setprofileImage(pic, gndr) {
            if (pic == null || pic == "")
                if (gndr == true) return gndr = "https://pccdn.pyar.com/pcimgs/profilePicM.jpg";
                else return gndr = "https://pccdn.pyar.com/pcimgs/profilePicM.jpg";
            else
                return gndr = "https://pccdn.pyar.com" + pic.replace("/tnb/", "/tns/");
        }
        function BindNotificationSettings() {
            if (vm.memPrflResponse != null) {
                if (vm.memPrflResponse.NotificationSettings) {
                    vm.EmlRecMatchs = vm.memPrflResponse.NotificationSettings.rmEml;
                    vm.EmlViewsMe = vm.memPrflResponse.NotificationSettings.pvEml;
                    vm.EmlFlirtsMe = vm.memPrflResponse.NotificationSettings.flirtEml;
                    //vm.EmlMsgMe = vm.memPrflResponse.NotificationSettings.msgEml;
                    vm.EmlPyrPrmtn = vm.memPrflResponse.NotificationSettings.promoEml;
                    vm.EmlPyrTps = vm.memPrflResponse.NotificationSettings.tipEml;
                }
            }
        }

        function getProfileInfo(callBackFun) {
            if ($("#dvAcnt").attr("data-basiData") == "Y") {
                showLoader();
                accountSrvc.profileInfo(vm.mId(), function (response, status) {
                    callBackFun(response);
                    $("#dvAcnt").attr("data-basiData", "N");
                });
            }
        }

        //function setDOB(dob) {
        //    if (dob != null || dob != "") {
        //        var dateTime = new Date(dob);
        //        var date = parseInt(dateTime.getUTCDate());
        //        var month = parseInt((dateTime.getUTCMonth() + 1));
        //        if (date <= 9)
        //            date = "0" + date;
        //        if (month <= 9)
        //            month = "0" + month;
        //        return month + "/" + date + "/" + dateTime.getUTCFullYear();
        //    } else
        //        return "";
        //}

        vm.dobChange = function (event) {
            vm.bodError = false;
            vm.DOBPlaceHolder = "MM / DD / YYYY";
            if (vm.dateOfBirth) {
                var numChars = vm.dateOfBirth.length;
                var thisVal = vm.dateOfBirth;
                if (event.keyCode != 8) {
                    if (numChars === 2) {
                        thisVal += '/';
                        vm.dateOfBirth = thisVal;
                    }
                    else if (numChars === 5) {
                        thisVal += '/';
                        vm.dateOfBirth = thisVal;
                    }
                }
            }
        };

        vm.dobFocus = function () {
            vm.DOBPlaceHolder = "MM / DD / YYYY";
            vm.bodError = false;
        }

        //function getCntryName(ddlCtrl, ctrId, calBackFun) {
        //    angular.forEach(ddlCtrl, function (value, key) {
        //        if (value.countryId == ctrId)
        //            calBackFun(value.countryName);
        //    });
        //}

        function bindTimeZone(timeZoneLst, timeZone, calBackFun) {
            angular.forEach(timeZoneLst, function (value, key) {
                if (value.val == timeZone) {
                    calBackFun(value.txt);
                }
            });
        }
        vm.savePrivacyProfile = function () {
            $("#tempHidePopup").modal("show");
        }
        vm.tempHideYes = function () {
            vm.tempProfileHide = true;
            accountSrvc.saveProfileHide(vm.mId(), vm.tempProfileHide, function (response, status) {
                if (status == 200 && response == true) {
                    $("#tempHidePopup").modal("hide");
                    $window.localStorage.setItem("tmpHd", true);
                    $timeout(function () {
                        abndnSrvc.rmvSsn();
                    }, 300);

                }
            });
        }

        //vm.CnclPrivacyProfile = function () {
        //    vm.InvisibleBrowsing = vm.invBrsng = vm.memPrflResponse.InvisibleBrowsing;
        //    vm.tempProfileHide = vm.memPrflResponse.tempProfileHide;
        //}
        vm.FnInvisibleBrowsing = function () {
            accountSrvc.saveInvisibleBrowsing(vm.mId(), vm.invBrsng, function (response, status) {
                if (status == 200 && response == true) {
                    getSessionSrvc.u_ssnd("invisibleBrowsing", vm.invBrsng);
                } else
                    alert("fail");
            });
        }

        //vm.FntempProfileHide = function () {
        //    vm.tempProfileHide = !vm.tempProfileHide;
        //}
        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BIND TEH USER DETAILS END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/


        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  CHANGE PASSWORD   STARTS  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/
        vm.dvPwd = true;
        vm.dvPwdAE = false;
        //var brdrBlueCls = 'pfbgbrdr';
        vm.CurrentPwdPlaceholder = 'Current Password';
        vm.PwdPlaceholder = 'New Password';
        vm.CnfPwdPlaceholder = 'Confirm Password';
        //vm.bgWht = "bgWht";

        function rsntSecSctn() {
            vm.currentPasswordEml = vm.newEml = vm.CnfrmEml = vm.CurrentPassword = vm.password = vm.confirmPassword = "";
            vm.curpwdKpclsEml = vm.NewEmlcls = vm.CnfNewEmlcls = vm.curpwdKpcls = vm.pwdKpcls = vm.cnfPwdKpcls = "bgWht";
            vm.CurPwdPlaceholderEml = "Current Password";
            vm.EmailPlaceholder = "New Email";
            vm.CnfrmEmailPlaceholder = "Confirm Email";
            vm.CurrentPwdPlaceholder = "Current Password";
            vm.PwdPlaceholder = "New Password";
            vm.CnfPwdPlaceholder = "Confirm Password";
        }


        vm.dvChngEml = true;
        vm.myChngPwdAE = function () {
            vm.dvPwd = false;
            vm.dvPwdAE = true;
            vm.dvChngEml = true;
            vm.dvEmlAE = false;
            vm.resetCngEmlModels();
            rsntSecSctn();
        }

        vm.CnclChngPwd = function () {
            vm.resetCngPwdModels();
            vm.dvPwd = true;
            vm.dvPwdAE = false;
        }


        //Change Password button disabled function
        vm.BtnChngPwdPopUp = function () {
            if (vm.CurrentPassword && vm.password && vm.confirmPassword) {
                if (vm.CurrentPassword.length >= 8  && vm.CurrentPassword != vm.password && vm.password == vm.confirmPassword) {
                    vm.chngPwdPopUpCls = "btn-bg regBtn"; return false;
                }
                else { vm.chngPwdPopUpCls = "btn-bg"; return true; }
            }
            else { vm.chngPwdPopUpCls = "btn-bg"; return true; }
        }


        function CrntPwdDtEmty(phTxt) {
            vm.CurrentPassword = null;
            vm.curpwdKpcls = "eror";
            vm.CurrentPwdPlaceholder = phTxt;
        }

        //current password change event 
        vm.currentPwdChnage = function () {
            vm.curpwdKpcls = "bgWht";
            if (vm.CurrentPassword && vm.CurrentPassword.length > 30) {
                $("#txtCurrPwd").blur();
            }
            else if (!vm.CurrentPassword) {
                vm.CurrentpwdFocus();
            }
        }

        //current password Blur event 
        vm.currentPwdBlur = function () {
            if (vm.CurrentPassword && vm.CurrentPassword.length > 30) { CrntPwdDtEmty('Must be < 30 characters'); }
        }

        //Current Password Focus Event
        vm.CurrentpwdFocus = function () {
            vm.curpwdKpcls = "bgWht";
            vm.CurrentPwdPlaceholder = "Current Password";
        }


        //new Password chnage event
        vm.passwordChnage = function () {
            if (vm.password && vm.password.length > 30)
                $("#txtPwd").blur();
        }
        //new Password blur event
        vm.pwdCheck = function () { pwdchkBlur(vm); }
        //New Password Focus Event
        vm.pwdFocus = function () { vm.pwdGuideLineMsg = true; pwdFcs(vm); }

        //Confirm password change event 
        vm.confirmPwdChnage = function () {
            if (vm.confirmPassword && vm.confirmPassword.length > 30)
                $("#txtCnfrmPwd").blur();
        }
        //Confirm password blur event 
        vm.cnfPwdCheck = function () { CnfPwdchkBlur(vm); }
        //Confirm password Focus event 
        vm.cnfPwdFocus = function () { CnfPwdFcs(vm); }

        vm.chngPwdPopUp = function () {
            vm.pType = "Password";
            $("#chngPwdPopup").modal("show");
        }
        vm.chngPwdEml = function () {
            $("#chngPwdPopup").modal("hide");
            if (vm.pType == "Password") {
                if ($scope.frmChngPwd.$valid) {
                    pcShowLoader("dvSecurity");
                    accountSrvc.changePwd(vm.mId(), vm.CurrentPassword, vm.confirmPassword, function (response, status) {
                        if (status == 200) {
                            if (response == 2) { //Current password missmatch
                                vm.CurrentPassword = null;
                                vm.CurrentPwdPlaceholder = "Incorrect Password – please try again";
                                vm.curpwdKpcls = "eror";
                                vm.pwdErrMsg = false;
                            }
                            else if (response == false) {
                                vm.pwdErrMsg = true;
                            }
                            else if (response == true) {
                                abndnSrvc.rmvSsn(function () {
                                    $window.location.href = '/signinpwdreset.html';
                                });

                            }
                        }
                        hideLoader();
                    });
                }
            } else if (vm.pType == "Email") {
                if ($scope.frmChngPwd.$valid) {
                    pcShowLoader("dvSecurity");
                    accountSrvc.changeEml(vm.mId(), vm.currentPasswordEml, vm.newEml, function (response, status) {
                        if (status == 200) {
                            //alert(response);
                            if (response == "2") {
                                vm.currentPasswordEml = null;
                                vm.CurPwdPlaceholderEml = 'Incorrect Password - please try again';
                                vm.curpwdKpclsEml = "err";
                            }
                            else if (response == "3") {
                                vm.newEml = null;
                                vm.EmailPlaceholder = 'Previous email can’t be used';
                                vm.NewEmlcls = "err";
                            }
                            else if (response === "1") {
                                vm.newEml = null;
                                vm.CnfrmEml = null;
                                vm.EmailPlaceholder = 'This is already a registered email';
                                vm.NewEmlcls = "err";
                            }
                            else if (response === true) {
                                //alert("email changed successfully");
                                $timeout(function () { abndnSrvc.rmvSsn(); }, 100);
                            }
                        }
                        hideLoader();
                    });
                }
            }
        }

        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  CHANGE PASSWORD  END  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/


        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  CHANGE NAME  STARTS  )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/
        vm.dvChngNme = true;
        vm.MemNamePlaceholder = "First Name";

        vm.myChngNmeAE = function () {
            if (vm.fNameAltrDt <= 0) {
                vm.dvChngNme = false;
                vm.dvNamAE = true;
                vm.memName = "Change Name";
                vm.fName = vm.memNameU;
                //vm.chngNmeHvr = false;
            }
            //else {
            //    vm.chngNmeHvr = true;
            //}
        }

        $(document).ready(function () {
            $("#ancChagneName,.acnchgnmhvrdv").hover(function () {
                if (vm.fNameAltrDt > 0)
                    $(".acnchgnmhvrdv").show();
            }, function () {
                $(".acnchgnmhvrdv").hide();
            });
        });

        vm.fNameDsbl = function () {
            if (vm.fName && vm.fName.length != 1) {
                //if (vm.memNameU.toUpperCase() == vm.fName.toUpperCase()) { delete vm.chngNmedsblCls; return true; }
                if (vm.memNameU == vm.fName) { delete vm.chngNmedsblCls; return true; }
                else { vm.chngNmedsblCls = "regBtn"; return false; }
            }
            else { delete vm.chngNmedsblCls; return true; }
        }

        vm.CnclChngNme = function () { vm.dvChngNme = true; vm.dvNamAE = false; vm.memName = vm.memNameU; vm.nameKpcls = "bgWht"; }
        vm.chngNmePopUp = function () { $("#chngNamePop").modal("show"); }
        vm.captlFname = function (name) { return (captlFname(name)) };

        vm.chngfName = function () {
            vm.fName = captlFname(vm.fName);
            accountSrvc.PrfChangeName(vm.mId(), vm.fName, function (response, status) {
                if (status == 200 && response == true) {
                    vm.CnclChngNme();
                    $("#chngNamePop").modal("hide");
                    //Updating Member Name
                    vm.fNameAltrDt = 90;
                    vm.ChngNmeCls = "acndsblnme";
                    vm.memNameU = vm.memName = vm.fName;
                    getSessionSrvc.u_ssnd("firstName", vm.fName);
                }
            });
        }

        function nameEmpty(phTxt,txtClr) {
            vm.fName = null;
            vm.MemNamePlaceholder = phTxt;
            vm.nameKpcls = txtClr;
        }

        //first Name blur event
        vm.fNameCheck = function () { if ((vm.fName && vm.fName.length == 1) || !vm.fName) { nameEmpty("Please enter a valid first name", "eror"); } }

        //firstName chanage evnt
        vm.fnameChnage = function () {
            //vm.nameKpcls = "bgWht acchnme";
            if (vm.fName) {
                if (vm.fName.length > 30) 
                    nameEmpty("Must be < 30 characters", "eror");
                else
                    vm.nameKpcls = "bgWht";
            }
            else if (!vm.fName) { nameEmpty("First Name", "bgWht"); }
        }

        vm.fnameFocus=function() {
            if(!vm.fName)
                nameEmpty("First Name", "bgWht");
        }

        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  CHANGE NAME  END  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/



        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  CHANGE EMAIL STARTS  )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/

        vm.resetCngEmlModels = function () {
            vm.currentPasswordEml = null;
            vm.newEml = null;
            vm.CnfrmEml = null;
        }
        vm.resetCngPwdModels = function () {
            vm.CurrentPassword = null;
            vm.password = null;
            vm.confirmPassword = null;
        }
        vm.dvEmlAE = false;
        vm.myChngEmlAE = function () {
            vm.resetCngPwdModels();
            vm.dvChngEml = false;
            vm.dvPwd = true;
            vm.dvPwdAE = false;
            vm.dvEmlAE = true;
            rsntSecSctn();
        }
        vm.CnclChngEml = function () {
            vm.resetCngEmlModels();
            vm.dvEmlAE = false;
            vm.dvChngEml = true;
        }

        vm.CurPwdPlaceholderEml = 'Current Password';
        vm.EmailPlaceholder = 'New Email';
        vm.CnfrmEmailPlaceholder = 'Confirm Email';

        //Change Email button disabled function
        vm.EmlFrmValid = function () {
            if (vm.currentPasswordEml && vm.newEml && vm.CnfrmEml) {
                if (vm.currentPasswordEml.length >= 8 && $rootScope.emailRegex.test(vm.newEml) && vm.newEml != vm.email && $rootScope.emailRegex.test(vm.CnfrmEml) && vm.newEml == vm.CnfrmEml) {
                    vm.btnChngEmailCls = "btn-bg regBtn"; return false;
                }
                else { vm.btnChngEmailCls = "btn-bg"; return true; }
            }
            else { vm.btnChngEmailCls = "btn-bg"; return true; }
        }

        function CrntpwdDtEmty(phTxt) {
            vm.currentPasswordEml = null;
            vm.curpwdKpclsEml = "eror";
            vm.CurPwdPlaceholderEml = phTxt;
        }

        //Current Password Change event
        vm.CrntPasswordChnage = function () {
            vm.curpwdKpclsEml = "bgWht";
            if (vm.currentPasswordEml && vm.currentPasswordEml.length > 30) {
                $("#txtCrntPwdEml").blur();
            }
            else if (!vm.currentPasswordEml) {
                vm.CrntPasswordFocus();
            }
        }

        //Current Password blur event
        vm.CrntPasswordBlur = function () {
            if (vm.currentPasswordEml && vm.currentPasswordEml.length > 30) { CrntpwdDtEmty('Must be < 30 characters'); }
        }

        //current Password Focus Event
        vm.CrntPasswordFocus = function () {
            vm.curpwdKpclsEml = "bgWht";
            vm.CurPwdPlaceholderEml = "Current Password";
        }

        function emailDtEmty(phTxt) {
            vm.newEml = null;
            vm.NewEmlcls = "eror";
            vm.EmailPlaceholder = phTxt;
        }

        //New Email blur event
        vm.emailCheck = function () {
            var isMatcheRex = $rootScope.emailRegex.test(vm.newEml);
            if (vm.newEml && vm.newEml.length > 75) { emailDtEmty('Must be < 75 characters'); vm.CnfrmemailFocus(); }
            else if (!isMatcheRex) { emailDtEmty('Please enter a valid email address'); vm.CnfrmemailFocus(); }
            else if (vm.newEml == vm.email) { emailDtEmty('Email should not match current'); vm.CnfrmemailFocus(); }
            else if (vm.newEml && vm.CnfrmEml && vm.newEml != vm.CnfrmEml) { CnfNewEmailDtEmty('Email does not match'); }
            else {
                accountSrvc.chkEmlExist(vm.newEml, function (response, status) {
                    if (status == 200) {
                        if (response == true) {
                            emailDtEmty('This is already a registered email'); //Email Exist
                        }
                    }
                });
            }
        }
        //New Email Change event
        vm.NewEmlChnage = function () {
            vm.NewEmlcls = 'bgWht';
            if (vm.newEml && vm.newEml.length > 75) {
                $("#txtnewEml").blur();
            }
            else if (!vm.newEml) {
                vm.NewEmlFocus();
            }
        }

        //New Email Focus Event
        vm.NewEmlFocus = function () {
            vm.NewEmlcls = "bgWht";
            vm.EmailPlaceholder = "New Email";
        }

        function CnfNewEmailDtEmty(phTxt) {
            vm.CnfrmEml = null;
            vm.CnfNewEmlcls = "eror";
            vm.CnfrmEmailPlaceholder = phTxt;
        }

        //confirm Email blur event
        vm.CnfrmemailCheck = function () {
            if (vm.CnfrmEml && vm.CnfrmEml.length > 75) { CnfNewEmailDtEmty('Must be < 75 characters'); }
            else if ((vm.newEml && vm.CnfrmEml && vm.newEml != vm.CnfrmEml) || (vm.newEml && !vm.CnfrmEml)) { CnfNewEmailDtEmty('Email does not match'); }
        }
        //confirm Email Change event
        vm.CnfNewEmlChnage = function () {
            vm.CnfNewEmlcls = "bgWht";
            if (vm.CnfrmEml && vm.CnfrmEml.length > 75) { $("#txtCnfrmEml").blur(); }
            else if (!vm.CnfrmEml) { vm.CnfrmemailFocus(); }
        }

        //confirm Email Focus Event
        vm.CnfrmemailFocus = function () {
            vm.CnfNewEmlcls = "bgWht";
            vm.CnfrmEmailPlaceholder = "Confirm Email";
        }

        vm.chngEmail = function () {
            vm.pType = "Email";
            $("#chngPwdPopup").modal("show");
        }


        /*******************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( CHANGE EMAIL END  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/      

        vm.pgNo = 1;
        vm.pgSize = 100;
        vm.blockedMems = [];
        vm.localPgSize = 20;
        vm.limitToMemTileCnt = 20;
        vm.contentExists = true;
        vm.ShowViewMore = false;
        vm.isPrvcyOpned = false;

        function GetBlockedMembs(pageNo, pgSize, fromAutoScroll) {
            pcShowLoader("blkMems");
            accountSrvc.GetBlockedMembes(vm.mId(), pageNo, pgSize, function (response, status) {
                if (status == 200 && response.length > 0) {
                    if (response.length < vm.localPgSize)
                        vm.ShowViewMore = false;
                    else {
                        if (vm.pgNo == 1) {
                            $timeout(function () {
                                if (vm.blockedMems.length > 0) {
                                    vm.ShowViewMore = true;
                                }
                            }, 500)
                        }
                        else
                            vm.ShowViewMore = true;
                    }

                    if (response.length < vm.pgSize)
                        vm.contentExists = false;
                    else
                        vm.contentExists = true;

                    if (fromAutoScroll) {
                        angular.forEach(response, function (data) {
                            vm.blockedMems.push(data);
                        });
                    } else
                        vm.blockedMems = response;
                } else if (status == 204) {
                    vm.contentExists = false;
                    if (vm.blockedMems.length == 0)
                        vm.dvNoResult = true;
                }
                hideLoader();
            });
        }

        //$scope.scrollLoad = function () {
        //    if (vm.blockedMems.length > 0 && ($(window).scrollTop() >= (($(document).height() - $("#pcFtr").outerHeight()) - $(window).height()))) {
        //        vm.limitToMemTileCnt += vm.localPgSize;
        //        if (vm.contentExists && (vm.blockedMems.length == (vm.pgNo * vm.pgSize))) {
        //            if ((vm.limitToMemTileCnt + (2 * vm.localPgSize) == (vm.blockedMems.length))) {
        //                vm.pgNo++;
        //                GetBlockedMembs(vm.pgNo, vm.pgSize, true);
        //            }
        //        }
        //    }
        //}

        vm.viewMore = function () {
            if (vm.contentExists && (vm.blockedMems.length == (vm.pgNo  * vm.pgSize))) {
                if ((vm.limitToMemTileCnt == (vm.blockedMems.length))) {
                    vm.pgNo++;
                    GetBlockedMembs(vm.pgNo, vm.pgSize, true);
                }
            }
            vm.limitToMemTileCnt += vm.localPgSize;
            if (vm.blockedMems.length < vm.limitToMemTileCnt)
                vm.ShowViewMore = false;
        };

        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BLOLCKED/UMBLOCKED MEMBER  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        /*******************************************************************************************************************************************************************/

        vm.unblockMemPop = function (memBlockedId, FirstName, storageCollection, ProfilePic, Gender) {
            vm.memBlkId = memBlockedId;
            vm.blkMemName = FirstName;
            vm.blkMemProfilePic = vm.GetProfilePic(ProfilePic, Gender);
            vm.blckMemgndr = Gender
            $("#ublck").modal('show');
        }
        vm.unBlkMember = function () {
            $("#ublck").modal('hide');
            accountSrvc.UnBlockMember(vm.mId(), vm.memBlkId, function (response, status) {
                if (status == 200 && response == true) {
                    msgSrvc.sendMbrBlockNtfn(vm.mId(), vm.frmfn, vm.frmgender, vm.memBlkId, false);  // calling sndblck notifctn api when a user is unblocked 
                    $scope.$emit("selfblck", vm.memBlkId, vm.blkMemName, vm.blckMemgndr, false);// listner to hide the block message if chatbox opens
                    for (var i = 0; i < vm.blockedMems.length; i++) {
                        if (vm.blockedMems[i].memId == vm.memBlkId)
                            vm.blockedMems.splice(i, 1);
                    }
                } else
                    alert("failed");
            });
        }
        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BLOLCKED/UMBLOCKED MEMBER  END  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        /*******************************************************************************************************************************************************************/

        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SERVICE CALLING MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        /*******************************************************************************************************************************************************************/
        vm.TimeZoneLstFunc = function (val) {
            vm.setTimeZone = val;
            if (vm.mId() != null && vm.memPrflResponse.timeZone != vm.setTimeZone) {
                accountSrvc.saveTimezone(vm.mId(), vm.setTimeZone, function (response, status) {
                    if (status == 200 && response == true) {
                        vm.memPrflResponse.timeZone = vm.setTimeZone;
                        getSessionSrvc.u_ssnd("timeZone", vm.setTimeZone);
                    }
                    else {
                        alert("failed");
                    }
                });
            }
        }
        vm.unitsSave = function () {
            if (vm.mId() != null && vm.memPrflResponse.units != vm.units) {
                accountSrvc.saveUnits(vm.mId(), vm.units, function (response, status) {
                    if (status == 200 && response == true) {
                        vm.memPrflResponse.units = vm.units;
                        getSessionSrvc.u_ssnd("units", vm.units);
                    }
                    else {
                        alert("failed");
                    }
                });
            }
        }
        vm.DOBSave = function () {
            if (vm.ValidateDob()) {
                if (vm.mId() != null && vm.dateOfBirth && vm.memPrflResponse.dob != vm.dateOfBirth && vm.dateOfBirth.length > 9) {
                    accountSrvc.saveDOB(vm.mId(), vm.dateOfBirth, function (response, status) {
                        if (status == 200 && response == true) {
                            vm.memPrflResponse.dateOfBirth = new Date(vm.dateOfBirth);
                        }
                        else {
                            alert("failed");
                        }
                    });
                }
            }
        }
        //vm.setGender = function (gender) {
        //    vm.selGender = gender;
        //    if (vm.mId() != null && vm.memPrflResponse.gender != vm.selGender) {
        //        accountSrvc.saveGender(vm.mId(), vm.selGender, function (response, status) {
        //            if (status == 200 && response == true) {
        //                getSessionSrvc.u_ssnd("gender", vm.selGender); //updating gender in login cookie
        //                vm.memPrflResponse.gender = vm.selGender;
        //                vm.profileImageSrc = updateImgVersion(vm.profileImageSrc);
        //                $scope.$emit("refreshHdrPP", vm.profileImageSrc);
        //            }
        //            else {
        //                alert("failed");
        //            }
        //        });
        //    }
        //}
        vm.setPrefGender = function (genderPref) {
            vm.selPrefGender = genderPref;
            if (vm.mId() != null && vm.memPrflResponse.genderPref != vm.selPrefGender) {
                accountSrvc.saveGenderPref(vm.mId(), vm.selPrefGender, function (response, status) {
                    if (status == 200 && response == true) {
                        getSessionSrvc.u_ssnd("genderPref", vm.selPrefGender); //updating genderPref in login cookie
                        vm.memPrflResponse.genderPref = vm.selPrefGender;
                    }
                    else {
                        alert("failed");
                    }
                });
            }
        }
        //vm.countryIdFunc = function (cntryId) {
        //    vm.cntryId = cntryId;
        //}

        vm.DOBPlaceHolder = "MM / DD / YYYY";
        vm.bodError = false;
        vm.ValidateDob = function () {
            var flag = true;
            vm.bodError = false;
            years = Math.floor(moment(new Date()).diff(moment(vm.dateOfBirth, "MM/DD/YYYY"), 'years', true));
            //now = new Date()
            //born = new Date(vm.dateOfBirth);
            //years = Math.floor((now.getTime() - born.getTime()) / (365 * 24 * 60 * 60 * 1000));
          
            if (years < 0 || isNaN(years)) {
                vm.bodError = true;
                vm.DOBPlaceHolder = "Please enter a valid date";
                vm.dateOfBirth = null;
            }

            else if (years < 18) {
                flag = false;
                vm.bodError = true;
                vm.dateOfBirth = null;
                vm.DOBPlaceHolder = "You must be at least 18 to register";
            }
            else if (years > 99) {
                flag = false;
                vm.bodError = true;
                vm.DOBPlaceHolder = "Are you really " + years + " years old?";
                vm.dateOfBirth = null;
            }
            return flag;
        }


        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SERVICE CALLING MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        /*******************************************************************************************************************************************************************/

        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  DELETE ACCOUNT MODULE START ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        /*******************************************************************************************************************************************************************/

        vm.DeleteAccount = function () {
            if (emailSentOrNot == true) {
                emailSentOrNot = false
                showLoader();
                accountSrvc.deleteAccountSendLink(vm.mId(), function (response, status) {
                    emailSentOrNot = true;
                    if (status == 200 && response == true) {
                        $("#DeleteAccntPop").modal("hide");
                        $timeout(function () {
                            startInterval(vm, $interval);
                            vm.dvpgVisble = false;
                            vm.deleteAcnRsndEmlDv = true;
                            hideLoader();
                        }, 500);
                    }
                    else {
                        $("#ErrAlert").modal("show"); hideLoader();
                    }
                });
            }
        }

        vm.ResendAcntDelLink = function () {
            if (emailSentOrNot == true) {
                emailSentOrNot = false;
                showLoader();
                accountSrvc.deleteAccountSendLink(vm.mId(), function (response, status) {
                    emailSentOrNot = true;
                    if (status == 200 && response == true) {
                        startInterval(vm, $interval);
                        hideLoader();
                    }
                    else {
                        hideLoader();
                        $("#ErrAlert").modal("show"); hideLoader();
                    }
                });
            }
        }
        

        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  DELETE ACCOUNT MODULE END  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        /*******************************************************************************************************************************************************************/

        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  NOTIFICATION SETTING MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        /*******************************************************************************************************************************************************************/
        function startNtfLdrs(Id) { $("#" + Id).attr('style', "background-image:url('https://pccdn.pyar.com/pcimgs/acnLdr.svg'); cursor:default;"); }
        function ntfLdrs(Id, chkModal) {
            if (chkModal) { $("#" + Id).attr('style', "background-image:url('https://pccdn.pyar.com/pcimgs/cbg.png')"); }
            else { $("#" + Id).attr('style', "background-image:url('https://pccdn.pyar.com/pcimgs/cb.png')"); }
        }

        vm.chkEmlRecMatchs = function () {
            if (vm.mId() != null && vm.EmlRecMatchs != null) {
                startNtfLdrs("rmLdr");
                accountSrvc.saveSettingsEmlrecmatch(vm.mId(), vm.EmlRecMatchs, function (response, status) {
                    if (status == 200 && response == true) {
                    }
                    else {
                        alert("failed");
                    }
                    ntfLdrs("rmLdr", vm.EmlRecMatchs)
                });
            }
        }
        vm.chkEmlViewsMe = function () {
            if (vm.mId() != null && vm.EmlViewsMe != null) {
                startNtfLdrs("smvLdr");
                accountSrvc.saveSettingsEmlviewme(vm.mId(), vm.EmlViewsMe, function (response, status) {
                    if (status == 200 && response == true) {
                    }
                    else {
                        alert("failed");
                    }
                    ntfLdrs("smvLdr", vm.EmlViewsMe);
                });
            }
        }
        vm.chkEmlFlirtsMe = function () {
            if (vm.mId() != null && vm.EmlFlirtsMe != null) {
                startNtfLdrs("smfLdr");
                accountSrvc.saveSettingsEmlflirtme(vm.mId(), vm.EmlFlirtsMe, function (response, status) {
                    if (status == 200 && response == true) {
                    }
                    else {
                        alert("failed");
                    }
                    ntfLdrs("smfLdr", vm.EmlFlirtsMe);
                });
            }
        }
        //vm.chkEmlMsgMe = function () {
        //    if (vm.mId() != null && vm.EmlMsgMe != null) {
        //        startNtfLdrs("smmLdr");
        //        accountSrvc.saveSettingsEmlmsgme(vm.mId(), vm.EmlMsgMe, function (response, status) {
        //            if (status == 200 && response == true) {
        //            }
        //            else {
        //                alert("failed");
        //            }
        //            ntfLdrs("smmLdr", vm.EmlMsgMe);
        //        });
        //    }
        //}
        vm.chkEmlPyrPrmtn = function () {
            if (vm.mId() != null && vm.EmlPyrPrmtn != null) {
                startNtfLdrs("ppromLdr");
                accountSrvc.saveSettingsEmlpyrprmtn(vm.mId(), vm.EmlPyrPrmtn, function (response, status) {
                    if (status == 200 && response == true) {
                    }
                    else {
                        alert("failed");
                    }
                    ntfLdrs("ppromLdr", vm.EmlPyrPrmtn);
                });
            }
        }
        vm.chkEmlPyrTps = function () {
            if (vm.mId() != null && vm.EmlPyrTps != null) {
                startNtfLdrs("ptipsLdr");
                accountSrvc.saveSettingsEmlpyrtips(vm.mId(), vm.EmlPyrTps, function (response, status) {
                    if (status == 200 && response == true) {
                    }
                    else {
                        alert("failed");
                    }
                    ntfLdrs("ptipsLdr", vm.EmlPyrTps);
                });
            }
        }
        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  NOTIFICATION SETTING MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        /*******************************************************************************************************************************************************************/

        //Basic and Premium Members differentiation
        vm.prfSubPop = function () {
            $("#prfSubPop").modal("show");
        }
        if (premMember == 1) {
            vm.txtblr = "txtblr";
            vm.eyeImg = "https://pccdn.pyar.com/pcimgs/vwDisabled.png";
            vm.rbtVsbl = false;
            //vm.isPremiumUser = false;
        }
        else if (premMember == 2) {
            delete vm.txtblr;
            vm.eyeImg = "https://pccdn.pyar.com/pcimgs/vwAct.png";
            vm.rbtVsbl = true;
            //vm.isPremiumUser = true;
        }
        //Basic and Premium Members differentiation End
        vm.getGender = function (val) {
            if (val == true) return "https://pccdn.pyar.com/pcimgs/actions/leicnM.svg"; else return "https://pccdn.pyar.com/pcimgs/actions/leicnF.svg";
        }
        vm.cntryDsply = function (city, state, country) {
            if (getSessionSrvc.p_cntry() == country) { return city + ", " + state; } else { return city + ", " + state + ", " + country; }
        }

        vm.SaveLocation = function () {
            if (vm.mId() != null) {
                accountSrvc.saveLocation(vm.mId(), vm.cntryId, vm.cityId, function (response, status) {
                    if (status == 200 && response == true) {
                        vm.memPrflResponse.countryId = vm.cntryId;
                        vm.memPrflResponse.cityId = vm.cityId;
                        vm.memPrflResponse.city = vm.cityName;
                        vm.unbind = false;

                        var cntryName = "";
                        for (var i = 0; i < vm.countries.length; i++) {
                            if (vm.countries[i].countryId == vm.cntryId) {
                                cntryName = vm.countries[i].countryName;
                                break;
                            }
                        }
                        //updating member cookie
                        getSessionSrvc.u_ssnd("country", cntryName);
                        getSessionSrvc.u_ssnd("countryId", vm.cntryId);
                    }
                    else {
                        alert("failed");
                    }
                });
            }
        }

        vm.calculateAge = function (val) {
            return calculateAge(val);
        }
        vm.GetProfilePic = function (profilepic, gender) {

            if (profilepic == null || profilepic == "" || profilepic == undefined) {
                if (gender == true) return "https://pccdn.pyar.com/pcmbr/defaults/profilemtnb.jpg";
                else if (gender == false) return "https://pccdn.pyar.com/pcmbr/defaults/profileftnb.jpg";
            }
            else return "https://pccdn.pyar.com" + profilepic;
        }

        //city intelligence module   
        $scope.$on("countryBind", function (e, txtId, countryId, data) {
            console.log("bind : " + txtId + "  --  " + countryId + "  --  " + JSON.stringify(data));
            vm.cntryId = data.countryId;
            vm.cityId = data.cityId;
            vm.cityName = data.cityName;
            vm.unbind = false;
            vm.SaveLocation();
        });

        $scope.$on("countryUnBind", function (e, txtId, countryId) {
            console.log("unbind : " + txtId + "  --  " + countryId);
            vm.unbind = true;
        });

        $rootScope.$on("bindCountry", function (e, countries) {
            vm.countries = countries;
        });

        $rootScope.$on('cancelledPlan', function (data) {
            vm.isCancelledPlan = true;
        });

        vm.setCountry = function (txtId, dvId, countryId) {
            //$("#txtAccCurrLocCity").prop('disabled', false);
            countryIntlSrv.SetCountry(txtId, dvId, countryId);
        }
        countryIntlSrv.initSrvc();
        //city intelligence module
    }]);