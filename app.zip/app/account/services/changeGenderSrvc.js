﻿angular.module("app").service('changeGenderSrvc', ['$http', function ($http) {
    this.ApprovechangeGender = function (reqId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/cg/" + reqId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
}]);