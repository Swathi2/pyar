﻿angular.module("app").service('accountSrvc', ['$http', function ($http) {

    this.profileInfo = function (memberId, funCallBack) {
        var url = getApiDomainUrl() + "/api/account/accinfo/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    }
    this.changePwd = function (memberId, currentpassword, newpassword, funCallBack) {
        var data = { memberId: memberId, currentpassword: currentpassword, newpassword: newpassword }
        var url = getApiDomainUrl() + "/api/account/changepassword";
        PostServiceByURL($http, url, data, funCallBack);
    }
    this.changeEml = function (memberId, password, newEmail, funCallBack) {
        var data = { memberId: memberId, password: password, newEmail: newEmail }
        var liveUrl = getApiDomainUrl() + "/api/account/changeemail";
        PostServiceByURL($http, liveUrl, data, funCallBack);
    }
    this.saveProfileHide = function (memId, isHide, funCallBack) {
        var liveURL = getApiDomainUrl() + "/api/account/ptmphd/" + memId + "/" + isHide;
        GetServiceByURL($http, liveURL, funCallBack);
    }
    this.GetBlockedMembes = function (memId, pgNo, PgSize, funCallBack) {
        var liveURL = getApiDomainUrl() + "/api/account/block/" + memId + "/" + pgNo + "/" + PgSize;
        GetServiceByURL($http, liveURL, funCallBack);
    }
    this.UnBlockMember = function (memId, memBlkId, funCallBack) {      
        var liveURL = getApiDomainUrl() + "/api/actions/rmblk/" + memId + "/" + memBlkId;
        GetServiceByURL($http, liveURL, funCallBack);
    }
    //Change Member Name
    this.PrfChangeName = function (memberId, firstname, funCallBack) {
        var data = { memberId: memberId, firstname: firstname }
        var url = getApiDomainUrl() + "/api/account/changename";
        PostServiceByURL($http, url, data, funCallBack);
    }
    //auto save services start
    this.saveTimezone = function (memId, timezone, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/tmzn/" + memId + "/" + timezone;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    this.saveUnits = function (memId, units, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/unts/" + memId + "/" + units;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    this.saveLocation = function (memId, countryId, cityId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/lctn/" + memId + "/" + countryId + "/" + cityId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    this.saveDOB = function (memId, dob, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/dob/" + memId;
        var data = { dt: dob }
        PostServiceByURL($http, liveUrl, data, funCallBack);
    }
    //this.saveGender = function (memId, gender, funCallBack) {
    //    var liveUrl = getApiDomainUrl() + "/api/account/gender/" + memId + "/" + gender;
    //    GetServiceByURL($http, liveUrl, funCallBack);
    //}
    this.saveGenderPref = function (memId, genderPref, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/genderpref/" + memId + "/" + genderPref;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    this.saveInvisibleBrowsing = function (memId, browsing, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/invbrwng/" + memId + "/" + browsing;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    //auto save services start end
    this.saveSettingsEmlrecmatch = function (memId, Emlrecmatch, funCallBack) {
        var liveurl = getApiDomainUrl() + "/api/account/emlrecmatch/" + memId + "/" + Emlrecmatch;
        GetServiceByURL($http, liveurl, funCallBack);
    }
    this.saveSettingsEmlviewme = function (memId, Emlviewme, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/emlviewme/" + memId + "/" + Emlviewme;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    this.saveSettingsEmlflirtme = function (memId, Emlflirtme, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/emlflirtme/" + memId + "/" + Emlflirtme;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    //this.saveSettingsEmlmsgme = function (memId, Emlmsgme, funCallBack) {
    //    var liveUrl = getApiDomainUrl() + "/api/account/emlmsgme/" + memId + "/" + Emlmsgme;
    //    GetServiceByURL($http, liveUrl, funCallBack);
    //}
    this.saveSettingsEmlpyrprmtn = function (memId, Emlpyrprmtn, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/emlpyrprmtn/" + memId + "/" + Emlpyrprmtn;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    this.saveSettingsEmlpyrtips = function (memId, Emlpyrtips, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/emlpyrtips/" + memId + "/" + Emlpyrtips;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    //notification setting module end
    this.chkEmlExist = function (email, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/chkemlexst";
        var data = { val: email };
        PostServiceByURL($http, liveUrl, data, funCallBack);
    }
    //Delete Account link email
    this.deleteAccountSendLink = function (mId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/delmemcls/" + mId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    this.unSubEml = function (encEmail, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/account/unsubeml";
        var data = { val: encEmail };
        PostServiceByURL($http, liveUrl, data, funCallBack);
    }

}]);