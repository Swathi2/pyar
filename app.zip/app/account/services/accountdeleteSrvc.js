﻿angular.module("app").service('accountdeleteSrvc', ['$http', function ($http) {

    this.deleteAccountLinkCheck = function (mId, linkCode, funCallBack) {
        var url = getApiDomainUrl() + "/api/account/delmemclc/" + mId + "/" + linkCode;
        GetServiceByURL($http, url, funCallBack);
    }

    this.deleteAccntFnl = function (mId, linkCode, reasonType, reasonExplantion, funCallBack) {
        var url = getApiDomainUrl() + "/api/account/delmem";
        var data = { lgnMbrId: mId, linkCode: linkCode, statusCause: reasonType, reason: reasonExplantion };
        PostServiceByURL($http, url, data, funCallBack);
    }
}]);