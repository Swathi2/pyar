﻿window.fbAsyncInit = function () {
    FB.init({
        appId: getFBClntId(),
        cookie: false,
        xfbml: true,
        version: 'v2.8'
    });
};

(function (d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) { return; }
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
   
}(document, 'script', 'facebook-jssdk'));


function fbLogin(callback) {
   
    FB.login(function (response) {
        
        if (response.authResponse) {
            getFbUserData(callback);
        } 
    }, { 'scope': 'email' });
}

function getFbUserData(callback) {
    FB.api('/me', { locale: 'en_US', fields: 'id,first_name,last_name,email,link,gender,locale,picture,birthday' },
    function (response) {
        callback(response);       
    });
}

function fbLogout(callback) {
 
    FB.logout(function (response) {
        callback(response);    
    });
}