﻿angular.module('app').service('socialLgnSrvc', ['$http', function ($http) {

    this.lgnCheck = function (lgnCheckObj, funCallBack) {
        var data = JSON.stringify(lgnCheckObj);
        var url = getApiDomainUrl() + "/api/registersignin/pcsocreg";
       // var url = getApiDomainUrl() + "/api/registersignin/regsocchk";
        PostServiceByURL($http, url, data, funCallBack);
    }

    this.lgnWithFbPh = function (regId, funCallBack) {
        var url = getApiDomainUrl() + "/api/registersignin/regsocsec/" + regId;
        GetServiceByURL($http, url, funCallBack);
    }    
    this.fb = function (myKeyVals, funCallBack) {
        var url = getApiDomainUrl() + "/api/registersignin/fb";
        PostServiceByURL($http, url, myKeyVals, funCallBack);
    };
}]);