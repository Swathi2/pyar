﻿angular.module("app").controller('registerfbemlCtrl', ['$scope', '$window', 'socialLgnSrvc', '$rootScope', function ($scope, $window, socialLgnSrvc, $rootScope) {
    var vm = this;
    var regData = JSON.parse($window.localStorage.getItem("memreg"));
    if (regData == null) {
        $window.location.href = "/register.html";
        return false;
    }
    vm.email = null;
    vm.EmailPlaceholder = "Email";
    vm.OopsDrctDv = true;
    //Email blur event
    vm.emailCheck = function () { emlchkBlur($rootScope, vm); }
    //Email change event
    vm.emailChnage = function () { emlchangeEvnt(vm); }
    //Email Focus Event
    vm.emailFocus = function () { emlFcs(vm); }

    vm.nextDsbl = function () { if (vm.email && $rootScope.emailRegex.test(vm.email)) { vm.btnClass = "nxtbtnhr"; return false; } else { vm.btnClass = ""; return true; } }

    vm.submitForm = function () {
        if ($scope.frmRegFbEml.$valid) {        
            var lgnCheckObj = { fn: regData.fn, socId: regData.socId, eml: vm.email, lgnType: regData.lgnType };
            socialLgnSrvc.lgnCheck(lgnCheckObj, function (response, status) {
                if (status == 200) {
                    if (response.status == true) {
                        if (response.proceedType == "reg") {
                            vm.jsonSession = { "mid": response.refId };
                            $window.localStorage.setItem("memreg", JSON.stringify(vm.jsonSession));
                            $window.localStorage.setItem("fbEmlMember", JSON.stringify(true));
                            if (response.isEmlVerified == true)
                                $window.location.href = '/register/security/details.html?' + response.refId;
                            else if (response.isEmlVerified == false)
                            $window.location.href ='/register/emailsend.html';
                        }
                    }
                    else if (response.status == false)
                        if (response.errType == "2" || response.errType == "6" || response.errType == "7") {
                            vm.OopsDrctDv = false;
                            vm.OopsEmlExistDv = true;
                        }                     
                        else if (response.errType == "0" || response.errType == "3")
                            alert("Invalid request");
                        else if (response.errType == "4")
                            alert("Email sending failed");
                }
            });
        }
    }
}]);