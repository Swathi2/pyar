﻿var captchaVerfication = "";
function recaptchaChk() {
    captchaVerfication = "Captcha verified";
}

angular.module("app").controller('registersocialsecCtrl', ['$scope', '$window', '$http', 'chkregsessionSrvc', 'socialLgnSrvc', '$interval', function ($scope, $window, $http, chkregsessionSrvc, socialLgnSrvc, $interval) {
    var vm = this
    $scope.memreg = $window.localStorage.getItem("memreg");
    //sessionStorage.removeItem("memreg");

    if ($scope.memreg == null) {
        $window.location.href = "/register.html";
        return false;
    }

    $scope.btnDisabled = function () {
        if ($scope.ageCnfrm && $scope.agree && captchaVerfication) {
            $scope.activeCls = "nxtbtntb nxtbtnhr"; return false;
        }
        else { $scope.activeCls = "nxtbtntb"; return true; }
    }

    //this function need to after getting response from google captcha.
    $interval(function () { if (captchaVerfication) { $scope.btnDisabled(); } }, 100);

    var regId = JSON.parse($scope.memreg).regId;
    $scope.submitForm = function () {
        if ($scope.frmSecurity.$valid) {
            socialLgnSrvc.lgnWithFbPh(regId, function (response, status) {
                if (status = 200) {
                    //1: invalid id, 2: no recored found (or) loginType mismatch ,3:invalid login type, 4:OTP Sent fail (or) email sent fail
                    if (response == 1 || response == 2 || response == 4) {
                        $window.localStorage.removeItem("memreg");
                        $("#ApiErrMsg").text("Unable to process, please try again."); $("#ErrAlert").modal("show");                                        
                    }
                    else if (response == 3) {
                        $window.localStorage.removeItem("memreg");
                        $("#ApiErrMsg").text("Please sign in with your email. This account is already registered under the email address entered."); $("#ErrAlert").modal("show");                       
                    }
                  else if (response.type == 1) {
                        vm.jsonSession = { "regId": response.id };
                        $window.localStorage.setItem("memreg", JSON.stringify(vm.jsonSession));
                        $window.location.href = '/register/security/details.html?' + response.id;
                    }
                    else if (response.type == 2) {
                        vm.jsonSession = { "mid": regId };
                        $window.localStorage.setItem("memreg", JSON.stringify(vm.jsonSession));
                        $window.location.href = "/register/security/email.html";
                    }
                }
                captchaVerfication = "";
            });
        }
        else {
            alert("Please fill all fileds!");
        }
    };

    ////privacy policy click event
    //vm.ppClick = function () {
    //    cmnSrvc.PPService(function (response, status) {
    //        if (status == 204) {
    //            alert("the content is not there (take the appropriate action)");
    //            return false;
    //        }
    //        else if (status == 200) {
    //            vm.ppVersion = "Version " + eval(JSON.stringify(response.version));
    //            vm.lstUpdated = "Last updated: " + $filter('date')(eval(JSON.stringify(response.dateCreated)), "MMMM d, yyyy");
    //            vm.ppContent = $sce.trustAsHtml(response.policytext);
    //            $("#ppModal").modal("show");
    //        }
    //    });
    //};

    ////Terms condtions click event
    //vm.tcClick = function () {
    //    cmnSrvc.TCService(function (response, status) {
    //        if (status == 204) {
    //            alert("the content is not there (take the appropriate action)");
    //            return false;
    //        }
    //        else if (status == 200) {
    //            vm.tcVersion = "Version " + eval(JSON.stringify(response.version));
    //            vm.lstUpdated = "Last updated: " + $filter('date')(eval(JSON.stringify(response.dateCreated)), "MMMM d, yyyy");
    //            vm.tcContent = $sce.trustAsHtml(response.policytext);
    //            $("#tcModal").modal("show");
    //        }
    //    });
    //};
}]);