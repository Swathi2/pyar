﻿angular.module("app").controller('instragramPhtsCtrl', ['$scope', '$window', '$state', '$timeout', function ($scope, $window, $state, $timeout) {
    function getUrlVars() {
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('#') + 1).split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    }
    var hasAccessToken = getUrlVars();
    if (hasAccessToken == "access_token") {
        var In_Data = $window.localStorage.getItem("In_data");
        if (In_Data) {
            var In_Data = JSON.parse(In_Data);
            $window.localStorage.removeItem("In_data");
            var access_token = hasAccessToken["access_token"];
            var temp = { PhotoIndex: In_Data.PhotoIndex, upldPhotoType: In_Data.upldPhotoType, access_token: access_token };
            $window.localStorage.setItem("In_data", JSON.stringify(temp));
            $window.location.href = '/profile.html';
        }
    }
}]);