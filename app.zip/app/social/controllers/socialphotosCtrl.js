﻿
angular.module("app").controller('socialPhotosCtrl', ["$scope", "$rootScope", "$window", "$http", "socialphotosSrvc", "prflphotodataSrvc", function ($scope, $rootScope, $window, $http, socialphotosSrvc, prflphotodataSrvc) {
    //variable declaration
    var vm = this;
    vm.accessToken = "";
    vm.imgPath = "";
    vm.albumId = "";
    vm.btnNextActive = "prvbtn";
    vm.btnValid = true;
    vm.albums = [];
    vm.maxWidth = 1920;
    vm.maxHeight = 1920;
    vm.minWidth = 400;
    vm.minHeight = 400;
    //variable declaration end

    //get images from facebook
    vm.btnFBPhotos = function () {
        FB.login(function (response) {
            if (response.authResponse) {
                var access_token = FB.getAuthResponse()['accessToken'];
                vm.accessToken = access_token;
                var client_id = getFBClntId();
                socialphotosSrvc.getAlbums(client_id, access_token, function (response, status) {
                    var albumsList = [];
                    for (var i = 0; i < response.data.length; i++) {

                        albumsList.push({ albumId: response.data[i].id, albumName: response.data[i].name });
                    }
                    $rootScope.srcType = 2;
                    vm.albums = albumsList;
                    vm.btnNextActive = "prvbtn";
                    $("#dvSourceSelector").css("display", "none");
                    $("#dvAlbums").css("display", "block");
                });
            }
        });
    }
    //get photos by album id
    vm.getAlbumPhotos = function () {
        var photUrls = [];
        socialphotosSrvc.bindPhotos(vm.albumId, vm.accessToken, function (response, status) {
            if (status == 200) {
                var albumsList = [];
                for (var i = 0; i < response.data.length; i++) {

                    var url = "https://graph.facebook.com/" + response.data[i].id + "/picture?access_token=" + vm.accessToken;
                    photUrls.push({ "imgUrl": url });
                }
                vm.albumPhotos = photUrls;
                $("#dvAlbums").css("display", "none");
                $("#dvAlbumPhotos").css("display", "block");
            }
        });
    }
    //image from my pc
    vm.btnMyPC = function () {
        //rise a file upload click event        
        $("#fupPhtGlry").click();
        //vm.srcType = 1 for my pc
        $rootScope.srcType = 1;
    }
    vm.btnBackAlbum = function () {
        $("#dvAlbums").css("display", "none");
        $("#dvAlbumPhotos").css("display", "none");
        $("#dvSourceSelector").css("display", "block");
    }
    //click on album name 
    vm.selectAlbum = function (albumId, index) {
        $("[id^='dvAlbum']").removeClass("bxshdw");
        $("#dvAlbum" + index).addClass("bxshdw");
        if (albumId != "" && albumId != undefined && albumId != null) {
            vm.btnNextActive = "prvbtn regBtn";
            vm.albumId = albumId;
            vm.btnValid = false;
        }
    }
    // album photo back button click
    vm.btnBackAlbumPhotos = function () {
        vm.btnNextActive = "prvbtn";
        vm.albumId = "";
        vm.btnValid = true;
        $("#dvAlbumPhotos").css("display", "none");
        $("#dvAlbums").css("display", "block");

    }
    vm.clsDvAlbum = function () {
        $("#dvAlbums").css("display", "none");
    }
    vm.clsDvAlbumPhotos = function () {
        $("#dvAlbumPhotos").css("display", "none");
    }
    function loadImage(imgPath, index, calBackFun) {
        $("<img/>").load(function () {
            vm.imgRealWidth = this.width;
            vm.imgRealHeight = this.height;
            if (vm.imgRealWidth < vm.minWidth || vm.imgRealHeight < vm.minHeight) {
                var errorMsgDiv = "<div class='hvrmask visible-lg' style='opacity: 1;border-radius: 20px;'><p class='prfHvr' style='line-height: 150px;'>Too small</p></div>";
                $("#selectedImg" + index).parent().append(errorMsgDiv);
                calBackFun(false);
            }
            else {
                calBackFun(true);
                $('#cropImg').croppie('destroy');
                $rootScope.adjCrpToDtsny = 3;
                vm.imgHeight = vm.imgRealHeight;
                vm.imgwidth = vm.imgRealWidth;

                if (vm.imgRealWidth > vm.imgRealHeight) {
                    if (vm.imgRealWidth > vm.maxWidth) {
                        vm.imgHeight = vm.imgRealHeight * (vm.maxWidth / vm.imgRealWidth);
                        vm.imgwidth = vm.maxWidth;
                    }
                } else {
                    if (vm.imgRealHeight > vm.maxHeight) {
                        vm.imgwidth = vm.imgRealWidth * (vm.maxHeight / vm.imgRealHeight);
                        vm.imgHeight = vm.maxHeight;
                    }
                }
                $rootScope.imgPath = imgPath;
                $rootScope.realWidth = vm.imgwidth;
                $rootScope.realHeight = vm.imgHeight;
            }
        }).attr("src", imgPath);
    }

    vm.albumImgClick = function (imgPath, index) {
        $("[id^='selectedImg']").removeClass("bxshdw");
        $("#selectedImg" + index).addClass("bxshdw");
        var width = $("#selectedImg" + index).width();
        var height = $("#selectedImg" + index).height();
        loadImage(imgPath, index, function (response) {
            if (response) {
                $("#btnSelectPhoto").attr('disabled', false);
                $("#btnSelectPhoto").addClass("regBtn");
            } else {
                $("#btnSelectPhoto").attr('disabled', true);
                $("#btnSelectPhoto").removeClass("regBtn");
            }
        });
    }

    vm.btnINPhotos = function () {
        $rootScope.srcType = 3;
        var clientid = getIGClntId();
        //var redirectUri = "http://localhost:49984/profile.html";
        var redirectUri = "https://dev.pyar.com/profile.html";
        document.location.href = "https://api.instagram.com/oauth/authorize/?client_id=" + clientid + "&redirect_uri=" + redirectUri + "&response_type=token";
    }

    function getUrlVars() {
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('#') + 1).split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    }

    var hasAccessToken = getUrlVars();
    if (hasAccessToken == "access_token") {
        var access_token = hasAccessToken["access_token"];
        var photoUrls = [];
        socialphotosSrvc.bindPhotosIN(access_token, function (response) {
            var albumsList = [];
            for (var i = 0; i < response.data.length; i++) {
                var url = response.data[i].images.low_resolution.url;
                photoUrls.push({ "imgUrl": url });
            }
            vm.albumPhotos = photoUrls;
            $("#photosPopup").modal("show");
            $("#dvSourceSelector").css("display", "none");
            $("#dvAlbumPhotos").css("display", "block");
        });
    }
}]);