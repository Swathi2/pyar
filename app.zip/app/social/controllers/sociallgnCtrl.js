﻿
angular.module("app").controller('sociallgnCtrl', ['getSessionSrvc', "$scope", "$window", "selfprofileSrvc",  '$state',  function (getSessionSrvc, $scope, $window, selfprofileSrvc, $state) {
    var vm = this;
    var socialData = JSON.parse($window.localStorage.getItem("socialData"));
    $window.localStorage.removeItem("socialData");           
        if (socialData && socialData.lgnType == "fb") {
            onfbSuccess(socialData.lgnData);
        }

    vm.trophyPopsocEmpty = true;
    vm.trophyPopsoc = false;

    vm.fbSignIn = function () {
        //var redirectUri = "http://localhost:49984/fb.html";
        var redirectUri = "https://dev.pyar.com/fb.html";
        var clientid = getFBClntId();
        window.location.href = "https://www.facebook.com/v2.10/dialog/oauth?client_id=" + clientid + "&redirect_uri=" + redirectUri + "&response_type=code&scope=email";
    }

    var socialTrop;   
    vm.fbLgn = function (trop) {
        socialTrop = trop;
        fbLogin(function (response) {
            if (response != undefined) {
                if (trop == 'T') {
                    selfprofileSrvc.socTrophy(getSessionSrvc.p_mId(), function (response, status) {
                    });
                    $scope.$apply(function () {
                        vm.trophyPopsocEmpty = false;
                        vm.trophyPopsoc = true;
                    });
                }
            }
            else {
                alert("Login Failed Please try again..");
                return false;
            }
        });

    }
    function onfbSuccess(response) {
        if (response != undefined) {
            if (socialTrop == 'T') {
                selfprofileSrvc.socTrophy(getSessionSrvc.p_mId(), function (response, status) {
                });
                $scope.$apply(function () {
                    vm.trophyPopsocEmpty = false;
                    vm.trophyPopsoc = true;
                });
            }
        }
        else {
            alert("Login Failed Please try again..");
            return false;
        }
    };
    //function change url
    function navigate(response, url) {
        $window.sessionStorage.setItem("8B3414FB", response.id);
        $state.go(url);
    }

    //function for getting response Id's based on index
    function rspStaus(id, response) {
        if (response.refId != undefined) {
            return response.refId.indexOf(id) > -1;
        }
    }

}]);