﻿angular.module("app").controller('fblgnCtrl', ['getSessionSrvc', '$scope', '$window', '$state', '$timeout', 'socialLgnSrvc', function (getSessionSrvc, $scope, $window, $state, $timeout, socialLgnSrvc) {
    //var redirectUri = "http://localhost:49984/fb.html";
    var redirectUri = "https://dev.pyar.com/fb.html";
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    if (vm.mId())
    {
        $state.go("dashboard");
        return false;
    }
    showLoader();
    var clientid = getFBClntId();   
    function getUrlVars() {
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('/') + 1).split('?');
        if (hashes[1]) {
            hashes = hashes[1]
            hash = hashes.split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
            if (vars[0] == "error")
                return false;
            else
                return vars;
        } else  return false;
    };
        var code = getUrlVars();
        if (code == false) {
            hideLoader();
            $state.go("signin");
            return false;
        }
        else if (code == "code") {
            var code = code["code"]
            var code1 = code.split('&');
            var actualCode = code1[0];// actual code obtained in request
            var myKeyVals = {
                "code": actualCode,
                "redirectUrl": redirectUri,
                "clntId": clientid
            }
            socialLgnSrvc.fb(myKeyVals, function (response, status) {
                if (response == 1) {
                    window.location.href = "https://www.facebook.com/v2.10/dialog/oauth?client_id=" + clientid + "&redirect_uri=" + redirectUri;
                }
                else {
                    var lgnCheckObj = { fn: response.first_name, socId: response.id, eml: response.email, lgnType: 2 }; /*response.email*/
                    socialLgnSrvc.lgnCheck(lgnCheckObj, function (outVal, status) {                  
                        loginCheck(outVal, status, response, 2);
                    });

                }
            });
        }
        else {
            //window.location.href = "https://www.facebook.com/v2.10/dialog/oauth?client_id=" + clientid + "&redirect_uri=" + redirectUri;
        }


    //function to check member acc info using response
    function loginCheck(response, status, responseData, lgnType) {       
        hideLoader();     
        if (status == 200) {
            if (response.status == true) {
                if (response.lgnData && response.proceedType == "lgn") {
                    if (rspStaus(10, response.lgnData) == true) { $("#ErrAlert").modal("show"); hideLoader(); }
                    else if (rspStaus(3, response.lgnData) == true) { navigate(response.lgnData, "profilehide"); }
                    else if (rspStaus(1, response.lgnData) == true) { navigate(response.lgnData, "privacy-policy-pop"); }
                    else if (rspStaus(2, response.lgnData) == true) { navigate(response.lgnData, "terms-conditionspop"); }
                    else if (response.lgnData == 8) {
                        $("#ApiErrMsg").text("Your account has been suspended/deleted. Please contact our helpdesk for further information."); $("#ErrAlert").modal("show");
                        $state.go("register");
                    }
                    else if (response.lgnData == "6" || response.lgnData == "7") {
                        vm.signInType = "email";
                        $('#socialUsrPopup').modal('show');
                    }
                    else if (getSessionSrvc.validateSessionInfo(response.lgnData)) {
                        var loginType = window.sessionStorage.getItem("DtpsNtP");
                        $window.sessionStorage.removeItem("DtpsNtP");
                        $window.sessionStorage.removeItem("8B3414FB");
                        getSessionSrvc.setLoginData(response.lgnData);
                        if (loginType == "DT") {
                            var pgName = window.sessionStorage.getItem("Dtppn");
                            $window.sessionStorage.removeItem("Dtppn");
                            if (lgnType == 2 || lgnType == 4)
                                $window.location.href = "/dating-tip" + pgName + "";
                        }
                        else if (lgnType == 2 || lgnType == 4)
                            $window.location.href = "/dashboard.html";
                    }
                }
                else if (response.proceedType == "reg") {
                    vm.jsonSession = { "mid": response.refId };
                    $window.localStorage.setItem("memreg", JSON.stringify(vm.jsonSession));
                    if (response.isEmlVerified == true)
                        $window.location.href = '/register/security/details.html?' + response.refId;
                    else if (response.isEmlVerified == false)
                       $state.go('register/emailsend');
                }
            }
            else if (response.status == false) {
                //0:Invalid request,1:email enter page,2:member already registered,3:invalid login type,4:email link or otp send fail6d,6: facebook only,7:linked in only.
                if (response.errType == "1") {
                    if (lgnType == 2) {
                        vm.jsonSession = { "fn": responseData.first_name, "socId": responseData.id, "lgnType": 3 };
                        $window.localStorage.setItem("memreg", JSON.stringify(vm.jsonSession));
                        $window.location.href = '/register/security/fb/email.html';
                    }
                    if (lgnType == 4) {
                        vm.jsonSession = { "fn": responseData.firstName, "socId": responseData.id, "lgnType": 5 };
                        $window.localStorage.setItem("memreg", JSON.stringify(vm.jsonSession));
                        $window.location.href = '/register/security/fb/email.html';
                    }
                }
                else if (response.errType == "2" || response.errType == "6" || response.errType == "7") {
                    vm.signInType = "email";
                    $('#socialUsrPopup').modal('show');
                }
                else if (response.errType == "0" || response.errType == "3")
                    alert("Invalid request");
                else if (response.errType == "4")
                    alert("Email sending failed");
            }
        }
    }
    //function change url
    function navigate(response, url) {
        $window.sessionStorage.setItem("8B3414FB", response.id);
        $state.go(url);
    }

    //function for getting response Id's based on index
    function rspStaus(id, response) {
        if (response.refId != undefined) {
            return response.refId.indexOf(id) > -1;
        }
    }

    vm.gotoLoginPg = function () {
        $('#socialUsrPopup').modal('hide');;
        $timeout(function () { $state.go('signin'); }, 300);
    }
}]);