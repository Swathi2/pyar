﻿using System;
using System.Data;

public partial class app_datingTips_shareDtip : BasePage
{
    #region Page_init event
    protected void Page_Init(Object sender, EventArgs e)
    {
        //http://localhost:49984/app/datingTips/shareDtip.aspx?url=http%3A%2F%2Fdev.pyar.com%2Fdating-tip%2Fmake-your-profile-stand-out.html#.WjuoBmgKwjM.twitter

        //http://localhost:49984/app/datingTips/shareDtip.aspx?rt=15&pt=fb&url=https%3A%2F%2Fdev.pyar.com%2Fdating-tip%2Fmake-your-profile-stand-out.html
        //https://dev.pyar.com/app/datingTips/shareDtip.aspx?rt=15&pt=fb&url=https%3A%2F%2Fdev.pyar.com%2Fdating-tip%2Fmake-your-profile-stand-out.html
        //https://www.pyar.com/app/datingTips/shareDtip.aspx?rt=15&pt=fb&url=https%3A%2F%2Fdev.pyar.com%2Fdating-tip%2Fmake-your-profile-stand-out.html

        //http://localhost:49984/app/datingTips/shareDtip.aspx?pt=fb&url=https%3A%2F%2Fdev.pyar.com%2Fdating-tip%2Fmake-your-profile-stand-out.html
        //https://dev.pyar.com/app/datingTips/shareDtip.aspx?pt=fb&url=https%3A%2F%2Fdev.pyar.com%2Fdating-tip%2Fmake-your-profile-stand-out.html
        //https://www.pyar.com/app/datingTips/shareDtip.aspx?pt=fb&url=https%3A%2F%2Fdev.pyar.com%2Fdating-tip%2Fmake-your-profile-stand-out.html

        if (Request.QueryString["url"] != null && Request.QueryString["url"].ToString() != "")
        {
            string encodedUrlURL = Request.QueryString["url"].ToString();
            string URL = Uri.UnescapeDataString(encodedUrlURL);
            Uri TipUri = new Uri(URL);
            if (TipUri.Host.ToLower() == "www.pyar.com" || TipUri.Host.ToLower() == "dev.pyar.com")
            {
                string[] URLData = URL.Split('/');
                string pageName = "/" + URLData[URLData.Length - 1];
                string pageType = "";

                if (pageName != "")
                {
                    string refreshTime = "1", cdnPath = "https://pccdn.pyar.com";
                    string metaTitle, metaDesc, metaKeywords, imagePath, videoUrl;

                    GetGuideDataByPgName(pageName, out metaTitle, out metaDesc, out metaKeywords, out imagePath, out videoUrl);
                    imagePath = cdnPath + imagePath;

                    if (!string.IsNullOrEmpty(Request.QueryString["pt"]))
                        pageType = Request.QueryString["pt"].ToString().ToLower();

                    if (!string.IsNullOrEmpty(Request.QueryString["rt"]))
                        refreshTime = Request.QueryString["rt"].ToString();

                    AddNewLine();

                    if (pageType == "gp")
                    {
                        AddMetaTag("og:title", metaTitle);
                        AddMetaTag("og:description", metaDesc);
                        AddMetaTag("og:image", imagePath);
                    }
                    else if (pageType == "fb")
                    {
                        AddMetaTag("og:title", metaTitle);
                        AddMetaTag("og:description", metaDesc);
                        AddMetaTag("og:image", imagePath);
                    }
                    else if (pageType == "tw")
                    {
                        if (videoUrl != "")
                        {
                            AddMetaTag("twitter:card", "player");
                            AddMetaTag("twitter:title", metaTitle);
                            AddMetaTag("twitter:site", "@addthis");
                            AddMetaTag("twitter:description", metaDesc);
                            AddMetaTag("twitter:player", videoUrl);
                            AddMetaTag("twitter:player:width", "1280");
                            AddMetaTag("twitter:player:height", "720");
                            AddMetaTag("twitter:image:src", imagePath);
                        }
                        else
                        {
                            AddMetaTag("twitter:card", "summary_large_image");
                            AddMetaTag("twitter:title", metaTitle);
                            AddMetaTag("twitter:description", metaDesc);
                            AddMetaTag("twitter:image:src", imagePath);
                        }
                    }
                    else if (pageType == "tu")
                    {
                        if(videoUrl != "")
                        {
                            AddMetaPropertyTag("og:title", metaTitle);
                            AddMetaPropertyTag("og:description", metaDesc);
                            AddMetaPropertyTag("og:video", videoUrl);
                            AddMetaTitle(metaTitle);
                            AddMetaTag("description", metaDesc);
                            AddMetaTag("keywords", metaKeywords);
                            AddOtherTag("<meta property=\"og:video\" content=\"" + videoUrl + "\" />");
                        }
                        else
                        {
                            AddMetaPropertyTag("og:title", metaTitle);
                            AddMetaPropertyTag("og:description", metaDesc);
                            AddMetaPropertyTag("og:image", imagePath);
                            AddMetaTitle(metaTitle);
                            AddMetaTag("description", metaDesc);
                            AddMetaTag("keywords", metaKeywords);
                            AddOtherTag("<meta property=\"og:image\" content=\"" + imagePath + "\" />");
                        }
                    }
                    else if (pageType == "dfb")
                    {
                        string _metaTitle = "I'm finding great matches on Pyar.com";
                        string _metaDesc = "You deserve to find someone you can connect with in a meaningful way. Sign up today!";
                        string _imagePath = cdnPath + "/pcimgs/sharepyar.jpg";

                        AddMetaTag("og:title", _metaTitle);
                        AddMetaTag("og:description", _metaDesc);
                        AddMetaTag("og:image", _imagePath);
                        AddOtherTag("<meta property=\"og:image\" content=\"" + _imagePath + "\" />");
                    }
                    else
                    {
                        AddMetaTitle(metaTitle);
                        AddMetaTag("description", metaDesc);
                        AddMetaTag("keywords", metaKeywords);
                        AddOtherTag("<meta property=\"og:image\" content=\"" + imagePath + "\" />");
                    }

                    AddRefreshMetaTag(refreshTime, URL);
                }
                else
                    Response.Redirect("https://www.pyar.com");
            }
            else
                Response.Redirect("https://www.pyar.com");
        }
        else
            Response.Redirect("https://www.pyar.com");
    }
    #endregion

    #region Page_Load event
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    #endregion

    #region get guide meta data using guide page name
    public void GetGuideDataByPgName(string guiPgName, out string metaTitle, out string metaDesc, out string metaKeywords, out string imagePath, out string videoUrl)
    {
        metaTitle = metaDesc = metaKeywords = imagePath = videoUrl= "";
        Utilities utlObj = new Utilities();
        DataSet guideMetaData = utlObj.GuideMetaByPageName(guiPgName);
        if (guideMetaData.Tables.Count > 0 && guideMetaData.Tables[0].Rows.Count > 0)
        {
            metaTitle = guideMetaData.Tables[0].Rows[0]["title"].ToString();
            metaDesc = guideMetaData.Tables[0].Rows[0]["description"].ToString();
            metaKeywords = guideMetaData.Tables[0].Rows[0]["keywords"].ToString();
            imagePath = guideMetaData.Tables[0].Rows[0]["bannerThumbnail"].ToString();
            videoUrl = guideMetaData.Tables[0].Rows[0]["videoUrl"].ToString();
        }
    }
    #endregion
}