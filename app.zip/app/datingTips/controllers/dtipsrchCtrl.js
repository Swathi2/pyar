﻿angular.module("app").controller("dtipsrchCtrl", ['$scope', '$http', 'dtipSrvc', 'dtipdataSrvc', '$window', '$location', '$state', '$timeout', function ($scope, $http, dtipSrvc, dtipdataSrvc, $window, $location, $state, $timeout) {
    var vm = this;
    var pageNumbr = 1;
    var pageSize = 12;
    vm.guides = [];
    var scrollable = true;
    vm.ShowViewMore = false;
    vm.dvpgVisble = false;
    vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";

    //page unevenly loading resolve function
    vm.pgVisble = function () {
        $timeout(function () {
            vm.dvpgVisble = true;
        }, 300, true);
    }
    //get tips by search text of this page
    vm.searchTipsG = function ($event) {
        pageNumbr = 1;
        var keyCode = $event.which || $event.keyCode;
        if (!vm.searchText && keyCode === 13)
            $state.go("dating-tips");
        if (keyCode === 13 && vm.searchText != undefined && vm.searchText != "") {
            $location.path("/dating-tip-srch.html").search({ st: vm.searchText });
            scrollable = true;
            vm.guides = [];
        }
    }

    $scope.$watch(function () { return $location.search() }, function (params) {
        vm.searchText = params.st;
        if (vm.searchText != "" && vm.searchText != undefined)
            getSearchTips(vm.searchText);
        else
            $state.go("dating-tips");
    });

    function getSearchTips(searchText) {
        vm.ShowViewMore = false;
        showLoader();
        var searchData = { guideName: searchText, pgNo: pageNumbr, pgSize: pageSize }
        if (searchText) {
            //service for searching tips
            vm.guides = dtipSrvc.srchTipsG(searchData, function (response, status) {
                hideLoader();
                if (status == 200 && response && response.tips && response.tips.length > 0) {
                    for (var i = 0; i < response.tips.length; i++) {
                        response.tips[i].dateTimeCreated = DateFormat(response.tips[i].dateTimeCreated);
                        response.tips[i].guideName = preapareGuideName(response.tips[i].guideName, 100, 3);
                    }
                    vm.guides = response.tips;
                    vm.SearchData = "Results for '" + searchText + "'";
                    vm.ShowViewMore = response.tips.length == pageSize;
                } else {
                    vm.SearchData = "No Results for '" + searchText + "'";
                    vm.ShowViewMore = false;
                }
                vm.pgVisble();
                vm.shwRstTxt = true;
                vm.searchText = searchText;
            });
        }
    };

    //when open individual tip scrool to top
    vm.scrolTop = function () {
        $('html, body').scrollTop(0);
    }
    //clear the search text on clear click
    vm.clearSearch = function () {
        vm.searchText = '';
        $state.go("dating-tips");
    }

    vm.loadMoreTips = function () {
        if (vm.guides) {
            if (vm.guides.length == (pageNumbr * pageSize)) {
                pageNumbr++;
                var searchText = { guideName: vm.searchText, pgNo: pageNumbr, pgSize: pageSize }
                if (vm.searchText) {
                    vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/acnLdr.svg";
                    showLoader();
                    //service for search tips
                    dtipSrvc.srchTipsG(searchText, function (response, status) {
                        if (status == 200 && response && response.tips && response.tips.length > 0) {
                            for (var i = 0; i < response.tips.length; i++) {
                                response.tips[i].dateTimeCreated = DateFormat(response.tips[i].dateTimeCreated);
                                response.tips[i].guideName = preapareGuideName(response.tips[i].guideName, 100, 3);
                                vm.guides.push({ bannerThumbnail: response.tips[i].bannerThumbnail, guideName: response.tips[i].guideName, guidId: response.tips[i].guidId, guidePageName: response.tips[i].guidePageName, guideContent: response.tips[i].guideContent, dateTimeCreated: response.tips[i].dateTimeCreated, aName: response.tips[i].aName, videoUrl: response.tips[i].videoUrl });
                            }
                            vm.ShowViewMore = response.tips.length == pageSize;
                        } else
                            vm.ShowViewMore = false;
                        hideLoader();
                        vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
                    });
                }
            }
        }
    }



    ////scrool function
    //$scope.scrollLoad = function () {
    //    //scrollable condition true only if data is availble
    //    if (vm.guides) {
    //        if (scrollable && vm.guides.length == (pageNumbr * pageSize)) {
    //            if ($(window).scrollTop() >= (($(document).height() - $("#pcFtr").outerHeight() - 20) - $(window).height())) {                  
    //                pageNumbr++;
    //                var searchText = { guideName: vm.searchText, pgNo: pageNumbr, pgSize: pageSize }
    //                if (vm.searchText) {
    //                    showLoader();
    //                    //service for search tips
    //                    dtipSrvc.srchTipsG(searchText, function (response, status) {
    //                        if (status == 200) {
    //                            if (response.length == 0 || response.length < pageSize)
    //                                scrollable = false;
    //                            for (var i = 0; i < response.length; i++) {
    //                                response[i].dateTimeCreated = DateFormat(response[i].dateTimeCreated);
    //                                response[i].guideName = preapareGuideName(response[i].guideName, 100, 3);
    //                            }
    //                            //cancatenating tips on scrool down 
    //                            for (var i = 0; i < response.length; i++) {
    //                                vm.guides.push({ bannerThumbnail: response[i].bannerThumbnail, guideName: response[i].guideName, guidId: response[i].guidId, guidePageName: response[i].guidePageName, guideContent: response[i].guideContent, dateTimeCreated: response[i].dateTimeCreated, aName: response[i].aName });
    //                            }
    //                        }
    //                        hideLoader();
    //                    });
    //                }

    //            }
    //        }
    //    }
    //}
    vm.bindImgSrc = function (imgPath) {
        return addCdnPath(imgPath);
    }
    //function for updating Socialsharing url
    vm.socialShares = function (classNm, pgType, dtipPageUrl, title) {
        updatingSocialSharingUrl(classNm, pgType, dtipPageUrl, title);
    }

    //date format 
    function DateFormat(date) {
        if (date) {
            var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var dateObj = new Date(date);
            var month = dateObj.getUTCMonth(); //months from 1-12
            var day = dateObj.getUTCDate();
            var year = dateObj.getUTCFullYear();
            var newdate = monthNames[month] + " " + day + ", " + year;
            return newdate;
        }
    }

    function preapareGuideName(text, len, dtCnt) {
        if (text) {
            var tempDv = document.createElement("DIV");
            tempDv.innerHTML = text;
            var resultText = tempDv.innerText.trim();

            if (resultText.length > len)
                return resultText.substring(0, (len - dtCnt)) + "...";
            else
                return resultText;
        }
    }
    $('body').css('background', '#ffffff');
}]);