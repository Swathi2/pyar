﻿angular.module("app").controller("dtiplstCtrl", ['$scope', '$http', 'dtipSrvc', 'dtipdataSrvc', '$stateParams', '$window', '$location', '$timeout', '$rootScope', function ($scope, $http, dtipSrvc, dtipdataSrvc, $stateParams, $window, $location, $timeout, $rootScope) {
    tabMenu();
    var vm = this;
    var pageNumbr = 1;
    var pageSize = 12;
    var sectId = 0;
    var scrollable = true;
    var state = checkNullOrUndefined(dtipdataSrvc.getSecId());
    vm.dvpgVisble = false;
    vm.seachPlaceHolder = "Search dating tips";
    vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
    vm.ShowViewMore = false;
    vm.sectionDatingTip = 1;
    vm.sectionVideo = 3;
    vm.sectionQuote = 4;

    //function for updating Socialsharing url
    vm.socialShares = function (classNm, pgType, dtipPageUrl, title) {
        updatingSocialSharingUrl(classNm, pgType, dtipPageUrl, title);
    }

    //page unevenly loading resolve function
    vm.pgVisble = function () {
        $timeout(function () {
            vm.dvpgVisble = true;
            if ($rootScope.selectedTabId) {
                $("#guiSecTab" + $rootScope.selectedTabId).click();
                $rootScope.selectedTabId = null;
            }
        }, 200, true);
    }
    //checking for privious loading section if not available calling services
    if (state) {
        var secId = dtipdataSrvc.getSecId();
        vm.sections = dtipdataSrvc.getSectionsData();
        vm.selectedId = secId;
        vm.sectionType = dtipdataSrvc.getSecType();
        getTipBySection(secId,1);

    }
    else {
        //Service for getting sections 
        vm.sections = dtipSrvc.tipSectionG(function (response, status) {
            if (response.length > 0 && status == 200) {
                //adding Featured section
                var featureObj = { secId: 0, secType: vm.sectionDatingTip, secName: 'Featured', priority: 0 };
                response.push(featureObj);
                //order the sections based on priority column
                response = response.sort(function (a, b) {
                    return (a['priority'] > b['priority']) ? 1 : ((a['priority'] < b['priority']) ? -1 : 0);
                });
                //storing sections for further use
                dtipdataSrvc.setSectionsData(response);
                vm.sections = response;
                if ($stateParams.secId) {
                    vm.selectedId = $stateParams.secId;
                    var secObj = response.find(function (obj) {
                        return obj.secId == $stateParams.secId;
                    });
                    vm.sectionType = secObj.secType;
                    getTipBySection(vm.selectedId, 1);
                }
                else {
                    vm.selectedId = 0;
                    vm.sectionType = vm.sectionDatingTip;
                    //calling tips by section
                    getTipBySection(response[0].secId, 1);
                }
            }
        });
    }


    //Search functionality change event
    vm.searchChnage = function () {
        if (vm.searchText && vm.searchText.length > 100) {
            vm.searchText = null;
            vm.seachPlaceHolder = 'Must be < 100 characters';
        }
        else {
            vm.seachPlaceHolder = "Search dating tips";
        }
    }
    
    //tips by section wise using section id
    vm.getTipBySection = function (secObj) {
        //storing secId and secType for selected index of sections
        $location.search({ secId: secObj.secId });
        dtipdataSrvc.setSecId(secObj.secId);
        dtipdataSrvc.setSecType(secObj.secType);

        vm.hasNoTips = false;
        scrollable = true;
        vm.guides = '';
        sectId = secObj.secId;
        pageNumbr = 1;
        vm.selectedId = secObj.secId;
        vm.sectionType = secObj.secType;
        vm.trendingTips = vm.trendingVideos = vm.trendingQuotes = [];
        getTipBySection(secObj.secId, 1);

    };
    //getting search tips
    vm.srchTipsG = function ($event) {
        var keyCode = $event.which || $event.keyCode;
        if (keyCode === 13 && vm.searchText != undefined && vm.searchText != "") {
            //dtipdataSrvc.setSearchData(vm.searchText);
            $location.path("/dating-tip-srch.html").search({ st: vm.searchText });
        }
    }
    //clear the search text on clear click
    vm.clearSearch = function () {
        vm.searchText = null;
    }
    //when open individual tip scrool to top
    vm.scrolTop = function () {
        $('html, body').scrollTop(0);
    }

    //tips by section id page number
    function getTipBySection(secId, pageNumbr) {
        sectId = secId;
        vm.ShowViewMore = false;
        if (checkNullOrUndefined(secId)) {
            showLoader();
            //service for getting tips based on section id
            dtipSrvc.tipsBySecId(secId, pageNumbr, pageSize, function (response, status) {
                if (response && status == 200) {
                    vm.trendingTips = response.trndTips ? response.trndTips : [];
                    vm.trendingVideos = response.trndVideos ? response.trndVideos : [];
                    vm.trendingQuotes = response.trndQuotes ? response.trndQuotes : [];

                    if (response.tips && response.tips.length > 0) {
                        vm.hasNoTips = false;

                        for (var i = 0; i < response.tips.length; i++) {
                            response.tips[i].dateTimeCreated = DateFormat(response.tips[i].dateTimeCreated);
                            response.tips[i].guideName = preapareGuideName(response.tips[i].guideName, 100, 3);
                        }
                        vm.guides = response.tips;
                        vm.ShowViewMore = response.tips.length == pageSize;
                    } else {
                        vm.hasNoTips = true;
                        vm.ShowViewMore = false;
                    }
                } else {
                    vm.hasNoTips = true;
                    vm.ShowViewMore = false;
                }
                vm.pgVisble();
                hideLoader();
            });
        }
    };
    //checking the value is null or undefined 
    function checkNullOrUndefined(val) {
        return !(angular.isUndefined(val) || val === null);//true if the value is null or undefined;
    }


    vm.loadMoreTips = function () {
        if (vm.guides) {
            if (vm.guides.length == (pageNumbr * pageSize)) {
                vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/acnLdr.svg";
                showLoader();
                pageNumbr++;
                //service call for tips by sec id
                dtipSrvc.tipsBySecId(sectId, pageNumbr, pageSize, function (response, status) {
                    if (status == 200 && response && response.tips && response.tips.length > 0) {
                        for (var i = 0; i < response.tips.length; i++) {
                            response.tips[i].dateTimeCreated = DateFormat(response.tips[i].dateTimeCreated);
                            response.tips[i].guideName = preapareGuideName(response.tips[i].guideName, 100, 3);
                            vm.guides.push({ bannerThumbnail: response.tips[i].bannerThumbnail, guideName: response.tips[i].guideName, guidId: response.tips[i].guidId, guidePageName: response.tips[i].guidePageName, guideContent: response.tips[i].guideContent, dateTimeCreated: response.tips[i].dateTimeCreated, aName: response.tips[i].aName, videoUrl: response.tips[i].videoUrl });
                        }
                        vm.ShowViewMore = response.tips.length == pageSize;
                        vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
                    } else
                        vm.ShowViewMore = false;
                    hideLoader();
                });
            }
        }
    }

    vm.bindImgSrc = function (imgPath) {
        return addCdnPath(imgPath);
    }

    //date format 
    function DateFormat(date) {
        if (date) {
            var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var dateObj = new Date(date);
            var month = dateObj.getUTCMonth(); //months from 1-12
            var day = dateObj.getUTCDate();
            var year = dateObj.getUTCFullYear();
            var newdate = monthNames[month] + " " + day + ", " + year;
            return newdate;
        }
    }
    function preapareGuideName(text, len, dtCnt) {
        if (text) {
            var tempDv = document.createElement("DIV");
            tempDv.innerHTML = text;
            var resultText = tempDv.innerText.trim();

            if (resultText.length > len)
                return resultText.substring(0, (len - dtCnt)) + "...";
            else
                return resultText;
        }
    }


    $('body').css('background', '#ffffff');

    vm.bnr = function (index) {
        if ($(window).width() <= 767 || index != 0) {
            return false
        } else return true;
    };

    vm.nobnr = function (index) {
        if ($(window).width() <= 767) {
            return true
        } else {
            if (index == 0) return false;
            else return true;
        }
    };
}])