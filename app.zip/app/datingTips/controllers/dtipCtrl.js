﻿angular.module("app").controller("dtipCtrl", ['getSessionSrvc', '$scope', '$http', 'dtipSrvc', 'dtipdataSrvc', 'dtipcmtSrvc', '$window', '$stateParams', '$location', '$state', '$rootScope', '$filter', '$timeout', function (getSessionSrvc, $scope, $http, dtipSrvc, dtipdataSrvc, dtipcmtSrvc, $window, $stateParams, $location, $state, $rootScope, $filter, $timeout) {

    var vm = this;
    vm.guidId = "";
    vm.CmntId = "";
    vm.pgNo = 1;
    vm.pgSize = 3;
    vm.rplyPgSize = 3;
    vm.scrollable = true;
    vm.memId = "";
    //vm.loadTipData = true;
    vm.data = { Comments: [], Replies: [] };
    vm.dvpgVisble = false;
    vm.cmtPlaceHolder = "Write your comment here";
    var firstName = getSessionSrvc.p_fn();
    var profilePicPath = getSessionSrvc.p_ppic().replace("/tnb/", "/tns/");
    if (profilePicPath == null || profilePicPath == "")
        vm.profilePic = 'https://pccdn.pyar.com/pcimgs/avatarM.png';
    else
        vm.profilePic = "https://pccdn.pyar.com" + profilePicPath.replace("/tnb/", "/tn/");

    //page unevenly loading resolve function
    vm.pgVisble = function () {
        $timeout(function () {
            vm.dvpgVisble = true;
            hideLoader();
        }, 400, true);
    }
    vm.memId = getSessionSrvc.p_mId();

    vm.showHideEdtDel = function (cmtId) {
        $("ul[id^=drpEdDl]").each(function (i, e) {
            if (("drpEdDl" + cmtId) == ($(e).attr("id"))) { $(e).toggle(); } else { $(e).css("display", "none"); }
        });
        vm.CmntId = cmtId;
    }

    //page name from state parameters
    var gpn = $stateParams.gpn;
    //checking for privious loading section if not available calling services
    if (dtipdataSrvc.getSectionsData().length != 0) {
        vm.sections = dtipdataSrvc.getSectionsData();
    } else {
        //Service for getting sections 
        vm.sections = dtipSrvc.tipSectionG(function (response, status) {
            //showLoader();
            if (status == 200 && response.length > 0) {
                //adding Featured section
                var featureObj = { secId: 0, secName: 'Featured', priority: 0 };
                response.push(featureObj);
                response = response.sort(function (a, b) {
                    return (a['priority'] > b['priority']) ? 1 : ((a['priority'] < b['priority']) ? -1 : 0);;
                });
                //storing sections for further use
                dtipdataSrvc.setSectionsData(response);
                vm.sections = response;
            }
            //hideLoader();
        });
    }

    vm.selectedId = dtipdataSrvc.getSecId() == null ? 0 : dtipdataSrvc.getSecId();
    
    getTipData();
    //function to get individula tip by guide page name
    function getTipData() {
        var guidePageName = { guidePageName: "/" + gpn };
        //service for getting individual tip based on pagename
        if (guidePageName != "" && guidePageName != undefined) {
            showLoader();
            dtipSrvc.tipByPageName(guidePageName, function (response, status) {
                if (status == 200 && response) {
                    vm.guideResponse = response;
                    if (response.dateTimeCreated && response.aName && response.secName) {
                        vm.bndAdrDtls = true;
                        vm.guidePostedTime = organizeDate(response.dateTimeCreated);// "Thursday,june 2,2016,12:00 PM";
                        vm.guidePostedAuthor = response.aName;//"Mike";
                        vm.guidePostedSection = response.secName;//"Long-term";  
                    } else
                        vm.bndAdrDtls = false;
                    //vm.guidBanner = addCdnPath(response.banner);
                    vm.guideName = response.guideName;
                    vm.guidePageName = response.guidePageName;
                    vm.guideContent = response.guideContent;
                    //vm.bannerThumbnail = response.bannerThumbnail;
                    vm.selectedId = response.secId;
                    vm.guidId = response.guidId;
                    BindComments(response.guidId);
                    similarTips(response.guidId);
                    //vm.loadTipData = false;
                    //hideLoader();
                    vm.guideTitle = response.title;
                    //vm.guideDescription = response.description;
                    //vm.guideKeyword = response.keywords;
                    pyrTitlesD(response.title, response.description, response.keywords);
                } else {
                    $window.location.href = "/err404.html";
                }
            });
        }
    }
   
    //date format 
    function organizeDate(date) {
        if (date) {
            var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var dateObj = new Date(date);
            var month = dateObj.getUTCMonth(); //months from 1-12
            var day = dateObj.getUTCDate();
            var year = dateObj.getUTCFullYear();
            var dayName = dateObj.getDay();
            var newdate = days[dayName] + ", " + monthNames[month] + " " + day + ", " + year + " at " + formatAMPM(dateObj);
            return newdate;
        }
    }
    //Time Formate
    function formatAMPM(date) {
        if (date) {
            var hours = date.getHours();
            var minutes = date.getMinutes();
            var ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // the hour '0' should be '12'
            minutes = minutes < 10 ? '0' + minutes : minutes;
            var strTime = hours + ':' + minutes + ' ' + ampm;
            return strTime;
        }
    }
    //bind comments
    function BindComments(guidId) {
        if (vm.guideResponse && vm.guideResponse.cmtFlag == true) {
            vm.cmntShow = true;
            if (guidId != "" && guidId != undefined) {
                showLoader();
                vm.pgNo = 1;
                dtipcmtSrvc.getCmnts(guidId, vm.pgNo, vm.pgSize, function (response, status) {
                    if (status == 200) {
                        vm.guidId = guidId;
                        vm.data = response;
                        vm.scrollable = true;
                        if (parseInt(vm.pgNo) == 1)
                            vm.cmtCnt = response.commentCnt;
                    }
                });
                hideLoader();
            }
        } else {
            vm.cmntShow = false;
        }
    }
    //add comments
    vm.AddCmt = function () {
        if (vm.comment) {
            //comment type 1 for dating tip comments
            dtipcmtSrvc.addComment(vm.comment, 0, vm.guidId, vm.memId, 1, firstName, profilePicPath, function (response, status) {
                if (status == 200) {
                    vm.cancelCmt();
                    BindComments(vm.guidId);
                }
            });
        }
    }
    //add reply
    vm.AddRply = function (cmtId) {
        if (cmtId != "" && cmtId != undefined) {
            //comment type 1 for dating tip comments
            dtipcmtSrvc.addComment(vm.addRplyText, cmtId, vm.guidId, vm.memId, 1, firstName, profilePicPath, function (response, status) {
                if (status == 200) {
                    BindComments(vm.guidId);
                }
            });
        }
    }
    //update comment
    vm.updateCmt = function (cmtId) {
        if (cmtId != "" && cmtId != undefined && $("#edtCmt" + cmtId).val() != "") {
            dtipcmtSrvc.updateCmnt(cmtId, $("#edtCmt" + cmtId).val(), vm.memId, function (response, status) {
                if (status == 200) {
                    BindComments(vm.guidId);
                }
            });
        }
    }
    //update reply
    vm.updateRply = function (cmtId) {
        if (cmtId != "" && cmtId != undefined && $("#edtRply" + cmtId).val() != "") {
            dtipcmtSrvc.updateCmnt(cmtId, $("#edtRply" + cmtId).val(), vm.memId, function (response, status) {
                if (status == 200) {
                    BindComments(vm.guidId);
                }
            });
        }
    }
    //delete comment or reply
    vm.deleteCmt = function () {
        if (vm.CmntId != "" && vm.CmntId != undefined) {
            dtipcmtSrvc.deleteCmnt(vm.CmntId, vm.memId, function (response, status) {
                if (status == 200) {
                    $('#deleteCmtpop').modal('hide');
                    BindComments(vm.guidId);
                }
            });
        }
    }
    //bind more replys
    vm.moreRplys = function (cmtId) {
        var pgNo = parseInt($("#rplyPgNo" + cmtId).attr("data-rplyPgNo"), 10) + 1;
        $("#rplyPgNo" + cmtId).attr("data-rplyPgNo", pgNo);
        if (cmtId != "" && cmtId != undefined) {
            //alert("cmtId" + cmtId + "pgNo" + pgNo + "rplyPgSize" + vm.rplyPgSize);
            dtipcmtSrvc.replysByCmtId(cmtId, pgNo, vm.rplyPgSize, function (response, status) {
                showLoader();
                if (status == 200) {
                    //alert(response.length);
                    for (var i = 0; i < response.length; i++) {
                        vm.data.Replies[cmtId].push({ "commentId": response[i].commentId, "comments": response[i].comments, "replyId": response[i].replyId, "dateCreated": response[i].dateCreated, "dateCreatedTimeStamp": response[i].dateCreatedTimeStamp, "firstName": response[i].firstName, "profilePic": response[i].profilePic, "memberId": response[i].memberId });
                    }
                }
                hideLoader();
                $("#dvRpl" + cmtId).hide();
            });
        }
    }

    vm.delPopup = function (commentId) {
        vm.CmntId = commentId;
    }

    vm.clearReplies = function (cmtId) {
        $("#dvaddRply" + cmtId).show();
        $("[id*=dvaddRply]").not($("#dvaddRply" + cmtId)).hide();
        vm.addRplyText = "";
        $('[id^=addRply]').attr('placeholder', "Write your comment here");
        $("[id^=addRply]").css('background-image', 'url(https://pccdn.pyar.com/pcimgs/wrcmnt.png)');
        $("[id*=dvEdt]").not($("#dvEdt" + cmtId)).hide();
        $("[id*=dvReadOnly]").show();
    }

    vm.clearComments = function (cmtId) {
        $("[id*=dvaddRply]").not($("#dvaddRply" + cmtId)).hide();
        $("[id*=dvEdt]").not($("#dvEdt" + cmtId)).hide();
        $("#dvEdt" + cmtId).show();
        $("[id*=dvReadOnly]").show();
        $("#edtRply" + cmtId).val($("#rply" + cmtId).text());
    }
    vm.clearEdits = function (cmtId) {
        $("[id*=dvEdt]").not($("#dvEdt" + cmtId)).hide();
        $("#dvEdt" + cmtId).show();
        $("[id*=dvReadOnly]").not($("#dvReadOnly" + cmtId)).show();
        $("[id*=dvaddRply]").hide();
        $("#edtCmt" + cmtId).val($("#cmt" + cmtId).text());
    }

    vm.cancelCmt = function () {
        vm.comment = "";
        vm.cmtPlaceHolder = "Write your comment here";
        $("#txtCmnt").css('background-image', 'url(https://pccdn.pyar.com/pcimgs/wrcmnt.png)');
    }

    //set sec id on tab click for selected index on sections
    vm.onClickTab = function (secId) {
        dtipdataSrvc.setSecId(secId);
    }
    vm.gotoSections = function () {
        $rootScope.selectedTabId = vm.selectedId;
        $state.go('dating-tips');       
    }

    ////getting search tips
    //vm.srchTipsG = function ($event) {
    //    var keyCode = $event.which || $event.keyCode;
    //    if (keyCode === 13 && vm.searchText != undefined && vm.searchText != "") {
    //        dtipdataSrvc.setSearchData(vm.searchText);
    //        $location.path("/dating-tip-srch.html");
    //    }
    //}
    //when open individual tip scrool to top
    vm.scrolTop = function () {
        $('html, body').scrollTop(0);
    }
    ////clear the search text on clear click
    //vm.clearSearch = function () {
    //    vm.searchText = '';
    //}
    //checking the value is null or undefined 
    //function checkNullOrUndefined(val) {
    //    return !(angular.isUndefined(val) || val === null);//true if the value is null or undefined;
    //}
    //preparing only 100 chars for tip content with three dots
    function preapareTipContent(text, len, dtCnt) {
        if (text) {
            var tempDv = document.createElement("DIV");
            tempDv.innerHTML = text;
            var resultText = tempDv.innerText.trim();

            if (resultText.length > len)
                return resultText.substring(0, (len - dtCnt)) + "...";
            else
                return resultText;
        }
    }
    //$scope.$on('$viewContentLoaded', function () {
    //    //Here your view content is fully loaded !!
    //    //Here you can write your custom logic which will execute after content loaded.      
    //    $timeout(function () {
    //        addThisSocailSharing();
    //    }, 0);
    //});


    vm.isUsrCmt = function (cmtMemId) {
        if (vm.memId == cmtMemId)
            return true;
        else
            return false;
    }

    vm.registerUsr = function () {
        $('#signinCmtPop').modal('hide');
        $window.open('/register.html', '_blank');
    }

    vm.memberCollection = getSessionSrvc.p_pgc();
    //need to get gender from comment api
    vm.profileImageSrc = function (imgPath) {
        return $filter("PrflPicFltr")(imgPath, true, vm.memberCollection);
    }
    vm.txtCmtDsbld = false;
    vm.cmtFocus = function (type) {
        if (vm.memId != null && vm.memId != "" && vm.memId != undefined) {
            vm.txtCmtDsbld = false;
            $('#signinCmtPop').modal('hide');
            if (type == 'C') {
                vm.cmtPlaceHolder = "";
                $("#txtCmnt").css('background-image', 'none');
                $("[id*=dvEdt]").hide();
                $("[id*=dvaddRply]").hide();
                $("[id*=dvReadOnly]").show();
            }
            else {
                $("[id^=addRply]").attr('placeholder', '');
                $("[id^=addRply]").css('background-image', 'none');
            }
        } else {
            $rootScope.pgName = vm.guidePageName;
            window.sessionStorage.setItem("Dtppn", vm.guidePageName);
            $('#signinCmtPop').modal('show');
            vm.txtCmtDsbld = true;
            $("#txtEmail").attr("placeholder", "Email");
            $("#txtEmail").addClass("bgWht");
            $("#txtPwd").attr("placeholder", "Password");
            $("#txtPwd").addClass("bgWht");
        }
    }
    vm.clsLgnPopup = function () {
        vm.txtCmtDsbld = false;
    }
    vm.cmtBlur = function (type, cmtId) {
        if (type == 'C') {
            if (vm.comment == "" || vm.comment == undefined) {
                vm.cmtPlaceHolder = "Write your comment here";
                $("#txtCmnt").css('background-image', 'url(https://pccdn.pyar.com/pcimgs/wrcmnt.png)');
            }
        }
        else {
            if (vm.addRplyText == "" || vm.addRplyText == undefined) {
                $("[id^=addRply]").attr('placeholder', 'Write your comment here');
                $("[id^=addRply]").css('background-image', 'url(https://pccdn.pyar.com/pcimgs/wrcmnt.png)');
            }
        }
    }

    //comment change event
    vm.commentChange = function (type) {
        if (type == 'C') {
            if (vm.comment && vm.comment.length > 1500) {
                vm.cmtPlaceHolder = "Must be < 1500 characters";
                vm.comment = null;
            }
        }
        else if (type == 'R') {
            if (vm.addRplyText && vm.addRplyText.length > 1500) {
                $("[id^=addRply]").attr('placeholder', 'Must be < 1500 characters');
                vm.addRplyText = null;
            }
        }
    }

    vm.replyCancel = function (cmtId) {
        $("#addRply" + cmtId).val("");
        $("#dvaddRply" + cmtId).hide();
    }

    //function to get similar tips
    function similarTips(guidId) {
        //service for getting related tips
        if (guidId != "" && guidId != undefined) {
            showLoader();
            dtipSrvc.similarTips(guidId, function (response, status) {
                if (response.length > 0 && status == 200) {
                    //if related tips are available we are showing the data in div else hiding the div
                    vm.hasRelTips = true;
                    for (var i = 0; i < response.length; i++) {
                        response[i].guideContent = preapareTipContent(response[i].guideContent, 85, 3);
                    }
                    vm.guides = response;
                } else {
                    vm.hasRelTips = false;
                }
                //hideLoader();
                vm.pgVisble();
            });
        }
    }

    $scope.scrollLoad = function () {
        if (vm.scrollable) {
            if ($(window).scrollTop() >= (($(document).height() - $("#pcFtr").outerHeight() - 20) - $(window).height())) {
                if (vm.data["Comments"].length == (vm.pgNo * vm.pgSize)) {
                    vm.pgNo++;
                    dtipcmtSrvc.getCmnts(vm.guidId, vm.pgNo, vm.pgSize, function (response, status) {
                        showLoader();
                        if (status == 200) {
                            if (response.Comments != undefined) {
                                if (response.Comments.length == 0 || response.Comments.length < vm.pgSize)
                                    vm.scrollable = false;
                                for (var i = 0; i < response.Comments.length; i++) {
                                    vm.data.Comments.push({ "commentId": response.Comments[i].commentId, "memberId": response.Comments[i].memberId, "comments": response.Comments[i].comments, "replyId": response.Comments[i].replyId, "dateCreated": response.Comments[i].dateCreated, "dateCreatedTimeStamp": response.Comments[i].dateCreatedTimeStamp, "firstName": response.Comments[i].firstName, "profilePic": response.Comments[i].profilePic });
                                }
                                Object.assign(vm.data.Replies, response.Replies);
                            }
                        }
                        hideLoader();
                    });
                }
            }
        }
    }
    vm.bindImgSrc = function (imgPath) {
        return addCdnPath(imgPath);
    }
    //function for updating Socialsharing url
    vm.socialShares = function (classNm, pgType, dtipPageUrl, title) {
        updatingSocialSharingUrl(classNm, pgType, dtipPageUrl, title);
    }
}]);

function edtCncl(cmtId) {
    var dvEdt = "dvEdt" + cmtId;
    var dvReadOnly = "dvReadOnly" + cmtId;
    $("#" + dvEdt).hide();
    $("#" + dvReadOnly).show();
}

$('body').click(function () {
    $("ul[id^=drpEdDl]").each(function (i, e) {
        var target = event.target.nodeName;
        if (target != "IMG") {
            $(e).hide();
        }
    });

});
