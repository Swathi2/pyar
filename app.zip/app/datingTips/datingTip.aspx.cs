﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Text;
using System.Net;
using System.IO;

public partial class app_datingTips_datingTip : BasePage
{
    #region Global Variable Declaration
    public string title = "", description = "", keywords = "", secId = "0", videoUrl = "", pageUrl = "";
    string imageCdnPath = "https://pccdn.pyar.com";
    private bool cmntFlag = false;
    #endregion

    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(Request.QueryString["dtName"]))
        {
            if (!IsPostBack)
            {
                BindData();
                LoadScripts();
            }
        }
        else
            Response.Redirect("/dating-tips.html");
    }
    #endregion

    #region BindData
    private void BindData()
    {
        string dtName = Request.QueryString["dtName"].ToString();
        if (dtName.Substring(dtName.Length - 5) != ".html")
            dtName += ".html";
        dynamic data = new JObject();
        data.guidePageName = "/" + dtName;
        var tipData = ExecuteURL("https://pcapi.pyar.com/api/datingtips/dtinfo/", "POST", data.ToString());
        if (string.IsNullOrEmpty(tipData))
        {
            Response.Redirect("/dating-tips.html");
            return;
        }
        var pgTipData = JObject.Parse(tipData);
        if (pgTipData != null && pgTipData.tip != null)
        {
            JObject tipDataObj = pgTipData.tip;
            #region bind dating tip content
            h1dtName.InnerText = lblDtName.Text = tipDataObj["guideName"].ToString();
            hdndtPageName.Value = tipDataObj["guidePageName"].ToString();
            lblPostDt.Text = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Convert.ToDateTime(tipDataObj["dateTimeCreated"]).Month) + " "
                             + Convert.ToDateTime(tipDataObj["dateTimeCreated"]).Day.ToString() + ", "
                             + Convert.ToDateTime(tipDataObj["dateTimeCreated"]).Year.ToString();
            lbldtAuthor.Text = tipDataObj["aName"].ToString();
            lblSecName.Text = tipDataObj["secName"].ToString();
            lblContent.Text = tipDataObj["guideContent"].ToString();
            hdnGuideId.Value = tipDataObj["guidId"].ToString();
            secId = tipDataObj["secId"].ToString();
            title = tipDataObj["title"].ToString();
            description = tipDataObj["description"].ToString();
            keywords = tipDataObj["keywords"].ToString();
            cmntFlag = Convert.ToBoolean(tipDataObj["cmtFlag"]);
            pageUrl = "https://dev.pyar.com/dating-tip/" + dtName;
            videoUrl = tipDataObj["videoUrl"].ToString();
            if (videoUrl != "")
            {
                string[] video = videoUrl.Split(new string[] { "/" }, StringSplitOptions.RemoveEmptyEntries);
                ancPinterest.Attributes.Add("href", "https://www.pinterest.com/pin/create/button/?url="+ pageUrl +"&media=http://img.youtube.com/vi/"+ video[video.Length - 1] + "/0.jpg&description="+description +"");
            }
            else
                ancPinterest.Attributes.Add("href", "https://www.pinterest.com/pin/create/button/?url=" + pageUrl + "&media="+imageCdnPath + tipDataObj["bannerThumbnail"].ToString()+"&description=" + description + "");
            #endregion

            #region Guide View Count Update
            if (!string.IsNullOrEmpty(tipDataObj["guidId"].ToString()))
            {
                string ipAddress = "";
                if (Session["guideview"] == null || !Session["guideview"].ToString().Contains("," + tipDataObj["guidId"].ToString() + ","))
                {
                    if (Request.ServerVariables["REMOTE_ADDR"] != null)
                        ipAddress = Request.ServerVariables["REMOTE_ADDR"];
                    if (Session["guideview"] == null)
                        Session["guideview"] = "," + tipDataObj["guidId"].ToString() + ",";
                    else
                        Session["guideview"] = Session["guideview"].ToString() + tipDataObj["guidId"].ToString() + ",";
                    Utilities utlObj = new Utilities();
                    utlObj.GuidesViewCntU(Convert.ToInt32(tipDataObj["guidId"]), ipAddress);
                }
            }
            #endregion

            #region Bind Related and Other Tips, Videos and Quotes
            if (pgTipData.rltdTips != null)
                BindRelatedTips(pgTipData.rltdTips);

            if (pgTipData.otherTips != null)
                BindOtherTips(pgTipData.otherTips);

            if (pgTipData.rltdVideos != null)
                BindRelatedVideos(pgTipData.rltdVideos);

            if (pgTipData.otherVideos != null)
                BindOtherVideos(pgTipData.otherVideos);

            if (pgTipData.rltdQuotes != null)
                BindRelatedQuotes(pgTipData.rltdQuotes);

            if (pgTipData.otherQuotes != null)
                BindOtherQuotes(pgTipData.otherQuotes);
            #endregion
        }
        else
        {
            Response.Redirect("/dating-tips.html");
            return;
        }
    }
    #endregion

    #region BindRelatedTips
    public void BindRelatedTips(JArray relatedTipData)
    {
        if (relatedTipData != null && relatedTipData.Count > 0)
        {
            List<tblRelTips> lstReltips = new List<tblRelTips>();
            for (int i = 0; i < relatedTipData.Count; i++)
                lstReltips.Add(new tblRelTips()
                {
                    guidId = Convert.ToInt32(relatedTipData[i]["guidId"]),
                    secName = relatedTipData[i]["secName"].ToString(),
                    guideName = relatedTipData[i]["guideName"].ToString(),
                    guidePageName = relatedTipData[i]["guidePageName"].ToString(),
                    bannerThumbnail = relatedTipData[i]["bannerThumbnail"].ToString(),
                });
            rptRelTips.DataSource = lstReltips;
            rptRelTips.DataBind();
            dvRelTips.Visible = true;
        }
        else
            dvRelTips.Visible = false;
    }
    #endregion

    #region BindOtherTips
    public void BindOtherTips(JArray otherTipData)
    {
        if (otherTipData != null && otherTipData.Count > 0)
        {
            List<tblRelTips> lstOthrtips = new List<tblRelTips>();
            for (int i = 0; i < otherTipData.Count; i++)
                lstOthrtips.Add(new tblRelTips()
                {
                    guidId = Convert.ToInt32(otherTipData[i]["guidId"]),
                    guideName = otherTipData[i]["guideName"].ToString(),
                    guidePageName = otherTipData[i]["guidePageName"].ToString(),
                });
            rptOthrTips.DataSource = lstOthrtips;
            rptOthrTips.DataBind();
            dvOthrTips.Visible = true;
        }
        else
            dvOthrTips.Visible = false;
    }
    #endregion

    #region BindRelatedVideos
    public void BindRelatedVideos(JArray relatedVideoData)
    {
        if (relatedVideoData != null && relatedVideoData.Count > 0)
        {
            List<tblRelTips> lstRelVideos = new List<tblRelTips>();
            for (int i = 0; i < relatedVideoData.Count; i++)
                lstRelVideos.Add(new tblRelTips()
                {
                    guidId = Convert.ToInt32(relatedVideoData[i]["guidId"]),
                    secName = relatedVideoData[i]["secName"].ToString(),
                    guideName = relatedVideoData[i]["guideName"].ToString(),
                    guidePageName = relatedVideoData[i]["guidePageName"].ToString(),
                    videoUrl = relatedVideoData[i]["videoUrl"].ToString(),
                });

            rptRelVideos.DataSource = lstRelVideos;
            rptRelVideos.DataBind();
            dvRelVideos.Visible = true;
        }
        else
            dvRelVideos.Visible = false;
    }
    #endregion

    #region BindOtherVideos
    public void BindOtherVideos(JArray otherVideoData)
    {
        if (otherVideoData != null && otherVideoData.Count > 0)
        {
            List<tblRelTips> lstOtherVideo = new List<tblRelTips>();
            for (int i = 0; i < otherVideoData.Count; i++)
                lstOtherVideo.Add(new tblRelTips()
                {
                    guidId = Convert.ToInt32(otherVideoData[i]["guidId"]),
                    guideName = otherVideoData[i]["guideName"].ToString(),
                    guidePageName = otherVideoData[i]["guidePageName"].ToString(),
                });
            rptOthrVideos.DataSource = lstOtherVideo;
            rptOthrVideos.DataBind();
            dvOthrVideos.Visible = true;
        }
        else
            dvOthrVideos.Visible = false;
    }
    #endregion

    #region BindRelatedQuotes
    public void BindRelatedQuotes(JArray relatedQuoteData)
    {
        if (relatedQuoteData != null && relatedQuoteData.Count > 0)
        {
            List<tblRelTips> lstRelQuotes = new List<tblRelTips>();
            for (int i = 0; i < relatedQuoteData.Count; i++)
                lstRelQuotes.Add(new tblRelTips()
                {
                    guidId = Convert.ToInt32(relatedQuoteData[i]["guidId"]),
                    secName = relatedQuoteData[i]["secName"].ToString(),
                    guideName = relatedQuoteData[i]["guideName"].ToString(),
                    guidePageName = relatedQuoteData[i]["guidePageName"].ToString(),
                    bannerThumbnail = relatedQuoteData[i]["bannerThumbnail"].ToString(),
                    videoUrl = relatedQuoteData[i]["videoUrl"].ToString(),
                });
            rptRelQuotes.DataSource = lstRelQuotes;
            rptRelQuotes.DataBind();
            dvRelQuotes.Visible = true;
        }
        else
            dvRelQuotes.Visible = false;
    }
    #endregion

    #region BindOtherQuotes
    public void BindOtherQuotes(JArray otherQuoteData)
    {
        if (otherQuoteData != null && otherQuoteData.Count > 0)
        {
            List<tblRelTips> lstOtherQuote = new List<tblRelTips>();
            for (int i = 0; i < otherQuoteData.Count; i++)
                lstOtherQuote.Add(new tblRelTips()
                {
                    guidId = Convert.ToInt32(otherQuoteData[i]["guidId"]),
                    guideName = otherQuoteData[i]["guideName"].ToString(),
                    guidePageName = otherQuoteData[i]["guidePageName"].ToString(),
                });
            rptOtherQuotes.DataSource = lstOtherQuote;
            rptOtherQuotes.DataBind();
            dvOtherQuotes.Visible = true;
        }
        else
            dvOtherQuotes.Visible = false;
    }
    #endregion

    #region LoadScripts
    private void LoadScripts()
    {
        AddNewLine();
        base.AddMetaTitle(title);
        base.AddMetaTag("description", description);
        base.AddMetaTag("keywords", keywords);
        base.AddOtherTag("<meta charset=\"utf-8\" />");
        base.AddOtherTag("<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />");
        base.AddMetaViewPoint();
        base.AddOtherTag("<link href=\"https://fonts.googleapis.com/css?family=Open+Sans:100light,400,600,700\" rel=\"stylesheet\" />");
        base.AddOtherTag("<link href=\"/styles/pc.css\" rel=\"stylesheet\" />");
        base.AddOtherTag("<script type='text/javascript' src='/scripts/dtscriptlib.js'></script>");
        base.AddOtherTag("<script src='/scripts/bootstrap.min.js'></script>");
        base.AddOtherTag("<script src='//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-58c79badfd3a742e'></script>");
        base.AddOtherTag("<script type='text/javascript' src='/scripts/srct.js'></script>");
        if (cmntFlag)
        {
            dvComments.Visible = true;
            base.AddOtherTag("<script src='/scripts/dtCmnts.js'></script>");
        }
    }
    #endregion

    #region ExecuteURL
    public string ExecuteURL(string url, string metdod = "GET", string postData = "")
    {
        try
        {
            HttpWebRequest webRequest = WebRequest.Create(url) as HttpWebRequest;
            webRequest.Method = metdod;
            if (metdod == "POST")
            {
                webRequest.ContentType = "application/json";
                Encoding encoding = new UTF8Encoding();
                byte[] dataBytes = encoding.GetBytes(postData);
                webRequest.ContentLength = dataBytes.Length;
                using (Stream stream = webRequest.GetRequestStream())
                    stream.Write(dataBytes, 0, dataBytes.Length);
            }

            using (WebResponse response = webRequest.GetResponse())
            {
                using (Stream dataStream = response.GetResponseStream())
                {
                    using (StreamReader responseReader = new StreamReader(dataStream))
                    {
                        return responseReader.ReadToEnd().ToString();
                    }
                }
            }
        }
        catch (Exception)
        {
            return "";
        }
    }
    #endregion
}