﻿angular.module("app").service('dtipcmtSrvc', ['$http', '$window', function ($http, $window) {
    this.getCmnts = function (guidId, pgNo, pgSige, callBackFun) {
        $http({
            method: "GET",
            url: getApiDomainUrl() + "/api/datingtips/gc/" + guidId + "/" + pgNo + "/" + pgSige + "",
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            callBackFun(response, status);
        }).error(function (error, status) {
            alert("Something Going Wrong from webmethod.!");
        });
    };
    //this.getRplys = function (guidId, pgNo, pgSige, callBackFun) {
    //    $http({
    //        method: "GET",
    //        url: getApiDomainUrl() + "/api/datingtips/gcr/" + guidId + "/" + pgNo + "/" + pgSige + "",
    //        headers: {
    //            'Content-Type': 'application/json; charset=utf-8',
    //            'dataType': 'json'
    //        }
    //    }).success(function (response, status) {
    //        callBackFun(response, status);
    //    }).error(function (error, status) {
    //        alert("Something Going Wrong from webmethod.!");
    //    });
    //};
    this.addComment = function (cmt, replId, PgId, memId, cmnType, firstName, profilePicPath, callBackFun) {
        $http({
            method: "POST",
            url: getApiDomainUrl() + "/api/datingtips/gca",
            data: { comment: cmt, replyId: replId, pageId: PgId, memberId: memId, commentType: cmnType, firstName: firstName, profilePicPath: profilePicPath },
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            callBackFun(response, status);
        }).error(function (error, status) {
            alert("Something Going Wrong from webmethod.!");
        });
    };
    this.deleteCmnt = function (cmnTd, memId, callBackFun) {
        $http({
            method: "GET",
            url: getApiDomainUrl() + "/api/datingtips/gcd/" + cmnTd + "/" + memId + "",
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            callBackFun(response, status);
        }).error(function (error, status) {
            $window.location.href = "/dating-tips.html";
        });
    };
    this.updateCmnt = function (cmtId, cmt, memId, callBackFun) {       
        $http({
            method: "POST",
            url: getApiDomainUrl() + "/api/datingtips/gcu",
            data: { commentId: cmtId, comment: cmt, memberId: memId },
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            callBackFun(response, status);
        }).error(function (error, status) {
            alert("Something Going Wrong from webmethod.!");
        });
    };

    this.replysByCmtId = function (cmnTd, pgNo, pgSige, callBackFun) {       
        $http({
            method: "GET",
            url: getApiDomainUrl() + "/api/datingtips/gcr/" + cmnTd + "/" + pgNo + "/" + pgSige + "",
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            callBackFun(response, status);
        }).error(function (error, status) {
            $window.location.href = "/dating-tips.html";
        });
    };
}]);