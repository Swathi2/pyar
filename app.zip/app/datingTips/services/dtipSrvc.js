﻿                     angular.module("app").service('dtipSrvc', ['$http','$window',function ($http,$window) {
    this.tipSectionG = function (callBackFun) {
        $http({
            method: "GET",
            url: getApiDomainUrl() + "/api/datingtips/gs",
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            callBackFun(response,status);
        }).error(function (error, status) {
            alert("Something Going Wrong from webmethod.!");
        });
    };
    this.tipsBySecId = function (secId, pgNo, pgSige, callBackFun) {
        $http({
            method: "GET",
            url: getApiDomainUrl() + "/api/datingtips/dtlst/" + secId + "/" + pgNo + "/" + pgSige + "",
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response,status) {
            callBackFun(response,status);
        }).error(function (error, status) {
            alert("Something Going Wrong from webmethod.!");
        });
    };
    this.srchTipsG = function (searchText,callBackFun) {
        $http({
            method: "POST",
            url: getApiDomainUrl() + "/api/datingtips/dtsrch",
            data:JSON.stringify(searchText),
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response,status) {
            callBackFun(response, status);
        }).error(function (error, status) {
            alert("Something Going Wrong from webmethod.!");
        });
    };
    this.tipByPageName = function (GuidPageName, callBackFun) {
        $http({
            method: "POST",
            url: getApiDomainUrl() + "/api/datingtips/gd",
            data: JSON.stringify(GuidPageName),
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response,status) {
            callBackFun(response,status);
        }).error(function (error, status) {
            $window.location.href = "https://dev.pyar.com/dating-tips.html";
        });
    };
    this.similarTips = function (guidId, callBackFun) {
        $http({
            method: "GET",
            url: getApiDomainUrl() + "/api/datingtips/sg/" + guidId + "",
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response,status) {
            callBackFun(response,status);
        }).error(function (error, status) {
            alert("Something Going Wrong from webmethod.!");
        });
    };

    this.GetTrendingGuides = function (callBackFun) {
        $http({
            method: "GET",
            url: getApiDomainUrl() + "/api/datingtips/tgd/",
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            callBackFun(response, status);
        }).error(function (error, status) {
            alert("Something Going Wrong from webmethod.!");
        });
    };
}]);