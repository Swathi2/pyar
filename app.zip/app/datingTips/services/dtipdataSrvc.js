﻿angular.module("app").factory('dtipdataSrvc', function () {
    var SearchData = [];
    var sectionsData = [];
    var SecId = null;
    var SecType = 1;

    //function setSearchData(data) { SearchData = data; }
    //function getSearchData() { return SearchData; }
    function setSectionsData(data) { sectionsData = data; }
    function getSectionsData() { return sectionsData; }
    function setSecId(data) { SecId = data; }
    function getSecId() { return SecId; }
    function setSecType(data) { SecType = data; }
    function getSecType() { return SecType; }

    return {
        //setSearchData: setSearchData,
       // getSearchData: getSearchData,
        setSectionsData: setSectionsData,
        getSectionsData: getSectionsData,
        setSecId: setSecId,
        getSecId: getSecId,
        setSecType: setSecType,
        getSecType: getSecType,
    }
});