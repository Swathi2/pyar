﻿function tabMenu() {
    $(document).ready(function () {
        //make all tabs data invisible on load
        $("#pchtbdv div[id^='tb']").attr('style', 'display:none');
        $("#pchtb a[id^='tb']").click(function () {
            //getting cliked one id
            var ancId = $(this).attr('id');
            activeAccountTab(ancId);
        })

        function activeAccountTab(ancId) {
            //add active class for clicked one
            $("#pchtb #" + ancId).addClass('active');
            //removing active class for links (tab data links)
            $("#pchtb a[id^='tb']").not("#pchtb #" + ancId).removeClass('active');
            //make all tabs data invisible 
            $("#pchtbdv div[id^='tb']").attr('style', 'display:none');
            //make clicked tab data visible 
            $("#pchtbdv div[id='" + ancId + "dv']").attr('style', 'display:');
        }
        //for showing the first link data visible - raised the click event
        $("#pchtb #tb1").click();
    });

    (function ($) {
        $(document).on('show.bs.tab', '.nav-tabs-responsive [data-toggle="tab"]', function (e) {
            var $target = $(e.target);
            var $tabs = $target.closest('.nav-tabs-responsive');
            var $current = $target.closest('li');
            var $next = $current.next();
            var $prev = $current.prev();
            var updateDropdownMenu = function ($el, position) {
                $el
                    .removeClass('pull-xs-left pull-xs-center pull-xs-right')
                    .addClass('pull-xs-' + position);
            };

            $tabs.find('>li').removeClass('next prev');
            $prev.addClass('prev');
            $next.addClass('next');
        });
    })(jQuery);

}