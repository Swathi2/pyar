﻿var imgCdnPath = "https://pccdn.pyar.com";
/**********************************************************
                Common Service start
**********************************************************/
angular.module("app").service('cmnSrvc', ['$http', 'getSessionSrvc', function ($http, getSessionSrvc) {

    var mId = function () { return getSessionSrvc.p_mId(); }

    this.memReport = function (reportedBy, reportedOn, refType, refId, rptReasonType, rptReason, funCallBack) {
        //refType: 1- reporting on member, 2- reporting on Photo
        //refId: 1- memeberId, 2- PhotoId
        var data = { reportedBy: reportedBy, reportedOn: reportedOn, refType: refType, refId: refId, rptReasonType: rptReasonType, rptReason: rptReason }
        var url = getApiDomainUrl() + "/api/profile/rptmbr";
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.memFlirtCheck = function (fmId, tmId, funCallBack) {
        var url = getApiDomainUrl() + "/api/actions/flrtchk/" + fmId + "/" + tmId;
        GetServiceByURL($http, url, funCallBack);
    };
    this.ftPOPCheck = function (refid) {
        //refid: 1-trophies, 2- favorite, 3- unfavorite, 4-flirt, 5 - Trail Expiry, 
        var ftpop = getSessionSrvc.p_ftPOP().split(",")[0].split("#");
        if (ftpop[refid - 1] == "1")
            return true;
        else
            return false;
    }
    this.ftPOPCheckTrophy = function (trophies, refid) {
        var ftpop = trophies.split("#");
        if (ftpop[refid - 1] == "1")
            return true;
        else
            return false;
    }
    // function to update unfav modal has opened
    this.ftPOPUpdate = function (refid) {
        //refid: 6- favorite, 7- unfavorite, 8-flirt
        var ftPOPS = getSessionSrvc.p_ftPOP().split(",");
        var ftpop = ftPOPS[0].split("#");
        ftpop[refid - 1] = "0";
        var ftpopNew = ftpop.join("#");
        getSessionSrvc.u_ssnd("ftPOP", ftpopNew + "," + ftPOPS[1]);

        var url = getApiDomainUrl() + "/api/registersignin/ftpopu/" + getSessionSrvc.p_mId() + "/" + refid + "/false";
        GetServiceByURL($http, url, '');
    }

    //Service for Member Hide check
    this.memberHideCheck = function (memberId, memHideId, funCallBack) {
        var url = getApiDomainUrl() + "/api/actions/hdchk/" + memberId + "/" + memHideId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Payment Prices
    this.getMSSP = function (memberId, funCallBack) {
        // var url = getApiDomainUrl() + "/api/pmthlpr/gmssp/" + memberId;
        //var url = getApiDomainUrl() + "/api/bt/gpi/" + memberId;
        var url = getApiDomainUrl() + "/api/pmthlpr/gpi/" + memberId
        GetServiceByURL($http, url, funCallBack);
    };


    //Card Details
    this.getCardDetails = function (memberId, funCallBack) {
        // var url = getApiDomainUrl() + "/api/pmthlpr/gmssp/" + memberId;
        //var url = getApiDomainUrl() + "/api/bt/gpi/" + memberId;
        var url = getApiDomainUrl() + "/api/bt/recgetcard/" + memberId
        GetServiceByURL($http, url, funCallBack);
    };

    //check if user is blocked
    this.getMemberBlockId = function (tmId, funCallBack) {
        var url = getApiDomainUrl() + "/api/actions/blkchkb/" + mId() + "/" + tmId;
        GetServiceByURL($http, url, funCallBack);
    }

    //Check Trail or Premium Expires
    this.isTrialOrPrmExpired = function () {
        var subscriptnEndDate = getSessionSrvc.p_subex();
        if (subscriptnEndDate) {
            var subExpDate = new Date(subscriptnEndDate);
            var premMember = getSessionSrvc.p_sub(); //1. Basic 2. Premium   
            var curDate = new Date();
            var trailMembr = getSessionSrvc.p_subtm()
            if (trailMembr != 1 || (premMember == 1 && (subExpDate < curDate))) return true;
            else return false;
        } else {
            return false;
        }
    }
    //session update from profile and membership ctrls
    this.sessionUpdate = function (response) {
        if (response.hasOwnProperty('sId')) getSessionSrvc.u_ssnd("sId", response["sId"]);
        if (response.hasOwnProperty('dateTimeSubscrbSt')) getSessionSrvc.u_ssnd("dateTimeSubscrbSt", response['dateTimeSubscrbSt']);
        if (response.hasOwnProperty('dateTimeSubscrbExp')) getSessionSrvc.u_ssnd("dateTimeSubscrbExp", response['dateTimeSubscrbExp']);
        if (response.hasOwnProperty('trialMember')) getSessionSrvc.u_ssnd("trialMember", response['trialMember']);
    }

    //Privacy policy service creation
    this.PPService = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/policies/pp";
        GetServiceByURL($http, url, funCallBack);
    }

    // Terms conditons service creation
    this.TCService = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/policies/tc";
        GetServiceByURL($http, url, funCallBack);
    }

    //get date based on time zone
    this.getDate = function (zone, utcDT,pageType) {
        try {
            var format = "";
            if (pageType == "membership")
                format = "MMMM, DD, YYYY";
            else
                format = "MMM, DD, YYYY";
            if (zone && utcDT) {
                if (zone.length > 0)
                    return moment.tz(moment.utc(utcDT), zone).format(format);
                else
                    return moment.utc(utcDT).format(format);
            }
            else
                return moment.tz(moment.utc(new Date()), zone).format(format);
        } catch (e) {
            console.log("vm.getDate  --  " + e.message);
            alert("vm.getDate  --  " + e.message);
        }
    };

    this.getTrialDays = function () {
        var trialDays = getSessionSrvc.p_trldays();
        if (trialDays)
            return trialDays + "-day";
        else
            return "365-day";
    };
}]);
/**********************************************************
                Common Service end
**********************************************************/










/**********************************************************
                Common Factory start
**********************************************************/
angular.module("app").factory('hbySearchFact', function () {
    var hbySearchData = [];

    function sethbySearchData(data) { hbySearchData = data; }
    function gethbySearchData() { return hbySearchData; }

    return {
        sethbySearchData: sethbySearchData,
        gethbySearchData: gethbySearchData,
    }
});

/**********************************************************
                Common Factory  end
**********************************************************/











/**********************************************************
                Common Filters start
**********************************************************/
angular.module("app").filter('htmlToPlaintext', function () {
    return function (text) {
        return text ? String(text).replace(/<[^>]+>/gm, '') : '';
    };
});

//filter for changing profile pic based on gender
angular.module("app").filter("PrflPicFltr", function () {
    //var dtn = new Date().valueOf();
    return function (pic, gndr, memberCollection) {
        if (pic == null || pic == "") {
            if (gndr == true) return gndr = "https://pccdn.pyar.com/pcimgs/profilePicM.jpg";
            else return gndr = "https://pccdn.pyar.com/pcimgs/profilePicF.jpg";
        }
        else
            return gndr = "https://pccdn.pyar.com" + pic.replace("/tnb/", "/tn/");
    }
});

/**********************************************************
                Common Filters end
**********************************************************/











/**********************************************************
                Common Directives start
**********************************************************/
//angular.module("app").directive('socailSharing', function ($timeout) {
//    return {
//        //only use as attributes
//        restrict: 'A',
//        link: function ($scope, $element, $attrs) {
//            if ($scope.$last === true) {
//                $timeout(function () {
//                    //$scope.$emit('addThisSocailSharing');
//                    addThisSocailSharing();
//                });
//            }
//        }
//    }
//});

//home.html,register.html,signin.html,signout.html,signinpwdreset.html
//header - fixed on scrolling and strip clolr change
//Usage <pc-scrollheader></pc-scrollheader>
angular.module("app").directive("pcScrollheader", function () { return { templateUrl: "/app/common/templates/scrollheader.html" } })

//for desktop devices
//<pc-msg></pc-msg>
angular.module("app").directive("pcMsg", function () {
    return {
        restrict: 'E',
        templateUrl: "/app/chat/templates/msg.html",
        controller: "msgCtrl",
        controllerAs: "msgCtrlAs"
    }
});
//<pc-feedback></pc-feedback>
angular.module("app").directive("pcFeedback", function () {
    return {
        restrict: 'E',
        templateUrl: "/app/feedback/templates/feedback.html",
        controller: "feedbackCtrl",
        controllerAs: "feedbackCtrlAs"
    }
});
//for mobile or tab devices
//<pc-msg-m></pc-msg-m>
angular.module("app").directive("pcMsgM", function () {
    return {
        restrict: 'E',
        templateUrl: "/app/chat/templates/msgM.html",
        controller: "msgMCtrl",
        controllerAs: "msgMCtrlAs"
    }
});

//othersmatchProfile
angular.module("app").directive("mtProfile", function () {
    return {
        restrict: 'E',
        templateUrl: "/app/profile/others/templates/mtProfile.html",
        controller: "othersprofileCtrl",
        controllerAs: "othersprofileCtrlAs"
    }
});
angular.module("app").directive("otherProfile", function () {
    return {
        restrict: 'E',
        templateUrl: "app/profile/others/templates/othersprofile.html",
    }
});

//creating custom directive for Comparing 
//ngCompare={{model which need to compare}}
angular.module("app").directive('ngCompare', function () {
    return {
        require: 'ngModel',
        link: function (scope, currentEl, attrs, ctrl) {
            var comparefield = document.getElementsByName(attrs.ngCompare)[0]; //getting first element
            compareEl = angular.element(comparefield);

            //current field key up
            currentEl.on('keyup', function () {
                if (compareEl.val() != "") {
                    var isMatch = currentEl.val() === compareEl.val();
                    ctrl.$setValidity('compare', isMatch);
                    scope.$digest();
                }
            });

            //Element to compare field key up
            compareEl.on('keyup', function () {
                if (currentEl.val() != "") {
                    var isMatch = currentEl.val() === compareEl.val();
                    ctrl.$setValidity('compare', isMatch);
                    scope.$digest();
                }
            });
        }
    }
});

//creating custom directive for Allow only Aphabets 
//allow-only-alphabets
angular.module("app").directive('allowOnlyAlphabets', function () {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {
                if (event.which >= 65 && event.which <= 90) {
                    // to allow alphabets keys  
                    return true;
                }
                else if ([8, 9, 13, 27, 32, 35, 36, 37, 38, 39, 40, 46].indexOf(event.which) > -1) {
                    // to allow backspace, enter, escape, arrows  
                    return true;
                }
                else {
                    event.preventDefault();
                    // to stop others  
                    return false;
                }
            });
        }
    }
});
//allow-only-Numbers
angular.module("app").directive('allowOnlyNumbers', function () {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (e) {
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||
                    // Allow: Ctrl+A, Command+A
                   (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                    // Allow: home, end, left, right, down, up
                   (e.keyCode >= 35 && e.keyCode <= 40)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105 || e.keyCode == 190)) {
                    e.preventDefault();
                }
            });
        }
    }
});


app.directive('allowOnlyLettersAndSpace', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                var transformedInput = text.replace(/[^a-zA-Z ]/g, '');
                if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                    ngModelCtrl.$render();
                }
                return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    }
});
//allow-only-country codes
angular.module("app").directive('allowCountryCodes', function () {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (e) {
                if ($.inArray(e.keyCode, [8, 9, 27, 13, 37, 39, 46, 107, 109, 110, 187, 189, 190]) !== -1 ||
                    // Allow: Ctrl+A, Command+A
                   (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                    // Allow: home, end, left, right, down, up
                   (e.keyCode >= 35 && e.keyCode <= 40)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            });
        }
    }
});

//creating custom directive for DOB Format
angular.module("app").directive('dobFormat', function () {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {

                var str = "~!@#$%^&*()";
                var val = str.indexOf(event.key.toString());

                if (val != -1) { event.preventDefault(); return false; }
                if (event.which >= 48 && event.which <= 57) { return true; }
                else if (event.which >= 96 && event.which <= 105) { return true; } // numLock keys on                    
                else if ([8, 9, 13, 27, 35, 36, 37, 38, 39, 40, 46].indexOf(event.which) > -1) { return true; }// to allow backspace, enter, escape, arrows  
                else { event.preventDefault(); return false; }
            });
        }
    }
});

//Createting custom directive for google recaptcha
//usage <pc-recaptcha></pc-recaptcha>
angular.module("app").directive('pcRecaptcha', function () {
    return {
        restrict: 'E',
        template: '<div class="g-recaptcha" data-sitekey="' + getGoogleClntId() + '" data-callback="recaptchaChk"></div>'


    }
});

angular.module("app").directive('edtComment', function ($compile) {
    return {

        link: function (scope, element, attrs) {
            var html = "<div id='dvEdt{{cmt.commentId}}'><p class='col-xs-12 npd'> <textarea id='edtCmt{{cmt.commentId}}' rows='2' class='form-control'  ng-bind='cmt.comments' ></textarea></p><p class='text-right'><a type='button' class='fvrte dtcnlbtn dvlst' data-id='{{cmt.commentId}}' onclick='javascript:edtCncl(" + scope.cmt.commentId + ")'>Cancel</a><input type='button' class='cmntbtn outlnone' value='Submit' ng-click='dtipCtrlAs.updateCmt(cmt.commentId)'/></p></div>",
            compiledElement = $compile(html)(scope);
            element.on('click', function (event) {
                var commentId = scope.cmt.commentId;
                var dvElement = angular.element(document.getElementById("cmtBlk" + commentId));

                dvElement.append(compiledElement);
                $("#dvReadOnly" + commentId).hide();
                $("#drpEdDl" + commentId).hide();
            });
        }
    }
});

angular.module("app").directive('edtRply', function ($compile) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var html = "<div id='dvEdt{{rply.commentId}}'><p class='npd'> <textarea rows='2' id='edtRply{{rply.commentId}}' class='form-control'  ng-bind='rply.comments'></textarea></p><p class='text-right'><a type='button' class='fvrte dtcnlbtn dvlst' onclick='javascript:edtCncl(" + scope.rply.commentId + ")'>Cancel</a><input type='button' class='cmntbtn outlnone' value='Submit' ng-click='dtipCtrlAs.updateRply(rply.commentId)'/></p></div>",
            compiledElement = $compile(html)(scope);
            element.on('click', function (event) {
                var commentId = scope.rply.commentId;
                var dvElement = angular.element(document.getElementById("rplBlk" + commentId));

                dvElement.append(compiledElement);
                $("#dvReadOnly" + commentId).hide();
                $("#drpEdDl" + commentId).hide();
            });
        }
    }
});

angular.module("app").directive('rplComment', function ($compile) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var html = "<div class='cmntbx cmtmgtp'><label class='col-xs-2 col-sm-2 col-lg-1 npd'>" +
                "<img style='width:45px;' src='https://pccdn.pyar.com/pcimgs/avatarM.png'></label><p class='col-xs-10 col-sm-10 col-lg-11'>" +
                "<textarea id='addRply{{cmt.commentId}}' rows='2' placeholder='Write your comment here' class='form-control wrcmnt' ng-model='$parent.dtipCtrlAs.addRplyText' ng-focus='dtipCtrlAs.cmtFocus()' ng-blur='dtipCtrlAs.cmtBlur()' data-target='#signinCmtPop'>Write your comments </textarea></p>" +
                "<p class='col-lg-12 text-right mbcnsb'><a type='button' class='cmtcnbtn dtcnlbtn dvlst' onclick='javascript:replyCancel(" + scope.cmt.commentId + ")'>Cancel</a><input type='button' class='cmntbtn outlnone' ng-disabled='!$parent.dtipCtrlAs.addRplyText && !dtipCtrlAs.isLogin' value='Submit' ng-click='dtipCtrlAs.AddRply(cmt.commentId)' /></p></div>",
            compiledElement = $compile(html)(scope);
            element.on('click', function (event) {
                var commentId = scope.cmt.commentId;
                var dvElement = angular.element(document.getElementById("addRply" + commentId));
                dvElement.append(compiledElement);
            });
        }
    }
});

angular.module("app").directive('autoTabTextbox', [function () {
    return {
        restrict: "A",
        link: function (scope, el, attrs) {
            el.bind('keyup', function (e) {
                if (this.value.length === this.maxLength) {
                    var element = document.getElementById(attrs.autoTabTextbox);
                    if (element) {
                        element.focus();
                    }
                }
            });
        }
    }
}]);

angular.module("app").directive('prsnltyImageSlider', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit(attr.prsnltyImageSlider);
                });
            }
        }
    }
});

angular.module("app").directive('trophyImageSlider', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            $timeout(scope.$eval(attrs.trophyImageSlider), 0);
        }
    }
});

angular.module("app").directive('onFinishRender', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true)
                $timeout(function () { scope.$emit(attr.onFinishRender); });
        }
    }
});

app.directive('onFinishRenderSortbyAsc', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$first === true)
                $timeout(function () { scope.$emit(attr.onFinishRenderSortbyAsc); });
        }
    }
});

angular.module("app").directive('onMpFinishRender', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            $timeout(scope.$eval(attrs.onMpFinishRender), 0);
        }
    }
});

angular.module("app").directive('onFinishtileRender', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit(attr.onFinishtileRender);
                }, 0);
            }
        }
    }
});

//directive from textbox text limit
app.directive('textLength', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attrs) {
            var limit = parseInt(attrs.textLength);
            angular.element(elem).on("keypress", function (e) {
                if (this.value.length == limit) {
                    if (e.which != 8 && e.which != 16 && e.which != 35 && e.which != 36 && e.which != 46) {
                        e.preventDefault();
                    }
                }
            });
        }
    }
});

//Directive for even loading Dating tips images
app.directive('imgLoad', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attrs) {
            elem.on('load', function (event, source) {
                scope.$apply(function () {
                    $("#" + attrs.imgid).attr('src', attrs.ngSrc)
                   elem.remove();
                });
            });
        }
    };
});
// Directive for Embeded Videos in dating tips 
app.directive('embedSrc', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var embdClass = '';
            if (attrs.isbnr == 'true') embdClass = 'dtpqtbgvideo';
            else if (attrs.isbnr == 'quote') embdClass = 'dtpqtembed';
            else embdClass = 'dtpqtvides';
            var embedHtml = "<p class="+ embdClass +"><embed src=" + attrs.embedSrc + " frameborder='0' allow='autoplay; encrypted-media'></p>"
            $(element).append(embedHtml)
        }
    };
})

//Directive for premium member
app.directive("matchTile", ['$rootScope', '$filter', '$timeout', '$location', '$window', '$state', 'cmnSrvc', 'msgSrvc', 'getSessionSrvc', 'othersprofileSrvc', 'srchSrvc',
    function ($rootScope, $filter, $timeout, $location, $window, $state, cmnSrvc, msgSrvc, getSessionSrvc, othersprofileSrvc, srchSrvc) {
        return {
            restrict: 'E',
            transclude: true,
            templateUrl: "/app/dashboard/templates/matchtilePrem.html",
            scope: {
                name: "=", tileindex: "=", tilepath: "@"
            },

            link: function (scope, elm, attrs, ctrl) {
                var vm = scope;
                var rs = $rootScope;
                var mId = getSessionSrvc.p_mId();
                var frmfn = getSessionSrvc.p_fn();
                var frmgndr = getSessionSrvc.p_gndr();
                var p_cntry = getSessionSrvc.p_cntry();
                var wdth = $(window).width() >= 1200 && $(window).width() <= 1400;
                var sId = function () { return getSessionSrvc.p_sub(); } //1. Basic 2. Premium

                vm.fvrtdImg = "https://pccdn.pyar.com/pcimgs/actions/fvrtd.svg";
                vm.fvImg = "https://pccdn.pyar.com/pcimgs/actions/fvrt.svg";
                vm.flirtlgtImg = "https://pccdn.pyar.com/pcimgs/actions/flirt-red.svg";
                vm.flirtImg = "https://pccdn.pyar.com/pcimgs/actions/flirt.svg";
                vm.ldrImg = "https://pccdn.pyar.com/pcimgs/acnLdr.svg";

                vm.calculateAge = function (val) { return calculateAge(val); }
                vm.gotoProfile = function (mId) { return "/match/" + getSessionSrvc.pce(mId); }
                vm.setMatch = function (mId) {
                    if ($(window).width() <= 767 && $("#matchmb").length > 0) {
                        //$("#matchmb").show();
                        //$("#matchldr").show();  
                        //$('body').css('overflow', 'hidden');
                        // $('body').css('position', 'fixed');
                        $rootScope.$broadcast("matchbrdcast", mId);
                    } else {
                        $window.location.href = "/match/" + getSessionSrvc.pce(mId);
                        //$window.open("/match/" + getSessionSrvc.pce(mId), "_blank")
                    }
                }
                vm.setFlirtIcnImg = function (flirtType) { if (flirtType == 1) return vm.flirtlgtImg; else return vm.flirtImg; }
                vm.setFavIcnImg = function (favType) { if (favType == 1) return vm.fvrtdImg; else return vm.fvImg; }
                vm.hvrMask = function (val) { if (val == -1 || val == -2) { return "hvrmaskbgblue" } else { return "hvrmaskbgred"; } }
                vm.selctPyarPernt = function (val) { if (val == -1 || val == -2) { return "?" } else { return val; } }
                vm.matchQ = function (val) { if (val == -1 || val == -2) { return ""; } else { return "%"; } }
                vm.cntryDsply = function (city, state, country) { if (p_cntry == country) { return city + ", " + state; } else { return city + ", " + state + ", " + country; } }
                //if (wdth) { vm.stateCntryLimit = 12; vm.NameLimit = 8; } else { vm.stateCntryLimit = 20; vm.NameLimit = 15; }

                vm.txtDots = function (city, state, country) {
                    var plceLgth = city.length + state.length;
                    if (p_cntry == country) { if (wdth) { if ((plceLgth) > 12) return "..."; else return ""; } else { if ((plceLgth) > 18) return "..."; else return ""; } }
                    else { if (wdth) { if ((plceLgth + country.length) > 12) return "..."; else return ""; } else { if ((plceLgth + country.length) > 18) return "..."; else return ""; } }
                }

                vm.matchSelection = function (val) {
                    if (val == -1 || val == -2) { return "NOT ENOUGH INFO"; }
                    else if (val >= 80 && val <= 100) { return "PERFECT MATCH"; }
                    else if (val >= 60 && val <= 79) { return "GREAT MATCH"; }
                    else if (val >= 30 && val <= 59) { return "GOOD MATCH"; }
                    else if (val > 0 || val <= 29) { return "NOT A MATCH"; }
                }

                vm.mtTrophies = function (val, type) {
                    if (val != null) {
                        var trophiesCnt = 0;
                        var trophies = val.split("#");
                        for (var i = 0; i <= 4; i++) {
                            if (trophies[i] == type)
                                trophiesCnt++;
                        }
                        return new Array(trophiesCnt);
                    }
                }
                vm.getGender = function (val) {
                    if (val == true) return "https://pccdn.pyar.com/pcimgs/actions/leicnM.svg";
                    else return "https://pccdn.pyar.com/pcimgs/actions/leicnF.svg";
                }

                vm.GetProfilePic = function (profilepic, gender) {
                    if (profilepic == null || profilepic == "" || profilepic == undefined) {
                        if (gender == true) return "https://pccdn.pyar.com/pcmbr/defaults/profilemtnb.jpg";
                        else if (gender == false) return "https://pccdn.pyar.com/pcmbr/defaults/profileftnb.jpg";
                    }
                    else return "https://pccdn.pyar.com" + profilepic;
                }

                function getPed(memId) { if (memId) { return "pyrMem" + getSessionSrvc.pce(memId); } }

                function memData(memId, Name, ProfilePic, Gender, tileindex) {
                    rs.curMemId = memId;
                    rs.firstName = Name;
                    rs.profilePic = vm.GetProfilePic(ProfilePic, Gender);
                    rs.gender = Gender;
                    rs.tileindex = tileindex;
                }

                $('body').click(function (e) {
                    if (["dbdvoops", "fltrophd", "fltroptxt", "fvbld"].indexOf(e.target.className.split(" ")[0]) == -1) {
                        $('[id^=dbdvoops]').hide();
                    }
                });

                elm.on('mouseover', "#btnflirt" + scope.name.memId, "#dbdvoops" + scope.name.memId, function () {
                    $('[id^=dbdvoops]').hide();
                    if (elm.find("#btnflirt" + scope.name.memId).attr("data-flirt") == 1) {
                        $("#dbdvoops" + scope.name.memId).fadeIn();
                    }
                });

                elm.on('mouseleave', ".lksicn", "#dbdvoops" + scope.name.memId, function () {
                    $('[id^=dbdvoops]').hide();
                });

                //FAVORITE MODULE STARTS 
                vm.FavIcnClk = function (memId, Name, ProfilePic, Gender, tileindex) {
                    memData(memId, Name, ProfilePic, Gender, tileindex);
                    //if ($("#btnfav" + rs.curMemId).attr("data-fav") == 1) {
                    //    if (ftPOPCheck(3))
                    //        vm.matchTileFavoriteModal = "#matchTileFavoriteModal";
                    //    else
                    //        vm.matchTileFavoriteModal = "";
                    //    rs.FavRemoveClk();
                    //}
                    //else {
                    //    if (ftPOPCheck(2))
                    //        vm.matchTileFavoriteModal = "#matchTileFavoriteModal";
                    //    else
                    //        vm.matchTileFavoriteModal = "";
                    //    AddRemoveFavarite(rs.curMemId, rs.firstName, rs.profilePic, rs.gender, rs.tileindex);
                    //}

                    if (cmnSrvc.ftPOPCheck(3) == false && cmnSrvc.ftPOPCheck(2) == false && $("#btnfav" + rs.curMemId).attr("data-fav") == 1) {
                        vm.matchTileFavoriteModal = "";
                        rs.FavRemoveClk();
                    }
                    else if (cmnSrvc.ftPOPCheck(2) == false && $("#btnfav" + rs.curMemId).attr("data-fav") == 0) {
                        vm.matchTileFavoriteModal = "";
                        AddRemoveFavarite(rs.curMemId, rs.firstName, rs.profilePic, rs.gender, rs.tileindex);
                    }
                    else if (cmnSrvc.ftPOPCheck(3) == false && cmnSrvc.ftPOPCheck(2) == false) {
                        vm.matchTileFavoriteModal = "";
                        AddRemoveFavarite(rs.curMemId, rs.firstName, rs.profilePic, rs.gender, rs.tileindex);
                    }
                    else if (cmnSrvc.ftPOPCheck(2) == true) {
                        vm.matchTileFavoriteModal = "#matchTileFavoriteModal";
                        AddRemoveFavarite(rs.curMemId, rs.firstName, rs.profilePic, rs.gender, rs.tileindex);
                    }
                    else if (cmnSrvc.ftPOPCheck(2) == false) {
                        vm.matchTileFavoriteModal = "";
                        AddRemoveFavarite(rs.curMemId, rs.firstName, rs.profilePic, rs.gender, rs.tileindex);
                    }
                }

                $("#favpop2").hide();

                function AddRemoveFavarite(memId, Name, ProfilePic, Gender, tileindex) {
                    vm.favType = $("#btnfav" + rs.curMemId).attr("data-fav");
                    if (vm.favType == null || vm.favType == "" || vm.favType == undefined || vm.favType == 0 || vm.favType == "0") {
                        vm.favType = $("#btnfav" + rs.curMemId).attr("data-fav", 0);
                    }
                    //if (vm.favType == 1 && ftPOPCheck(3) == false) {
                    //    vm.matchTileFavoriteModal = "";
                    //    rs.FavRemoveClk();
                    //}
                    //else if (vm.favType == 1) {
                    //    vm.matchTileFavoriteModal = "#matchTileFavoriteModal";
                    //    $("#btnflirt" + rs.curMemId).attr("data-fav", 1);
                    //    $("#favpop").hide(); $("#favpop2").show();
                    //}
                    if (vm.favType == 1) {
                        if (cmnSrvc.ftPOPCheck(3)) {
                            vm.matchTileFavoriteModal = "#matchTileFavoriteModal";
                            $("#btnflirt" + rs.curMemId).attr("data-fav", 1);
                            $("#favpop").hide(); $("#favpop2").show();
                        }
                        else {
                            vm.matchTileFavoriteModal = "";
                            rs.FavRemoveClk();
                        }
                    }
                    else {
                        $("#ImgFav" + rs.curMemId).attr("src", vm.ldrImg);
                        if (mId && rs.curMemId) {
                            othersprofileSrvc.addFavorite(mId, rs.curMemId, function (response, status) {
                                if (status == 200 && response == true) {
                                    // rs.is_Favorited = 1;
                                    if (cmnSrvc.ftPOPCheck(2))
                                        cmnSrvc.ftPOPUpdate(2);
                                    $("#favpop").show();
                                    $("#favpop2").hide();

                                    if (vm.favCarryVal == 1) {  // checking the fav click in a flirt modal
                                        $("#matchTileFavoriteModal").modal("hide");
                                        $("#FlrtPop").hide();
                                        $("#FlrtPop2").hide();
                                        $("#FlrtPop3").show();
                                        vm.favCarryVal = 0;
                                    } else {
                                        $("#matchTileFlirtModal").modal("hide");
                                    }

                                    $("#btnfav" + rs.curMemId).attr("data-fav", 1);
                                    $("#btnflirt" + rs.curMemId).attr("data-fav", 1);
                                    $("#ImgFav" + rs.curMemId).attr("src", vm.fvrtdImg);
                                }
                                else {
                                    $("#ImgFav" + rs.curMemId).attr("src", vm.fvImg);
                                }
                            });
                        } else {
                            $("#ImgFav" + rs.curMemId).attr("src", vm.fvImg);
                        }
                    }
                }
                rs.goPremium = function () {
                    $("#matchTileFlirtModal").modal('hide');
                    $("#matchTileFlirtModal").on('hidden.bs.modal', function () {
                        $state.go("payment")
                    })
                }

                rs.FavRemoveClk = function () {
                    $("#ImgFav" + rs.curMemId).attr("src", vm.ldrImg);
                    if (mId && rs.curMemId) {
                        othersprofileSrvc.removeFavorite(mId, rs.curMemId, function (response, status) {
                            if (status == 200 && response == true) {
                                //rs.is_UnFavorited = 1;
                                if (cmnSrvc.ftPOPCheck(3))
                                    cmnSrvc.ftPOPUpdate(3);
                                if (scope.tilepath == "myfavorites") {
                                    $("#" + getPed(rs.curMemId)).remove();
                                   //if ($('[id^=pyrMem]').length < 20) {
                                    rs.$emit("CallFavTileData", rs.tileindex); //caaling viewMore function in dashboardCtrl.
                                   // }
                                }

                                $("#favpop").hide(); $("#favpop2").hide();
                                $("#btnflirt" + rs.curMemId).attr("data-fav", 0);
                                $("#btnfav" + rs.curMemId).attr("data-fav", 0);
                                $("#ImgFav" + rs.curMemId).attr("src", vm.fvImg);
                            }
                            else {
                                $("#ImgFav" + rs.curMemId).attr("src", vm.fvrtdImg);
                            }
                        });
                    }
                    else {
                        $("#ImgFav" + rs.curMemId).attr("src", vm.fvrtdImg);
                    }
                }
                //FAVORITE MODULE END 

                //FLIRT MODULE START            
                vm.FlirtIcnClk = function (memId, Name, ProfilePic, Gender, tileindex) {
                    $('[id^=dbdvoops]').fadeOut();
                    memData(memId, Name, ProfilePic, Gender, tileindex);

                    //if ($("#btnflirtImg" + rs.curMemId).attr("src") == vm.flirtlgtImg) {
                    //    $("#dbdvoops" + scope.name.memId).fadeIn();
                    //    return false;
                    //}
                    //else {
                        if (sId() == 2) {
                            rs.FlirtAddClk();
                            //if (cmnSrvc.ftPOPCheck(4)) {
                            //    vm.matchTileFlirtModal = "#matchTileFlirtModal";
                            //}
                            //else {
                            //    vm.matchTileFlirtModal = "#matchTileFlirtModal";
                            //    // Uncomment the below code and comment the above line when a flirt popup needs to be shown only at once
                            //    //vm.matchTileFlirtModal = "";
                            //    //rs.FlirtAddClk();
                            //}

                            //vm.favType = $("#btnflirt" + rs.curMemId).attr("data-fav");

                            //if (!vm.favType == null || vm.favType == "" || vm.favType == undefined || vm.favType == 0 || vm.favType == "0") {
                            //    vm.favType = $("#btnflirt" + rs.curMemId).attr("data-fav", 0);
                            //}
                            //if (vm.favType == 1) { $("#FlrtPop,#FlrtPop3,#FlrtPop4").hide(); $("#FlrtPop2").show(); }
                            //else { $("#FlrtPop").show(); $("#FlrtPop2,#FlrtPop3,#FlrtPop4").hide(); }
                        } else {
                            if (cmnSrvc.isTrialOrPrmExpired()) {
                                vm.matchTileFlirtModal = "#matchTileFlirtModal";
                                $("#FlrtPop,#FlrtPop2,#FlrtPop3").hide(); $("#FlrtPop4").show();
                            } else showMobileVerificationPop();
                        }
                   // }
                }

                rs.FavAddClk = function () {
                    if (cmnSrvc.ftPOPCheck(2) == true) {
                        vm.favCarryVal = 1;
                    } else {
                        vm.favCarryVal = 0;
                    }
                    //rs.is_Favorited = 1;
                    AddRemoveFavarite(rs.curMemId, rs.firstName, rs.profilePic, rs.gender, rs.tileindex);
                }
                vm.isFlrtAcnCmltd = true;
                rs.FlirtAddClk = function () {
                    $("#btnflirtImg" + rs.curMemId).attr("src", vm.ldrImg);
                    if (mId && rs.curMemId && vm.isFlrtAcnCmltd == true) {
                        vm.isFlrtAcnCmltd = false;
                        othersprofileSrvc.addFlirt(mId, rs.curMemId, function (response, status) {
                            vm.isFlrtAcnCmltd = true;
                            if (status == 200 && response == true) {                              
                                rs.flirt = 1;
                                //rs.is_Flirted = 1;
                                //if (cmnSrvc.ftPOPCheck(4))
                                //    cmnSrvc.ftPOPUpdate(4);
                                $("#matchTileFlirtModal").modal("hide");                               
                                $("#FlrtPop").hide(); $("#FlrtPop2").hide(); $("#FlrtPop3").hide();
                                $("#btnflirt" + rs.curMemId).attr("data-flirt", 1);
                                $("#btnflirtImg" + rs.curMemId).attr("src", vm.flirtlgtImg);
                                $("#btnflirt" + rs.curMemId).prop("disabled", true);

                                //send  flirt notification
                                var type = 51;
                                if (msgSrvc.conId)
                                    msgSrvc.sendMemberNotifications(rs.curMemId, getSessionSrvc.p_fn(), getSessionSrvc.p_ppic(), getSessionSrvc.p_gndr(), type, new Date());
                                else
                                    $rootScope.ntfnData.push({ "sendType": 1, "tmId": rs.curMemId, "fn": getSessionSrvc.p_fn(), "pp": getSessionSrvc.p_ppic(), "gender": getSessionSrvc.p_gndr(), "type": type, "date": new Date() });

                                ////send flirt push notificatoion
                                //msgSrvc.sendFlirtPushNotification(mId, rs.curMemId, getSessionSrvc.p_fn(), getSessionSrvc.p_ppic(), getSessionSrvc.p_gndr(), function (response, status) {
                                //    if (status == 200 && response == true) {
                                //        console.log("flirt push notification sent");
                                //    }
                                //    else {
                                //        console.log("flirt push notification sent fail - " + response);
                                //    }
                                //});
                            }
                            else {
                                $("#btnflirtImg" + rs.curMemId).attr("src", vm.flirtImg);
                                vm.isFlrtAcnCmltd = true;
                            }
                        });
                    }
                    else {
                        $("#btnflirtImg" + rs.curMemId).attr("src", vm.flirtImg);
                    }
                }

                //fav&unfav from others profile
                $rootScope.$on("favUnfavclick", function (e, data) {
                    if (data.fav == 'yes') {
                        $("#btnfav" + data.mId).attr("data-fav", 1);
                        $("#btnflirt" + data.mId).attr("data-fav", 1);
                        $("#ImgFav" + data.mId).attr("src", vm.fvrtdImg);
                    } else {
                        $("#btnflirt" + data.mId).attr("data-fav", 0);
                        $("#btnfav" + data.mId).attr("data-fav", 0);
                        $("#ImgFav" + data.mId).attr("src", vm.fvImg);
                    };
                });
                //flirt from others profile
                $rootScope.$on("otherprfFlrt", function (e, data) {
                    $("#btnflirt" + data).attr("data-flirt", 1);
                    $("#btnflirtImg" + data).attr("src", vm.flirtlgtImg);
                    $("#btnflirt" + data).prop("disabled", true);
                });

                //vm.flrtmsgonmsovr = false;
                //FLIRT MODULE START END

                //Toogle button Click Start
                vm.memHideCheck = function (memId, Name, ProfilePic, Gender, tileindex) {
                    memData(memId, Name, ProfilePic, Gender, tileindex);
                    vm.hideUnHideTxt = "";
                    if (!vm.hideType) { vm.hideType = 1; }
                    //loader showing
                    $("#tileImg" + tileindex).show();
                    $("#imghd" + tileindex).hide();

                    if (scope.tilepath != "recommendedmatches" && scope.tilepath != "mutualmatches" && scope.tilepath != "reversematches") {
                        srchSrvc.MemberHideCheck(mId, rs.curMemId, function (response, status) {
                            $("#tileImg" + tileindex).hide();
                            $("#imghd" + tileindex).show();
                            if (status == 200 && response == true) {
                                vm.hideUnHideTxt = "Unhide";
                                vm.hideType = 2;
                            } else {
                                vm.hideUnHideTxt = "Hide";
                                vm.hideType = 1;
                            }
                        });
                    }
                    else {
                        $("#tileImg" + tileindex).hide();
                        $("#imghd" + tileindex).show();
                        vm.hideUnHideTxt = "Hide";
                    }
                }
                //Toogle button click End

                vm.ReportPopClk = function (memId, Name, ProfilePic, Gender, tileindex) {
                    memData(memId, Name, ProfilePic, Gender, tileindex);
                    $("#dbRptDv").show(); $("#dbRptDvConfirm").hide(); $("#dbRptDvThankyou").hide();
                }

                function rptEmpty(phTxt) { rs.reportTxt = null; rs.reportTxtPlaceHoder = phTxt; rs.txtCls = ""; }

                //Report textbox blur event
                rs.rptCheck = function () { if (!rs.reportTxt) { rptEmpty("Tell us what happened"); } }
                //Report textbox chanage evnt
                rs.rptChnage = function () {
                    vm.nameKpcls = "bgWht";
                    if (rs.reportTxt && rs.reportTxt.length > 250) { rptEmpty("Please ensure that your Details do not exceed 250 characters"); rs.txtCls = "txtaraPhClr" }
                    else if (!rs.reportTxt) { rptEmpty("Tell us what happened"); }
                }

                rs.ReportClk = function () {
                    $("#dbRptDv").hide(); $("#dbRptDvConfirm").show(); $("#dbRptDvThankyou").hide();
                    rs.RptBtnDsbl = true;
                    rs.dsblClass = "flrtbtndsble";
                    rs.reportTxt = "";
                    rs.txtCls = "";
                    rs.reportTxtPlaceHoder = "Tell us what happened";
                    // Report Action Start
                    rs.reportJson = [{ name: "Spam", value: "1" }, { name: "Inappropriate", value: "2" }, { name: "Abuse/Threat", value: "3" }, { name: "Other", value: "4" }];
                }

                rs.RptRsnClk = function (val) {
                    rs.RptRsnVal = val;
                    rs.RptBtnDsbl = false;
                    rs.dsblClass = null;
                    delete rs.txtCls;
                    rs.reportTxtPlaceHoder = "Tell us what happened";
                }

                rs.RptSubmit = function () {
                    if (rs.RptRsnVal == 4 && (rs.reportTxt == "" || rs.reportTxt == null || rs.reportTxt == undefined)) {
                        rs.txtCls = "txtaraPhClr";
                        rs.reportTxtPlaceHoder = 'Since you selected "Other" as your reason, please give us some details.';
                    }
                    else {
                        //refType: 1- reporting on member, 2- reporting on Photo
                        //refId: 1- memeberId, 2- PhotoId
                        cmnSrvc.memReport(mId, rs.curMemId, 1, rs.curMemId, rs.RptRsnVal, rs.reportTxt, function (response, status) {
                            if (status == 200 && response == true) {
                                $("#dbRptDv").hide(); $("#dbRptDvConfirm").hide(); $("#dbRptDvThankyou").show();
                            }
                        });
                    }
                }
                // Report Action End

                // BLOCK MEMBER START
                vm.BlckPopClk = function (memId, Name, ProfilePic, Gender, tileindex) {
                    memData(memId, Name, ProfilePic, Gender, tileindex);
                    $("#BlckPopDv").show(); $("#BlckPopDvThankyou").hide();
                }

                rs.BlockSubmit = function () {
                    othersprofileSrvc.addBlock(mId, rs.curMemId, function (response, status) {
                        if (status == 200 && response == true) {
                            $("#BlckPopDv").hide(); $("#BlckPopDvThankyou").show();
                            sendBlockNtfn();
                            //removing tile from repeater
                            removeTileById(rs.curMemId);
                        }
                    });
                }
                //BLOCK MEMBER END

                //HIDE MODULE START
                vm.hidemem = function (memId, Name, ProfilePic, Gender, tileindex) {
                    memData(memId, Name, ProfilePic, Gender, tileindex);
                    if (vm.hideType == 1) {
                        vm.matchTileHideModal = "#matchTileHideModal";
                        $("#dbHidePopDv").show();
                        $("#dbHidePopDvThankyou").hide();
                    } else {
                        $("#dbHidePopDv").hide();
                        $("#dbHidePopDvThankyou").hide();
                        vm.matchTileHideModal = "";
                        othersprofileSrvc.removeHide(mId, rs.curMemId, function (response, status) {
                            if (status == 200 && response == true) {
                                vm.hideUnHideTxt = "Hide";
                                vm.hideType = 1;
                            }
                        });
                    }
                }

                rs.hideClk = function () {
                    othersprofileSrvc.addHide(mId, rs.curMemId, function (response, status) {
                        if (status == 200 && response == true) {
                            $("#dbHidePopDv").hide();
                            $("#dbHidePopDvThankyou").show();
                            vm.hideUnHideTxt = "Unhide";
                            vm.hideType = 2;

                            if (scope.tilepath == "recommendedmatches" || scope.tilepath == "mutualmatches" || scope.tilepath == "reversematches") {
                                $("#" + getPed(rs.curMemId)).remove();
                               //if ($('[id^=pyrMem]').length < 20) {
                                rs.$emit("CallFavTileData", rs.tileindex); //caaling viewMore function in dashboardCtrl.
                              // }
                            }
                        }
                    });
                }
                //HIDE MODULE END

                rs.viewFavorites = function () {
                    $("#matchTileFavoriteModal").modal("hide");
                    $("#matchTileFlirtModal").modal("hide");
                    if ($location.path() != "/dashboard.html") {
                        $window.localStorage.setItem('tlcrval', "true");
                        $timeout(function () {
                            $state.go('dashboard');
                        }, 100);
                    }
                    else {
                        $timeout(function () {
                            $("#pchtb #tb2").click();
                            $('html, body').scrollTop(0);
                        }, 100);
                    }
                }

                vm.openCW = function (mId, fn) {
                    if ($(window).width() > 1199)
                        rs.$broadcast("openPCW", mId);
                    else
                        rs.$broadcast("openMPCW", mId, fn);
                };

                scope.$on("recBlockNtfnChg", function (e, mId, fn, gender, status) {
                    // if a user is blocked 
                    if (status) {
                        removeTileById(mId);
                        rs.tileindex = '';
                    }
                });

                scope.$on("recSelfBlockNtfnChg", function (e, mId, status) {
                    // if a user is blocked 
                    if (status) {
                        removeTileById(mId);
                        rs.tileindex = '';
                    }
                });

                function sendBlockNtfn() {
                    msgSrvc.sendMbrBlockNtfn(mId, frmfn, frmgndr, rs.curMemId, true);   // calling sndblck notifctn api when a user is blocked
                    rs.$emit("selfblck", rs.curMemId, rs.firstName, rs.gender, true);  // listner to show the block message if chatbox opens
                }

                function removeTileById(memId) {
                    if ($location.path() == '/dashboard.html') {
                        $("#" + getPed(memId)).remove();
                        rs.$emit("CallFavTileData", rs.tileindex); //caaling viewMore function in dashboardCtrl.
                    } else {
                        $("#" + memId).remove();
                        rs.$emit("tileBlockSearch", rs.tileindex); //caaling viewMore function in SearchController.
                    }
                };
            },
        }
    }]);

//Directive for baisc member
app.directive("matchTileBasic", ['getSessionSrvc', function (getSessionSrvc) {
    return {
        restrict: 'E',
        transclude: true,
        templateUrl: "/app/dashboard/templates/matchtileBasic.html",
        scope: {
            name: "=",
            modalShowpop: "@"
        },

        link: function (scope, elm, attrs, ctrl) {
            var vm = scope;
            var p_cntry = getSessionSrvc.p_cntry();
            vm.calculateAge = function (val) { return calculateAge(val); }
            vm.cntryDsply = function (city, state, country) { if (p_cntry == country) { return city + ", " + state; } else { return city + ", " + state + ", " + country; } }

            vm.txtDots = function (city, state, country) {
                if (p_cntry == country) { if ((city.length + state.length) > 18) { return "..."; } else { return ""; } }
                else { if ((city.length + state.length + country.length) > 18) { return "..."; } else { return ""; } }
            }

            vm.getGender = function (val) {
                if (val == true) return "https://pccdn.pyar.com/pcimgs/actions/leicnM.svg";
                else return "https://pccdn.pyar.com/pcimgs/actions/leicnF.svg";
            }

            vm.GetProfilePic = function (profilepic, gender) {
                if (profilepic == null || profilepic == "" || profilepic == undefined) {
                    if (gender == true) return "https://pccdn.pyar.com/pcmbr/defaults/profilemtnb.jpg";
                    else if (gender == false) return "https://pccdn.pyar.com/pcmbr/defaults/profileftnb.jpg";
                }
                else return "https://pccdn.pyar.com" + profilepic;
            }
        },
    }
}]);

//Directive for privacy policy and terms and conditions popup
app.directive("pptcModal", function ($filter, $sce, $compile) {
    return {
        restrict: 'E',
        templateUrl: '/app/common/templates/popups/pptc.html',
        transclude: true,
        scope: {
            pptcdata: '='
        },
        link: function (scope, ele, attr) {
            var response = scope.pptcdata;
            scope.policyName = response.policyName;
            scope.version = "Version " + eval(JSON.stringify(response.version));
            scope.lstUpdated = "Last updated: " + $filter('date')(eval(JSON.stringify(response.dateCreated)), "MMMM d, yyyy");
            scope.content = $sce.trustAsHtml(response.policytext);
        }
    }

})

/**********************************************************
                Common Directives end
**********************************************************/




















/**********************************************************
                Common functions start
**********************************************************/
//get fb clientId
function getFBClntId() { return "208096986336968"; };

//get instagram clientId
function getIGClntId() { return "5127b09dd06f4f10ae7b558f37e665f1"; };

//get google recaptcha clientId
function getGoogleClntId() { return "6LeeqRUUAAAAAPQap6b-AN2mNtol3kq72cxfyhlh"; };

//get BrainTree Authorisation key
function getBrainTreeAuth() { return 'sandbox_kyysr8d4_57xhjty4bt9tzk6m'; };

//get Api Domain Url
function getApiDomainUrl() { return "https://pcapi.pyar.com"; };

//// to close the modal and its backdrop when user click browser back/forward buttons
jQuery(document).ready(function ($) {
    if (window.history && window.history.pushState) {
        $(window).on('popstate', function () {
            if (window.location.pathname.split("?")[0] != "/account.html") {
                $(".modal").hide();
                $('body').removeClass('modal-open');
                $('.modal-backdrop').remove();
            };
        });
    }
});
// scroll up to show the div when there are no search results
$.fn.isInViewport = function () {
    $('body, html').animate({
        scrollTop: $(this).offset().top - (window.innerHeight || document.documentElement.clientHeight) + $(this).height() + 15
    }, 1000);
};

//Navbar toggles
$(document).on("click", "#headerMobile", function () {
    var _opened = $("#headerMobile").length > 0 && !$("#headerMobile").hasClass("collapsed");
    if (_opened === true) { $("#mobNav").attr("style", "z-index:10001;"); $("#mobNavMask").addClass('mbnavmenu-open'); }
    else { $("#mobNav").attr("style", ""); $("#mobNavMask").removeClass('mbnavmenu-open'); };
});
$(document).on("click", "#mobNavMask", function () {
    navclose();
});
//function to close navbar in Profile(Mobile view)
function navclose() {
    if ($("#headerMobile").length > 0 && !$("#headerMobile").hasClass("collapsed")) {
        $("#bs-example-navbar-collapse-1").removeClass("in")
        $("#headerMobile").addClass("collapsed");
        $("#mobNav").attr("style", "");
        $("#mobNavMask").removeClass('mbnavmenu-open');
    }
}
function showLoader() {
    try {
        var dvPcLdrObj = $("#pcldr");
        if (dvPcLdrObj) {
            dvPcLdrObj.css('z-index', '99999').css("position", "fixed").css("top", $(window).height() / 2 - dvPcLdrObj.outerHeight() / 2).css("left", $(window).width() / 2 - dvPcLdrObj.outerWidth() / 2);
            dvPcLdrObj.show();
        }
    }
    catch (e) {

    }
}
function hideLoader() {
    try {
        if ($("#pcldr"))
            $("#pcldr").hide();
    }
    catch (e) {

    }
}
function pcShowLoader(parentDiv) {
    try {
        if ($("#" + parentDiv) && $("#pcldr")) {
            var dvPcLdrParent = $("#" + parentDiv).offset();
            var ldrImgTop = dvPcLdrParent.top + (($("#" + parentDiv).outerHeight() - $("#pcldr").outerHeight()) / 2) + 'px';
            var ldrImgLeft = dvPcLdrParent.left + (($("#" + parentDiv).outerWidth() - $("#pcldr").outerWidth()) / 2) + 'px';
            $("#pcldr").css({ top: ldrImgTop, left: ldrImgLeft, position: 'absolute', display: '', 'z-index': '9999' });
            $("#pcldr").show();
        }
    } catch (e) {

    }
}
function pcHideLoader() {
    try {
        if ($("#pcldr"))
            $("#pcldr").hide();
    } catch (e) {

    }

}
function pcShowTileImgById(imgId) {
    try {
        if ($("#tileImg" + imgId))
            $("#tileImg" + imgId).show();
    } catch (e) {

    }
}
function pcHideTileImgById(imgId) {
    try {
        if ($("#tileImg" + imgId))
            $("#tileImg" + imgId).hide();
    } catch (e) {

    }
}
function pcShowPopupLoader() {
    try {
        if ($("#pcldr"))
            $("#pcldr").css({ 'z-index': 99999999, 'display': 'block', 'position': 'absolute', 'top': '50%', 'left': '50%' });
    } catch (e) {

    }
}
//premium amount for a country
function getPremiumamnt(responseArray) {
    var respayObj = responseArray.find(function (obj) {
        return (obj.subscribeDurationType && obj.subscribeDuration) == 1
    })
    return respayObj;
}
//function addThisSocailSharing() { addthis.toolbox('.addthis_toolbox');}
//function for updating Socialsharing url 
function updatingSocialSharingUrl(classNm, pgType, dtipPageUrl, dtipTitle) {
    if (pgType == "tu") {
        var updatedUrl = 'https://dev.pyar.com/dating-tip/' + dtipPageUrl.replace("/", "").toLowerCase();
        var encodedUrl = encodeURIComponent("https://dev.pyar.com/app/datingTips/shareDtip.aspx?pt=" + pgType + "&url=" + updatedUrl);
        var tumblrUrl = "http://www.tumblr.com/share?v=3&u=" + encodedUrl;
        windowPOP(tumblrUrl, 530, 630);
    } else if (pgType == "dfb") {
        var encodedUrl = encodeURIComponent("https://dev.pyar.com/app/datingTips/shareDtip.aspx?pt=" + pgType + "&url=" + dtipPageUrl);
        var fbUrl = "https://facebook.com/sharer.php?u=" + encodedUrl;
        windowPOP(fbUrl, 530, 630);
    } else {
        var updatedUrl = 'https://dev.pyar.com/dating-tip/' + dtipPageUrl.replace("/", "").toLowerCase();
        if ($("#dvshareBtn").length > 0) $("#dvshareBtn").remove();
        $(".custom_images").append('<a id="dvshareBtn" style="display:none;"></a>');
        $("#dvshareBtn").addClass(classNm);
        addthis.toolbox(".addthis_toolbox", null, {
            title: dtipTitle,
            url: "https://dev.pyar.com/app/datingTips/shareDtip.aspx?pt=" + pgType + "&url=" + encodeURIComponent(updatedUrl)
        });
        $("#dvshareBtn").click();
    }
}

function windowPOP(url, width, height) {
    if (width == "")
        width = window.innerWidth - 10;
    if (height == "")
        height = window.innerHeight;
    window.open(url, '', 'height=' + height + ',width=' + width + ',top=' + ((screen.height) ? (screen.height - height) / 2 : 0) + ',left=' + ((screen.width) ? (screen.width - width) / 2 : 0) + ',scrollbars=yes,resizable=no');
}

// End of updating Socialsharing url
$(window).resize(function () { if ($("#pcldr").css('display') != "none") { showLoader(); } });

function isCurrentDate(date) {
    var today = moment.utc(new Date()).format("YYYY-MM-DD");
    var dt = moment.utc(date).format("YYYY-MM-DD");
    if (moment(today).isSame(dt))
        return true;
    else
        return false;
};

function opnDdl(id) {
    $("#" + id + "dopn").slideToggle();
    var pos = $("#" + id).position();
    var top = $("#" + id).outerHeight() + pos.top;
    var left = pos.left;
    $("#" + id + "dopn").css("position", "absolute").css("top", top).css("left", left);
    $("#" + id + "dopn ul li").click(function () {
        $("#" + id).html($(this).text());
    });
    setDropdwnName(id);
}

// this function is used in match preference height dropdown 
function opnDdlhgt(id) {
    $("#" + id + "dopn").slideToggle();
    var pos = $("#" + id).position();
    var top = $("#" + id).outerHeight() + pos.top;
    var left = pos.left;
    $("#" + id + "dopn").css("position", "absolute").css("top", top).css("left", left);
    setDropdwnName(id);
}

// this function is used in match preference height dropdown end here
function opnMultiDdl(id) {
    $("#" + id + "dopn").slideToggle();
    var pos = $("#" + id).position();
    var top = $("#" + id).outerHeight() + pos.top;
    var left = pos.left;
    $("#" + id + "dopn").css("position", "absolute").css("top", top).css("left", left);
    $("#" + id + "dopn ul li").click(function () {
        $("#" + id).push($(this).val());
    });
    setDropdwnName(id);
}

function setDropdwnName(dropdownId) {
    if ($("body").data("dropdownName") != dropdownId)
        $("#" + $("body").data("dropdownName") + "dopn").hide();
    $("body").data("dropdownName", dropdownId);
};
function bdyClk() {
    $("body").click(function (e) {
        //var dparr = ["dvEyeClr", "dvHairClr", "dvHght", "dvBld", "dvDiet", "dvSmk", "dvDrnk", "dvRltnTyp",
        //                "dvNoofChldrn", "dvChldrnPref", "dvNoofPets", "dvPetPref", "dvPrefLang", "dvRlgus", "dvTrdtnl", "dvFmlyLang", "dvCntryLst",
        //                "dvEthnicityLst", "dvReligionLst", "dvAofWorkLst", "dvStatusLst", "dvEducationLst", "dvCountryLst",
        //                "ampdst", "ampdstcntry", "amprlg", "ampawrk", "ampwhdgr", "amphtwn", "ampapmxhgt", "ampapmnhgt", "amplshbtsmk", "amplshbtdrk", "amplsidlr", "amplschldp", "amplsptsp", "amplsplng", "amplsfmlylng", "amplsrlg", "amplstrd",
        //                "dvPrefLangLst", "dvFmlyLangLst", "dvRlgnLst",
        //                "dvAccTimeZone", "dvAccCurrLoc", "dvAccGender", "dvAccIntrstd",
        //                "dvSrchGender", "dvSrchLocation", "dvSrchCountry", "dvSrchAoW", "dvSrchHD", "dvSrchHCountry", "dvSrchRlgn", "dvSrchMxHeight", "dvSrchMnHeight", "dvSrchHCountryIR", "dvSrchSH", "dvSrchWC", "dvSrchWP", "dvSrchPL", "dvSrchDH", "dvSrchRH", "dvSrchCH", "dvSrchFL",
        //                "dvCatLst", "sbscsgndr", "sbscslcn",
        //                "pyamnt", "pymCntry" //used in payment.html
        //];
        //////match preferences
        //for (var i = 0; i < dparr.length; i++) {
        //    if ((e.target.id != dparr[i]) && (e.target.id != dparr[i] + "dopn")) {
        //        $("#" + dparr[i] + "dopn").hide();
        //    }
        //}
        var drpDwnNm = $("body").data("dropdownName");
        if (drpDwnNm && (e.target.id != drpDwnNm) && (e.target.id != drpDwnNm + "dopn"))
            $("#" + drpDwnNm + "dopn").hide();
        // to collapse the header in mobile view on clicking outside the navbar-toggle
        //if ($(window).width() <= 768) {
        //    if (e.target.innerText != 'Matches' && (e.target.parentElement.className) != 'visible-xs nvicn favcls') {
        //        var clickover = $(e.target);
        //        if (localStorage.getItem("toPath") == "/profile.html" && $("body").hasClass("modalTest modal-open")) {
        //            var _opened = $(".navbar-collapse").hasClass("navbar-collapse in");
        //            if (_opened === true && !clickover.hasClass("navbar-toggle")) {
        //                $("#matchprefnavtoogle.navbar-toggle").click();
        //            };
        //               $("#bs-example-navbar-collapse-1").removeClass("in")
        //               $("#headerMobile").addClass("collapsed");
        //        } else {
        //            var _opened = $("#headerMobile").length > 0 && !$("#headerMobile").hasClass("collapsed");
        //            if (_opened === true && !clickover.hasClass("navbar-toggle")) {
        //                $("#headerMobile.navbar-toggle").click();
        //            };
        //        };
        //    };
        //};

        if (window.location.pathname == "/payment.html") { //used in payment.html
            if (!$(e.target).hasClass('cvvImg')) {
                $("#cvvDiv").fadeOut();
            }
        }
    });
}

//reference https://codepen.io/dimbslmh/full/mKfCc
function setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find('.modal-content');
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find('.modal-header').outerHeight() || 0;
    var footerHeight = this.$element.find('.modal-footer').outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.$content.css({
        'overflow': 'hidden'
    });

    this.$element
      .find('.modal-body').css({
          'max-height': maxHeight,
          'overflow-y': 'auto'
      });
}

$('.modal').on('show.bs.modal', function () {
    $(this).show();
    setModalMaxHeight(this);
});

$(window).resize(function () {
    if ($('.modal.in').length != 0) {
        setModalMaxHeight($('.modal.in'));
    }
});
//End here

//function for calling in webservices.
function errStatuChk(status) {
    if (status == -1) {
        //doing nothing. no alert.
    }
    else {
        $("#ErrAlert").modal("show"); hideLoader();
        if (window.location.pathname == "/payment.html") {
            $("#btnFnlOrdr").attr("disabled", false).css("background-color", "rgba(192, 35, 74, 0.85)");
            $(".freezepay").remove();
        };
    }
    //else if (status == 400) {
    //    $("#ApiErrMsg").text("Bad Request."); $("#ErrAlert").modal("show"); $("#errCd").text("400"); hideLoader();
    //}
    //else if (status == 401) {
    //    $("#ApiErrMsg").text("Unauth­orized."); $("#ErrAlert").modal("show"); $("#errCd").text("401"); hideLoader();
    //}
    //else if (status == 403) {
    //    $("#ApiErrMsg").text("Forbidden."); $("#ErrAlert").modal("show"); $("#errCd").text("403"); hideLoader();
    //}
    //else if (status == 404) {
    //    $("#ApiErrMsg").text("Resource you are requesting is not found."); $("#ErrAlert").modal("show"); $("#errCd").text("404"); hideLoader();

    //}
    //else if (status == 405) {
    //    $("#ApiErrMsg").text("Method Not Allowed."); $("#ErrAlert").modal("show"); $("#errCd").text("405"); hideLoader();
    //}
    //else if (status == 500) {
    //    $("#ApiErrMsg").text("Internal Server Error."); $("#ErrAlert").modal("show"); $("#errCd").text("500"); hideLoader();
    //}
    //else {
    //    $("#ApiErrMsg").text("Something Going Wrong from webmethod.!"); $("#ErrAlert").modal("show"); $("#errCd").text("X"); hideLoader();
    //}

}


// Service for Get Method
function GetServiceByURL($http, url, funCallBack) {
    $http({
        method: "GET",
        url: url,
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'dataType': 'json',
            'appt': 'website'
        }
    }).success(function (response, status) {
        //checking function type, if it is function or not
        if (funCallBack && typeof funCallBack === 'function') {
            funCallBack(response, status);
        }
    }).error(function (reason, status) {
        errStatuChk(status);
    });
}

// Service for Post Method
function PostServiceByURL($http, url, jsonData, funCallBack) {
    $http({
        method: "POST",
        url: url,
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'dataType': 'json',
            'appt':'website'
        },
        data: jsonData,
    }).success(function (response, status) {
        //checking function type, if it is function or not
        if (funCallBack && typeof funCallBack === 'function') {
            funCallBack(response, status);
        }
    }).error(function (reason, status) {
        errStatuChk(status);
    });
}

function scrollHdr(activeSlider) {
    if ($(window).scrollTop() > 50) {
        $('.rgsnvbr').addClass('scrlactv').removeClass('scrlstrpclr');
        $("#img1").hide();
        $("#img2").show();
    }
    else {
        if (window.location.pathname == "/") {
            if ($("#" + activeSlider).hasClass("active")) {
                $('.rgsnvbr').addClass('scrlactv').addClass("scrlstrpclr");
                $("#img1").hide();
                $("#img2").show();
            } else {
                $('.rgsnvbr').addClass('scrlactv').addClass("scrlstrpclr");
                $("#img1").hide();
                $("#img2").show();
            }
        }
        else {
            $('.rgsnvbr').removeClass('scrlactv').removeClass('scrlstrpclr');
            $("#img1").show();
            $("#img2").hide();
        }
    }
}

//for header strip change on scroll
function headerStripScroll() {
    $(window).bind('scroll', function () {
        scrollHdr("slider2");
    });
}



//To Disable Right click event in payment page
$(document).on("contextmenu", function (e) {
    if (window.location.pathname == "/payment.html") e.preventDefault();
    else return true;
});


//End Here

//Function for dynamically loading title, keywords & description
function pyrTitles($rootScope, toState) {

    //$('html, body').scrollTop(0);
    var path = toState.url;
    var title = "", description = "", keywords = "";
    if (path == "/") {
        title = "Home - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/register.html") {
        title = "Register - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/register/security.html") {
        title = "Register-Security - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/register/security/email.html") {
        title = "Register-Security-Email - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "register/security/fb.html") {
        title = "Register - Facebook - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }

    else if (path == "/register/security/fb/email.html") {
        title = "Register - Security - Facebook - Email  - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/register/security/details.html") {
        title = "Register - Security - Details - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
        //else if (path == "/register-mem-promotion.html") {
        //    title = "Register - Member Protection - Pyar.com";
        //    description = "find matches on pyar.com";
        //    keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
        //}
    else if (path == "/reg-membership.html") {
        title = "Regisetr Mmebership - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/signin.html") {
        title = "Signin - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/signout.html") {
        title = "signout - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }

    else if (path == "/signinPwdRese.html") {
        title = "Password Reset - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/forgotpwd.html") {
        title = "Forgot Password - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/forgotpwdsec.html") {
        title = "Forgot password Security - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/forgotpwdreset.html") {
        title = "Forgot Password Reset - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/forgotpwdreseteml.html") {
        title = "Password Reset Email - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }

    else if (path == "/contactus.html") {
        title = "Contactus - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/help/contactus.html") {
        title = "Contactus - Help - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/help/signin/contactus.html") {
        title = "Member Contactus - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/aboutus.html") {
        title = "About Us - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/ourteam.html") {
        title = "Our Team - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }

        //else if (path == "/membership.html") {
        //    title = "Memberships - Pyar.com";
        //    description = "find matches on pyar.com";
        //    keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
        //}
    else if (path == "/non-membership.html") {
        title = "Non-Membership - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/permium-member.html") {
        title = "Permium-Member - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path.split("?")[0] == "/dating-tips.html") {
        title = "Dating Tips - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/dating-tip/:gpn") {
        title = "Single Dating Tip - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/dating-tip-srch.html") {
        title = "Dating Tip Search - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/aboutus.html") {
        title = "About Us - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/dtiplst.html") {
        title = "Dating-Tips - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/dating-tips2.html") {
        title = "Dating-Tips2 - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/dating-tips3.html") {
        title = "Dating-Tips3 - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/privacy-policy.html") {
        title = "Privacy Policy - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/privacy-policy-pop.html") {
        title = "Privacy Policy Pop - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/terms-conditions.html") {
        title = "Terms-Conditions - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/terms-conditionspop.html") {
        title = "Terms Conditions Pop - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/dashboard.html") {
        title = "Dashboard - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else if (path == "/dashboard2.html") {
        title = "Dashboard2 - Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    else {
        title = "Pyar.com";
        description = "find matches on pyar.com";
        keywords = "pyar,love,india love,find love,online dating,meet indian singles,singles";
    }
    $('title').text(title);
    $('meta[name=description]').attr('content', description);
    $('meta[name=keywords]').attr('content', keywords);
}
function pyrTitlesD(title, description, keywords) {
    $('title').text(title);
    $('meta[name=description]').attr('content', description);
    $('meta[name=keywords]').attr('content', keywords);
}

function bodyStyles($rootScope, toState) {
    var path = toState.url;
    var pdzeroArr = ["/", "/signin.html", "/register.html", "/signout.html", "/signouthide.html", "/signinpwdreset.html", "/forgotpwd.html", "/forgotpwdreseteml.html", "/forgotpwdreset.html"]
    //Adding padding to body dynamically based on page conditions
    if (pdzeroArr.indexOf(path) != -1) {
        $('body').css('padding-top', '0px');
    }
    else {
        $('body').css('padding-top', '60px');
    }
    $('body').css('background', '#fafafa');
    //End
}

//units from local storage

function pyrUntsTxt(units) {
    if (units != null && units == 2)
        return "Kms";
    else
        return "Miles";
};

function calculateRadius(units, radius) {
    if (units != null && units == 2)
        return Math.round(radius / 1.6);
    else
        return radius;
};

//check date format -- MM/DD/YYYY
//function check_date(field) {
//    if (field) {
//        var checkstr = "0123456789"; var DateField = field; var Datevalue = ""; var DateTemp = ""; var seperator = "/"; var day; var month; var year; var leap = 0; var err = 0; var i; var sErrorMsg = ""; err = 0; DateValue = DateField;
//        for (i = 0; i < DateValue.length; i++) { if (checkstr.indexOf(DateValue.substr(i, 1)) >= 0) { DateTemp = DateTemp + DateValue.substr(i, 1); } }
//        DateValue = DateTemp;
//        if (DateValue.length == 6) { DateValue = DateValue.substr(0, 4) + '20' + DateValue.substr(4, 2); }
//        if (DateValue.length != 8) { err = 19; }
//        year = DateValue.substr(4, 4);
//        if (year == 0) { err = 20; }
//        month = DateValue.substr(0, 2);
//        if ((month < 1) || (month > 12)) { err = 21; }
//        day = DateValue.substr(2, 2);
//        if (day < 1) { err = 22; }
//        if ((year % 4 == 0) || (year % 100 == 0) || (year % 400 == 0)) { leap = 1; }
//        if ((month == 2) && (leap == 1) && (day > 29)) { err = 23; }
//        if ((month == 2) && (leap != 1) && (day > 28)) { err = 24; }
//        if ((day > 31) && ((month == "01") || (month == "03") || (month == "05") || (month == "07") || (month == "08") || (month == "10") || (month == "12"))) { err = 25; }
//        if ((day > 30) && ((month == "04") || (month == "06") || (month == "09") || (month == "11"))) { err = 26; }
//        if ((day == 0) && (month == 0) && (year == 00)) { err = 0; day = ""; month = ""; year = ""; seperator = ""; }
//        if (err == 0) { DateField.value = month + seperator + day + seperator + year; }
//        else { sErrorMsg = "Date is incorrect! Please Check the days in the selected Month"; }

//        //comparing two dates 
//        var curDt = new Date();
//        curDt.setDate(curDt.getDate() - 1);
//        var txtDt = month + seperator + day + seperator + year;
//        if ((new Date(txtDt).getTime() > new Date(curDt).getTime())) {
//            sErrorMsg = "date greterthan current date";
//            return sErrorMsg;
//        }
//        return sErrorMsg;

//    } else {
//        return "Date is incorrect! Please Check the days in the selected Month";
//    }
//};

//calculate age using dob
function calculateAge(dateOfBirth) {
    var dob = new Date(dateOfBirth);
    var today = new Date();
    var age = Math.floor((today - dob) / (365.25 * 24 * 60 * 60 * 1000));
    return age;
    //$('#age').html(age + ' years old');
}

//check selected element is visible to screen or not
(function ($) {
    $.fn.visible = function (partial) {
        var $t = $(this),
	    	$w = $(window),
	    	viewTop = $w.scrollTop(),
	    	viewBottom = viewTop + $w.height(),
	    	_top = $t.offset().top,
	    	_bottom = _top + $t.height(),
	    	compareTop = partial === true ? _bottom : _top,
	    	compareBottom = partial === true ? _top : _bottom;

        return ((compareBottom <= viewBottom) && (compareTop >= viewTop));
    };

})(jQuery);

//check div has scroll or not
(function ($) {
    $.fn.hasScrollBar = function () {
        return this.get(0).scrollHeight > this.height();
    }
})(jQuery);

//capitalize each word after space (using for firstName)
function captlFname(nme) {
    if (nme) {
        return nme.replace(/\w\S*/g, function (tStr) {
            return tStr.charAt(0).toUpperCase() + tStr.substr(1);
        });
    }
}

function commaSeperatedNumbStrCheck(val) {
    if (val == "" || val == null)
        return true;
    if (val) {
        if (/^[0-9]+(,[0-9]+)*$/.test(val)) {
            return true;
        } else {
            return false;
        }
    }
}

function updateImgVersion(imgPath) {
    var dtn = new Date().valueOf();
    imgPath += "?v=" + dtn;
    if (imgPath.indexOf("?v=") != -1) {
        var lastIndex = imgPath.indexOf("?");
        imgPath = imgPath.substring(0, lastIndex);
    }
    return imgPath + "?v=" + dtn;
}


//using for Email Textbox validation
function emailDtEmty(vm, phTxt) {
    vm.email = null;
    vm.emailKpcls = "eror";
    vm.EmailPlaceholder = phTxt;
}

function emlFcs(vm) {
    vm.emailKpcls = "bgWht";
    vm.EmailPlaceholder = "Email";
}

function emlchkBlur($rootScope, vm) {
    var isMatcheRex = $rootScope.emailRegex.test(vm.email);
    if (vm.email && vm.email.length > 75) { emailDtEmty(vm, 'Must be < 75 characters'); }
    else if (!isMatcheRex) { emailDtEmty(vm, 'Please enter a valid email address'); }
}

function emlchangeEvnt(vm) {
    vm.emailKpcls = "bgWht";
    //if (vm.email && vm.email.length > 75) { emailDtEmty(vm, 'Must be < 75 characters'); }
    if (vm.email && vm.email.length > 75) { $("#txtEmail").blur(); }
    //else if (!vm.email) { emailDtEmty(vm, 'Email'); vm.emailKpcls = "bgWht"; }
}

//using for password Textbox validation

function pwdDtEmty(vm, phTxt) {
    vm.password = null;
    vm.pwdKpcls = "eror";
    vm.PwdPlaceholder = phTxt;
}
function pwdFcs(vm) {
    vm.pwdKpcls = "bgWht";
    vm.PwdPlaceholder = "Password";
    var path = window.location.pathname;
    if (path == "/forgotpwdreset.html" || path == "/account.html") {
        vm.PwdPlaceholder = "New Password";
    }
    else {
        vm.PwdPlaceholder = "Password";
    }
}

function pwdchangeEvnt(vm) {
    vm.pwdKpcls = "bgWht";
    if (vm.password && vm.password.length > 30) {
        pwdDtEmty(vm, 'Must be < 30 characters');
    }
    else if (!vm.password) {
        pwdDtEmty(vm, 'Password'); vm.pwdKpcls = "bgWht";
    }
}


function pwdchkBlur(vm) {
    var path = window.location.pathname;
    if (vm.password && vm.password.length > 30) {
        pwdDtEmty(vm, 'Must be < 30 characters');
        CnfPwdFcs(vm);
    }
    else if (!vm.password || vm.password.length < 8) {
        if (path == "/register.html" || path == "/forgotpwdreset.html" || path == "/account.html") {
            pwdDtEmty(vm, 'please follow password guidelines');
            vm.pwdGuideLineMsg = true;
            CnfPwdFcs(vm);
        } else {
            pwdDtEmty(vm, 'Invalid Password');
        }
    }
    else if (vm.password && vm.CurrentPassword && vm.CurrentPassword == vm.password) { pwdDtEmty(vm, 'Password should not match current'); }
    else if (vm.password && vm.confirmPassword && vm.password != vm.confirmPassword) { CnfPwdDtEmty(vm, 'Password does not match'); }
    else {
        vm.pwdGuideLineMsg = false;
    }
}
//using for confirm password Textbox validation

function CnfPwdDtEmty(vm, phTxt) {
    vm.confirmPassword = null;
    vm.cnfPwdKpcls = "eror";
    vm.CnfPwdPlaceholder = phTxt;
}

function CnfPwdFcs(vm) {
    vm.cnfPwdKpcls = "bgWht";
    vm.CnfPwdPlaceholder = "Confirm Password";
}

//Confirm password change event 
function CnfPwdchangeEvnt(vm) {
    vm.cnfPwdKpcls = "bgWht";
    if (vm.confirmPassword && vm.confirmPassword.length > 30) {
        CnfPwdDtEmty(vm, 'Must be < 30 characters');
    }
    else if (!vm.confirmPassword) { CnfPwdFcs(vm); }
}

//Confirm password blur event 
function CnfPwdchkBlur(vm) {
    if (vm.confirmPassword && vm.confirmPassword.length > 30) {
        CnfPwdDtEmty(vm, 'Must be < 30 characters');
    }
    else if (vm.password && vm.password.length > 30) {
        CnfPwdDtEmty(vm, 'Must be < 30 characters');
    }
    else if ((vm.password && vm.confirmPassword && vm.password != vm.confirmPassword) || (vm.password && !vm.confirmPassword)) {
        CnfPwdDtEmty(vm, 'Password does not match');
    }
}

//cdn path adding for image path
function addCdnPath(imgPath) {
    if (imgPath.indexOf(imgCdnPath) !== -1) {
        return imgPath;
    } else
        return imgCdnPath + imgPath;
};

function getBrowserType() {
    var standalone = window.navigator.standalone,
        userAgent = window.navigator.userAgent.toLowerCase(),
        safari = /safari/.test(userAgent),
        ios = /iphone|ipod|ipad/.test(userAgent);
    return ios;
};


//Displaying Time to resend the mail and OTP and Disabling the resend  button
function startInterval(vm, $interval) {
    vm.mailSent = false;
    vm.startTime = 30;
    if (angular.isDefined(vm.intrvl)) {
        $interval.cancel(vm.intrvl);
    }
    vm.intrvl = $interval(function () {
        vm.startTime = vm.startTime - 1
        if (vm.startTime.toString().length < 2) {
            vm.startTime = "0" + vm.startTime;
        }
        if (vm.startTime == "00") {
            vm.mailSent = true;
            $interval.cancel(vm.intrvl);
        }
    }, 1000)
}

function getDate(dob) {
    var date = dob.getDate();
    var month = dob.getMonth() + 1;
    var year = dob.getFullYear();
    return month + "/" + date + "/" + year;
};

function GetJSONKeysCount(sObj) {
    var length = 0;
    for (var key in sObj) {
        if (sObj.hasOwnProperty(key))
            length++;
    }
    return length;
};

function getCurrentGMT() {
    return -(new Date().getTimezoneOffset() / 60);
};

function getTZIdbyGMT(gmt) {
    var tzId = 1;
    if (gmt == 0)
        tzId = 1;
    else if (gmt > 0 && gmt <= 1) tzId = 3;
    else if (gmt > 1 && gmt <= 2) tzId = 4;
    else if (gmt > 2 && gmt <= 3) tzId = 6;
    else if (gmt > 3 && gmt <= 3.5) tzId = 7;
    else if (gmt > 3.5 && gmt <= 4) tzId = 8;
    else if (gmt > 4 && gmt <= 5) tzId = 9;
    else if (gmt > 5 && gmt <= 5.5) tzId = 10;
    else if (gmt > 5.5 && gmt <= 6) tzId = 11;
    else if (gmt > 6 && gmt <= 7) tzId = 12;
    else if (gmt > 7 && gmt <= 8) tzId = 13;
    else if (gmt > 8 && gmt <= 9) tzId = 14;
    else if (gmt > 9 && gmt <= 9.5) tzId = 15;
    else if (gmt > 9.5 && gmt <= 10) tzId = 16;
    else if (gmt > 10 && gmt <= 11) tzId = 17;
    else if (gmt > 11 && gmt <= 12) tzId = 18;
    else if (gmt < -10 && gmt <= -11) tzId = 19;
    else if (gmt < -9 && gmt <= -10) tzId = 20;
    else if (gmt < -8 && gmt <= -9) tzId = 21;
    else if (gmt < -7 && gmt <= -8) tzId = 22;
    else if (gmt < -6 && gmt <= -7) tzId = 23;
    else if (gmt < -5 && gmt <= -6) tzId = 25;
    else if (gmt < -4 && gmt <= -5) tzId = 26;
    else if (gmt < -3 && gmt <= -4) tzId = 28;
    else if (gmt < -2 && gmt <= -3) tzId = 30;
    else if (gmt < 0 && gmt <= -1) tzId = 32;
    return tzId;
};

function getTimeZone(tzId) {
    var zones = { 1: "Africa/Ouagadougou", 2: "UTC", 3: "Europe/Jersey", 4: "Europe/Budapest", 5: "Europe/Budapest", 6: "Europe/Vilnius", 7: "Iran", 8: "Europe/Samara", 9: "Asia/Karachi", 10: "Asia/Calcutta", 11: "Asia/Thimbu", 12: "Asia/Bangkok", 13: "Asia/Hong_Kong", 14: "Asia/Tokyo", 15: "Australia/North", 16: "Australia/Lindeman", 17: "Australia/Sydney", 18: "Asia/Kamchatka", 19: "Pacific/Midway", 20: "Pacific/Honolulu", 21: "America/Adak", 22: "America/Anchorage", 23: "America/Los_Angeles", 24: "America/Los_Angeles", 25: "America/Managua", 26: "America/Mexico_City", 27: "America/Mexico_City", 28: "America/New_York", 29: "America/Moncton", 30: "America/Fortaleza", 31: "America/Fortaleza", 32: "Atlantic/Cape_Verde" };
    return zones[tzId];
};

function getTimeZones() {
    var timeZones = moment.tz.names();
    var zonesArrObj = [];
    for (var i = 0; i < timeZones.length; i++) {
        zonesArrObj.push({ "val": parseInt(i) + 1, "zone": timeZones[i], "GMT": moment.tz(timeZones[i]).format('Z'), "txt": "(GMT" + moment.tz(timeZones[i]).format('Z') + ") " + timeZones[i] });
    }
    return zonesArrObj;
};

function getTimeZoneById(tzId) {
    var zone = "";
    var zonesArrObj = getTimeZones();
    for (var i = 0; i < zonesArrObj.length; i++) {
        if (zonesArrObj[i].val == tzId) {
            zone = zonesArrObj[i].zone;
            break;
        }
    }

    if (zone == "")
        zone = moment.tz.guess();
    return zone;
};

function getTZIdByZone(zone) {
    if (!zone)
        zone = moment.tz.guess();
    var tzId = null;
    var zonesArrObj = getTimeZones();
    for (var i = 0; i < zonesArrObj.length; i++) {
        if (zonesArrObj[i].zone == zone) {
            tzId = zonesArrObj[i].val;
            break;
        }
    }
    return tzId;
};

function browserDetection() {
    var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;// Opera 8.0+    
    var isFirefox = typeof InstallTrigger !== 'undefined';// Firefox 1.0+    
    var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || safari.pushNotification);// Safari 3.0+ "[object HTMLElementConstructor]" 
    var isIE = /*@cc_on!@*/false || !!document.documentMode;// Internet Explorer 6-11
    var isEdge = !isIE && !!window.StyleMedia;// Edge 20+    
    var isChrome = !!window.chrome && !!window.chrome.webstore;// Chrome 1+        

    if (isIE) { return "IE"; }
    else if (isChrome) { return "CHROME"; }
    else if (isSafari) { return "SAFARI"; }
    else if (isOpera) { return "OPERA"; }
    else if (isFirefox) { return "FIREFOX"; }
    else if (isEdge) { return "EDGE"; }
}
function updateMblVrfySession(ssnObj, getSessionSrvc, $rootScope, $window, isfrmTropy) {
    //var subDays = "", trialMember = 1, trailType = "";
    //for (var i = 0; i < ssnObj.length; i++) {
    //    if (ssnObj[i].Key == "sId")
    //        getSessionSrvc.u_ssnd("sId", ssnObj[i].Value);
    //    else if (ssnObj[i].Key == "subscribeStrtDT")
    //        getSessionSrvc.u_ssnd("dateTimeSubscrbSt", ssnObj[i].Value);
    //    else if (ssnObj[i].Key == "subscribeExprDT")
    //        getSessionSrvc.u_ssnd("dateTimeSubscrbExp", ssnObj[i].Value);
    //    //else if (ssnObj[i].Key == "trailMember")
    //    //    getSessionSrvc.u_ssnd("trailMember", ssnObj[i].Value);
    //    else if (ssnObj[i].Key == "trialMember")
    //        getSessionSrvc.u_ssnd("trialMember", ssnObj[i].Value);
    //    else if (ssnObj[i].Key == "subscribeDays")
    //        subDays = ssnObj[i].Value;
    //    else if (ssnObj[i].Key == "trailType")
    //        trailType = ssnObj[i].Value;
    //}
    for (var key in ssnObj) {
        getSessionSrvc.u_ssnd(key, ssnObj[key]);
    }

    if (isfrmTropy) {
        //  var trailObj = { subDays: subDays, fromFreeTrialPage: true, trailType: trailType };
        // $rootScope.trailObj = trailObj;
        $rootScope.fromFreeTrialPage = true;
        $window.localStorage.setItem("P_ftrl", null);
    };
}

function showMobileVerificationPop() { $("#smPP").modal('show'); }
function hideMobileVerificationPop() { $("#smPP").modal('hide'); }
/**********************************************************
                Common functions end
**********************************************************/








/**********************************************************
                Notification helper functions end
**********************************************************/
var notifyTypes = { flirt: 51, profileFillReminder: 52, profilePhoto: 53, galleryPhoto: 54, profileView: 61, profileViewMulti: 62, profileViewBasic: 63 };

function ntfnNavigate(notifyType, mId, sId, $location, $state, $cookieStore, $rootScope, $window) {
    if (notifyType == notifyTypes.flirt || notifyType == notifyTypes.profilePhoto || notifyType == notifyTypes.galleryPhoto) {
        if ($(window).width() <= 767 && $("#matchmb").length > 0) {
            $rootScope.$broadcast("matchbrdcast", mId);
        } else {
            $window.open("/match/" + mId, "_blank")
        }
        //$location.path('/match/' + mId);
    }
    else if (notifyType == notifyTypes.profileView || notifyType == notifyTypes.profileViewMulti || notifyType == notifyTypes.profileViewBasic) {
        if (sId == 2) {
            if ($location.path() == "/dashboard.html")
                $rootScope.$broadcast("openTab", "tb6");
            else {
                $cookieStore.put("P_dbTb", "tb6");
                $state.go("dashboard");
            }
        }
        else
            showMobileVerificationPop();
        //$state.go("membership");
    }
    else if (notifyType == notifyTypes.profileFillReminder)
        $state.go("profile");
};

function getNMTypes(notificationsSrvc, funCallBack) {
    notificationsSrvc.getNMTypes(function (response, status) {
        funCallBack(response, status);
    });
};

function resetNMCount(mId, msgSrvc, $rootScope) {
    if (msgSrvc.conId && $rootScope.mnCnt && $rootScope.mnCnt > 0) {
        msgSrvc.updateMbrNtfnView(mId, 'R', function (response, status) {
            if (status == 200 && response == true)
                $rootScope.mnCnt = 0;
        });
    }
};

function getNM(ntfns, $rootScope, $filter, lgnfn) {
    //bind notification msg based on notifyType
    for (var j = 0; j < ntfns.length; j++) {
        for (var i = 0; i < $rootScope.nmTypes.length; i++) {
            if (ntfns[j].notifyType == $rootScope.nmTypes[i].notifyType) {
                ntfns[j].NotificationMsg = ($filter('notifyMsg')($rootScope.nmTypes[i].notificationMsg, ntfns[j].fn, ntfns[j].gender, lgnfn, ntfns[j].pvCnt));
                ntfns[j].pp = getPP(ntfns[j].pp, ntfns[j].gender);
                ntfns[j].notifyIconPath = imgCdnPath + $rootScope.nmTypes[i].notifyIconPath;
                break;
            }
        }
    }
    return ntfns;
};

function getPP(imageUrl, gender) {
    if (imageUrl)
        return imgCdnPath + imageUrl.replace("/p/tnb/", "/p/tns/");
    else
        return gender ? imgCdnPath + "/pcmbr/defaults/profilemtns.jpg" : imgCdnPath + "/pcmbr/defaults/profileftns.jpg";
};
function prepareNotifications(ntfns, pvs, sId, $filter, $rootScope, lgnfn) {
    var ntfnInfo = { ntfns: [], pvToDt: null };
    var pvAlerts = [];
    if (pvs.length > 0) {
        var result = [];
        //group by the date
        for (var i = 0; i < pvs.length; i++) {
            var d = getDate(new Date(pvs[i].dtCreated));
            if (!result[d])
                result[d] = [];
            result[d].push(pvs[i])
        }

        //decide profile view type based on count and subscription type
        for (var date in result) {
            var altObj = $filter("orderBy")(result[date], "-dtCreated")[0];
            if (sId == 1) {
                altObj.notifyType = 63;
                altObj.pvCnt = result[date].length;
            }
            else {
                if (result[date].length == 1)
                    altObj.notifyType = 61;
                else {
                    altObj.notifyType = 62;
                    altObj.pvCnt = result[date].length;
                }
            }
            pvAlerts.push(altObj);
        };

        //add to notifications
        var date = new Date($filter("orderBy")(pvAlerts, "dtCreated")[0].dtCreated);
        date.setDate(date.getDate() + 1);
        ntfnInfo.pvToDt = getDate(date);
        ntfns = ntfns.concat(pvAlerts);
    }
    else
    {
        var date = new Date($filter("orderBy")(ntfns, "dtCreated")[0].dtCreated);
        date.setDate(date.getDate() + 1);
        ntfnInfo.pvToDt = getDate(date);
    }

    ntfns = getNM(ntfns, $rootScope, $filter, lgnfn);
    ntfnInfo.ntfns = $filter("orderBy")(ntfns, "-dtCreated");
    return ntfnInfo;
};


function convertNumToText(num) {
    var a = ['', 'one ', 'two ', 'three ', 'four ', 'five ', 'six ', 'seven ', 'eight ', 'nine ', 'ten ', 'eleven ', 'twelve ', 'thirteen ', 'fourteen ', 'fifteen ', 'sixteen ', 'seventeen ', 'eighteen ', 'nineteen '];
    var b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
    if ((num = num.toString()).length > 9) return 'overflow';
    n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return; var str = '';
    str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
    str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
    str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
    str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
    str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) : '';
    return str;
}

function getMemberBlockStatus(isSelfBlock, blockId, blockStatus) {
    if (isSelfBlock) {
        if (blockStatus) {
            if (blockId == '1')
                blockId = '2';
            else if (blockId == '3')
                blockId = '4';
        }
        else {
            if (blockId == '2')
                blockId = '1';
            else if (blockId == '4')
                blockId = '3';
        }
    }
    else {
        if (blockStatus) {
            if (blockId == '1')
                blockId = '3';
            else if (blockId == '2')
                blockId = '4';
        }
        else {
            if (blockId == '3')
                blockId = '1';
            else if (blockId == '4')
                blockId = '2';
        }
    }
    return blockId;
};
/**********************************************************
                Notification helper functions end
**********************************************************/


//Directive for mobile number verification
app.directive("mobilenoVerification", ['$window', '$http', '$location', '$state', 'membershipSrvc', 'registerSrvc', 'getSessionSrvc', '$timeout', '$interval', '$rootScope', '$cookieStore','cmnSrvc',
    function ($window, $http, $location, $state, membershipSrvc, registerSrvc, getSessionSrvc, $timeout, $interval, $rootScope, $cookieStore, cmnSrvc) {
        return {
            restrict: 'E',
            transclude: true,
            templateUrl: "/app/common/templates/mblnoverification.html",

            link: function (scope, elm, attrs, ctrl) {
                var vm = scope;
                var rs = $rootScope;
                var mId = getSessionSrvc.p_mId();
                vm.countryId = getSessionSrvc.p_cntryId();
                vm.trialDays = function () { return cmnSrvc.getTrialDays() };

                vm.mblvryPopClose = function () {
                    vm.sendCodeStep1 = true;
                    vm.sendCodeStep2 = vm.dvUnlockPrem = false;
                    vm.premBenfits = true;
                    vm.sendBtnCls = "prmtnbtndsbld";
                    vm.phNoPlshldr = "Enter Mobile Number";
                    vm.sendCodedsbld = true;
                    vm.mailSent = true;
                    $("#txtphoneNo").val('');
                    vm.phoneNo = "";
                    vm.errCls = "";
                }
                vm.mblvryPopClose();

                function getTxtboxValues() {
                    vm.phoneNo = $("#txtphoneNo").val();
                    vm.countrycode = $("#txtcountrycode").val();
                    vm.OtpDigit1 = $("#otpDigit1").val();
                    vm.OtpDigit2 = $("#otpDigit2").val();
                    vm.OtpDigit3 = $("#otpDigit3").val();
                    vm.OtpDigit4 = $("#otpDigit4").val();
                    vm.OtpDigit5 = $("#otpDigit5").val();
                    vm.OtpDigit6 = $("#otpDigit6").val();
                    vm.codeWrongMsg = false;
                }

                function clearTxtboxValues() {
                    vm.OtpDigit1 = $("#otpDigit1").val('');
                    vm.OtpDigit2 = $("#otpDigit2").val('');
                    vm.OtpDigit3 = $("#otpDigit3").val('');
                    vm.OtpDigit4 = $("#otpDigit4").val('');
                    vm.OtpDigit5 = $("#otpDigit5").val('');
                    vm.OtpDigit6 = $("#otpDigit6").val('');
                    vm.OtpDigit1 = vm.OtpDigit2 = vm.OtpDigit3 = vm.OtpDigit4 = vm.OtpDigit5 = vm.OtpDigit6 = "";
                    vm.OtpDigit1dsbld = vm.OtpDigit2dsbld = vm.OtpDigit3dsbld = vm.OtpDigit4dsbld = vm.OtpDigit5dsbld = vm.OtpDigit6dsbld = false;
                }

                if (vm.countryId) {
                    registerSrvc.CountryCodeG(vm.countryId, function (response) {
                        getTxtboxValues();
                        if (response)
                            vm.countrycode =  response;                       
                    });
                }

                //phone no text box blur event
                vm.phNoKeyUp = function () {                    
                    getTxtboxValues();
                    if (vm.phoneNo) {
                        vm.errCls = "";
                        vm.phNoPlshldr = "";
                    } else {
                        vm.phNoPlshldr = "Enter Mobile Number";
                    }
                    cntryAndNumberVlded();                    
                }
                //country code textbox keyup event
                vm.cntryCodeKeyUp = function () {
                    getTxtboxValues();
                    cntryAndNumberVlded();
                }
                // button validation based on country code and phone number
                function cntryAndNumberVlded() {
                    if (vm.countrycode && vm.phoneNo) {
                        if (vm.countrycode == "91" && vm.phoneNo.length == 10) {
                            vm.sendCodedsbld = false;
                            vm.sendBtnCls = "prmtnbtn curptr";
                        }
                        else if (vm.countrycode != "91" && vm.phoneNo.length > 6) {
                            vm.sendCodedsbld = false;
                            vm.sendBtnCls = "prmtnbtn curptr";
                        } else {
                            vm.sendCodedsbld = true;
                            vm.sendBtnCls = "prmtnbtndsbld";
                        }
                    } else {
                        vm.sendCodedsbld = true;
                        vm.sendBtnCls = "prmtnbtndsbld";
                    }
                }
               
                //otp code enter textboxes keyup events
                vm.OtpDigit1keyup = function () {
                    getTxtboxValues();
                    if (vm.OtpDigit1) {
                        if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                            vm.otpCheck();
                        } else
                            $("#otpDigit2").focus();
                    }
                }
                vm.OtpDigit2keyup = function () {
                    getTxtboxValues();
                    if (vm.OtpDigit2) {
                        if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                            vm.otpCheck();
                        } else
                            $("#otpDigit3").focus();
                    }
                }
                vm.OtpDigit3keyup = function () {
                    getTxtboxValues();
                    if (vm.OtpDigit3) {
                        if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                            vm.otpCheck();
                        } else
                            $("#otpDigit4").focus();
                    }
                }
                vm.OtpDigit4keyup = function () {
                    getTxtboxValues();
                    if (vm.OtpDigit4) {
                        if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                            vm.otpCheck();
                        } else
                            $("#otpDigit5").focus();
                    }
                }
                vm.OtpDigit5keyup = function () {
                    getTxtboxValues();
                    if (vm.OtpDigit5) {
                        if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                            vm.otpCheck();
                        } else
                            $("#otpDigit6").focus();
                    }
                }
                vm.OtpDigit6keyup = function () {
                    getTxtboxValues();
                    if (vm.OtpDigit6) {
                        if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                            vm.otpCheck();
                            $("#otpDigit6").blur();
                        }
                        else if (!vm.OtpDigit1)
                            $("#otpDigit1").focus();
                        else if (!vm.OtpDigit2)
                            $("#otpDigit2").focus();
                        else if (!vm.OtpDigit3)
                            $("#otpDigit3").focus();
                        else if (!vm.OtpDigit4)
                            $("#otpDigit4").focus();
                        else if (!vm.OtpDigit5)
                            $("#otpDigit5").focus();
                    }
                }

                //need to call api
                vm.otpCheck = function () {
                    showLoader();
                    getTxtboxValues();
                    $("[id^='otpDigit']").blur();
                    vm.OtpDigit1dsbld = vm.OtpDigit2dsbld = vm.OtpDigit3dsbld = vm.OtpDigit4dsbld = vm.OtpDigit5dsbld = vm.OtpDigit6dsbld = true;

                    if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                        vm.otpCodeStr = vm.OtpDigit1 + vm.OtpDigit2 + vm.OtpDigit3 + vm.OtpDigit4 + vm.OtpDigit5 + vm.OtpDigit6;
                        registerSrvc.checkPhoneNoVerification(mId, vm.otpResponseId, vm.otpCodeStr, function (response, status) {
                            if (status == 200) {
                                if (response) {
                                    updateMblVrfySession(response, getSessionSrvc, $rootScope, $window, true);
                                    //var sid = "", subDays = "", subStartDay = "", subEndDay = "", trailMember = false, trailType = "";
                                    //angular.forEach(response, function (key, value) {
                                    //    var values = Object.values(key);
                                    //    if (values[0] == "sId")
                                    //        sid = values[1];
                                    //    else if (values[0] == "subscribeDays")
                                    //        subDays = values[1];
                                    //    else if (values[0] == "subscribeStrtDT")
                                    //        subStartDay = values[1];
                                    //    else if (values[0] == "subscribeExprDT")
                                    //        subEndDay = values[1];
                                    //    else if (values[0] == "trailMember")
                                    //        trailMember = values[1];
                                    //    else if (values[0] == "trailType")
                                    //        trailType = values[1];
                                    //});
                                    //var trailObj = { subDays: subDays, fromFreeTrialPage: true, trailType: trailType };
                                    //getSessionSrvc.u_ssnd("sId", sid);
                                    //getSessionSrvc.u_ssnd("dateTimeSubscrbSt", subStartDay);
                                    //getSessionSrvc.u_ssnd("dateTimeSubscrbExp", subEndDay);
                                    //getSessionSrvc.u_ssnd("trailMember", trailMember);
                                    //$rootScope.trailObj = trailObj;
                                    //$window.localStorage.setItem("P_ftrl", null);
                                    //$state.go('dashboard');
                                    vm.sendCodeStep1 = vm.sendCodeStep2 = false;
                                    vm.dvUnlockPrem = true;
                                    hideLoader();
                                } else {
                                    vm.codeWrongMsg = true;
                                    clearTxtboxValues();
                                    hideLoader();
                                }
                            }
                        });
                    }
                    else {
                        hideLoader();
                    }
                }

                //send code button click
                vm.sendCode = function () {
                    showLoader();
                    getTxtboxValues();
                    if (mId && vm.phoneNo && vm.countrycode && vm.countrycode.length <= 3) {
                        $("#hdncountrycode").val(vm.countrycode);
                        $("#hdnphoneNo").val(vm.phoneNo);                      
                        registerSrvc.sendPhoneNumber(mId, vm.countrycode, vm.phoneNo, function (response, status) {
                            if (status == 200) {
                                if (parseInt(response) == 0) {
                                    vm.errCls = "eror";
                                    //vm.phoneNo = "";
                                    $("#txtphoneNo").val('');
                                    vm.phNoPlshldr = "Number in use";
                                    vm.sendBtnCls = "prmtnbtndsbld";
                                    vm.sendCodedsbld = true;
                                    hideLoader();
                                }
                                else if ((parseInt(response) == -1) || (parseInt(response) == -2)) {
                                    vm.errCls = "eror";
                                    //vm.phoneNo = "";
                                    $("#txtphoneNo").val('');
                                    vm.phNoPlshldr = "Message sending failed";
                                    vm.sendBtnCls = "prmtnbtndsbld";
                                    vm.sendCodedsbld = true;
                                    hideLoader();
                                }
                                else {
                                    vm.sendCodeStep1 = vm.dvUnlockPrem = false;
                                    vm.sendCodeStep2 = true;
                                    vm.otpResponseId = response;
                                    vm.errCls = '';
                                    hideLoader();
                                    startInterval(vm, $interval);
                                }
                            } else {
                                vm.errCls = "eror";
                                //vm.phoneNo = "";
                                $("#txtphoneNo").val('');
                                vm.phNoPlshldr = "Invalid member info";
                                vm.sendBtnCls = "prmtnbtndsbld";
                                vm.sendCodedsbld = true;
                                hideLoader();
                            }
                        });
                    }
                    else {
                        hideLoader();
                    }
                }


                //resed otp code button click
                vm.resendCode = function (sendType) {
                    showLoader();
                    vm.codeWrongMsg = false;
                    getTxtboxValues();
                    if (sendType == true) {
                        //   $("#errCodePopup").modal('hide');
                        vm.sendCodeStep1 = vm.dvUnlockPrem = false;
                        vm.sendCodeStep2 = true;
                        hideLoader();
                    }
                    startInterval(vm, $interval);
                    clearTxtboxValues();
                    vm.countrycode = $("#hdncountrycode").val();
                    vm.phoneNo = $("#hdnphoneNo").val();

                    if (mId && vm.phoneNo && vm.countrycode && vm.countrycode.length <= 3) {
                        registerSrvc.reSendPhoneNumber(mId, vm.countrycode, vm.phoneNo, function (response, status) {
                            if (status == 200 && response) {
                                vm.sendCodeStep1 = vm.dvUnlockPrem = false;
                                vm.sendCodeStep2 = true;
                                vm.otpResponseId = response;
                                hideLoader();
                            }
                            else {
                                hideLoader();
                            }
                        });
                    }

                }

                vm.mbleEntPg = function () {
                    getTxtboxValues();
                    vm.sendCodeStep1 = true;
                    vm.sendCodeStep2 = vm.dvUnlockPrem = false;
                    vm.phoneNo = $("#hdnphoneNo").val();
                    vm.countrycode = $("#hdncountrycode").val();
                }
                vm.btnbackToResend = function () {
                    getTxtboxValues();
                    clearTxtboxValues();
                    vm.sendCodeStep1 = vm.dvUnlockPrem = false;
                    vm.sendCodeStep2 = true;
                    vm.phoneNo = $("#hdnphoneNo").val();
                    vm.countrycode = $("#hdncountrycode").val();
                }
            },
        }
    }]);