﻿angular.module("app").controller('emlunsubCtrl', ['accountSrvc', '$scope', '$location', function (accountSrvc, $scope, $location) {
    var encEmail = $location.absUrl().split('?')[1].split('=')[1];
    accountSrvc.unSubEml(encEmail, function (response, status) {
    });
}]);