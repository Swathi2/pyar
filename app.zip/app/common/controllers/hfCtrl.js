﻿angular.module("app").controller('headerCtrl', function (getSessionSrvc, msgSrvc, notificationsSrvc, cmnSrvc, ntfcnFact, $scope, $rootScope, $window, $location, $state, abndnSrvc, $http, $filter, $cookieStore, $timeout, $interval, $cookieStore) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.sId = function () { return getSessionSrvc.p_sub(); };
    vm.fn = function () { return getSessionSrvc.p_fn(); };
    vm.pp = function () { return getSessionSrvc.p_ppic(); };
    vm.gender = function () { return getSessionSrvc.p_gndr(); };
    vm.tz = function () { return getSessionSrvc.p_tz(); };
    vm.notifications = [];
    vm.imageCDN = "https://pccdn.pyar.com";

    ////for TV CASTING Banner in home page - START
    //vm.tvCastingPOP = true;
    //vm.tvCastingPOPClose = function () {
    //    vm.tvCastingPOP = false;
    //}
    ////for TV CASTING Banner in home page - END

    //$('#aboutus,#privacyPolicy,#terms,#membership,#contactus,#datingtips,#register,#signin').click(function () {
    //    $('html, body').scrollTop(0);
    //});
    bdyClk();

    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        var path = toState.url;
        var fromPath = fromState.url;
        var sVal = getSessionSrvc.p_mId();
        vm.Lgnfn = getSessionSrvc.p_fn();
        vm.mid = sVal;
        // cheking cookie based on url conditions
        function checkSsn(PagePath) {
            if (sVal == "" || sVal == null || sVal == undefined) {
                vm.showRegHeader = false;
                vm.showSignInHeader = true;
                vm.logoUrl = "/";
            }
            else {
                vm.showRegHeader = true;
                vm.showSignInHeader = false;
                vm.logoUrl = "/dashboard.html";
            }
        }
        checkSsn(path);

        if (fromPath == "/signout.html" || fromPath == "/signin.html" || fromPath == "/register.html" || fromPath == "/dating-tip/:gpn")
            $timeout(function () { vm.chkMsgCWHide(path); vm.chkHlpusBHide(path); }, 2000);
        else {
            vm.chkMsgCWHide(path);
            vm.chkHlpusBHide(path);
        }
        //profile picture checking 
        if (sVal != null) {
            var pic = getSessionSrvc.p_ppic();
            var gndr = getSessionSrvc.p_gndr();
            if (pic == null || pic == "")
                if (gndr == true) vm.profilePic = 'https://pccdn.pyar.com/pcimgs/avatarM.png';
                else vm.profilePic = 'https://pccdn.pyar.com/pcimgs/avatarF.png';
            else
                vm.profilePic = updateImgVersion("https://pccdn.pyar.com" + pic.replace("/tnb/", "/tns/"));
        }
        //End
    });

    vm.signOutMember = function () {
        abndnSrvc.rmvSsn();
    };

    vm.goHome = function () {
        $cookieStore.remove('P_dbTb');
        if ($location.path() == "/dashboard.html")
            $state.reload();
        else
            $state.go('dashboard');
    };

    vm.GetProfilePic = function (profilepic, gender) {
        if (profilepic == null || profilepic == "" || profilepic == undefined) {
            if (gender == true) return "https://pccdn.pyar.com/pcmbr/defaults/profilemtnb.jpg";
            else if (gender == false) return "https://pccdn.pyar.com/pcmbr/defaults/profileftnb.jpg";
        }
        else return "https://pccdn.pyar.com" + profilepic;
    };

    //vm.openMatchs = function (e) {
    //    try {
    //        if ($(window).width() < 767) {
    //            $(e.target).removeAttr("data-toggle");
    //            if ($location.path() != "/dashboard.html")
    //                $window.location.href = "/dashboard.html";
    //                else
    //                    navclose();
    //        }
    //    } catch (e) {

    //    }
    //}

    vm.openDashboardTab = function (tabId) {
        $cookieStore.put("P_dbTb", tabId);
        if ($location.path() == "/dashboard.html")
            $state.reload();
        else
            $state.go('dashboard');
    };

    vm.goAccMdl = function () {
        $state.go('account');
    };

    vm.goPrfMdl = function () {
        $state.go('profile');
    };

    vm.searchBtnClk = function () {
        var memberType = getSessionSrvc.p_sub();
        if (memberType == 1) {
            $state.go("basicsearch");
        }
        else if (memberType == 2) {
            $state.go("advancedsearch");
        } else
            $state.go("signin");
    };

    $scope.$on('refreshHdrPP', function (e, imgPath) {
        var dtn = new Date().valueOf();
        vm.profilePic = imgPath.replace("/tn/", "/tns/") + "?v=" + dtn;
    });
    //help us improve
    vm.hlpusBPgHideArr = ['/payment.html', '/paymentsuccess'];
    vm.hlpshow = false;
    vm.hlpuspgshow = false;

    //msg nav actions
    vm.msgCWPgHideArr = ['/membership.html', '/terms-conditions.html', '/privacy-policy.html', '/msgcenter.html', '/account.html', '/payment.html','/changecard.html', '/paymentsuccess'];
    vm.ppm = "https://pccdn.pyar.com/pcmbr/defaults/profilemtns.jpg";
    vm.ppf = "https://pccdn.pyar.com/pcmbr/defaults/profileftns.jpg";
    vm.mwshow = false;
    vm.mwpgshow = false;
    vm.mrc = [];
    vm.msgLoader = false;
    vm.mrcEmpty = false;
    vm.mrcEmptyLn = [];
    $rootScope.mnCnt = 0;
    $rootScope.mmCnt = [];
    vm.imgCDN = "https://pccdn.pyar.com/";
    vm.pgSize = 20;
    vm.zone = function () { return getTimeZoneById(vm.tz()); };

    $scope.$on("msgSrvcReady", function (e) {
        try {
            //get member messages count
            vm.getMemberMsgCounts();
            vm.sendNotifications();
            vm.showHideMCW();

            //on service ready checking if member already click on the message and waiintg for request then we call calling again get recent msgs functions
            if ($("#msgLnk").attr("aria-expanded") == "true" && $("ul li#limrc").attr("data-reqProcess") == "true") {
                $("ul li#limrc").attr("data-reqProcess", "false");
                vm.getMRM();
            }

        } catch (e) {
            console.log("msgSrvcReady  --  " + e.message);
            alert("msgSrvcReady  --  " + e.message);
        }
    });

    $scope.$on("receiveMsg", function (e, mId, fn, msg, tmpp, convrnId, datetime, sender) {
        try {
            if (!sender) {
                vm.incrMsgCount(mId);
                $rootScope.$digest();
            }
        } catch (e) {
            alert('error : receiveMsg \n' + e.message);
            console.log('error : receiveMsg \n' + e.message);
        }
    });

    $scope.$on("onlineStatusChg", function (e, mId, statusType, status) {
        if (vm.mrc && vm.mrc.length > 0) {
            for (var i = 0; i < vm.mrc.length; i++) {
                if (mId = vm.mrc[i].tmId) {
                    if (statusType == 1)
                        vm.mrc[i].online = status;
                    else if (statusType == 2)
                        vm.mrc[i].offline = status;
                    break;
                }
            }
        }
    });

    $scope.$on("msgSeenCntChg", function (e, tmIds, status) {
        for (var i = 0; i < tmIds.length; i++) {
            if (status)
                vm.incrMsgCount(tmIds[i]);
            else
                vm.decrMsgCount(tmIds[i]);
        }
    });

    //if a user is blocked suddenly
    $scope.$on("recBlockNtfnChg", function (e, tmId, fn, gender, status) {
        try {
            vm.removeRecentMsgMembersById(tmId, status);
        } catch (e) {
            console.log("ntfn  --  " + e.message);
            alert("ntfn  --  " + e.message);
        }
    });

    $scope.$on("recSelfBlockNtfnChg", function (e, tmId, status) {
        try {
            vm.removeRecentMsgMembersById(tmId, status);
        } catch (e) {
            console.log("ntfn  --  " + e.message);
            alert("ntfn  --  " + e.message);
        }
    });

    vm.removeRecentMsgMembersById = function (tmId, status) {
        if (status && vm.mrc.length > 0) { // if Messages box in the navbar is opened 
            var splcindx = vm.mrc.findIndex(function (obj) {
                return obj.tmId == tmId
            });
            vm.mrc.splice(splcindx, 1);
        }
    }

    vm.openMatchProfile = function (tmId) {
        if (tmId)
            $window.open("/match/" + getSessionSrvc.pce(tmId), "_blank");
    };

    vm.openNCW = function () {
        try {
            $scope.$broadcast("openNCW");
        } catch (e) {
            console.log("vm.openNCW  --  " + e.message);
            alert("vm.openNCW  --  " + e.message);
        }
    };

    vm.openPCW = function (mId, fn) {
        try {
            if ($(window).width() > 1199)
                $rootScope.$broadcast("openPCW", mId);
            else
                $rootScope.$broadcast("openMPCW", mId, fn);
        } catch (e) {
            console.log("vm.openPCW  --  " + e.message);
            alert("vm.openPCW  --  " + e.message);
        }
    };

    vm.openRCH = function (e) {
        try {
            if ($(window).width() <= 767) {
                $(e.target).removeAttr("data-toggle");
                if ($window.location.pathname != "/msgcenter.html")
                    $window.location.href = "/msgcenter.html";
                else
                    navclose();
            }
            else {
                if ($(e.target).parent()[0].className == "dropdown") {
                    $("ul li#limrc").attr("data-pgNo", "1");
                    vm.mrc = [];
                    vm.mrcEmptyLn = [];
                    vm.getMRM();

                    //on scroll load next recent contacts
                    $("ul li#limrc").scroll(function (e) {
                        var scrollTop = $(this).scrollTop() + $(this).innerHeight();
                        if (scrollTop >= $(this)[0].scrollHeight)
                            vm.getMRM();
                    });
                }
            }
        } catch (e) {
            console.log("vm.openRCH  --  " + e.message);
            alert("vm.openRCH  --  " + e.message);
        }
    };

    vm.getMRM = function () {
        try {
            if ($("ul li#limrc").attr("data-reqProcess") == "false") {
                $("ul li#limrc").attr("data-reqProcess", "true");
                var pgNo = $("ul li#limrc").attr("data-pgNo");
                vm.msgLoader = true;
                if (getSessionSrvc.p_mId()) {
                    msgSrvc.getMemberRecentMsgContacts(getSessionSrvc.p_mId(), pgNo, vm.pgSize, function (response, status) {
                        $("ul li#limrc").attr("data-reqProcess", "false");
                        vm.msgLoader = false;
                        if (status == 200) {
                            if (response && response.length > 0)
                                vm.mrc = vm.mrc.concat(response);

                            if (!response || response.length < vm.pgSize)
                                $("ul li#limrc").unbind("scroll");
                            if (pgNo == 1 && response.length < 4) {
                                for (var i = 0; i < (4 - response.length) ; i++)
                                    vm.mrcEmptyLn.push(i);
                            }
                            if (pgNo == 1 && response.length == 0)
                                vm.mrcEmpty = true;
                            else
                                vm.mrcEmpty = false;
                            pgNo++;
                            $("ul li#limrc").attr("data-pgNo", pgNo);
                        }
                    });
                } else
                    $state.go('signin');
            }
        } catch (e) {
            console.log("vm.getMRM  --  " + e.message);
            alert("vm.getMRM  --  " + e.message);
        }
    };

    vm.getDateOrTime = function (msgDT) {
        var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), msgDT);
        if (dtObj.date)
            return dtObj.date;
        else
            return dtObj.time;
    };

    vm.getMemberMsgCounts = function () {
        if (getSessionSrvc.p_mId()) {
            msgSrvc.getMessagesCount(getSessionSrvc.p_mId(), function (response, status) {
                if (status == 200) {
                    $rootScope.mmCnt = response.tmIds;
                    $rootScope.mnCnt = response.notifyCnt;
                    vm.checkAndResetNtfnCount();
                }
            });
        }
    };

    vm.incrMsgCount = function (mId) {
        var notExist = true;
        if ($rootScope.mmCnt && $rootScope.mmCnt.length > 0) {
            for (var i = 0; i < $rootScope.mmCnt.length; i++) {
                if ($rootScope.mmCnt[i] == mId) {
                    notExist = false;
                    break;
                }
            }
        }
        if (notExist)
            $rootScope.mmCnt.push(mId);
    };

    vm.decrMsgCount = function (mId) {
        if ($rootScope.mmCnt && $rootScope.mmCnt.length > 0) {
            for (var i = 0; i < $rootScope.mmCnt.length; i++) {
                if ($rootScope.mmCnt[i] == mId) {
                    $rootScope.mmCnt.splice(i, 1);
                    break;
                }
            }
        }
    };

    $rootScope.$on("chkMsgCWHide", function (e, url) {
        if (url)
            vm.chkMsgCWHide(url);
    });

    vm.chkMsgCWHide = function (url) {
        var mId = getSessionSrvc.p_mId();
        var sId = getSessionSrvc.p_sub();
        if (mId && sId == 2) {
            vm.mwshow = true;
            var status = true;
            for (var i = 0; i < vm.msgCWPgHideArr.length; i++) {
                if (url.indexOf(vm.msgCWPgHideArr[i]) >= 0) {
                    status = false;
                    break;
                }
            }
            vm.mwpgshow = status;
            //alert(url + "  --  " + status);
        }
        else {
            vm.mwshow = false;
            vm.mwpgshow = false;
        }
    };
    vm.chkHlpusBHide = function (url) {
        var mId = getSessionSrvc.p_mId();
        if (mId) {
            vm.hlpshow = true;
            var status = true;
            for (var i = 0; i < vm.hlpusBPgHideArr.length; i++) {
                if (url.indexOf(vm.hlpusBPgHideArr[i]) >= 0) {
                    status = false;
                    break;
                }
            }
            vm.hlpuspgshow = status;
            //alert(url + "  --  " + status);
        }
        else {
            vm.hlpshow = false;
            vm.hlpuspgshow = false;
        }
    };

    vm.hdrResize = null;
    vm.showHideMCW = function () {
        if ($(window).width() > 1199 && $.inArray($location.path(), vm.msgCWPgHideArr) == -1)
            vm.mwpgshow = true;
        else
            vm.mwpgshow = false;
        $scope.$digest();
    };

    $(window).resize(function () {
        try {
            if (vm.hdrResize)
                $timeout.cancel(vm.hdrResize);
            vm.hdrResize = $timeout(function () { vm.showHideMCW(); }, 1000);
        } catch (e) {
            console.log("header resize  --  " + e.message);
            alert("header resize  --  " + e.message);
        }
    });

    $scope.openPS = function (id) {
        $("#" + id).modal("show");
    };

    $scope.PSSClk = function (id) {
        $("#" + id).modal("hide");
        $("#" + id).on("hidden.bs.modal", function () {
            $state.go("payment");
        })
    };
    //messages here

    //notifications start
    vm.ntfnPgSize = 20;
    vm.pvFromDt = "";
    vm.pvToDt = "";
    vm.ntfnLoader = false;
    vm.ntfEmpty = false;
    vm.ntfnEmptyLn = [];

    vm.openNtfn = function (e) {
        try {
            if ($(window).width() < 767) {
                $(e.target).removeAttr("data-toggle");
                if ($location.path() != "/notifications.html")
                    $window.location.href = "/notifications.html";
                else
                    navclose();
            }
            else if ($(e.target).parent()[0].className == "dropdown") {
                $("ul li#liNtf").attr("data-pgNo", "1");
                vm.notifications = [];
                if ($rootScope.nmTypes && $rootScope.nmTypes.length > 0)
                    vm.getNotifications();
                else {
                    getNMTypes(notificationsSrvc, function (response, status) {
                        if (status == 200) {
                            $rootScope.nmTypes = response;
                            vm.getNotifications();
                        }
                    });
                }

                //on scroll load next recent notifications
                $("ul li#liNtf").scroll(function (e) {
                    var scrollTop = $(this).scrollTop() + $(this).innerHeight();
                    if (scrollTop >= $(this)[0].scrollHeight)
                        vm.getNotifications();
                });
            }
        } catch (e) {
            console.log("vm.openNtfn  --  " + e.message);
            alert("vm.openNtfn  --  " + e.message);
        }
    };

    vm.getNotifications = function () {
        try {
            if ($("ul li#liNtf").attr("data-reqProcess") == "false") {
                $("ul li#liNtf").attr("data-reqProcess", "true");
                var pgNo = $("ul li#liNtf").attr("data-pgNo");
                vm.ntfnLoader = true;
                if (vm.mId()) {
                    notificationsSrvc.getNotifications(vm.mId(), vm.sId(), pgNo, vm.ntfnPgSize, vm.pvFromDt, vm.pvToDt, function (response, status) {
                        $("ul li#liNtf").attr("data-reqProcess", "false");
                        if (status == 200) {
                            //check respone length less than pgSize then stop calling on scroll
                            if (response.notifications.length < vm.ntfnPgSize)
                                $("ul li#liNtf").unbind("scroll");

                            //push to existing notifications
                            var data = prepareNotifications(response.notifications, response.profileViews, vm.sId(), $filter, $rootScope, vm.fn());
                            vm.pvToDt = data.pvToDt;
                            for (var i = 0; i < data.ntfns.length; i++)
                                vm.notifications.push(data.ntfns[i]);

                            if (pgNo == 1) {
                                //check unread alerts exist reset to 0
                                resetNMCount(vm.mId(), msgSrvc, $rootScope);
                                //if notificatins are empty show empty state
                                if (vm.notifications.length == 0)
                                    vm.ntfEmpty = true;
                                else
                                    vm.ntfEmpty = false;
                                //check and add empty lines
                                vm.checkNtfnEmptyLines();
                            }
                            pgNo++;
                            $("ul li#liNtf").attr("data-pgNo", pgNo);
                        }
                        vm.ntfnLoader = false;
                    });
                } else
                    $state.go('signin');
            }
        } catch (e) {
            console.log("vm.getNotifications  --  " + e.message);
            alert("vm.getNotifications  --  " + e.message);
        }
    };

    vm.ntfnNavigate = function (notifyType, tmId) {
        ntfnNavigate(notifyType, getSessionSrvc.pce(tmId), vm.sId(), $location, $state, $cookieStore, $rootScope, $window);
    };

    vm.checkAndResetNtfnCount = function () {
        if ($location.path() == "/notifications.html" || $("aNtfn").attr("aria-expanded") == "true")
            resetNMCount(vm.mId(), msgSrvc, $rootScope);
    };

    vm.getPP = function (imageUrl, gender) {
        if (imageUrl) return vm.imageCDN + imageUrl.replace("/p/tnb/", "/p/tns/");
        else if (gender == true) return vm.imageCDN + "/pcmbr/defaults/profilemtns.jpg";
        else if (gender == false) return vm.imageCDN + "/pcmbr/defaults/profileftns.jpg"
    };

    $scope.$on("receiveNotifications", function (e, tmId, fn, pp, gender, type, date) {
        try {
            //if member is in notification or header notification menu opened
            //then need to add there oather wise increment count
            //remove true add check opened or not
            if ($location.path() == "/notifications.html" || $("#aNtfn").attr("aria-expanded") == "true") {
                if (pp)
                    pp = pp + "?v=" + new Date().valueOf();
                var ntfns = [{ "notifyType": type, "mId": tmId, "fn": fn, "gender": gender, "pp": pp, "dtCreated": date, "NotificationMsg": "", "pvCnt": 1 }];
                ntfns = getNM(ntfns, $rootScope, $filter, vm.fn());
                //if we receive notification in notification page
                if ($location.path() == "/notifications.html")
                    $rootScope.$broadcast("addNtfn", ntfns);

                if ($("#aNtfn").attr("aria-expanded") == "true") {
                    for (var i = 0; i < ntfns.length; i++)
                        vm.notifications.unshift(ntfns[i]);
                    //if notifications is previously in empty state then chage state to non-empty 
                    if (vm.ntfEmpty == true && vm.notifications.length > 0)
                        vm.ntfEmpty = false;
                    vm.checkNtfnEmptyLines();
                }
            }
            else {
                if ($rootScope.mnCnt && $rootScope.mnCnt > 0)
                    $rootScope.mnCnt += 1;
                else
                    $rootScope.mnCnt = 1;
                $rootScope.$digest();
            }
            //check flirt notification
            if (type == 51) {
                vm.flirtBackData.push({ "tmId": tmId, "fn": fn, "pp": pp, "gender": gender, "flirtSent": false });
                vm.checkFlirtBack();
            }
            $scope.$digest();
        } catch (e) {
            console.log("receiveNotifications  --  " + e.message);
            alert("receiveNotifications  --  " + e.message);
        }
    });

    vm.sendNotifications = function () {
        if (vm.mId() && $rootScope.ntfnData) {
            while ($rootScope.ntfnData.length > 0 && msgSrvc.conId) {
                if ($rootScope.ntfnData[0].sendType == 1)
                    msgSrvc.sendMemberNotifications($rootScope.ntfnData[0].tmId, $rootScope.ntfnData[0].fn, $rootScope.ntfnData[0].pp, $rootScope.ntfnData[0].gender, $rootScope.ntfnData[0].type, $rootScope.ntfnData[0].date);
                else
                    msgSrvc.sendMemberNWNotifications($rootScope.ntfnData[0].tmId, $rootScope.ntfnData[0].fn, $rootScope.ntfnData[0].pp, $rootScope.ntfnData[0].gender, $rootScope.ntfnData[0].type, $rootScope.ntfnData[0].date);
                $rootScope.ntfnData.splice(0, 1);
            }
        }
    };

    vm.checkNtfnEmptyLines = function () {
        vm.ntfnEmptyLn = [];
        if (vm.notifications.length < 4) {
            for (var i = 0; i < 4 - vm.notifications.length; i++)
                vm.ntfnEmptyLn.push(i);
        }
    };
    //notifications end

    //flirt start
    vm.flirtBackData = [];
    vm.flirt = null;
    vm.flirtTimeout = null;

    vm.checkFlirtBack = function () {
        //check if no popup are open

        if (vm.flirtBackData.length > 0) {
            if ($("body").hasClass("modal-open") == false) {
                vm.flirt = null;
                vm.flirtTimeout = null;
                checkMemberFlrtOrNot(function (flrtResponse) {
                    if (flrtResponse == false) {//not yet flirt
                        vm.flirt = vm.flirtBackData[0];
                        $("#flirtBackPopup").modal("show");
                        if ($location.path() != "/notifications.html" && $("#aNtfn").attr("aria-expanded") == "false" && $rootScope.mnCnt > 0)
                            $rootScope.mnCnt--;
                    }
                    else if (flrtResponse == true) {//flirted
                        vm.flirtBackData.splice(0, 1);
                        vm.checkFlirtBack();
                    }
                });
                
            }
            else {
                if (vm.flirtTimeout != null) {
                    $timeout.cancel(vm.flirtTimeout);
                    vm.flirtTimeout = null;
                }
                vm.flirtTimeout = $timeout(function () { console.log("timeout"); vm.checkFlirtBack(); }, 2000);
            }
        }
    };

    function checkMemberFlrtOrNot(funCallBack)
    {
        cmnSrvc.memFlirtCheck(vm.mId(), vm.flirtBackData[0].tmId, function (response, status) {
            if (status == 200) {
                funCallBack(response);
            }
        });
}

    var isFlrtAcnCmltd = true;
    vm.addFlirt = function (tmId) {
        if (vm.sId() == 2) {
            if (tmId && isFlrtAcnCmltd == true) {
                isFlrtAcnCmltd = false;
                checkMemberFlrtOrNot(function (flrtResponse) {   //check member already flirted or not               
                    if (flrtResponse == false) {
                        notificationsSrvc.addFlirt(vm.mId(), tmId, function (response, status) {
                            isFlrtAcnCmltd = true;
                            if (status == 200 && response == true) {
                                vm.flirt.flirtSent = true;
                                //send notification
                                var type = 51;
                                if (msgSrvc.conId)
                                    msgSrvc.sendMemberNotifications(tmId, vm.fn(), vm.pp(), vm.gender(), type, new Date());
                                else
                                    $rootScope.ntfnData.push({ "sendType": 1, "tmId": tmId, "fn": vm.fn(), "pp": vm.pp(), "gender": vm.gender(), "type": type, "date": new Date() });

                                ////send flirt push notificatoion
                                //msgSrvc.sendFlirtPushNotification(vm.mId(), tmId, vm.fn(), vm.pp(), vm.gender(), function (response, status) {
                                //    if (status == 200 && response == true) {
                                //        console.log("flirt push notification sent");
                                //    }
                                //    else {
                                //        console.log("flirt push notification sent fail - " + response);
                                //    }
                                //});
                            }
                        });
                    }
                    else {
                        vm.flirt.flirtSent = true;
                        isFlrtAcnCmltd = true;
                    }
                });
                }
        }
        else {
            $("#flirtBackPopup").modal("hide");
            if (cmnSrvc.isTrialOrPrmExpired()) {
                $("#matchTileFlirtModal").modal("show");
                $("#FlrtPop,#FlrtPop2,#FlrtPop3").hide(); $("#FlrtPop4").show();
            } else showMobileVerificationPop();
        }
    };

    vm.flirtClose = function () {
        $("#flirtBackPopup").modal("hide");
        for (var i = 0; i < vm.flirtBackData.length; i++) {
            if (vm.flirtBackData[i].tmId == vm.flirt.tmId) {
                vm.flirtBackData.splice(i, 1);
                break;
            }
        }
        vm.checkFlirtBack();
    };
    //flirt end


    vm.GetPremium = function (id) {
        $("#" + id).modal('hide');
        $("#" + id).on("hidden.bs.modal", function () {
            $state.go("payment");
        })
    }

    //privacy policy click event
    vm.ppClick = function () {
        vm.pptcdata = ""
        showLoader();
        cmnSrvc.PPService(function (response, status) {
            hideLoader();
            if (status == 204) {
                alert("the content is not there (take the appropriate action)");
                return false;
            }
            else if (status == 200) {
                vm.pptcdata = response;
                $("#ptcModal").modal("show");
            }
        });
    };

    //Terms condtions click event
    vm.tcClick = function () {
        vm.pptcdata = ""
        showLoader();
        cmnSrvc.TCService(function (response, status) {
            hideLoader();
            if (status == 204) {
                alert("the content is not there (take the appropriate action)");
                return false;
            }
            else if (status == 200) {
                vm.pptcdata = response;
                $("#ptcModal").modal("show");
            }
        });
    };
});