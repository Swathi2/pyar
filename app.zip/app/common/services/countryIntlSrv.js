﻿angular.module("app").service('countryIntlSrv', ['$http', '$timeout', '$rootScope', '$filter', function ($http, $timeout, $rootScope, $filter) {
    var vm = this;
    vm.timeoutRef = null;
    vm.reqWait = false;
    vm.newCities = [];
    var showdivId = "dvIntl";
    var ulId = "ulContainer"
    var ResultStore = [];
    var curIndex = -1;
    vm.countries = [];

    //used select the coutry and set to countryId as city textbox data properties
    vm.SetCountry = function (txtId, dvId, countryId) {
        txtObj = $("#" + txtId);
        //if (txtObj.attr("data-cntryId") == "" || txtObj.attr("data-cntryId") != countryId) {
        if (countryId) {
            //enable textbox and set values as empty and set data properties
            txtObj.attr("disabled", false).attr("data-cntryId", countryId).attr("data-cityName", "").attr("data-txtVal", "").val("");
            vm.UnBind(txtId);
        }
        else
            txtObj.attr("data-cityName", "").attr("data-txtVal", "").val("");
        //hide country list
        $("#" + dvId).slideToggle();
        txtObj.removeClass('eror');
        txtObj.focus();
    };

    vm.resetCountry = function (txtId, dvId) {
        txtObj = $("#" + txtId);
        $("#" + dvId).html("Country");
        txtObj.attr("disabled", true).attr("data-cntryId", "").attr("data-cityName", "").attr("data-txtVal", "").val("");
        txtObj.removeClass('eror');
    };

    vm.BindCountries = function () {
        if (vm.countries.length > 0)
            $rootScope.$broadcast("bindCountry", vm.countries);
        else {
            vm.GetCountries(function (response, status) {
                if (status == 200 && response && response.length > 0) {
                    vm.countries = response;
                    $rootScope.$broadcast("bindCountry", response);
                }
            });
        }
    };

    $("body").on("click", function (event) {
        //user click on body and it is not a cityList then we have to hide
        if ($("#" + event.target.id).attr("data-source") != "cities")
            vm.CityListHide();
    });

    //Nedd to check
    //event for user press key
    $(document).keydown(function (event) {
        vm.Navigate(event);
    });

    //if user long press key up/down move to city list top to bottom/bottom to top
    vm.Navigate = function (event) {
        var kc = event.keyCode;
        if (kc == 40 || kc == 38) {
            var liElements = $("#" + ulId + " li");
            if (kc == 40) {
                if (curIndex < liElements.length - 1)
                    curIndex++;
            }
            else if (kc == 38 && curIndex >= 0)
                curIndex--;

            //check if list elements lenght is 1 and text as no results
            if (liElements.length == 1 && liElements.eq(0).text() == "No Results") {
                vm.UnBind(event.target.id);
                return;
            }

            //change color for selected index
            liElements.each(function (index, liItem) {
                if (index == curIndex) {
                    $(liItem).css("background-color", "rgb(153, 183, 220)").css("color", "rgb(255, 255, 255)");
                    $("#" + ulId).scrollTop($("#" + ulId).scrollTop() + $(liItem).position().top);
                }
                else
                    $(liItem).css("background-color", "#ffffff").css("color", "#16a085");
            });
            return;
        }
    }
    //End here

    vm.BindIntelligence = function () {
        //read all text box with attribute data source 
        $("input[type=text]").each(function (i, e) {
            if ($(e).attr("data-source") == "cities") {
                //hide city list on list enter press event
                $("body").on("keypress", "#" + $(e).attr("id"), function (kpEvent) {
                    $(e).removeClass('eror');
                    //if ($(e).attr("data-cntryId") == "") {
                    //    $(e).val("");
                    //    event.preventDefault();
                    //}
                    if (kpEvent.keyCode == 13 && $("#" + $(e).attr("data-dvIntl")).css("display") != "none") {
                        if (curIndex != -1) {
                            var liItem = $("#" + ulId + " li:eq(" + curIndex + ")");
                            var cid = $(liItem).attr("cityid");
                            vm.Bind($(e).attr("id"), $("#" + $(e).attr("id")).data(cid));
                            //vm.Bind($(e).attr("id"), $(liItem).attr("data-obj"));
                        }
                        vm.CityListHide($(e).attr("id"));
                    }
                });

                //disable cut/copy/paste event in textbox
                $(e).bind("cut copy paste", function (event) {
                    event.preventDefault();
                })


                //textbox key up event
                $(e).keyup(function (event) {
                    //removed this code as this causing invalid city name error  
                    //$(e).attr("data-cityName", "").attr("data-txtVal", "");

                    //if member type length less than srch length hide and abord search
                    if ($(e).val().length < $(e).attr("data-srchlength")) {
                        vm.CityListHide($(e).attr("id"));
                        return;
                    }

                    //in service call waiting for response
                    if (vm.reqWait) {
                        vm.CityLoaderShow($(e).attr("id"));
                        return;
                    }

                    //if user typing continuously wait for finshing typing
                    if (vm.timeoutRef) {
                        $timeout.cancel(vm.timeoutRef);
                        vm.timeoutRef = null;
                    }

                    //if member press up/dowun/enter key's we need to call imediatelly
                    var kc = event.keyCode;
                    if (kc == 40 || kc == 38 || kc == 13 || $(this).val().length == $(this).attr("data-srchlength")) {
                        if (kc != 40 && kc !== 38 && kc != 13)
                            vm.CityLoaderShow($(e).attr("id"));
                        vm.GetData($(e).attr("id"), event);
                    }
                    else {
                        vm.CityLoaderShow($(e).attr("id"));
                        vm.CallGetData($(e).attr("id"), event);
                    }
                });

                //on textbox blur we have to check user enter text is valid or not
                $(e).blur(function () {
                    var txtId = $(e).attr('id');
                    //if city exist set text with state
                    if (vm.IsCityExists(txtId)) {
                        $(e).val($(e).attr("data-txtVal"));
                    }
                    else {
                        //if city not exist call unbide and hide suggestions
                        vm.UnBind(txtId);
                        vm.CityListHide(txtId);
                        $(e).val("Invalid City name");
                        $(e).addClass('eror');
                        $("#" + $(e).attr("data-dvIntl")).hide();
                    }
                });

                //on focus show the avaliable result
                $(e).focus(function (event) {
                    $(e).val($(e).attr("data-cityName"));
                    $(e).removeClass('eror');
                    if ($(e).attr("data-cntryId") != "" && $(e).val()) {
                        if (vm.reqWait)
                            vm.CallGetData($(e).attr("id"), event);
                        else
                            vm.GetData($(e).attr("id"), event);
                    }

                });
            }
        });
    }

    //call GetDate function after 500 milly seconds
    vm.CallGetData = function (txtId, event) {
        vm.timeoutRef = $timeout(function () {
            if (vm.reqWait)
                vm.CallGetData(txtId, event);
            else
                vm.GetData(txtId, event);
        }, 500);
    }

    vm.GetData = function (txtId, event) {
        var txtObj = $("#" + txtId);

        //check user press up or down or enter press
        var kc = event.keyCode;
        if (kc == 40 || kc == 38 || kc == 13) {
            //var liElements = $("#" + ulId + " li");
            //if (kc == 40) {
            //    if (curIndex < liElements.length - 1)
            //        curIndex++;
            //}
            //else if (kc == 38 && curIndex >= 0)
            //    curIndex--;

            //if (liElements.length == 1 && liElements.eq(0).text() == "No Results") {
            //    vm.UnBind(txtId);
            //    return;
            //}

            //liElements.each(function (index, liItem) {
            //    if (index == curIndex) {
            //        $(liItem).css("background-color", "rgb(153, 183, 220)").css("color", "rgb(255, 255, 255)");
            //        $("#" + ulId).scrollTop($("#" + ulId).scrollTop() + $(liItem).position().top);
            //    }
            //    else
            //        $(liItem).css("background-color", "#ffffff").css("color", "#16a085");
            //});
            return;
        }

        curIndex = -1;
        if (txtObj.val().length == parseInt(txtObj.attr("data-srchlength"))) {
            if (!vm.CheckResultsExist(txtObj.attr("data-cntryid"), txtObj.val())) {
                vm.reqWait = true;
                vm.GetCities(txtObj.attr("data-cntryId"), txtObj.val(), function (response, status) {
                    vm.reqWait = false;
                    if (status == 200) {
                        //save result if response is empty or not(becasuse if no cities are found second time you will not to hit service)
                        vm.SaveResults(txtObj.attr("data-cntryid"), txtObj.val(), response);
                        vm.ShowResults(txtId);
                    }
                });
            }
            else {
                vm.ShowResults(txtId);
            }
        }
        else if (txtObj.val().length > parseInt(txtObj.attr("data-srchlength"))) {
            vm.ShowResults(txtId);
        }
        else
            vm.CityListHide(txtId);
    }

    vm.SaveResults = function (countryId, keyword, response) {
        if (!vm.CheckResultsExist(countryId, keyword)) {
            ResultStore.push({ "countryId": countryId, "keyword": keyword, "response": response });
        }
    }

    vm.ShowResults = function (txtId) {
        ulId = ulId + txtId;
        var txtObj = $("#" + txtId);
        var objPos = txtObj.offset();
        var top = objPos.top + txtObj.outerHeight() + 10;
        var left = objPos.left;
        var width = txtObj.outerWidth();

        var selectTag = "";
        var objArr = vm.GetResult(txtId);
        if (objArr.length > 0) {
            for (var i = 0; i < objArr.length; i++) {
                if (objArr[i].cityName.toLowerCase().indexOf(txtObj.val().toLowerCase()) == 0) {
                    selectTag += '<li style="cursor:pointer;text-align:left;font:normal 14px Arial #31a086;color:#16a085;line-height: 1.42857143;padding:6px 12px;border-bottom:1px solid rgba(0,0,0,0.15);"  cityid=\'' + "obj" + objArr[i].cityId + '\'><span>' + objArr[i].cityName + ", " + objArr[i].stateName + '<span></li>';
                    $("#" + txtId).data("obj" + objArr[i].cityId, objArr[i]);
                }
            }
        }
        if (selectTag == "") {
            selectTag = "<li style='cursor:default;text-align:left;background-color:#fff;font:normal 14px Arial;color:red;line-height: 1.42857143;padding:6px 12px;'>No Results</li>"
            vm.CheckAndAddCity(txtObj.attr("data-cntryId"), txtObj.val());
        }
        $("#" + txtObj.attr("data-dvIntl")).html('<ul id="' + ulId + '" txtId="' + txtId + '" style="padding-top: 20px;border: solid 1px #B2B2B7;max-height: 167px;overflow-y: auto;margin: 0px;padding: 0px;list-style-type: none;background-color: white;position:absolute;z-index: 999999;top:0px;left:0px;width:' + width + 'px">' + selectTag + '</ul>');
        vm.CityListShow(txtId);

        //list mouse hover event
        var liElements = $("#" + ulId + " li");
        if (liElements.eq(0).text() != "No Results") {
            liElements.hover(function () {
                var newIndex = $(this).index();
                liElements.each(function (index, liItem) {
                    if (index == newIndex) {
                        curIndex = index;
                        $(liItem).css("background-color", "rgb(153, 183, 220)").css("color", "rgb(255, 255, 255)");
                    }
                    else
                        $(liItem).css("background-color", "#ffffff").css("color", "#16a085");
                });
                event.stopPropagation();
            });

            $("#" + ulId + " li").click(function (event) {
                var cid = $(this).attr("cityid")
                vm.Bind(txtId, $("#" + txtId).data(cid))
                // vm.Bind(txtId, $(this).attr("data-obj"))
                vm.CityListHide(txtId);
            });
        }

        $("#" + ulId + " li").mousedown(function (event) {
            event.preventDefault();
        });
    }

    vm.IsCityExists = function (txtId) {
        var cityExists = false;
        var countryId = $("#" + txtId).attr("data-cntryid");
        var cityName = $("#" + txtId).attr("data-cityname");
        for (var i = 0; i < ResultStore.length; i++) {
            if (countryId == ResultStore[i].countryId && cityName.toLowerCase().indexOf(ResultStore[i].keyword.toLowerCase()) == 0) {
                for (var j = 0; j < ResultStore[i].response.length; j++) {
                    if (ResultStore[i].response[j].cityName.toLowerCase() == cityName.toLowerCase()) {
                        cityExists = true;
                        break;
                    }
                }
            }
        }
        return cityExists;
    }

    vm.GetResult = function (txtId) {
        var countryId = $("#" + txtId).attr("data-cntryid");
        var srchLen = $("#" + txtId).attr("data-srchlength");
        var keyword = $("#" + txtId).val();
        if (countryId == "" || keyword.length < 1)
            return "";

        var obj = "";
        for (var i = 0; i < ResultStore.length; i++) {
            if (countryId == ResultStore[i].countryId && ResultStore[i].keyword.toLowerCase().indexOf(keyword.substring(0, srchLen).toLowerCase()) == 0) {
                obj = ResultStore[i].response;
                break;
            }
        }
        return obj;
    }

    vm.CheckResultsExist = function (countryId, keyword) {
        var keywordExists = false;
        for (var i = 0; i < ResultStore.length; i++) {
            if (countryId == ResultStore[i].countryId && ResultStore[i].keyword.toLowerCase().indexOf(keyword.toLowerCase()) == 0)
                keywordExists = true;
        }
        return keywordExists;
    }

    vm.CityListHide = function (txtId) {
        if (txtId) 
            $("#" + $("#" + txtId).attr("data-dvIntl")).hide();      
        else 
            $("ul#" + ulId).each(function (i, e) {
                $("#" + $(e).parent().attr("id")).hide();
            });
    };

    vm.CityListShow = function (txtId) {
        $("#" + $("#" + txtId).attr("data-dvIntl")).show();
    }

    vm.CityLoaderShow = function (txtId) {
        $("dvLdr").show();
        var txtObj = $("#" + txtId);
        var objPos = txtObj.offset();
        var top = objPos.top + txtObj.outerHeight() + 10;
        var left = objPos.left;
        var width = txtObj.outerWidth();
        var style = "display:block;padding-top:20px;border:solid 1px #B2B2B7;height:100px;margin:0px;padding:0px;background-color:white;position:absolute;z-index: 999999;top:" + top + "px;left:" + left + "px;width:" + width + "px";
        var dvLdr = '<div id="dvLdr" class="ldrImg" style="' + style + '"><div class="clcntr"><img src="https://pccdn.pyar.com/pcimgs/pcloader.svg" height="64" class="ld ld-heartbeat" alt="loading..." /></div></div>';
        $("#" + txtObj.attr("data-dvIntl")).html(dvLdr);
        vm.CityListShow(txtId);
    }

    vm.CityLoaderHide = function (txtId) {
        $("#" + $("#" + txtId).attr("data-dvIntl")).html("");
    }

    vm.Bind = function (txtId, data) {
        //data = JSON.parse(data);
        $("#" + txtId).val(data.cityName + ", " + data.stateName);
        $("#" + txtId).attr("data-cityName", data.cityName);
        $("#" + txtId).attr("data-txtVal", $("#" + txtId).val());
        $rootScope.$broadcast("countryBind", txtId, $("#" + txtId).attr("data-cntryId"), data);
    }

    vm.UnBind = function (txtId) {
        $("#" + txtId).val("");
        $("#" + txtId).attr("data-cityName", "");
        $("#" + txtId).attr("data-txtVal", "");
        $rootScope.$broadcast("countryUnBind", txtId, $("#" + txtId).attr("data-cntryId"));
    }

    //this function is used for country Intellisense edit mode
    //first set country text for dropdown
    //second set required data properties 
    //load all cities for that keyword start with 3 characters for on focus show the list of cities avaliable
    vm.BindCity = function (txtId, dvId, countryId, cityId) {
        var txtObj = $("#" + txtId);
        vm.reqWait = true;

        //Bind country text to div
        vm.GetCountries(function (response, status) {
            if (response && response.length > 0) {
                for (var i = 0; i < response.length; i++) {
                    if (countryId == response[i].countryId) {
                        $("#" + dvId).html(response[i].countryName);
                        txtObj.attr("disabled", false);
                        break;
                    }
                }
            }
        });

        //Bind City text to textbox
        vm.GetCitiesById(countryId, cityId, function (response, status) {
            vm.reqWait = false;
            if (status == 200) {
                if (response && response.length > 0) {
                    vm.SaveResults(countryId, response[0].cityName.substring(0, 3), response);
                    for (var i = 0; i < response.length; i++) {
                        if (countryId == response[i].countryId && cityId == response[i].cityId) {
                            txtObj.attr("disabled", false).attr("data-cntryId", countryId).attr("data-cityName", response[i].cityName).attr("data-txtVal", response[i].cityName + ", " + response[i].stateName).val(response[i].cityName + ", " + response[i].stateName);
                            break;
                        }
                    }
                }
            }
        });
    }

    vm.CheckAndAddCity = function (countryId, cityName) {
        var cityExist = false;
        for (var i = 0; i < vm.newCities.length; i++) {
            if (vm.newCities[i].countryId == countryId && cityName.toLowerCase() == vm.newCities[i].cityName.toLowerCase().toLowerCase()) {
                cityExist = true;
                break;
            }
        }
        if (!cityExist) {
            vm.newCities.push({ "countryId": countryId, "cityName": cityName });
            vm.AddNewCites(countryId, cityName);
        }
    };

    //http actions
    vm.GetCountries = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/utils/countries";
        GetServiceByURL($http, url, function (response, status) {
            if (status == 200) {
                response = $filter("orderBy")(response, "priority");
                funCallBack(response, status);
            }
        });;
    }

    vm.GetCities = function (countryId, cityName, funCallBack) {
        var url = getApiDomainUrl() + "/api/utils/gci/" + countryId + "/" + cityName +"/";
        GetServiceByURL($http, url, funCallBack);
    }

    vm.GetCitiesById = function (countryId, cityId, funCallBack) {
        var url = getApiDomainUrl() + "/api/utils/gcibyId/" + countryId + "/" + cityId;
        GetServiceByURL($http, url, funCallBack);
    }

    vm.AddNewCites = function (countryId, cityName) {
        var url = getApiDomainUrl() + "/api/utils/ctmre";
        var data = { "countryId": countryId, "cityName": cityName };
        PostServiceByURL($http, url, data, function (response, sattus) {
            if (!response)
                console.log("unable to save");
        });
    }
    //End here

    vm.initSrvc = function () {
        vm.BindCountries();
        vm.BindIntelligence();
    };
}]);

var countryDvId = "";
function opnCntryddl(dvId, txtId) {
    countryDvId = dvId;
    $("#" + dvId + "dopn").slideToggle();
    var pos = $("#" + dvId).position();
    var top = $("#" + dvId).outerHeight() + pos.top;
    var width = $("#" + dvId).outerWidth();
    var left = pos.left;
    $("#" + dvId + "dopn").css("position", "absolute").css("top", top).css("left", left).css("width", width);
    $("#" + dvId + "dopn ul li").click(function () {
        $("#" + dvId).html($(this).text());
    });
}

$(document).ready(function () {
    $('body').click(function (evt) {
        if (evt.target.id != countryDvId)
            $("#" + countryDvId + "dopn").slideUp();
    });
});