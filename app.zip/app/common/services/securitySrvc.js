﻿angular.module("app").service('getSessionSrvc', ['msgSrvc','$http', '$window', '$rootScope', '$state', '$cookieStore', 'abndnSrvc', function (msgSrvc,$http, $window, $rootScope, $state, $cookieStore, abndnSrvc) {
    
    // setting login data cookie in encrypt format
    this.setLoginData = function (response) {
        $cookieStore.put("p_sfg", this.pce(JSON.stringify(response)));
        msgSrvc.connectServer(true);
    };

    //Getting member details by passing key.
    this.g_ssnd = function (key) {
        var ck = $cookieStore.get("p_sfg");
        if (ck != null && ck.length != 0)
            return JSON.parse(this.pcd((ck)))[key];
        else
            return "";
    }

    //service for updating login member cookie.
    this.u_ssnd = function (key,val) {
        var ck = $cookieStore.get("p_sfg");
        if (ck != null && ck.length != 0) {            
            var data = JSON.parse(this.pcd(ck));
            data[key] = val;
            $cookieStore.put("p_sfg", this.pce(JSON.stringify(data)));
        }
    }    

    //This Service return Encrypted Text format
    this.pce = function (et) {
        if (et) {
            var encrypted = CryptoJS.AES.encrypt(et, $rootScope.base64Key, { iv: $rootScope.iv });
            var enc = encrypted.ciphertext.toString(CryptoJS.enc.Base64);
            var val = enc.replace(/\+/g, "PPPP1").replace(/\//g, "YYYY4").replace(/\=/g, "RRRR3");
            if (val)
                return val;
            else
                abndnSrvc.rmvSsn();
        }
        else
            return null;
    }

    //This Service return Decrypted Text format
    this.pcd = function (dt) {
        if (dt) {
            dt = dt.replace(/PPPP1/g, "+").replace(/YYYY4/g, "/").replace(/RRRR3/g, "=");
            var decrypted = CryptoJS.AES.decrypt(CryptoJS.lib.CipherParams.create({ ciphertext: CryptoJS.enc.Base64.parse(dt) }), $rootScope.base64Key, { iv: $rootScope.iv });
            var val = decrypted.toString(CryptoJS.enc.Utf8);
            if (val)
                return val;
            else
                return null;//abndnSrvc.rmvSsn();
        }
        return null;
    }

    //Getting member details
    this.p_mId = function () { return this.g_ssnd("mId") };
    this.p_fn = function () { return this.g_ssnd("firstName")};
    this.p_gndr = function () { return this.g_ssnd("gender")};
    this.p_gndrp = function () { return this.g_ssnd("genderPref") };
    this.p_pgc = function () { return this.g_ssnd("storageCollection") };
    this.p_ppic = function () { return this.g_ssnd("profilePic") };
    this.p_ppicblr = function () { return this.g_ssnd("profilePicBlr") };
    this.p_ppicexst = function () { return this.g_ssnd("profilePicExists") };
    this.p_cntryId = function () { return this.g_ssnd("countryId") };
    this.p_cntry = function () { return this.g_ssnd("country") };
    this.p_stateId = function () { return this.g_ssnd("stateId") };
    this.p_sub = function () { return this.g_ssnd("sId") };
    //this.p_subtm = function () { return this.g_ssnd("trailMember") };
    this.p_subtm = function () { return this.g_ssnd("trialMember") };
    this.p_subst = function () { return this.g_ssnd("dateTimeSubscrbSt") };
    this.p_subex = function () { return this.g_ssnd("dateTimeSubscrbExp") };
    this.p_pprntg = function () { return this.g_ssnd("profileCmplnPrcnt") };
    this.p_tz = function () { return this.g_ssnd("timeZone") };
    this.p_uts = function () { return this.g_ssnd("units") };
    this.p_ib = function () { return this.g_ssnd("invisibleBrowsing") };
    this.p_lt = function () { return this.g_ssnd("loginType") };
    this.p_ftPOP = function () { return this.g_ssnd("ftPOP") };
    this.p_ssnId = function () { return this.g_ssnd("ssnId") };
    this.p_trldays = function () { return this.g_ssnd("trialDays") };
    this.p_msgMaxCnt = function () { return this.g_ssnd("msgMaxCnt") };

    this.validateSessionInfo = function (sObj) {
        if (/*GetJSONKeysCount(sObj) == 21 && */sObj.hasOwnProperty("mId") && sObj.mId != "" && sObj.mId != null && sObj.hasOwnProperty("firstName") && sObj.hasOwnProperty("gender") && sObj.hasOwnProperty("genderPref") &&
            sObj.hasOwnProperty("storageCollection") && sObj.hasOwnProperty("profilePic") && sObj.hasOwnProperty("profilePicBlr") && sObj.hasOwnProperty("profilePicExists") && sObj.hasOwnProperty("countryId") && sObj.hasOwnProperty("stateId") &&
            sObj.hasOwnProperty("sId") && sObj.hasOwnProperty("trialMember") && sObj.hasOwnProperty("dateTimeSubscrbSt") && sObj.hasOwnProperty("dateTimeSubscrbExp") && sObj.hasOwnProperty("profileCmplnPrcnt") && sObj.hasOwnProperty("timeZone") && sObj.hasOwnProperty("units") && sObj.hasOwnProperty("invisibleBrowsing") && sObj.hasOwnProperty("loginType") &&
            sObj.hasOwnProperty("ftPOP") && sObj.hasOwnProperty("ssnId") && sObj.hasOwnProperty("trialDays")
         )
            return true
        else
            return false;
    };

    //this method is used to check session existance before loading the page
    this.checkPgSec = function (pgType, event) {
        var path = window.location.pathname;
        if (path.indexOf('/match/') != -1) { //when the memeber is coming from link
            $window.localStorage.setItem("frmLnk", path.split("/")[2]);
        }
        else if (path.indexOf('/accountdel.html') != -1) { //when the memeber is coming from link to delete his account              
            $window.localStorage.setItem("p_adul", ((location.pathname + location.search).substr(1)).split('?')[1]);
        }
        
        if (pgType == "inpg") {
            if (!this.p_mId()) {
                $window.localStorage.setItem("lgnBackUrl", path);
                if (path.indexOf('/accountdel.html') != -1) location.href = "/signin.html";
                else location.href = "/";
                event.preventDefault();
            } else if (path == "/payment.html" && this.p_sub() == 2 && this.p_subtm() == 3) {
                location.href = "/dashboard.html";
                event.preventDefault();
            }
        }
        else if (pgType == "outpg") {
            if (this.p_mId()) {
                location.href = "/dashboard.html";
                event.preventDefault();
            }
        }
        //else if (pgType == "inoutpg") {
        //no need to check this condition 
        //}
    }

    //Signout api calling  
    $rootScope.$on("signoutSession", function (e,data) {
        var ismIdDr = this.p_mId();
        if (ismIdDr != undefined && ismIdDr != null && ismIdDr != '') {
            GetServiceByURL($http, getApiDomainUrl() + "/api/registersignin/signout/" + ismIdDr + "/" + this.p_ssnId(), function () {
            abndnSrvc.signoutUser();
          });
        }
    }.bind(this))

}]);


//Service for remove session
angular.module("app").service('abndnSrvc', ['msgSrvc', '$rootScope', '$window', '$cookieStore', '$state', '$location', '$timeout', function (msgSrvc, $rootScope, $window, $cookieStore, $state, $location, $timeout) {
    var timeOutCncl;
    this.rmvSsn = function (callBack) {
        $rootScope.$emit("signoutSession");
        timeOutCncl = $timeout(function () {
            this.signoutUser();
            callBack();
        }.bind(this), 500);

    };
    this.signoutUser = function () {
        $timeout.cancel(timeOutCncl);
        var p_sfg = $cookieStore.get("p_sfg");
        msgSrvc.disconnectServer();
        if (p_sfg != null || p_sfg != "" || p_sfg != undefined) {
            $cookieStore.remove('p_sfg');
            $cookieStore.remove("P_dbTb");
            $window.sessionStorage.removeItem("8B3414FB");
            $window.localStorage.removeItem("A5D7FPD45");
            $window.sessionStorage.removeItem("DtpsNtP");
            $window.localStorage.removeItem("pmds");
            $window.localStorage.removeItem("ppds");
            $window.localStorage.removeItem("P_dbTb");
            $window.localStorage.removeItem("p_adul");
            $window.localStorage.removeItem("memreg");
            if ($location.path().split("?")[0] == "/account.html" && $window.localStorage.getItem("tmpHd") != null) {
                $window.localStorage.removeItem("tmpHd");
                $window.location.href = "/signouthide.html";
            }
            else if ($location.path() == "/accountdel.html" && $window.localStorage.getItem("acntDlt") != null) {
                $window.localStorage.removeItem("acntDlt");
                $window.location.href = "/";
            }
            else if ($location.path() == "/register/security/details.html") {
                //No redirection                
            }
            else if ($location.path().split("?")[0] == "/forgotpwdreset.html") {
                $window.location.href = "/signinpwdreset.html";
            }
            else {
                $window.location.href = "/signout.html";
            }
        }
    }
}]);

angular.module("app").service('chkregsessionSrvc', ['$window', function ($window) {
    var sVal = localStorage.getItem("memreg");
    if (sVal == "" || sVal == null || sVal == undefined) {
        $window.location.href = "/register.html";
    }
}]);