﻿angular.module("app").controller("unsubcribeCtrl", function ($scope, $timeout) {
    var vm = this;
    showLoader();
    $timeout(function () {
        vm.unsubDv = true;
        hideLoader();
    }, 1000);
})