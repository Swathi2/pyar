﻿angular.module("app").service('subcribeSrvc', ['$http', '$location', function ($http, $location) {

    this.getMemberName = function (encMrId, funCallBack) {
        var url = getApiDomainUrl() + "/api/tu/mbrname/" + encMrId;
        GetServiceByURL($http, url, funCallBack);
    }

    this.isAlreadyRefered = function (encMrId, funCallBack) {
        var url = getApiDomainUrl() + "/api/tu/memrefchk/" + encMrId;
        GetServiceByURL($http, url, funCallBack);
    }

    this.memberSub = function (emailJson, callBackFun) {
        $http({
            method: "POST",
            url: getApiDomainUrl() + "/api/tu/memsub",
            data: emailJson,
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            callBackFun(response, status);
        }).error(function (error, status) {
            alert("Something Going Wrong from webmethod.!");
        });
    }

    this.memberRefEmailChecked = function (emailJson, callBackFun) {
        $http({
            method: "POST",
            url: getApiDomainUrl() + "/api/tu/refemlchk",
            data: emailJson,
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            callBackFun(response, status);
        }).error(function (error, status) {
            alert("Something Going Wrong from webmethod.!");
        });
    }

    this.saveReferelEmails = function (mId, emailJson, callBackFun) {
        $http({
            method: "POST",
            url: getApiDomainUrl() + "/api/tu/saveref/" + mId,
            data: emailJson,
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            callBackFun(response, status);
        }).error(function (error, status) {
            alert("Something Going Wrong from webmethod.!");
        });
    }

    this.unsubscribe = function (mnId, funCallBack) {
        var url = getApiDomainUrl() + "/api/tu/memunsub/" + mnId;
        GetServiceByURL($http, url, funCallBack);
    }

}]);


function showLoader() {
    var dvPcLdrObj = $("#pcldr");
    dvPcLdrObj.css("position", "fixed").css("top", $(window).height() / 2 - dvPcLdrObj.outerHeight() / 2).css("left", $(window).width() / 2 - dvPcLdrObj.outerWidth() / 2);
    dvPcLdrObj.show();
}

function hideLoader() {
    $("#pcldr").hide();
}



function errStatuChk(status) {
    if (status == -1 || status == 0) {
        //doing nothing. no alert.
    }
    else {
        $("#ErrAlert").modal("show"); hideLoader();
    }
    //else if (status == 400)
    //    alert("Bad Request.");
    //else if (status == 401)
    //    alert("Unauth­orized.");
    //else if (status == 403)
    //    alert("Forbidden.");
    //else if (status == 404)
    //    alert("Resource you are requesting is not found.");
    //else if (status == 405)
    //    alert("Method Not Allowed.");
    //else if (status == 500)
    //    alert("Internal Server Error.");
    //else
    //    alert("Something Going Wrong from webmethod.!");
}

// Service for Get Method
function GetServiceByURL($http, url, funCallBack) {
    $http({
        method: "GET",
        url: url,
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'dataType': 'json',
            'appt': 'website'
        }
    }).success(function (response, status) {
        funCallBack(response, status);
    }).error(function (reason, status) {
        errStatuChk(status);
    });
}
// Service for Post Method
function PostServiceByURL($http, url, jsonData, funCallBack) {
    $http({
        method: "POST",
        url: url,
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'dataType': 'json',
            'appt': 'website'
        },
        data: jsonData,
    }).success(function (response, status) {
        //checking function type, if it is function or not
        if (funCallBack && typeof funCallBack === 'function') {
            funCallBack(response, status);
        }
    }).error(function (reason, status) {
        errStatuChk(status);
    });
}


angular.module("app").filter('htmlToPlaintext', function () {
    return function (text) {
        return text ? String(text).replace(/<[^>]+>/gm, '') : '';
    };
});

