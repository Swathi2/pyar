﻿angular.module("app").controller("refersubCtrl", function ($scope, $filter, $state, $stateParams, subcribeSrvc, $interval, $timeout, $rootScope, $window) {
    var vm = this;
    vm.isNotValidMails = true;
    vm.mrId = $stateParams.mId;
    vm.email1 = vm.email2 = vm.email3 = vm.email4 = vm.email5 = "";
    vm.isEmailRyt1 = vm.isEmailRyt2 = vm.isEmailRyt3 = vm.isEmailRyt4 = vm.isEmailRyt5 = false;

    $rootScope.$on("$stateChangeSuccess", function (event, toState, toParams, fromState, fromParams) {
        if (fromState.url = '/default.aspx?mId') {
            vm.refDv = true;            
            hideLoader();
        }
    });

    showLoader();
    $timeout(function () { vm.refDv = true; hideLoader(); }, 1000);

    function needEmailCheck(email) {
        var emailReg = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/
        return emailReg.test(email);
    }

    function sndIvtsBtnDsbl() {
        if (!needEmailCheck(vm.email1) && !needEmailCheck(vm.email2) && !needEmailCheck(vm.email3) && !needEmailCheck(vm.email4) && !needEmailCheck(vm.email4)) {
            vm.btnSndInvtsCls = "ntfybtn";
            vm.isNotValidMails = true;
            vm.btnval = true;
        }
        else {
            if (vm.isEmailRyt1 == false && vm.isEmailRyt2 == false && vm.isEmailRyt3 == false && vm.isEmailRyt4 == false && vm.isEmailRyt5 == false) {
                vm.btnSndInvtsCls = "ntfybtn regBtn";
                vm.isNotValidMails = false;
            }
            else {
                vm.btnSndInvtsCls = "ntfybtn";
                vm.isNotValidMails = true;
            }
        }
    }

    $interval(function () { sndIvtsBtnDsbl(); }, 100);

    vm.referEmailChck1 = function (email) {
        if (vm.email1) {
            if (vm.email1 == vm.email2 || vm.email1 == vm.email3 || vm.email1 == vm.email4 || vm.email1 == vm.email5) {
                vm.emailError1 = 'Please enter a valid email address';
                vm.isEmailRyt1 = true;
                vm.kpImg1 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
            }
            else {
                if (!needEmailCheck(vm.email1)) {
                    vm.emailError1 = 'Please enter a valid email address';
                    vm.isEmailRyt1 = true;
                    vm.kpImg1 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';

                }
                else {
                    vm.emailError1 = '';
                    vm.isEmailRyt1 = false;
                    var emailJson = { 'txt': email }

                    subcribeSrvc.memberRefEmailChecked(emailJson, function (response, status) {
                        if (status == 200) {
                            if (response == "true" || response == true) {
                                vm.emailError1 = "User already invited/subscribed";
                                vm.isEmailRyt1 = true;
                                vm.kpImg1 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
                            }
                        }
                    })
                }
            }
        }
        else {
            vm.kpImg1 = '/';
        }

    }

    vm.referEmailChck2 = function (email) {
        if (vm.email2) {
            if (vm.email2 == vm.email1 || vm.email2 == vm.email3 || vm.email2 == vm.email4 || vm.email2 == vm.email5) {
                vm.emailError2 = 'Please enter a valid email address';
                vm.isEmailRyt2 = true;
                vm.kpImg2 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
            }
            else {
                if (!needEmailCheck(vm.email2)) {
                    vm.emailError2 = 'Please enter a valid email address';
                    vm.isEmailRyt2 = true;
                    vm.kpImg2 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
                }
                else {
                    vm.emailError2 = '';
                    vm.isEmailRyt2 = false;
                    var emailJson = { 'txt': email }

                    subcribeSrvc.memberRefEmailChecked(emailJson, function (response, status) {
                        if (status == 200) {
                            if (response == "true" || response == true) {
                                vm.emailError2 = "User already invited/subscribed";
                                vm.isEmailRyt2 = true;
                                vm.kpImg2 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
                            }
                        }
                    })
                }
            }
        }
        else {
            vm.kpImg2 = '/';
        }
    }

    vm.referEmailChck3 = function (email) {
        if (vm.email3) {
            if (vm.email3 == vm.email1 || vm.email3 == vm.email2 || vm.email3 == vm.email4 || vm.email3 == vm.email5) {
                vm.emailError3 = 'Please enter a valid email address';
                vm.isEmailRyt3 = true;
                vm.kpImg3 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
            }
            else {
                if (!needEmailCheck(vm.email3)) {
                    vm.emailError3 = 'Please enter a valid email address';
                    vm.isEmailRyt3 = true;
                    vm.kpImg3 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
                }
                else {
                    vm.emailError3 = '';
                    vm.isEmailRyt3 = false;
                    var emailJson = { 'txt': email }

                    subcribeSrvc.memberRefEmailChecked(emailJson, function (response, status) {
                        if (status == 200) {
                            if (response == "true" || response == true) {
                                vm.emailError3 = "User already invited/subscribed";
                                vm.isEmailRyt3 = true;
                                vm.kpImg3 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
                            }
                        }
                    })
                }
            }
        }
        else {
            vm.kpImg3 = '/';
        }
    }

    vm.referEmailChck4 = function (email) {
        if (vm.email4) {
            if (vm.email4 == vm.email1 || vm.email4 == vm.email2 || vm.email4 == vm.email3 || vm.email4 == vm.email5) {
                vm.emailError4 = 'Please enter a valid email address';
                vm.isEmailRyt4 = true;
                vm.kpImg4 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
            }
            else {
                if (!needEmailCheck(vm.email4)) {
                    vm.emailError4 = 'Please enter a valid email address';
                    vm.isEmailRyt4 = true;
                    vm.kpImg4 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
                }
                else {
                    vm.emailError4 = '';
                    vm.isEmailRyt4 = false;
                    var emailJson = { 'txt': email }

                    subcribeSrvc.memberRefEmailChecked(emailJson, function (response, status) {
                        if (status == 200) {
                            if (response == "true" || response == true) {
                                vm.emailError4 = "User already invited/subscribed";
                                vm.isEmailRyt4 = true;
                                vm.kpImg4 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
                            }
                        }
                    })
                }
            }
        }
        else {
            vm.kpImg4 = '/';
        }
    }

    vm.referEmailChck5 = function (email) {
        if (vm.email5) {
            if (vm.email5 == vm.email1 || vm.email5 == vm.email2 || vm.email5 == vm.email3 || vm.email5 == vm.email4) {
                vm.emailError5 = 'Please enter a valid email address';
                vm.isEmailRyt5 = true;
                vm.kpImg5 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
            }
            else {
                if (!needEmailCheck(vm.email5)) {
                    vm.emailError5 = 'Please enter a valid email address';
                    vm.isEmailRyt5 = true;
                    vm.kpImg5 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
                }
                else {
                    vm.emailError5 = '';
                    vm.isEmailRyt5 = false;
                    var emailJson = { 'txt': email }

                    subcribeSrvc.memberRefEmailChecked(emailJson, function (response, status) {
                        if (status == 200) {
                            if (response == "true" || response == true) {
                                vm.emailError5 = "User already invited/subscribed";
                                vm.isEmailRyt5 = true;
                                vm.kpImg5 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png';
                                sndIvtsBtnDsbl();
                            }
                        }
                    })
                }
            }
        }
        else {
            vm.kpImg5 = '/';
            sndIvtsBtnDsbl();
        }
    }

    vm.savingReferals = function () {
        showLoader();
        var emlArr = [];

        if (needEmailCheck(vm.email1)) emlArr.push(vm.email1);
        if (needEmailCheck(vm.email2)) emlArr.push(vm.email2);
        if (needEmailCheck(vm.email3)) emlArr.push(vm.email3);
        if (needEmailCheck(vm.email4)) emlArr.push(vm.email4);
        if (needEmailCheck(vm.email5)) emlArr.push(vm.email5);

        var emailJson = { 'txt': emlArr.toString() }

        subcribeSrvc.saveReferelEmails(vm.mrId, emailJson, function (response, status) {
            if (status == 200) {
                if (response == true || response == "true") {
                    hideLoader();                    
                    $window.location.href = "/thankyou.aspx";
                }
            }
        })
    }


    vm.emlKp1 = function () {
        vm.isEmailRyt1 = false;
        vm.kpImg1 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif';
        if (vm.email1) {
            if (needEmailCheck(vm.email1)) { vm.kpImg1 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/chck-mrk.png'; }
            else { vm.kpImg1 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif'; }
        }
        else {
            vm.kpImg1 = "/";
        }
    }

    vm.emlKp2 = function () {
        vm.isEmailRyt2 = false;
        vm.kpImg2 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif';
        if (vm.email2) {
            if (needEmailCheck(vm.email2)) { vm.kpImg2 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/chck-mrk.png'; }
            else { vm.kpImg2 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif'; }
        }
        else {
            vm.kpImg2 = "/";
        }
    }

    vm.emlKp3 = function () {
        vm.isEmailRyt3 = false;
        vm.kpImg3 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif';
        if (vm.email3) {
            if (needEmailCheck(vm.email3)) { vm.kpImg3 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/chck-mrk.png'; }
            else { vm.kpImg3 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif'; }
        }
        else {
            vm.kpImg3 = "/";
        }
    }

    vm.emlKp4 = function () {
        vm.isEmailRyt4 = false;
        vm.kpImg4 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif';
        if (vm.email4) {
            if (needEmailCheck(vm.email4)) { vm.kpImg4 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/chck-mrk.png'; }
            else { vm.kpImg4 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif'; }
        }
        else {
            vm.kpImg4 = "/";
        }
    }

    vm.emlKp5 = function () {
        vm.isEmailRyt5 = false;
        vm.kpImg5 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif';
        if (vm.email5) {
            if (needEmailCheck(vm.email5)) { vm.kpImg5 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/chck-mrk.png'; }
            else { vm.kpImg5 = 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif'; }
        }
        else {
            vm.kpImg5 = "/";
        }
    }
})