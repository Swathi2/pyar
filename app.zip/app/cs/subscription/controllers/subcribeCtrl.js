﻿angular.module("app").controller("subcribeCtrl", function ($scope, $filter, $state, $stateParams, subcribeSrvc, $window, $location) {
    var vm = this;
    vm.currentYear = $filter('date')(new Date(), "yyyy");
    vm.EmailPlaceholder = "Type your email";
    var emailReg = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/
    var urlMemId = $location.absUrl().split('?mId=')[1];

    if (urlMemId) {
        subcribeSrvc.getMemberName(urlMemId, function (response, status) {
            if (status == 200) {
                vm.email = response;
            }
        });
    }

    function emailDtEmty(vm, phTxt) { vm.email = null; vm.EmailPlaceholder = phTxt; }

    //Email blur event
    vm.emailCheck = function () {
        var isMatcheRex = emailReg.test(vm.email);
        if (!isMatcheRex) {
            if (vm.emcval != true) {
                emailDtEmty(vm, 'Type your email');
                vm.isEmailRyt = true;
                vm.emailError = 'Please enter a valid email address';
            }
            else emailDtEmty(vm, 'Must be < 75 characters');
            vm.emcval = false;
        }
        else if (vm.email && vm.email.length > 75) {
            emailDtEmty(vm, 'Must be < 75 characters');
        }
    }

    //Email change event
    vm.emailChnage = function () {
        vm.isEmailRyt = false;
        if (vm.email && vm.email.length > 75) {
            emailDtEmty(vm, 'Must be < 75 characters');
            vm.emcval = true;
        }
        else if (!vm.email) {
            vm.isEmailRyt = true;
            vm.emailError = 'Please enter a valid email address';
            emailDtEmty(vm, 'Type your email');
        }
    }

    //subscribe button disabled function
    vm.sbcrbBtnDsbl = function () {
        if (vm.email && emailReg.test(vm.email)) { vm.btnRegCls = "regBtn"; return false; }
        else { vm.btnRegCls = ""; return true; }
    }

    //subcribe button click event
    vm.SubscribeNow = function (email) {
        showLoader();
        var emailJson = { "txt": email }
        subcribeSrvc.memberSub(emailJson, function (response, status) {            
            if (status == 200) {
                vm.isEmailRyt = false;
                if (response == "1" || response == 1) {
                    vm.emailError = "Already Subscribed";
                    vm.isEmailRyt = true; 
                } else if (response == "2" || response == 2) {
                    vm.emailError = "Invalid Email Format";
                    vm.isEmailRyt = true; 
                } else if (response == "3" || response == 3) {
                    vm.emailError = "Email Should Not Be Empty";
                    vm.isEmailRyt = true; 
                }
                else if (response.length > 10) {
                    vm.email = "";                    
                    $window.location.href = "/emailReferral.aspx?mId=" + response;
                }
            }
            hideLoader();
        })
    }
});


//directive from textbox text limit
app.directive('textLength', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attrs) {
            var limit = parseInt(attrs.textLength);
            angular.element(elem).on("keypress", function (e) {
                if (this.value.length == limit)
                    e.preventDefault();
            });
        }
    }
});