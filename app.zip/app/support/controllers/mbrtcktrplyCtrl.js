﻿angular.module("app").controller('mbrtcktrplyCtrl', ['mbrtckreplySrvc', '$scope', '$window', '$state', '$timeout', function (mbrtckreplySrvc, $scope, $window, $state, $timeout) {
    var vm = this;
    $('body').css('padding-top', '0px');
    vm.isTcktActive = true;
    function getUrlParameter(param, dummyPath) {
        var sPageURL = dummyPath || window.location.search.substring(1),
            sURLVariables = sPageURL.split(/[&||?]/),
            res;

        for (var i = 0; i < sURLVariables.length; i += 1) {
            var paramName = sURLVariables[i],
                sParameterName = (paramName || '').split('=');

            if (sParameterName[0] === param) {
                res = sParameterName[1];
            }
        }
        return res;
    }
    var mtId = getUrlParameter('metId');
    if (mtId) {
        mbrtckreplySrvc.getMemberTicket(mtId, function (response, status) {
            if (status == 200) {
                if (!response[3]) {
                    vm.isTcktActive = true;
                    var ticketResponse = response[1];                   
                    var ticketConvertionResponse = response[2];                    
                    vm.lblHd = vm.mbrEmail = ticketResponse[0].Email;
                    vm.tcktCrtDate = ticketResponse[0].DateCreated;
                    vm.tcktTitle = ticketResponse[0].Title; 
                    vm.tcktId = ticketResponse[0].TicketId;
                    vm.tcktConversations = ticketConvertionResponse;
                } else {
                    vm.isTcktActive = false;
                }
            }
        });

        vm.saveReply = function () {
            if (vm.txtReply) {
                mbrtckreplySrvc.saveMemTicketConvertion(mtId, "", vm.txtReply, "CRPY", function (response, status) {
                    if (status == 200 && response == true) {
                        vm.tcktConversations.push({ ConversationType: false, Description: vm.txtReply, DateTimeCreated: new Date() });
                        vm.txtReply = "";
                        vm.sendBtnDsbld = true;
                        vm.sendBtnCls = "brdrnone cnbtn sndBtn";
                    }
                });
            } else {
                alert("please enter the reply");
            }
        }
    } else {
        $window.location.href = "/err404.html";
    }
    vm.sendBtnDsbld = true;
    vm.sendBtnCls = "brdrnone cnbtn sndBtn";
    vm.txtReplyKeyUp = function () {
        if (vm.txtReply) {
            vm.sendBtnDsbld = false;
            vm.sendBtnCls = "brdrnone cnbtn";
        }
        else {
            vm.sendBtnDsbld = true;
            vm.sendBtnCls = "brdrnone cnbtn sndBtn";
        }
    }
    
}]);