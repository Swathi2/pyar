﻿angular.module("app").service('mbrtckreplySrvc', ['$http', function ($http) {

    this.getMemberTicket = function (mtId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/helpcontact/mtkt/" + mtId + "";
        GetServiceByURL($http, liveUrl, funCallBack);
    }  
    this.saveMemTicketConvertion = function (mtId, title, description, action, funCallBack) {
        var data = {
            "mtId": mtId,
            "title": title,
            "description": description,
            "action": action
        }
        var liveUrl = getApiDomainUrl() + "/api/helpcontact/mtktreply";
        PostServiceByURL($http, liveUrl, data, funCallBack);
    }
}]);