﻿using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Net;

public partial class app_policies_tcm : System.Web.UI.Page
{
    #region Page Load
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            string policyData = ExecuteURL("https://pcapi.pyar.com/api/policies/tc/", "GET");
            if (!string.IsNullOrEmpty(policyData))
            {
                var policyDataObj = JObject.Parse(policyData);

                string version = Convert.ToString(policyDataObj["version"]);
                DateTime createdDT = Convert.ToDateTime(Convert.ToString(policyDataObj["dateCreated"]));
                string policytext = Convert.ToString(policyDataObj["policytext"]);

                dvVersion.InnerText = "Version " + version;
                dateCreated.InnerHtml = "<b>Last updated: " + createdDT.ToString("MMMM dd, yyyy") + "</b>";
                lblpolicytext.Text = policytext;
            }
        }
        catch (Exception) { }
    }
    #endregion

    #region ExecuteURL - web request
    public string ExecuteURL(string authUrl, string method)
    {
        try
        {
            HttpWebRequest webRequest = WebRequest.Create(authUrl) as HttpWebRequest;
            webRequest.Method = method;
            using (WebResponse response = webRequest.GetResponse())
            {
                using (Stream dataStream = response.GetResponseStream())
                {
                    using (StreamReader responseReader = new StreamReader(dataStream))
                    {
                        return responseReader.ReadToEnd().ToString();
                    }
                }
            }
        }
        catch (Exception)
        {
            return "";
        }
    }
    #endregion
}