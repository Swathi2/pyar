﻿angular.module("app").controller('tcCtrl', ['$scope', '$filter', 'tcSrvc', 'getSessionSrvc', 'cmnSrvc', '$window', '$timeout', '$sce', function ($scope, $filter, tcSrvc, getSessionSrvc, cmnSrvc, $window, $timeout, $sce) {
    var vm = this;
    vm.windowht = window.innerHeight;

    //Terms Conditions Service called.
    cmnSrvc.TCService(function (response, status) {
        if (status == 204) {
            alert("the content is not there (take the appropriate action)");
            return false;
        }
        else if (status == 200) {
            showLoader();
            vm.tcVersion = "Version " + eval(JSON.stringify(response.version));
            vm.lstUpdated = "Last updated: " + $filter('date')(eval(JSON.stringify(response.dateCreated)), "MMMM d, yyyy");
            vm.tcContent = $sce.trustAsHtml(response.policytext);
            hideLoader();
        }
    });   
    //open popup Page_Load
    $("#tcModal").modal("show");

    var ids = $window.sessionStorage.getItem("8B3414FB");
    vm.tcUpdateClk = function () {
        if (ids) {
            tcSrvc.tcUpdate(ids, function (response, status) {
                if (status == 200) {
                    function rspStaus(id) {
                        if (response.refId != undefined) {
                            return response.refId.indexOf(id) > -1;
                        }
                    }

                    function navigate(url) {
                        $window.sessionStorage.setItem("8B3414FB", response.id);
                        $window.location.href = url;
                    }

                    if (rspStaus(10) == true) { $("#ErrAlert").modal("show"); hideLoader(); }
                    else if (rspStaus(1) == true) { navigate("/privacy-policy-pop.html"); }
                    else if (rspStaus(2) == true) { navigate("/terms-conditionspop.html"); }
                    else if (rspStaus(3) == true) { navigate("/profilehide.html"); }
                    else if (response.mId != "" && response.mId != null) {
                        $window.sessionStorage.removeItem("8B3414FB");
                        getSessionSrvc.setLoginData(response);
                        $window.location.href = "/dashboard.html";
                    }
                }

            });
        }
        else 
            $window.location.href = "/signin.html";        
    };
}]);