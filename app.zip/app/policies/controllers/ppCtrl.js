﻿angular.module("app").controller('ppCtrl', ['$scope', '$filter', 'ppSrvc', 'getSessionSrvc','cmnSrvc', '$window', '$sce', '$rootScope', function ($scope, $filter, ppSrvc, getSessionSrvc,cmnSrvc, $window, $sce, $rootScope) {
    var vm = this;
    vm.windowht = window.innerHeight;
    // Privacy policy Service called.
    cmnSrvc.PPService(function (response, status) {
        if (status == 204) {
            alert("the content is not there (take the appropriate action)");
            return false;
        }
        else if (status == 200) {
            vm.ppVersion = "Version " + eval(JSON.stringify(response.version));
            vm.lstUpdated = "Last updated: " + $filter('date')(eval(JSON.stringify(response.dateCreated)), "MMMM d, yyyy");
            vm.ppContent = $sce.trustAsHtml(response.policytext);

        }
    });

    //open popup Page_Load
    $("#ppModal").modal("show");

    var ids = $window.sessionStorage.getItem("8B3414FB");
    vm.ppUpdateClk = function () {
        if (ids) {
            ppSrvc.ppUpdate(ids, function (response, status) {
                if (status == 200) {
                    function rspStaus(id) {
                        if (response.refId != undefined) {
                            return response.refId.indexOf(id) > -1;
                        }
                    }

                    function navigate(url) {
                        $window.sessionStorage.setItem("8B3414FB", response.id);
                        $window.location.href = url;
                    }

                    if (rspStaus(10) == true) { $("#ErrAlert").modal("show"); hideLoader(); }
                    else if (rspStaus(1) == true) { navigate("/privacy-policy-pop.html"); }
                    else if (rspStaus(2) == true) { navigate("/terms-conditionspop.html"); }
                    else if (rspStaus(3) == true) { navigate("/profilehide.html"); }
                    else if (response.mId != "" && response.mId != null) {
                        $window.sessionStorage.removeItem("8B3414FB");
                        getSessionSrvc.setLoginData(response);
                        $window.location.href = "/dashboard.html";
                    }
                }

            });
        }
        else
            $window.location.href = "/signin.html";
    };


    vm.EmailPlaceholder = "Email Address";
    //Email blur event
    vm.emailCheck = function () { emlchkBlur($rootScope, vm); }
    //Email change event
    vm.emailChnage = function () { emlchangeEvnt(vm); vm.oufrErr = false; }
    //Email Focus event
    vm.emailFocus = function () { emlFcs(vm); vm.EmailPlaceholder = "Email Address"; }

    vm.optoutfr = function () {
        ppSrvc.ouFr(vm.email, function (response, status) {
            if (status == 200) {
                if (response == 1 || response == "1" || response == 2 || response == "2") {
                    $window.location.href = '/optoutfrt.html';
                }
                else {
                    vm.email = "";
                    vm.oufrErr = true;
                }
            }
            else {
                vm.email = "";
                vm.oufrErr = true;
            }
        })
    }
}]);