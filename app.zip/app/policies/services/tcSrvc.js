﻿// Terms and Conditions Service
angular.module("app").service('tcSrvc', ['$http', function ($http) {
    //// Terms conditons service creation
    //this.TCService = function (funCallBack) {
    //    var url = getApiDomainUrl() + "/api/policies/tc";
    //    GetServiceByURL($http, url, funCallBack);
    //}

    //Service for Terms & conditions Update
    this.tcUpdate = function (ids, funCallBack) {
        var data = {}
        var url = getApiDomainUrl() + "/api/registersignin/tcacpt/" + ids;
        PostServiceByURL($http, url, data, funCallBack);
    }
}]);
