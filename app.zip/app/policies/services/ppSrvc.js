﻿angular.module("app").service('ppSrvc', ['$http', function ($http) {
    //Privacy policy service creation
    //this.PPService = function (funCallBack) {
    //    var url = getApiDomainUrl() + "/api/policies/pp";
    //    GetServiceByURL($http, url, funCallBack);
    //}

    //Service for Privacy Policy Update
    this.ppUpdate = function (ids, funCallBack) {
        var data = {}
        var url = getApiDomainUrl() + "/api/registersignin/ppacpt/" + ids;
        PostServiceByURL($http, url, data, funCallBack);
    }

    //Service for OptOut frined refferal
    this.ouFr = function (email, funCallBack) {
        var data = { val: email }
        var url = getApiDomainUrl() + "/api/dashboard/frdrefoo";
        PostServiceByURL($http, url, data, funCallBack);
    }
}]);