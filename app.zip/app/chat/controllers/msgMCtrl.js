﻿angular.module("app").controller('msgMCtrl', ['$scope', 'getSessionSrvc', '$rootScope', 'msgSrvc', 'cmnSrvc', '$filter', '$timeout', '$state', '$window', function ($scope, getSessionSrvc, $rootScope, msgSrvc, cmnSrvc, $filter, $timeout, $state, $window) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.sId = function () { return getSessionSrvc.p_sub(); };
    vm.fn = function () { return getSessionSrvc.p_fn() };
    vm.pp = function () { return getSessionSrvc.p_ppic() };
    vm.gender = function () { return getSessionSrvc.p_gndr(); };
    vm.tz = function () { return getSessionSrvc.p_tz(); };
    vm.msgMaxCnt = function () { return getSessionSrvc.p_msgMaxCnt(); };
    vm.txtMsgCnt = function () { return msgSrvc.txtOrNumDisplayForMsgCnt(vm.msgMaxCnt()); };
    vm.imgCDN = "https://ngagrpincblobstrdev.blob.core.windows.net/";
    vm.ppm = "https://pccdn.pyar.com/pcmbr/defaults/profilemtns.jpg";
    vm.ppf = "https://pccdn.pyar.com/pcmbr/defaults/profileftns.jpg";
    vm.scrollTo = 0;
    vm.pgNo = 1;
    vm.pgSize = 15;
    vm.gmmBusy = false;
    vm.stopScroll = true;
    vm.zone = function () { return getTimeZoneById(vm.tz()); };
    vm.typingStatus = false;
    vm.mch = [];
    vm.offlineMsgs = [];
    vm.prvHeight = 0;
    vm.txtSndMsg = "";
    vm.txtPaste = false;
    vm.txtFocus = false;
    vm.lastSeen = false;
    vm.sendTyping = false;
    // 1 - bind msgs on selected member
    // 2 - bind previous msgs on on scroll
    // 3 - bind sent msg 
    // 4 - bind receive msg
    vm.msgBindType = "";
    vm.showMC = false;
    vm.tmId = "";
    vm.tmfn = "";
    vm.tmpp = "";
    vm.online = "";
    vm.offline = "";
    vm.convrnId = "";
    vm.seenDT = "";
    vm.urExist = null;
    vm.urExistProcess = false;
    vm.isBD = null;
    vm.tmgender = null;
    vm.isIOS = getBrowserType();
    /**********************************************************
                    Self listeners start
    **********************************************************/
    //$timeout(function () { $rootScope.$broadcast("openMPCW", "ObWFJRt5T8ceQjIY9UF4JQRRRR3RRRR3", "Krishna Giddaluru"); }, 1000);
    $scope.$on("openMPCW", function (e, tmId, fn) {
        try {
            if (vm.sId() == 2) {
                if (tmId) {
                    //empty the object befor settting 
                    vm.showMC = true;
                    if (tmId != vm.tmId) {
                        $("#dvldr").show();
                        vm.resetVariables();
                        vm.tmId = tmId;
                        vm.tmfn = fn;
                        vm.checkConvrnHd();
                        vm.msgBindType = "1";
                        $("body").css("overflow", "hidden");
                    }
                }
            }
            else
                //$("#dvmmcw").modal("show");
                showMobileVerificationPop();

        } catch (e) {
            console.log("openMMC listener  --  " + e.message);
            alert("openMMC listener  --  " + e.message);
        }
    });

    $scope.$on("mchBindCmplt", function (e) {
        try {
            if (vm.msgBindType == "2")// on scroll top load previous messages
                $("#dvmch").animate({ scrollTop: ($("#dvmch").prop("scrollHeight") - (vm.prvHeight - 5)) }, 0);
        } catch (e) {
            console.log("mchBindCmplt  listener  --  " + e.message);
            alert("mchBindCmplt  listener  --  " + e.message);
        }
    });

    $scope.$on("mchBindCmpltFirst", function (e) {
        try {
            if (vm.msgBindType == "1") {// page load
                $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 0);
                $timeout(function () { vm.checkReadAndisBD(vm.mch); }, 100);
            }
            else if (vm.msgBindType == "3")// sent msg
                $timeout(function () { $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 1000) }, 50);
            else if (vm.msgBindType == "4" && vm.isScrollBottom())// receive msg
            {
                $timeout(function () {
                    $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 500);
                    vm.checkMRS(vm.mId(), vm.tmId);
                }, 50);
            }
        } catch (e) {
            console.log("mchBindCmpltFirst  listener  --  " + e.message);
            alert("mchBindCmpltFirst  listener  --  " + e.message);
        }
    });

    $scope.$on("online", function (e) {
        try {
            if (vm.tmId)
                vm.sendOfflineMsgs();
        } catch (e) {
            console.log("online listener  --  " + e.message);
            alert("online listener  --  " + e.message);
        }
    });
    /**********************************************************
                    Self listeners end
    **********************************************************/

    /**********************************************************
                    msg service listeners start
    **********************************************************/
    $scope.$on("msgSrvcReady", function (e) {
        try {
            if (vm.tmId)
                vm.sendOfflineMsgs();
        } catch (e) {
            console.log("msgSrvcReady listener  --  " + e.message);
            alert("msgSrvcReady listener  --  " + e.message);
        }
    });

    $scope.$on("receiveMsg", function (e, mId, fn, msg, tmpp, convernId, datetime, sender) {
        try {
            if (vm.tmId == mId) {
                if (($('body').data('user-mblckdid') == '2' || $('body').data('user-mblckdid') == '4')) {
                    msgSrvc.sendMbrBlockNtfn(vm.mId(), vm.fn(), vm.gender(), vm.tmId, true);   // calling sndblck notifctn api when a user is blocked if gets the msg evn user is blocked
                } else {
                    vm.msgBindType = "4";
                    if (sender)
                        vm.mch.push({ "fmId": vm.mId(), "tmId": vm.tmId, "convrnId": convernId, "msg": msg, "dtCreated": datetime });
                    else {
                        vm.mch.push({ "fmId": vm.tmId, "tmId": vm.mId(), "convrnId": convernId, "msg": msg, "dtCreated": datetime });
                        vm.urExist = true;
                        vm.isBD = true;
                        vm.checkMsgMaxCount();
                    }
                }
                vm.lastSeen = false;
                vm.typingStatus = false;
                $scope.$digest();
            }
        } catch (e) {
            console.log("receiveMsg listener  --  " + e.message);
            alert("receiveMsg listener  --  " + e.message);
        }
    });

    $scope.$on("recTypeReq", function (e, mId) {
        try {
            if (vm.tmId == mId) {
                vm.typingStatus = true;
                $timeout(function () { vm.typingStatus = false; }, 4000);
                $scope.$digest();
            }
        } catch (e) {
            console.log("recTypeReq listener  --  " + e.message);
            alert("recTypeReq listener  --  " + e.message);
        }
    });

    $scope.$on("recSeenStatus", function (e, mId, seenDT) {
        try {
            if (vm.tmId == mId) {
                if (vm.mch.length > 0 && vm.mch[vm.mch.length - 1].fmId == vm.mId()) {
                    var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), seenDT);
                    if (dtObj.date)
                        vm.lastSeenTxt = "Seen " + dtObj.date + " at " + dtObj.time;
                    else
                        vm.lastSeenTxt = "Seen at " + dtObj.time;
                    vm.lastSeen = true;
                    if (vm.isScrollBottom())
                        $timeout(function () { $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 1000) }, 10);
                    $scope.$digest();
                }
            }
        } catch (e) {
            console.log("recSeenStatus listener  --  " + e.message);
            alert("recSeenStatus listener  --  " + e.message);
        }
    });

    $scope.$on("onlineStatusChg", function (e, mId, statusType, status) {
        try {
            if (vm.tmId == mId) {
                if (statusType == 1)
                    vm.online = status;
                else if (statusType == 2)
                    vm.offline = status;
                $scope.$digest();
            }
        } catch (e) {
            console.log("onlineStatusChg listener  --  " + e.message);
        }
    });

    //if a user is blocked suddenly
    $scope.$on("recBlockNtfnChg", function (e, tmId, fn, gender, status) {
        try {
            // maintaning this variable to display blocked img even when user scrolls up the conversation by calling vm.getblckPP() if user is blocked
            if (vm.tmId == tmId) bindBlockStatusMWindow(tmId, fn, status, gender, false) // if blocked chatbox is opened already
            $scope.$digest();
        } catch (e) {
            console.log("ntfn  --  " + e.message);
            alert("ntfn  --  " + e.message);
        }
    });

    $scope.$on("recSelfBlockNtfnChg", function (e, tmId, status) {
        try {
            if (vm.tmId == tmId) bindBlockStatusMWindow(tmId, vm.tmfn, status, vm.tmgender, true) // if blocked chatbox is opened already
            $scope.$digest();
        } catch (e) {
            console.log("ntfn  --  " + e.message);
            alert("ntfn  --  " + e.message);
        }
    });


    function bindBlockStatusMWindow(mId, fn, blockStatus, gndr, isSelfBlock) {
        var blockId = getMemberBlockStatus(isSelfBlock, $('body').data("user-mblckdid"), blockStatus);
        $('body').data("user-mblckdid", blockId);
        switch (blockId) {
            case '4'://both blocked
            case '3'://other member blocked
            case '2'://self blocked
                vm.isMaxMsgRchd = true;
                vm.msgRestriction = true;
                if (blockId == '2') {
                    var imgbygndr = gndr ? "https://pccdn.pyar.com/pcimgs/mblck.png" : "https://pccdn.pyar.com/pcimgs/fmblck.png"
                    gndr = gndr ? 'him' : 'her';
                    vm.errdisplytxt = "You blocked <b>" + fn + "</b> . To send a message, please unblock " + gndr + " from your <a href='#' class='gotoAccnt'>ACCOUNT</a>. Otherwise, you may delete this message thread."
                }
                else
                    vm.errdisplytxt = "<b>" + fn + "</b> has blocked you. This conversation is now closed";
                $("#mshblc" + mId + " .pull-left img").attr("src", imgbygndr)
                vm.isBlockedUser = blockId;
                break;

            default:
            case '1'://not blocked 
                vm.isMaxMsgRchd = false;
                vm.errdisplytxt = "";
                vm.isBlockedUser = blockId;
                break;
        }
    }

    /**********************************************************
                    msg service listeners end
    **********************************************************/

    /**********************************************************
                    msg service functions start
    **********************************************************/
    vm.getMCH = function (funCallBack) {
        try {
            if (vm.tmId)
                msgSrvc.getMemberConvrnHead(vm.mId(), vm.tmId, funCallBack);
        } catch (e) {
            console.log("vm.getMCH  --  " + e.message);
            alert("vm.getMCH  --  " + e.message);
        }
    };

    vm.getMbrInfoById = function (mId, funCallBack) {
        try {
            if (mId)
                msgSrvc.getmemberInfoById(mId, funCallBack);
        } catch (e) {
            console.log("vm.getMbrInfoById  --  " + e.message);
            alert("vm.getMbrInfoById  --  " + e.message);
        }
    };

    vm.getMM = function () {
        try {
            if (vm.tmId) {
                if (vm.stopScroll || vm.gmmBusy) return;
                vm.prvHeight = $("#dvmch").prop("scrollHeight");
                $("#dvldr").show();
                vm.gmmBusy = true;
                msgSrvc.getMemberMessages(vm.convrnId, vm.mId(), vm.tmId, vm.pgNo, vm.pgSize, function (response, status) {
                    $("#dvldr").hide();
                    vm.gmmBusy = false;
                    if (status == 200) {
                        if (vm.pgNo == 1)
                            vm.getMemberBlockId(vm.tmId);

                        if (response && response.length > 0) {
                            if (response.length < vm.pgSize)
                                vm.stopScroll = true;
                            for (var i = 0; i < response.length; i++)
                                vm.mch.unshift(response[i]);
                        }
                        else
                            vm.stopScroll = true;
                        vm.pgNo++;
                    }
                });
            }
        } catch (e) {
            console.log("vm.getMM  --  " + e.message);
            alert("vm.getMM  --  " + e.message);
        }
    };

    vm.getMemberBlockId = function (tmId) {
        cmnSrvc.getMemberBlockId(tmId, function (response, status) {
            vm.isMsgInfoLoaded = true;
            if (status == 200) {
                if (response == '1')
                    vm.checkMsgMaxCount();
                else {
                    if (response == '2') bindBlockStatusMWindow(vm.tmId, vm.tmfn, true, vm.tmgender, true)
                    else if (response == '3') bindBlockStatusMWindow(vm.tmId, vm.tmfn, true, vm.tmgender, false)
                    else if (response == '4') bindBlockStatusMWindow(vm.tmId, vm.tmfn, true, vm.tmgender, true)
                };
            };
        })
    };

    vm.sendbtnClk = function () {
        if (vm.sId() == 2) {
            vm.sendMsg();
            $("#txtSndMsg").focus();
        }
        else
            showMobileVerificationPop();
        //$("#dvmmcw").modal("show");            
    };

    vm.sendMsg = function () {
        try {
            if (vm.sId() == 2 && vm.txtSndMsg) {
                if ($rootScope.online) {
                    msgSrvc.sendMsg(vm.tmId, vm.fn(), vm.pp(), vm.convrnId, vm.txtSndMsg);
                    vm.addMsgMaxCount();
                    vm.checkMCHdBD(vm.tmId);
                    vm.lastSeen = false;
                }
                else {
                    vm.offlineMsgs.push({ "tmId": vm.tmId, "fn": vm.fn(), "pp": vm.pp(), "convrnId": vm.convrnId, "msg": vm.txtSndMsg });
                    vm.disableInput = true;
                }
                vm.lastSeen = false;
                vm.msgBindType = "3";
                vm.mch.push({ "fmId": vm.mId(), "tmId": vm.tmId, "convrnId": vm.convrnId, "msg": vm.txtSndMsg, "dtCreated": moment.utc(new Date()).format() });
                $rootScope.$broadcast("bindCWMsg", vm.tmemId, vm.fn(), vm.msgTxt, vm.pp(), vm.convrnId, new Date(), true);
                vm.txtSndMsg = "";
            }
        } catch (e) {
            console.log("vm.sendMsg  --  " + e.message);
            alert("vm.sendMsg  --  " + e.message);
        }
    };

    vm.sendOfflineMsgs = function () {
        try {
            if ($rootScope.online && msgSrvc.conId) {
                while (vm.offlineMsgs.length > 0) {
                    msgSrvc.sendMsg(vm.offlineMsgs[0].tmId, vm.offlineMsgs[0].fn, vm.offlineMsgs[0].pp, vm.offlineMsgs[0].convrnId, vm.offlineMsgs[0].msg);
                    vm.addMsgMaxCount();
                    vm.checkMCHdBD(vm.tmId);
                    vm.offlineMsgs.splice(0, 1);
                    vm.disableInput = false;
                }
            }
        } catch (e) {
            console.log("vm.sendOfflineMsgs  --  " + e.message);
            alert("vm.sendOfflineMsgs  --  " + e.message);
        }
    };

    vm.sendTypeReq = function () {
        try {
            if (vm.tmId && vm.txtSndMsg && !vm.sendTyping) {
                vm.sendTyping = true;
                msgSrvc.sendTypeRequest(vm.tmId);
                $timeout(function () { vm.sendTyping = false; }, 5000);
            }
        } catch (e) {
            console.log("vm.sendTypeReq  --  " + e.message);
            alert("vm.sendTypeReq  --  " + e.message);
        }
    };
    /**********************************************************
                    msg service functions start
    **********************************************************/

    /**********************************************************
                    chat convrn helper functions start
    **********************************************************/
    vm.setMatch = function () {
        if ($(window).width() <= 767 && vm.tmId) {
            $rootScope.$broadcast("matchbrdcast", vm.tmId);
            vm.showMC = false;
        }
        else
            $window.open("/match/" + getSessionSrvc.pce(vm.tmId), "_blank");
    };

    vm.getPP = function (mId) {
        if (mId == vm.tmId) {
            if (vm.tmpp) return vm.imgCDN + vm.tmpp.replace("/p/tnb/", "/p/tns/");
            else if (vm.tmgender) return vm.ppm;
            else return vm.ppf;
        }
        else if (mId == vm.mId()) {
            if (vm.pp()) return vm.imgCDN + vm.pp().replace("/p/tnb/", "/p/tns/");
            else if (vm.gender()) return vm.ppm;
            else return vm.ppf;
        }
    };

    vm.getblckPP = function (mId) {
        if (vm.mId() == mId)
            return vm.imgCDN + vm.pp().replace("/p/tnb/", "/p/tns/");
        else
            return vm.tmgender ? "https://pccdn.pyar.com/pcimgs/mblck.png" : "https://pccdn.pyar.com/pcimgs/fmblck.png";
    }

    vm.resetVariables = function () {
        try {
            vm.pgNo = 1;
            vm.stopScroll = false;
            vm.gmmBusy = false;
            vm.lastSeen = false;
            vm.mch = [];
            vm.txtSndMsg = "";
            vm.lenErr = false;
            //to member data
            vm.tmId = "";
            vm.tmfn = "";
            vm.tmpp = "";
            vm.online = "";
            vm.offline = "";
            vm.convrnId = "";
            vm.seenDT = "";
            vm.urExist = null;
            vm.isBD = false;
            vm.msgInitiator = true;
            vm.msgCnt = 0;
            vm.tmgender = null;
            vm.sendTyping = false;
            vm.isMsgAvail = false;
            vm.isMaxMsgRchd = false;
            vm.isMsgInfoLoaded = false;
            vm.isBlockedUser = '1';
        } catch (e) {
            console.log("vm.resetVariables  --  " + e.message);
            alert("vm.resetVariables  --  " + e.message);
        }
    };

    vm.setMbrData = function (tmId, fn, pp, online, offline, convrnId, seenDT, urExist, urExistProcess, isBD, msgInitiator, msgCnt, gender) {
        try {
            vm.tmId = tmId;
            vm.tmfn = fn;
            vm.tmpp = pp;
            vm.online = online;
            vm.offline = offline;
            vm.convrnId = convrnId;
            vm.seenDT = seenDT;
            vm.urExist = urExist;
            vm.urExistProcess = urExistProcess;
            vm.isBD = isBD;
            vm.msgInitiator = msgInitiator;
            vm.msgCnt = msgCnt;
            vm.tmgender = gender;
            vm.checkMsgMaxCount();
            $('body').data("user-mblckdid", '1');
        } catch (e) {
            console.log("vm.setMbrData  --  " + e.message);
            alert("vm.setMbrData  --  " + e.message);
        }
    };

    vm.checkMsgMaxCount = function () {
        if (vm.msgMaxCnt() > 0 && $("body").data("user-mblckdid") == '1' && vm.tmId && vm.isBD == false && vm.msgInitiator == true && vm.msgCnt >= vm.msgMaxCnt()) {
            vm.isMaxMsgRchd = true;
            var gndrtxt = vm.tmgender ? "him" : "her"
            vm.errdisplytxt = "You have already sent " + vm.tmfn + " " + vm.txtMsgCnt() + " messages. To send more messages, please wait for " + gndrtxt + " to respond."
        }
        else {
            vm.isMaxMsgRchd = false;
            vm.errdisplytxt = "";
        }
    }

    vm.addMsgMaxCount = function () {
        if (vm.tmId && vm.isBD == false && vm.msgInitiator == true)
            vm.msgCnt = vm.msgCnt + 1;
    }

    vm.checkConvrnHd = function () {
        try {
            if (vm.tmId) {
                vm.getMCH(function (response, status) {
                    if (status == 200) {
                        if (response && response != null) {
                            vm.setMbrData(response.tmId, response.fn, response.pp, response.online, response.offline, response.convrnId, response.seenDT, response.urExist, false, response.isBD, response.msgInitiator, response.msgCnt, response.gender);
                            vm.getMM();
                        }
                        else
                            vm.checkMbrInfo();
                    }
                });
            }
        } catch (e) {
            console.log("vm.checkConvrnHd  --  " + e.message);
            alert("vm.checkConvrnHd  --  " + e.message);
        }
    };

    vm.checkMbrInfo = function () {
        try {
            if (vm.tmId) {
                vm.getMbrInfoById(vm.tmId, function (response, status) {
                    if (status == 200) {
                        if (response && response != "invalid mId") {
                            vm.isMsgAvail = true;
                            vm.setMbrData(response.mId, response.fn, response.pp, response.online, response.offline, "", "", true, false, false, true, 0, response.gender);
                            vm.getMM();
                        }
                        else
                            alert("member not found");
                    };
                });
            }
        } catch (e) {
            console.log("vm.checkMbrInfo  --  " + e.message);
            alert("vm.checkMbrInfo  --  " + e.message);
        }
    };

    vm.hideMC = function () {
        try {
            vm.resetVariables();
            $("body").css("overflow", "");
            vm.showMC = false;
            if ($rootScope.ismsgPopFrmop) { // show the otherProfile when Msg popup opens frm OthrProfile
                $("#matchmb").show();
                $("body").css("overflow", "hidden");
            };
        } catch (e) {
            console.log("vm.hideMC  --  " + e.message);
            alert("vm.hideMC  --  " + e.message);
        }
    };

    vm.txtSndMsgFocus = function (e) {
        try {
            if (vm.sId() == 2) {
                vm.txtFocus = true;
                if (vm.isScrollBottom())
                    $timeout(function () { $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 0); }, 0);
            }
            else {
                $("#txtSndMsg").blur();
                showMobileVerificationPop();
                //$("#dvmmcw").modal("show");
            }
        } catch (e) {
            console.log("vm.txtSndMsgFocus  --  " + e.message);
            alert("vm.txtSndMsgFocus  --  " + e.message);
        }
    };

    vm.scrolling = function (e, c) {
        e.scrollIntoView();
        if (c < 5) $timeout(function () { vm.scrolling(e, c + 1) }, 0);
    };

    vm.txtSndMsgChg = function () {
        try {
            if (vm.txtPaste && vm.txtSndMsg.length > 1000)
                vm.lenErr = true;
            else
                vm.lenErr = false;
            if (vm.txtSndMsg.length > 1000)
                vm.txtSndMsg = vm.txtSndMsg.substring(0, 1000);
            vm.sendTypeReq();
        } catch (e) {
            console.log("vm.txtSndMsgChg  --  " + e.message);
            alert("vm.txtSndMsgChg  --  " + e.message);
        }
    };

    vm.txtSndMsgkeyPress = function (event) {
        try {
            if (vm.tmId && event.keyCode == 13 && vm.txtSndMsg)
                vm.sendMsg();
        } catch (e) {
            console.log("vm.txtSndMsgkeyPress  --  " + e.message);
            alert("vm.txtSndMsgkeyPress  --  " + e.message);
        }
    };
    /**********************************************************
                    chat convrn helper functions end
    **********************************************************/

    /**********************************************************
                member chat histroy functions start
    **********************************************************/
    $("#dvmch").scroll(function (e) {
        try {
            if (vm.isScrollTop()) {
                vm.msgBindType = "2";
                vm.getMM();
            }
            else if (vm.isScrollBottom())
                vm.checkMRS(vm.mId(), vm.tmId);
        } catch (e) {
            console.log("dvmch scroll  --  " + e.message);
            alert("dvmch scroll  --  " + e.message);
        }
    });

    vm.checkReadAndisBD = function () {
        try {
            //append last seen when last msg ins login member msg
            var showSeen = false;
            if (vm.mch && vm.mch.length > 0)
                showSeen = $filter("orderBy")(vm.mch, "-dtCreated")[0].fmId == vm.mId() ? true : false;
            if (showSeen && vm.seenDT) {
                var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), vm.seenDT);
                if (dtObj.date)
                    vm.lastSeenTxt = "Seen " + dtObj.date + " at " + dtObj.time;
                else
                    vm.lastSeenTxt = "Seen at " + dtObj.time;
                vm.lastSeen = true;
                $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 1000);
            }
            else
                vm.lastSeen = false;

            //if unread exist true update to read
            if (vm.urExist)
                vm.checkMRS();
            //if conversion are not bidirectional check and update 
            if (!vm.isBD)
                vm.findMBD();
        } catch (e) {
            console.log("vm.checkReadAndisBD  --  " + e.message);
            alert("vm.checkReadAndisBD  --  " + e.message);
        }
    };

    vm.checkMRS = function () {
        try {
            if (vm.urExist && vm.urExistProcess == false && vm.isScrollBottom())
                vm.updateMRS();
        } catch (e) {
            console.log("vm.checkMRS --  " + e.message);
            alert("vm.checkMRS --  " + e.message);
        }
    };

    vm.updateMRS = function () {
        try {
            vm.urExistProcess = true;
            msgSrvc.updateMsgReadStatus(vm.mId(), vm.tmId, function (response, status) {
                if (status = 200 && response) {
                    vm.urExist = false;
                    vm.urExistProcess = false;
                    //check and decrese the count for unread msgs
                    $rootScope.$broadcast("chgMsgReadCount", [vm.tmId], false);
                }
                else {
                    console.log("unable to update read status  --  " + response);
                    alert("unable to update read status  --  " + response);
                }
            });
        } catch (e) {
            console.log("vm.updateMRS --  " + e.message);
            alert("vm.updateMRS --  " + e.message);
        }
    };

    vm.findMBD = function () {
        try {
            if (vm.isBD == false && vm.mch && vm.mch.length > 0) {
                var fmCnt = 0, tmCnt = 0;
                for (var i = 0; i < vm.mch.length; i++) {
                    if (vm.mch[i].fmId == vm.mId())
                        fmCnt++;
                    else
                        tmCnt++;
                }
                //check who to replay for set isBD
                if (vm.mch.length == tmCnt)
                    vm.isBDType = "1";//update in sending msg
                else if (vm.mch.length == fmCnt)
                    vm.isBDType = "2";//update will happen when other member send msg
                else if (fmCnt > 0 && tmCnt > 0) {
                    vm.updateMCHdBD();
                }
            }
        } catch (e) {
            console.log("vm.findMBD --  " + e.message);
            alert("vm.findMBD --  " + e.message);
        }
    };

    vm.checkMCHdBD = function () {
        try {
            vm.isMsgAvail = false;
            if (vm.isBD == false) {
                if (vm.msgInitiator == false)
                    vm.updateMCHdBD(vm.mId(), vm.tmId);
                else
                    vm.checkMsgMaxCount();
            }
        } catch (e) {
            console.log("vm.checkMCHdBD  --  " + e.message);
            alert("vm.checkMCHdBD  --  " + e.message);
        }
    };

    vm.updateMCHdBD = function () {
        try {
            msgSrvc.updateMsgConvHdBiDirectional(vm.mId(), vm.tmId, function (response, status) {
                if (status == 200 && response == "true") {
                    vm.isBD = true;
                    vm.isBDType = "3";
                    //broadcast for isbdupdate
                    $rootScope.$broadcast("chgIsBD", vm.tmId);
                }
            });
        } catch (e) {
            console.log("vm.updateMCHdBD --  " + e.message);
            alert("vm.updateMCHdBD --  " + e.message);
        }
    };
    /**********************************************************
                member chat histroy functions end
    **********************************************************/

    /**********************************************************
                    member helper function end
    **********************************************************/
    vm.isScrollTop = function () {
        try {
            if ($("#ulmch li").length > 0 && $("#dvmch").length > 0 && $("#dvmch").scrollTop() == 0)
                return true;
            else
                return false;
        } catch (e) {
            console.log("vm.isScrollTop  --  " + e.message);
            alert("vm.isScrollTop  --  " + e.message);
        }
    };

    vm.isScrollBottom = function () {
        try {
            var $this = $("#dvmch");
            if ($("#ulmch li").length > 0 && $this.length > 0) {
                var scrollTop = $this.scrollTop() + $this.innerHeight() + $("#ulmch li:last-child").height() + 50;
                if (scrollTop >= $this[0].scrollHeight)
                    return true;
                else
                    return false;
            }
            else
                return true;
        } catch (e) {
            console.log("vm.isScrollBottom  --  " + e.message);
            alert("vm.isScrollBottom  --  " + e.message);
        }
    };

    vm.getDateOrTime = function (dt) {
        try {
            var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), dt);
            if (dtObj.date)
                return dtObj.date;
            else if (dtObj.time)
                return dtObj.time;
            else
                return "";
        } catch (e) {
            console.log("vm.getDateOrTime  --  " + e.message);
            alert("vm.getDateOrTime  --  " + e.message);
        }
    };

    vm.isDatesSame = function (fromDt, toDt) {
        try {
            if (fromDt && toDt) {
                fromDt = new Date(fromDt);
                toDt = new Date(toDt);
                return fromDt.getMonth() == toDt.getMonth() && fromDt.getDate() == toDt.getDate() && fromDt.getFullYear() == toDt.getFullYear();
            }
            else
                return null;
        } catch (e) {
            console.log("vm.compareDate  --  " + e.message);
            alert("vm.compareDate  --  " + e.message);
        }
    };

    vm.getDate = function (dt) {
        try {
            return msgSrvc.getDate(vm.zone(), dt);
        } catch (e) {
            console.log("vm.getDate  --  " + e.message);
            alert("vm.getDate  --  " + e.message);
        }
    };

    vm.getTime = function (dt) {
        try {
            return msgSrvc.getTime(vm.zone(), dt);
        } catch (e) {
            console.log("vm.getTime  --  " + e.message);
            alert("vm.getTime  --  " + e.message);
        }
    };
    /**********************************************************
                    member helper function end
    **********************************************************/
    //vm.goMbrship = function () {
    //    $("#dvmmcw").modal("hide");
    //    vm.hideMC();
    //    //$state.go("membership");
    //};
}]);