﻿/// <reference path="../../../scripts/angular-signalr-hub.min.js" />
/// <reference path="../../../scripts/angular.js" />
/// <reference path="../services/msgSrvc.js" />
angular.module("app").controller('msgCtrl', ['getSessionSrvc', 'msgSrvc', 'cmnSrvc', '$rootScope', '$scope', '$location', '$timeout', '$compile', '$state', '$window', '$filter', function (getSessionSrvc, msgSrvc, cmnSrvc, $rootScope, $scope, $location, $timeout, $compile, $state, $window, $filter) {
    var vm = this;
    /**********************************************************
                        Variabl Declaration
    **********************************************************/
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.sId = function () { return getSessionSrvc.p_sub() };
    vm.fn = function () { return getSessionSrvc.p_fn(); };
    vm.gndr = function () { return getSessionSrvc.p_gndr(); };
    vm.pp = function () { return getSessionSrvc.p_ppic(); };
    vm.tz = function () { return getSessionSrvc.p_tz(); };
    vm.msgMaxCnt = function () { return getSessionSrvc.p_msgMaxCnt(); };
    vm.msgCWPgHideArr = ['/membership.html', '/terms-conditions.html', '/privacy-policy.html', '/msgcenter.html', '/account.html', '/payment.html', '/changecard.html', '/paymentsuccess/'];
    vm.imgCDN = "https://pccdn.pyar.com/";
    vm.ppm = "https://pccdn.pyar.com/pcmbr/defaults/profilemtns.jpg";
    vm.ppf = "https://pccdn.pyar.com/pcmbr/defaults/profileftns.jpg";
    vm.nawId = "";
    vm.msgCenterPgs = ["/msgcenter.html"];
    vm.mst = "";
    vm.inputChanged = false;
    vm.zone = function () { return getTimeZoneById(vm.tz()); };
    vm.pgSize = 10;
    vm.showList = [];
    vm.mnwSrchList = [];
    vm.ppHW = { width: 35, height: 35 };
    vm.mrc = [];
    vm.mrcEmpty = false;
    vm.mrcloader = true;
    vm.mcs = null;
    //new message window
    vm.txtncwsrch = null;
    vm.ncwRslts = [];
    //offline msg
    vm.offlineMsgs = [];
    /**********************************************************
                        Variabl Declaration End
    **********************************************************/

    /**********************************************************
                        msg service listeners start
    **********************************************************/
    $scope.$on("mrc", function (e, response, status) {
        try {
            if (status == 200) {
                vm.mrcloader = false;
                if (response && response.length > 0) {
                    vm.mrc = response;
                    vm.mrcEmpty = false;
                }
                else
                    vm.mrcEmpty = true;
            }
            else {
                alert("unable to update member login data");
                console.log("unable to update member login data");
            }
        } catch (e) {
            console.log("mrc  --  " + e.message);
            alert("mrc  --  " + e.message);
        }
    });

    $scope.$on("receiveMsg", function (e, mId, fn, msg, tmpp, convrnId, datetime, sender) {
        try {
            if ($("#private_" + mId).length > 0 && ($("#private_" + mId + " #chat-con").attr("user-blckdid") == '2' || $("#private_" + mId + " #chat-con").attr("user-blckdid") == '4')) {
                msgSrvc.sendMbrBlockNtfn(vm.mId(), vm.fn(), vm.gndr(), mId, true);   // calling sndblck notifctn api when a user is blocked if gets the msg even blocked
            } else vm.bindMRM(mId, fn, msg, tmpp, convrnId, datetime, sender);
        } catch (e) {
            alert('error : receiveMsg \n' + e.message);
            console.log('error : receiveMsg \n' + e.message);
        }
    });

    $scope.$on("recTypeReq", function (e, mId) {
        try {
            var ctrId = 'private_' + mId;
            if ($('#' + ctrId).length > 0) {
                $('#' + ctrId + ' #dvTyping').fadeIn("slow");
                if (vm.isScrollOnBottom(ctrId)) {
                    $("#" + ctrId + " .panel-body .chtcnt").animate({ scrollTop: $("#" + ctrId + " #chat-con").prop("scrollHeight") }, 2000);
                    $("#" + ctrId + " #lastseen").hide();
                }
                $('#' + ctrId + ' #dvTyping').delay(2000).fadeOut("slow");
            }
        } catch (e) {
            console.log("recTypeReq  --  " + e.message);
            alert("recTypeReq  --  " + e.message);
        }
    });

    $scope.$on("recSeenStatus", function (e, mId, seenDT) {
        try {
            var ctrId = 'private_' + mId;
            var seenObj = $("#" + ctrId + " #lastseen");
            var liObj = $("#" + ctrId + " #chat-con li:last-child");
            if (seenObj.length > 0 && liObj.attr("data-sender") == "true") {
                var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), seenDT);
                $("#" + ctrId + " #dvTyping").hide();
                if (dtObj.date)
                    seenObj.text("Seen " + dtObj.date + " at " + dtObj.time);
                else
                    seenObj.text("Seen at " + dtObj.time);
                seenObj.show();
                if (vm.isScrollOnBottom(ctrId))
                    $("#" + ctrId + " .panel-body .chtcnt").animate({ scrollTop: $("#" + ctrId + " #chat-con").prop("scrollHeight") }, 2000);
            }
        } catch (e) {
            console.log("recSeenStatus  --  " + e.message);
            alert("recSeenStatus  --  " + e.message);
        }
    });

    $scope.$on("statuTextChg", function (e, mId, statusText) {
        try {
            for (var i = 0; i < vm.mrc.length; i++) {
                if (vm.mrc[i].tmId == mId) {
                    vm.mrc[i].mst = statusText;
                    $scope.$digest();
                    break;
                }
            }
        } catch (e) {
            alert('error : statuTextChg \n' + e.message);
            console.log('error : statuTextChg \n' + e.message);
        }
    });

    $scope.$on("onlineStatusChg", function (e, mId, statusType, status) {
        try {
            //set active/inactive image for chat list window
            for (var i = 0; i < vm.mrc.length; i++) {
                if (vm.mrc[i].tmId == mId) {
                    if (statusType == 1)
                        vm.mrc[i].online = status;
                    else if (statusType == 2)
                        vm.mrc[i].offline = status;
                    status = vm.mrc[i].online && !vm.mrc[i].offline;
                    $scope.$digest();
                    break;
                }
            }
            vm.chgStatusImg(mId, status);
        } catch (e) {
            console.log("onlineStatusChg  --  " + e.message);
            alert("onlineStatusChg  --  " + e.message);
        }
    });

    $scope.$on("selfOnlineStatusChg", function (e, mId, statusType, status) {
        try {
            if (vm.mId() == mId && statusType == 2) {
                vm.mcs.offline = status;
                $scope.$digest();
            }
        } catch (e) {
            console.log("selfOnlineStatusChg listener  --  " + e.message);
        }
    });

    $scope.$on("msgSrvcReady", function (e) {
        try {
            if (!vm.mcs)
                vm.getMCS();
            vm.sendOfflineMsgs();
            vm.checkPendingTasks();
        } catch (e) {
            console.log("msgSrvcReady  --  " + e.message);
            alert("msgSrvcReady  --  " + e.message);
        }
    });

    //if a user is blocked suddenly
    $scope.$on("recBlockNtfnChg", function (e, tmId, fn, gender, status) {
        try {
            checkBlockStatus(tmId, fn, gender, status, false);
        } catch (e) {
            console.log("ntfn  --  " + e.message);
            alert("ntfn  --  " + e.message);
        }
    });

    $scope.$on("recSelfBlockNtfnChg", function (e, tmId, status) {
        try {
            var fn = $('#private_' + tmId).find("span#name").attr("data-name");
            var gender = $('#private_' + tmId).find("span#name").attr("data-gender");
            checkBlockStatus(tmId, fn, gender, status, true);
        } catch (e) {
            console.log("ntfn  --  " + e.message);
            alert("ntfn  --  " + e.message);
        }
    });

    $rootScope.$on("selfblck", function (e, tmId, fn, gender, status) {
        try {
            checkBlockStatus(tmId, fn, gender, status, true);
        } catch (e) {
            console.log("ntfn  --  " + e.message);
            alert("ntfn  --  " + e.message);
        }
    });

    function checkBlockStatus(tmId, fn, gender, blockStatus, isSelfBlock) {
        if ($("#private_" + tmId).length > 0) bindBlockStatusChatWindow(tmId, fn, blockStatus, gender, isSelfBlock) // showing error msg to the blocked user whose chatbox is opened already
        if (vm.ncwRslts.length > 0 && blockStatus) removeNWResultById(tmId);
        if (vm.mrc.length > 0) removeRecentMessageMemberById(tmId, blockStatus, gender) // member to be disabled in chatlist box 
    }

    function removeNWResultById(tmId) {
        var splcindx = vm.ncwRslts.findIndex(function (obj) {
            return obj.tmId == tmId
        });
        if (splcindx != -1) vm.ncwRslts.splice(splcindx, 1);
    }

    function removeRecentMessageMemberById(tmId, blockStatus, gender) {
        // get the index of chatList
        var splcindx = vm.mrc.findIndex(function (obj) {
            return obj.tmId == tmId
        });

        if (splcindx != -1) {
            if (blockStatus) {
                // if user exists in the list and he/she is blocked
                if ($("#private_" + tmId).length > 0) {
                    var imgbygndr = gender ? "https://pccdn.pyar.com/pcimgs/mblck.png" : "https://pccdn.pyar.com/pcimgs/fmblck.png"
                    $("#blckcht" + tmId + " img").attr("src", imgbygndr);
                    $("#blckcht" + tmId).addClass("blckchatdsb");
                    $("#blckcht" + tmId + " .onlne").css("display", "none");
                } else
                    vm.mrc.splice(splcindx, 1)
            } else {
                // if user exists in the list and he/she is unblocked
                var blckdId = $("#private_" + tmId + " #chat-con").attr("user-blckdid");
                if (blckdId == '1' || !blckdId) {
                    var obj = vm.mrc[splcindx];
                    $("#blckcht" + tmId + " img").attr("src", vm.getPP(obj.pp, obj.gender));
                    $("#blckcht" + tmId).removeClass("blckchatdsb");
                    $("#blckcht" + tmId + " .onlne").css("display", "block");
                }
            }
        }
    }

    function bindBlockStatusChatWindow(mId, fn, blockStatus, gndr, isSelfBlock) {
        var blockId = getMemberBlockStatus(isSelfBlock, $("#private_" + mId + " #chat-con").attr("user-blckdid"), blockStatus);
        $("#private_" + mId + " #chat-con").attr("user-blckdid", blockId);
        var hgtBfrErrTxt = getInitialChthgt(mId);
        switch (blockId) {
            case '4'://both blocked
            case '3'://other member blocked
            case '2'://self blocked
                $("#private_" + mId + " .cht-bx input").css("display", "none");
                $("#private_" + mId + " .cht-bx .maxerrormsg").remove();
                if (blockId == '2') {
                    gndr = gndr ? 'him' : 'her';
                    var imgbygndr = gndr ? "https://pccdn.pyar.com/pcimgs/mblck.png" : "https://pccdn.pyar.com/pcimgs/fmblck.png";
                    $("#private_" + mId + " .cht-bx").append("<div class='maxerrormsg' data-self='true'>You blocked <b>" + fn + "</b>. To send a message, please unblock " + gndr + " from your <a href='#' class='gotoAccnt'>ACCOUNT</a>. Otherwise, you may delete this message thread.</div>");
                    $("#private_" + mId + " .blcstimg img").attr("src", imgbygndr);
                }
                else
                    $("#private_" + mId + " .cht-bx").append("<div class='maxerrormsg' data-self='false'><b>" + fn + "</b> has blocked you.This conversation is now closed.</div>");
                $("#private_" + mId + " .popup-head").css({ 'border-top': '0.05em solid rgb(193, 193, 193) !important', 'border-color': 'rgb(193, 193, 193)', 'background': 'rgb(193, 193, 193)' })
                $("#private_" + mId + " .popup-body").css('border', '2px solid rgb(193, 193, 193)');
                $('#private_' + mId + ' div#cmwhead span#imgonline').hide();
                setChatshgtSame(mId, hgtBfrErrTxt);
                break;

            default:
            case '1'://not blocked 
                removeErrorchatMsg(mId);
                vm.checkMsgMaxCount(mId, hgtBfrErrTxt);
                break;
        }
    }

    function removeErrorchatMsg(mId) {
        $("#private_" + mId + " #chat-con").attr("user-blocked", 'false')
        $("#private_" + mId + " .popup-head,#private_" + mId + " .popup-body").removeAttr("style");
        $("#private_" + mId + " .maxerrormsg").remove();
        $("#private_" + mId + " .blcstimg img").attr("src", vm.imgCDN + "/" + $("#private_" + mId + " #chat-con").attr("data-pp").replace("/p/tnb/", "/p/tns/"));
        $('#private_' + mId + ' div#cmwhead span#imgonline').show();
    }

    function getInitialChthgt(mId) {
        var cwStatus = $("#private_" + mId).css("display") == "block" ? true : false;
        var cwBodyStatus = $("#private_" + mId + " #cmwbody").css("display") == "block" ? true : false;
        setCWVisibility(true, mId, cwStatus, cwBodyStatus);
        var initcthgt = "";
        $("#private_" + mId + " #cmwbody").css("display", "block");
        console.log($("#chatMsg").hasClass("ng-hide") + " --  " + $("#chatMsg").attr("class"));
        if ($("#chatMsg").hasClass("ng-hide")) {
            // if chatBox is not shown in somepages 
            $("#chatMsg").addClass("hidecbmc").removeClass("ng-hide");
            initcthgt = $("#private_" + mId + " .cht-bx").height();
            $("#chatMsg").addClass("ng-hide").removeClass("hidecbmc");
        } else
            initcthgt = $("#private_" + mId + " .cht-bx").height();
        setCWVisibility(false, mId, cwStatus, cwBodyStatus);
        return initcthgt;
    }

    function setChatshgtSame(mId, hgtBfrErrTxt) {
        var cwStatus = $("#private_" + mId).css("display") == "block" ? false : true;
        var cwBodyStatus = $("#private_" + mId + " #cmwbody").css("display") == "block" ? false : true;
        setCWVisibility(true, mId, cwStatus, cwBodyStatus);
        //  Maintains the equal heights even the length of errortexts is more
        if ($("#chatMsg").hasClass("ng-hide")) {
            // if chatBox is not shown in somepages 
            $("#chatMsg").addClass("hidecbmc").removeClass("ng-hide");
            $("#private_" + mId + " .msglst").css("height", $("#private_" + mId + " .msglst").height() - ($('#private_' + mId + ' .cht-bx').height() - hgtBfrErrTxt) + "px")
            $("#chatMsg").addClass("ng-hide").removeClass("hidecbmc");
        } else
            $("#private_" + mId + " .msglst").css("height", $("#private_" + mId + " .msglst").height() - ($('#private_' + mId + ' .cht-bx').height() - hgtBfrErrTxt) + "px")
        setCWVisibility(false, mId, cwStatus, cwBodyStatus);
    };

    function setCWVisibility(makeVisible, mId, cwStatus, cwBodyStatus) {
        try {
            var cwDisplayStatus = false;
            for (var i = 0; i < vm.showList.length; i++) {
                if (vm.showList[i].cwId == "private_" + mId && vm.showList[i].status) {
                    cwDisplayStatus = true;
                    break
                }
            }
            if (cwDisplayStatus) {
                if ($("#private_" + mId + " #cmwbody").css("display") == "none")
                    $("#private_" + mId + " #cmwhead").click();
            }
            else {
                if (makeVisible) {
                    $("#private_" + mId).attr("data-display", $("#private_" + mId).css("display"));
                    $("#private_" + mId).css("visibility", "hidden");
                    $("#private_" + mId).css("display", "block");

                    $("#private_" + mId + " #cmwbody").attr("data-display", $("#private_" + mId + " #cmwbody").css("display"));
                    $("#private_" + mId + " #cmwbody").css("visibility", "hidden");
                    $("#private_" + mId + " #cmwbody").css("display", "block");
                }
                else {
                    if ($("#private_" + mId).attr("data-display")) {
                        $("#private_" + mId).css("visibility", "visible");
                        $("#private_" + mId).css("display", $("#private_" + mId).attr("data-display"));
                    }

                    if ($("#private_" + mId + " #cmwbody").attr("data-display")) {
                        $("#private_" + mId + " #cmwbody").css("visibility", "visible");
                        $("#private_" + mId + " #cmwbody").css("display", $("#private_" + mId + " #cmwbody").attr("data-display"));
                    }
                }
            }
        } catch (e) {
            console.log("setCWVisibility --  " + e.message);
            alert("setCWVisibility --  " + e.message);
        }
    };

    $(document).on("click", ".gotoAccnt", function () {
        if (!$('#msgMid').hasClass('ng-hide')) {
            $('#msgMid').addClass('ng-hide');
            $('body').css('overflow', '');
        }
        $state.go("account", { 'tb': 'privacy' });
    });
    /**********************************************************
                        msg service listeners end
    **********************************************************/

    /**********************************************************
                        network listeners start
    **********************************************************/
    $scope.$on("offline", function (e) {
        try {

        } catch (e) {
            console.log("offline  --  " + e.message);
            alert("offline  --  " + e.message);
        }
    });

    $scope.$on("online", function (e) {
        try {
            vm.sendOfflineMsgs();
        } catch (e) {
            alert("online  --  " + e.message);
            console.log("online  --  " + e.message);
        }
    });
    /**********************************************************
                        network listeners end
    **********************************************************/

    /**********************************************************
                Self Broadcast listeners start
    **********************************************************/
    $scope.$on("openPCW", function (e, mId) {
        try {
            if (vm.sId() == 2) {
                if (!vm.checkPgs()) {
                    msgSrvc.getmemberInfoById(mId, function (response, status) {
                        if (status == 200 && response != "invalid mId")
                            vm.openPCW(response.mId, response.fn, response.pp, "", response.online, response.offline, response.gender);
                        else {
                            console.log("unable to get memberInfo  --  " + response);
                            alert("unable to get memberInfo  --  " + response);
                        }
                    });
                }
            }
            else
                vm.showPremiumPop();
        } catch (e) {
            console.log("openPCW listener  --  " + e.message);
            alert("openPCW listener  --  " + e.message);
        }
    });

    $scope.$on("openNCW", function (e) {
        try {
            if (vm.sId() == 2) {
                if (!vm.checkPgs())
                    vm.NCWindow();
            }
            else
                vm.showPremiumPop();
        } catch (e) {
            console.log("openNCW listener  --  " + e.message);
            alert("openNCW listener  --  " + e.message);
        }
    });

    $scope.$on("bindCWMsg", function (e, mId, fn, msg, tmpp, convrnId, datetime, sender) {
        try {
            vm.bindMRM(mId, fn, msg, tmpp, convrnId, datetime, sender);
            if (sender) {
                vm.addMsgMaxCount(mId);
                vm.checkMsgMaxCount(mId);
            }
        } catch (e) {
            console.log("bindCWMsg  --  " + e.message);
            alert("bindCWMsg  --  " + e.message);
        }
    });

    $scope.$on("chgMRS", function (e, tmIds, urExist) {
        try {
            for (var i = 0; i < tmIds.length; i++) {
                //checking the window is open changing the status
                if ($("#private_" + tmIds[i]).length > 0)
                    $("btn-input-" + tmIds[i]).attr("data-urExist", urExist).attr("data-urExistProcess", "false");

                //checking rmc and update urExist
                for (var j = 0; j < vm.mrc.length; j++) {
                    if (vm.mrc[j].tmId == tmIds[i]) {
                        vm.mrc[j].urExist = urExist;
                        break;
                    }
                }
            }
        } catch (e) {
            console.log("chgMRS listener  --  " + e.message);
            alert("chgMRS listener  --  " + e.message);
        }
    });
    /**********************************************************
                Self Broadcast listeners end
    **********************************************************/

    /**********************************************************
                    Chat Service functions start
    **********************************************************/
    vm.getMNWSrch = function (fn) {
        try {
            msgSrvc.getMNWSrch(vm.mId(), fn, function (response, status) {
                if (status == 200) {
                    if (response.length > 0)
                        vm.mnwSrchList.push({ key: key, val: response })
                    vm.bindSrchMember();
                }
                else {
                    console.log("unable to get member network contacts" + response);
                    alert("unable to get member network contacts" + response);
                }
            });
        } catch (e) {
            console.log("vm.getMNWSrch  --  " + e.message);
            alert("vm.getMNWSrch  --  " + e.message);
        }
    };

    vm.getMCS = function () {
        try {
            msgSrvc.getChatSettings(vm.mId(), function (response, status) {
                if (status == 200)
                    vm.mcs = response;
                else {
                    console.log("unable to get chat settings");
                    alert("unable to get chat settings");
                }
            });
        } catch (e) {
            console.log("vm.getMCS  --  " + e.message);
            alert("vm.getMCS  --  " + e.message);
        }
    };

    vm.updateMCS = function (type, status) {
        try {
            msgSrvc.updateMemberChatSettings(vm.mId(), type, status, function (response, respStatus) {
                if (respStatus == 200) {
                    if (type == 1) {
                        vm.mcs.offline = status;
                        msgSrvc.updateMemberOnlineStatus(2, status);
                    }
                    else if (type == 2)
                        vm.mcs.mute = status;
                }
                else {
                    console.log("unable to update chat settings");
                    alert("unable to update chat settings");
                }
            });
        } catch (e) {
            console.log("vm.updateMCS  --  " + e.message);
            alert("vm.updateMCS  --  " + e.message);
        }
    };

    vm.updateMST = function () {
        try {
            if (vm.mst) {
                msgSrvc.updateMST(vm.mst);
                vm.mst = "";
            }
        } catch (e) {
            console.log("vm.updateMST  --  " + e.message);
            alert("vm.updateMST  --  " + e.message);
        }
    };

    vm.getMemberMessages = function (convrnId, fmId, tmId, pgNo) {
        try {
            msgSrvc.getMemberMessages(convrnId, fmId, tmId, pgNo, vm.pgSize, function (response, status) {
                if (status == 200) {
                    vm.bindMHM(response, tmId);
                    //set convrnId and seen status
                    if (pgNo == 1) {
                        vm.getMCH(fmId, tmId, response);
                        $("#imgldr").removeClass("clcntr");
                        var rmdt = "";
                        if (response.length > 0)
                            rmdt = response[0].dtCreated;
                        else
                            rmdt = new Date();
                        $("#btn-input-" + tmId).attr("data-rmdt", rmdt);
                    }
                }
                else {
                    console.log("unable to get member Messages");
                    alert("unable to get member Messages");
                }
            });
        } catch (e) {
            console.log("vm.getMemberMessages  --  " + e.message);
            alert("vm.getMemberMessages  --  " + e.message);
        }
    };

    vm.checkMRS = function (fmId, tmId) {
        try {
            var ctrBdy = $("#private_" + tmId + " #cmwbody");
            var txtObj = $("#btn-input-" + tmId);
            if (ctrBdy.length > 0 && ctrBdy.css("display") != "none" && txtObj.attr("data-urExist") == "true" && txtObj.attr("data-urExistProcess") == "false") {
                var chlst = $("#private_" + tmId + " #chat-con li:last-child");
                if (chlst.length > 0 && chlst.visible("partial"))
                    vm.updateMRS(fmId, tmId);
            }
        } catch (e) {
            console.log("checkMRS --  " + e.message);
            alert("checkMRS  --  " + e.message);
        }
    }

    vm.updateMRS = function (fmId, tmId) {
        try {
            $("#btn-input-" + tmId).attr("data-urExistProcess", "true");
            msgSrvc.updateMsgReadStatus(fmId, tmId, function (response, status) {
                $("#btn-input-" + tmId).attr("data-urExistProcess", "false");
                if (status = 200 && response) {
                    //update msg read count for header control
                    $rootScope.$broadcast("msgSeenCntChg", [tmId], false);

                    //update msg urExist for open window and chat contacts
                    $("#btn-input-" + tmId).attr("data-urExist", "false");
                    for (var i = 0; i < vm.mrc.length; i++) {
                        if (tmId == vm.mrc[i].tmId) {
                            vm.mrc[i].urExist = false;
                            break;
                        }
                    }
                }
                else
                    console.log("unable to update read status");
            });
        } catch (e) {
            console.log("vm.updateMRS  --  " + e.message);
            alert("vm.updateMRS  --  " + e.message);
        }
    };

    vm.getMCH = function (fmId, tmId, msgs) {
        try {
            msgSrvc.getMemberConvrnHead(fmId, tmId, function (response, status) {
                var ctrId = "private_" + tmId;
                if (status == 200 && response) {
                    var txtMsg = $("#btn-input-" + tmId);
                    if (txtMsg.length > 0) {
                        txtMsg.attr("data-convrnId", response.convrnId);
                        txtMsg.attr("data-urExist", response.urExist);
                        txtMsg.attr("data-isBD", response.isBD);
                        txtMsg.attr("data-msgCnt", response.msgCnt);
                        txtMsg.attr("data-msgInitiator", response.msgInitiator);
                        //append last seen when last msg ins login member msg
                        var showSeen = false;
                        if (msgs && msgs.length > 0)
                            showSeen = msgs[0].fmId == fmId ? true : false;
                        if (showSeen && response.seenDT) {
                            var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), response.seenDT);
                            if (dtObj.date || dtObj.time) {
                                if (dtObj.date)
                                    $("#" + ctrId + " #lastseen").text("Seen " + dtObj.date + " at " + dtObj.time);
                                else
                                    $("#" + ctrId + " #lastseen").text("Seen at " + dtObj.time);
                                $("#" + ctrId + " #lastseen").show();
                                $("#" + ctrId + " #dvTyping").hide();
                                if (vm.isScrollOnBottom(ctrId))
                                    $("#" + ctrId + " .panel-body .chtcnt").animate({ scrollTop: $("#" + ctrId + " #chat-con").prop("scrollHeight") }, 1000);
                            }
                        }
                        //if unread exist true update to read
                        if (response.urExist)
                            vm.checkMRS(fmId, tmId);
                        if (!response.isBD)
                            vm.findMBD(fmId, tmId, msgs);
                    }
                }
                getMemberBlockId(tmId, response);

            });
        } catch (e) {
            console.log("vm.getMCH  --  " + e.message);
            alert("vm.getMCH  --  " + e.message);
        }
    };

    function getMemberBlockId(tmId, data) {
        cmnSrvc.getMemberBlockId(tmId, function (response, status) {
            if (status == 200) {
                if (response == '1') {
                    $("#private_" + tmId + " .cht-bx input").attr("readonly", false);
                    vm.checkMsgMaxCount(tmId);
                    if (vm.msgMaxCnt() > 0 && !data && $("#private_" + tmId + ' .msg_container_base').length) {
                        $("#private_" + tmId + ' .msg_container_base').append("<div class='maxmsgtxt'>You can send up to " + msgSrvc.txtOrNumDisplayForMsgCnt(vm.msgMaxCnt()) + " messages before you receive a response.</div>")
                        $("#private_" + tmId + " .popup-head").css({ 'border-top': '0.05em solid rgb(193, 193, 193) !important', 'border-color': 'rgb(193, 193, 193)', 'background': 'rgb(193, 193, 193)' })
                        $("#private_" + tmId + " .popup-body").css('border', '2px solid rgb(193, 193, 193)');
                    }
                } else {
                    var fn = $('#private_' + tmId).find("span#name").attr("data-name");
                    var gender = $('#private_' + tmId).find("span#name").attr("data-gender");
                    if (response == '2') checkBlockStatus(tmId, fn, gender, true, true)
                    else if (response == '3') checkBlockStatus(tmId, fn, gender, true, false);
                    else if (response == '4') checkBlockStatus(tmId, fn, gender, true, false);
                };
            };
        })
    };

    vm.findMBD = function (fmId, tmId, msgs) {
        try {
            var txtObj = $("#btn-input-" + tmId);
            if (txtObj.length > 0 && txtObj.attr("data-isBD") == "false" && msgs && msgs.length > 0) {
                var fmCnt = 0, tmCnt = 0;
                for (var i = 0; i < msgs.length; i++) {
                    if (msgs[i].fmId == fmId)
                        fmCnt++;
                    else
                        tmCnt++;
                }

                //check who to replay for set isBD
                if (fmCnt > 0 && tmCnt > 0) {
                    vm.updateMCHdBD(fmId, tmId);
                    txtObj.attr("data-isBD", "true");
                    vm.checkMsgMaxCount(tmId);
                }
            }
        } catch (e) {
            console.log("findMBD  --  " + e.message);
            alert("findMBD  --  " + e.message);
        }
    };

    vm.checkMCHdBD = function (fmId, tmId) {
        try {
            $('#private_' + tmId + ' .maxmsgtxt').remove();
            $("#private_" + tmId + " .popup-head,#private_" + tmId + " .popup-body").removeAttr("style");
            var txtObj = $("#btn-input-" + tmId);
            if (txtObj.length > 0 && txtObj.attr("data-isBD") == "false")
                if (txtObj.attr("data-msgInitiator") == false)
                    vm.updateMCHdBD(fmId, tmId);
                else
                    vm.checkMsgMaxCount(tmId);

        } catch (e) {
            console.log("vm.checkMCHdBD   --  " + e.message);
            alert("vm.checkMCHdBD   --  " + e.message);
        }
    };


    vm.addMsgMaxCount = function (tmId) {
        var txtObj = $("#btn-input-" + tmId);
        if (txtObj.length > 0 && txtObj.attr("data-isBD") == "false" && txtObj.attr("data-msgInitiator") == "true")
            txtObj.attr("data-msgCnt", parseInt(txtObj.attr("data-msgCnt")) + 1);
    };

    vm.checkMsgMaxCount = function (tmId, hgtbftint) {
        var txtObj = $("#btn-input-" + tmId);
        if ($("#private_" + tmId + " #chat-con").attr("user-blckdid") == '1') {
            var hgtBfrErrTxt = hgtbftint || getInitialChthgt(tmId);
            if (txtObj.length > 0) {
                if (vm.msgMaxCnt() > 0 && txtObj.attr("data-isBD") == "false" && txtObj.attr("data-msgInitiator") == "true" && parseInt(txtObj.attr("data-msgCnt")) >= vm.msgMaxCnt()) {
                    if ($("#private_" + tmId + " .maxerrormsg").length == 0) {
                        var tmIdName = $('#private_' + tmId).find("span#name").attr("data-name");
                        var gndrhisorher = $('#private_' + tmId).find("span#name").attr("data-gender") == "true" ? "him" : "her";
                        $("#private_" + tmId + " .cht-bx input").css("display", "none") //hide textbox and show max error msg
                        $("#private_" + tmId + " .cht-bx").append("<div class='maxerrormsg'>You have already sent " + tmIdName + " " + msgSrvc.txtOrNumDisplayForMsgCnt(vm.msgMaxCnt()) + " messages. To send more messages, please wait for " + gndrhisorher + " to respond.</div>")
                        $("#private_" + tmId + " .popup-head").css({ 'border-top': '0.05em solid rgb(193, 193, 193) !important', 'border-color': 'rgb(193, 193, 193)', 'background': 'rgb(193, 193, 193)' })
                        $("#private_" + tmId + " .popup-body").css('border', '2px solid rgb(193, 193, 193)');

                    }
                } else {
                    $("#private_" + tmId + " .cht-bx input").css("display", "block")   //show textbox and hide max error msg
                    $("#private_" + tmId + " .maxerrormsg").remove();
                    $("#private_" + tmId + " .popup-head,#private_" + tmId + " .popup-body").removeAttr("style");
                }
                setChatshgtSame(tmId, hgtBfrErrTxt);
            }
        }
    };

    vm.updateMCHdBD = function (fmId, tmId) {
        try {
            msgSrvc.updateMsgConvHdBiDirectional(fmId, tmId, function (response, status) {
                if (status == 200 && response == "true") {
                    $("#btn-input-" + tmId).attr("data-isBD", "true");
                    $("#btn-input-" + tmId).attr("data-isBDType", "3");
                    for (var i = 0; i < vm.mrc.length; i++) {
                        if (tmId == vm.mrc[i].tmId) {
                            vm.mrc[i].isBD = true;
                            break;
                        }
                    }
                }
            });
        } catch (e) {
            console.log("vm.updateMCHdBD  --  " + e.message);
            alert("vm.updateMCHdBD  --  " + e.message);
        }
    };

    vm.sendOfflineMsgs = function () {
        try {
            if (msgSrvc.conId) {
                while (vm.offlineMsgs.length > 0) {
                    msgSrvc.sendMsg(vm.offlineMsgs[0].tmId, vm.offlineMsgs[0].tmfn, vm.offlineMsgs[0].tmpp, vm.offlineMsgs[0].convrnId, vm.offlineMsgs[0].msg);
                    $("#btn-input-" + vm.offlineMsgs[0].tmId).prop("disabled", false);
                    $("#btn-input-" + vm.offlineMsgs[0].tmId).parent().removeClass("cht-bxdis");
                    $("#private_" + vm.offlineMsgs[0].tmId + " #nwmsg").hide();
                    vm.offlineMsgs.splice(0, 1);
                    vm.addMsgMaxCount(vm.offlineMsgs[0].tmId);
                    vm.checkMCHdBD(vm.mId(), tmId);
                }
            }
        } catch (e) {
            console.log("vm.sendOfflineMsgs  --  " + e.messages);
            alert("vm.sendOfflineMsgs  --  " + e.messages);
        }
    };
    /**********************************************************
                    Chat Service functions end
    **********************************************************/

    /**********************************************************
                        Chat Window Helper funcions start
    **********************************************************/
    vm.checkPendingTasks = function () {
        $("input[id^='btn-input-']").each(function (i, e) {
            if ($(e).attr("data-urExist") == "true" && $(e).attr("data-urExistProcess") == "false") {
                if (vm.mId())
                    vm.updateMRS(vm.mId, $(e).attr("data-id"));
            }
        })
    };

    vm.openPCW = function (tmId, tmfn, tmpp, convrnId, isOnlie, offline, gender) {
        try {
            vm.openPrivateChatWindow(tmId, tmfn, tmpp, convrnId, isOnlie && !offline, gender);
            $("#btn-input-" + tmId).focus();
        } catch (e) {
            console.log("openPCW  --  " + e.message);
            alert("openPCW  --  " + e.message);
        }
    };

    //bind member received msg
    vm.bindMRM = function (mId, fn, msg, tmpp, convrnId, datetime, sender) {
        var isCWExist = true;
        try {
            var ctrId = 'private_' + mId;
            //check member window or not
            if (sender && $('#' + ctrId).length == 0)
                return;
            else if ($('#' + ctrId).length == 0) {
                //restricting to open new chat window for msg center window if new msg receive.
                //only allow to add received msg if user already opend and chat window.
                if (vm.checkPgs() || $(window).width() < 1200)
                    return;
                isCWExist = false;
                vm.createPrivateChatWindow(ctrId, mId, convrnId, fn, tmpp, true);
            }
            var AllmsgHtml = "", dtLine = "";
            var isBottom = vm.isScrollOnBottom(ctrId);
            var txtObj = $("#btn-input-" + mId);
            var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), datetime);

            //mute notificatin
            if (!sender && vm.mcs && vm.mcs.mute == false && $('#chatAudio').length > 0)
                $('#chatAudio')[0].play();

            if (sender) {
                AllmsgHtml = "<li data-sender='true'><div class='col-xs-9 rgtmsgtcnt'>" + msg + "<br/><span class='mt'>" + (dtObj.time == "" ? dtObj.date : dtObj.time) + "</span></div><div class='col-xs-1 npd'><image src='" + (vm.imgCDN + vm.pp().replace("/p/tnb/", "/p/tns/")) + "' style='width:" + vm.ppHW.width + "px;height:" + vm.ppHW.height + "px;' class='upfr' /></div></li>";
                txtObj.attr("data-urExist", "false");
                txtObj.attr("data-urExistProcess", "false");
            }
            else {
                AllmsgHtml = "<li data-sender='false'><div class='col-xs-1 npd blcstimg'><image src='" + (vm.imgCDN + tmpp.replace("/p/tnb/", "/p/tns/")) + "' style='width:" + vm.ppHW.width + "px;height:" + vm.ppHW.height + "px;' class='upfl' /></div><div class='col-xs-9 lftmsgtcnt'>" + msg + "<br/><span class='mt'>" + (dtObj.time == "" ? dtObj.date : dtObj.time) + "</span></div></li>";
                txtObj.attr("data-urExist", "true");
                txtObj.attr("data-isBD", "true");
                vm.checkAndActivateFlash(ctrId);
                vm.checkMsgMaxCount(mId);
            }

            //date sepharation line
            if (txtObj.attr("data-rmdt") != "" && msgSrvc.isDatesSame(txtObj.attr("data-rmdt"), datetime) == false)
                dtLine += "<li><div class='dtsp'><span style='float:left;' class='mt'>" + msgSrvc.getDate(vm.zone(), datetime) + "</span></div></li>";
            txtObj.attr("data-rmdt", datetime);

            //adding message to chat window
            if (isCWExist)
                $('#' + ctrId + " .panel-body #chat-con").append(dtLine + AllmsgHtml);

            //auto scroll to bottom
            if (isBottom)
                $("#" + ctrId + " .panel-body .chtcnt").animate({ scrollTop: $("#" + ctrId + " .panel-body #chat-con").prop("scrollHeight") }, 2000);

            //hide dvTyping
            $("#" + ctrId + " #dvTyping").hide();

            //remove last seen receive new msg
            $("#" + ctrId + " #lastseen").hide();

            //check and update read status
            if (!sender)
                vm.checkMRS(vm.mId(), mId);
        } catch (e) {
            console.log("vm.bindMRM  --  " + e.message);
            alert("vm.bindMRM  --  " + e.message);
        }
    };

    //bind member msg history
    vm.bindMHM = function (messages, tmId) {
        var ctrId = 'private_' + tmId;
        try {
            if (messages.length > 0) {
                var Sagline = false;
                var daystring = "", toDisplayStr = "", licontent = "";
                var prevdate = $("#" + ctrId + " #loader").attr("data-prevDate");
                var prvHeight = $("#" + ctrId + " #chat-con").prop("scrollHeight");
                var localDt = "";
                var today = new Date();
                var timeformat = "";
                for (i = 0; i < messages.length; i++) {
                    var msg = "";
                    var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), messages[i].dtCreated);
                    if (messages[i].fmId == vm.mId())
                        msg = "<li><div class='col-xs-9 rgtmsgtcnt'>" + messages[i].msg + "<br/><span class='mt'>" + (dtObj.time == "" ? dtObj.date : dtObj.time) + "</span></div><div class='col-xs-1 npd'><image src='" + (vm.imgCDN + vm.pp().replace("/p/tnb/", "/p/tns/")) + "' style='width:" + vm.ppHW.width + "px;height:" + vm.ppHW.height + "px;' class='upfr' /></div></li>";
                    else {
                        if ($("#" + ctrId + " #chat-con").attr("user-blckdid") == '2') {
                            var blckImg = messages[i].gender ? 'https://pccdn.pyar.com/pcimgs/mblck.png' : 'https://pccdn.pyar.com/pcimgs/fmblck.png'
                            msg = "<li><div class='col-xs-1 npd blcstimg'><image src='" + blckImg + "' style='width:" + vm.ppHW.width + "px;height:" + vm.ppHW.height + "px;' class='upfl' /></div><div class='col-xs-9 lftmsgtcnt'>" + messages[i].msg + "<br/><span class='mt'>" + (dtObj.time == "" ? dtObj.date : dtObj.time) + "</span></div></li>";
                        }
                        else
                            msg = "<li><div class='col-xs-1 npd blcstimg'><image src='" + (vm.imgCDN + "/" + $("#" + ctrId + " #chat-con").attr("data-pp").replace("/p/tnb/", "/p/tns/")) + "' style='width:" + vm.ppHW.width + "px;height:" + vm.ppHW.height + "px;' class='upfl' /></div><div class='col-xs-9 lftmsgtcnt'>" + messages[i].msg + "<br/><span class='mt'>" + (dtObj.time == "" ? dtObj.date : dtObj.time) + "</span></div></li>";
                    }

                    if (prevdate != "" && msgSrvc.isDatesSame(prevdate, messages[i].dtCreated) == false)
                        msg += "<li><div class='dtsp'><span style='float:left;' class='mt'>" + msgSrvc.getDate(vm.zone(), prevdate) + "</span></div></li>";

                    licontent = msg + licontent;
                    prevdate = messages[i].dtCreated;
                }
                $('#' + ctrId + " .panel-body #chat-con").prepend(licontent);
                //hide loader
                $("#" + ctrId + " #loader").hide();
                //set prevdate for next binding segregation
                $("#" + ctrId + " #loader").attr("data-prevDate", prevdate);
                //first msg Date
                $("#" + ctrId + " #loader").attr("data-FMDate", $filter("orderBy")(messages, 'dtCreated')[0].dtCreated);
                //autoscroll previous li position
                $("#" + ctrId + "  .panel-body .chtcnt").animate({ scrollTop: $("#" + ctrId + " #chat-con").prop("scrollHeight") - prvHeight }, 0);
            }

            if (messages.length < vm.pgSize) {
                var fmDate = $("#" + ctrId + " #loader").attr("data-FMDate");
                $("#" + ctrId + " #loader").remove();
                //if user reach the end of the message then we display the date sepharation line
                if ($('#' + ctrId + " .panel-body #chat-con li").length > 0 && fmDate != "")
                    $('#' + ctrId + " .panel-body #chat-con").prepend("<li><div class='dtsp'><span style='float:left;' class='mt'>" + msgSrvc.getDate(vm.zone(), fmDate) + "</span></div></li>");
            }
        } catch (e) {
            $("#" + ctrId + " #loader").hide();
            console.log('error : GetLastMessages \n' + e.message);
        }
    };

    vm.openPrivateChatWindow = function (tmId, tmfn, tmpp, convrnId, online, gender) {
        try {
            var ctrId = 'private_' + tmId;
            if ($('#' + ctrId).length > 0)
                vm.moveCWFirst(ctrId);
            else
                vm.createPrivateChatWindow(ctrId, tmId, convrnId, tmfn, tmpp, online, gender);
        } catch (e) {
            console.log("vm.openPrivateChatWindow   --  " + e.message);
            alert("vm.openPrivateChatWindow   --  " + e.message);
        }
    };

    vm.createPrivateChatWindow = function (ctrId, tmId, convrnId, tmfn, tmpp, online, gender) {
        try {
            //check if name is morethan 15 characters set short name
            var chatWidnowHTML = "<div class='panel panel-heading' style='position:relative;display:table;width: 100%;margin-bottom: 0px;float:right;'>"
                + "<div id='" + ctrId + "' class='prvtcht popup-box chat-popup chatpp' style='display: block;bottom:0;right:0px;'>"
                + "<div id='cmwhead' class='popup-head clscwhd' data-ms='35000'>"
                + "<div class='col-md-9 col-xs-9 npd'><h3 class='panl-bx'><span id='imgonline' class='" + (online ? "onclr" : "offclr") + "'></span><span id='name' class='cwnm' data-name='" + tmfn + "' data-gender='" + (gender != "" && gender != null ? gender : "") + "'>" + tmfn + "<span id='msgcnt' data-msgcnt='0'></span></span></h3></div>"
                + "<div class='col-md-3 col-xs-3 npd' style='text-align: right;'><a href='javascript:void(0);'><span id='minim_chat_window' class='icon_minim'><img style='width:20px;height:20px' src='https://pccdn.pyar.com/pcimgs/min-collapse.png'></span></a><a href='javascript:void(0);'><span class='icon_close' data-id='" + ctrId + "'><img style='width:20px;height:20px' src='https://pccdn.pyar.com/pcimgs/ch-close.png'/> </span></a></div></div>"
                + "<div id='cmwbody' class='panel-body npd popup-body'>"
                + "<div class='msg_container_base msglst'><div class='chtcnt'>"
                + "<div class='text-center' id='loader' style='display:block;' data-prevDate='' data-pgNo='2' data-id='" + tmId + "'><img id='imgldr' src='https://pccdn.pyar.com/pcimgs/pcloader.svg' height='64' class='ld ld-heartbeat' alt='loading...'/></div>"
                + "<ul id='chat-con' class='mscht' data-pp='" + tmpp + "' user-blckdid='1'></ul>"
                + "<div id='dvTyping' data-typing='true' class='col-xs-12 pdb10' style='display:none;'>" + tmfn + " typing...</div>"
                + "<div id='lastseen' class='lastseen' style='display:none;'></div>"
                + "<div id='nwmsg' class='nwerrmsg' style='display:none;'>Message couldn't be sent. Check your connection and try again.<img class='nwicon' src='https://pccdn.pyar.com/pcimgs/mns.png' alt=''></div></div></div>"
                + "<div class='cht-bx'><input type='text' id='btn-input-" + tmId + "' data-id='" + tmId + "' data-convrnId='" + convrnId + "'  data-urExist='false' data-urExistProcess='false' data-isBD='false' data-msgInitiator='true' data-msgInitiator='true' data-msgCnt='0' data-rmdt='' class='frmcntrl' placeholder='Type a message' maxlength='1000' readonly/></div></div>";

            var cwObj = { cwId: ctrId, status: true };
            vm.showList.push(cwObj);
            $("#chatMsg").append(chatWidnowHTML);
            vm.setChatWindowHeight();
            vm.chgCWPos();

            //Chat text box key up event
            $('#' + ctrId + " #btn-input-" + tmId).on('keyup', function (e) {
                if (e.keyCode == 13) {
                    if (vm.sId() == 2) {
                        var tmId = $(this).attr("data-id");
                        var convrnId = $(this).attr("data-convrnId");
                        var msg = $(this).val();
                        if (msg != "") {
                            if ($rootScope.online) {
                                msgSrvc.sendMsg(tmId, vm.fn(), vm.pp(), convrnId, msg);
                                vm.addMsgMaxCount(tmId);
                                vm.bindMRM(tmId, tmfn, msg, "", convrnId, new Date(), true);
                                vm.checkMCHdBD(vm.mId(), tmId);
                            }
                            else {
                                vm.bindMRM(tmId, tmfn, msg, vm.pp(), convrnId, new Date(), true);
                                var offMsg = { "tmId": tmId, "fn": vm.fn(), "tmpp": vm.pp(), "convrnId": convrnId, "isBD": '"' + $(this).attr("data-isBD") + '"', "msg": msg };
                                vm.offlineMsgs.push(offMsg);
                                $("#" + ctrId + " #nwmsg").show();
                                $(this).prop("disabled", true);
                                $(this).parent().addClass("cht-bxdis");
                            }
                            $(this).val("").focus();
                        }
                    }
                    else
                        vm.showPremiumPop();
                }
                else if ($(this).val().length > 0)
                    $(this).attr("placeholder", "Type a message");
            });

            //on text paste event
            $('#' + ctrId + " #btn-input-" + tmId).on('paste', function (e) {
                var content = e.originalEvent.clipboardData.getData('text');
                if (content.length > 1000) {
                    $(this).attr("placeholder", "Must be < 1000 characters");
                    return false;
                }
            });

            //Send Typing Request
            $('#' + ctrId + " #btn-input-" + tmId).on('input', function (e) {
                if ($("#btn-input-" + tmId).val()) {
                    var dvTypeObj = $("#" + ctrId + " #dvTyping");
                    if ($rootScope.online && dvTypeObj.attr("data-typing") == "true") {
                        msgSrvc.sendTypeRequest(tmId);
                        dvTypeObj.attr("data-typing", false);
                        $timeout(function () { dvTypeObj.attr("data-typing", true); }, 10000);
                    }
                }
            });

            //get recent Chat conversion
            vm.getMemberMessages(convrnId, vm.mId(), tmId, 1);

            //on scroll up get recent chat conversion by pgNo
            $("#" + ctrId + " .panel-body .chtcnt").scroll(function () {
                if ($rootScope.online) {
                    //for load previous msgs
                    if (vm.isScrollOnTop(ctrId) && $("#" + ctrId + " #loader").length > 0) {
                        $("#" + ctrId + " #loader").show();
                        var pgNo = parseInt($("#" + ctrId + " #loader").attr("data-pgNo")) + 1;
                        var convrnId = $("#btn-input-" + tmId).attr("data-convrnid");
                        vm.getMemberMessages(convrnId, vm.mId(), tmId, pgNo);
                        $("#" + ctrId + " #loader").attr("data-pgNo", pgNo);
                    }
                    //for update read status of a msg
                    var lstChild = $("#" + ctrId + " #chat-con li:last-child");
                    if (lstChild.length > 0 && lstChild.visible("full"))
                        vm.checkMRS(vm.mId(), tmId);
                }
            });
            vm.manageChatWindows();
        }
        catch (e) {
            console.log('error : createPrivateChatWindow \n' + e.message);
            alert('error : createPrivateChatWindow \n' + e.message);
        }
    };

    vm.checkHiddenWindow = function () {
        try {
            var hidden, state;
            if (typeof document.hidden !== "undefined") {
                state = "visibilityState";
            } else if (typeof document.mozHidden !== "undefined") {
                state = "mozVisibilityState";
            } else if (typeof document.msHidden !== "undefined") {
                state = "msVisibilityState";
            } else if (typeof document.webkitHidden !== "undefined") {
                state = "webkitVisibilityState";
            }

            if (document[state] == "hidden")
                return true;
            else
                return false;
        } catch (e) {
            console.log("vm.checkHiddenWindow  --  " + e.message);
            alert("vm.checkHiddenWindow  --  " + e.message);
        }
    };

    vm.chgStatusImg = function (mId, status) {
        try {
            var addCls = "", removeCls = "";
            if (status) {
                addCls = "onclr";
                removeCls = "offclr";
            }
            else {
                addCls = "offclr";
                removeCls = "onclr";
            }

            //checking open private window
            if ($('#private_' + mId).length > 0) {
                $('#private_' + mId + ' div#cmwhead span#imgonline').removeClass(removeCls).addClass(addCls);
            }

            //checking dock/overflow window
            if ($("ul#dockul li#private_" + mId).length > 0) {
                $("ul#dockul li#private_" + mId + ' span#imgonline').removeClass(removeCls).addClass(addCls);
            }
        } catch (e) {
            console.log("vm.chgStatusImg  --  " + e.message);
            alert("vm.chgStatusImg  --  " + e.message);
        }
    };

    vm.checkPgs = function () {
        try {
            return vm.msgCWPgHideArr.includes($location.path());
        } catch (e) {
            console.log("vm.checkPgs  --  " + e.message);
        }
    };

    vm.closePCW = function (cwId) {
        try {
            for (var i = 0; i < vm.showList.length; i++) {
                if (vm.showList[i].cwId == cwId) {
                    $("div#" + cwId).parent().remove();
                    vm.showList.splice(i, 1);

                    if ($("ul#dockul li#" + cwId).length > 0) {
                        $("ul#dockul li#" + cwId).remove();
                    }
                    else if ($("ul#dockul li").length > 0) {
                        var dwId = $("ul#dockul li").first().attr("id");
                        for (var i = 0; i < vm.showList.length; i++) {
                            if (vm.showList[i].cwId == dwId) {
                                $("ul#dockul li#" + dwId).remove();
                                vm.showList[i].status = true;
                            }
                        }
                    }

                    if ($("ul#dockul li").length == 1) {
                        var dwId = $("ul#dockul li").first().attr("id");
                        for (var i = 0; i < vm.showList.length; i++) {
                            if (vm.showList[i].cwId == dwId) {
                                vm.showList[i].status = true;
                                $("#dvcwd").parent().remove();
                                vm.showList.splice(0, 1);
                                break;
                            }
                        }
                    }
                    vm.chgCWPos();
                    break;
                }
            }
        } catch (e) {
            console.log("vm.closePCW  --  " + e.message);
            alert("vm.closePCW  --  " + e.message);
        }
    };

    vm.isScrollOnTop = function (ctrlId) {
        try {
            var $this = $("#" + ctrlId + " .panel-body .chtcnt");
            var scrollTop = $this.scrollTop();
            if (scrollTop == 0)
                return true;
            else
                return false;
        } catch (e) {
            console.log("vm.isScrollOnTop  --  " + e.message);
            alert("vm.isScrollOnTop  --  " + e.message);
        }
    };

    vm.isScrollOnBottom = function (ctrlId) {
        try {
            var $this = $("#" + ctrlId + " .panel-body .chtcnt ");
            if ($this.length > 0) {
                var scrollTop = $this.scrollTop() + $this.innerHeight() + 100;
                if (scrollTop >= $this[0].scrollHeight)
                    return true;
                else
                    return false;
            }
            else
                return true;
        } catch (e) {
            console.log("isScrollOnBottom+" + e.message);
            alert("isScrollOnBottom+" + e.message);
        }
    };

    vm.closeNA = function () {
        try {
            if (vm.nawId) {
                vm.closePCW(vm.nawId);
            }
            $('#naModel').modal('hide');
        } catch (e) {
            console.log("vm.closeNA  --  " + e.message);
            alert("vm.closeNA  --  " + e.message);
        }
    };

    vm.showPremiumPop = function () {
        if (cmnSrvc.isTrialOrPrmExpired()) $scope.openPS("nmPP");
        else showMobileVerificationPop();
        //$scope.openPS("nmPP");
        //$scope.openPS("smPP");
        // showMobileVerificationPop();
    };

    //vm.showRplyPremiumPop = function () {
    //    if (cmnSrvc.isTrailPrmExpired()) $scope.openPS("nmPP");
    //    else showMobileVerificationPop();
    //    //$scope.openPS("smPP");
    //    //showMobileVerificationPop();
    //};

    vm.getPP = function (imgUrl, gender) {
        if (imgUrl) return vm.imgCDN + imgUrl.replace("/p/tnb/", "/p/tns/");
        else if (gender == true) return vm.ppm;
        else return vm.ppf;
    };
    /**********************************************************
                   Chat Window Helper funcions end
    **********************************************************/

    /**********************************************************
                   New Message button click start
    **********************************************************/
    //used to click on new message button
    vm.NCWindow = function () {
        try {
            var ctrId = 'dvncw';
            if ($("#" + ctrId).length == 0) {
                vm.txtncwsrch = "";
                var nmcw = "<div class='panel panel-heading' style='position:relative;display:table;width: 100%;margin-bottom: 0px;float:right;'>"
                    + "<div id='" + ctrId + "' class='prvtcht popup-box chat-popup chatpp' style='display: block;bottom:0;right:0px;'>"
                    + "<div id='cmwhead' class='popup-head clscwhd'>"
                    + "<div class='col-md-8 col-xs-8 npd'><h3 class='panl-bx'><span id='name' class='nmhd'>New message</span></h3></div>"
                    + "<div class='col-md-4 col-xs-4 npd' style='text-align: right;'><a href='javascript:void(0);'><span id='minim_chat_window' class='icon_minim'><img style='width:20px;height:20px' src='https://pccdn.pyar.com/pcimgs/min-collapse.png'></span></a><a href='javascript:void(0);'><span class='icon_close' data-id='" + ctrId + "'><img style='width:20px;height:20px' src='https://pccdn.pyar.com/pcimgs/ch-close.png'/></span></a></div></div>"
                    + "<div class='panel-body npd popup-body'>"
                    + "<div class='msg_container_base nmcwh'><div class='nmsrch'><input id='txtncwsrch' name='txtncwsrch' ng-model='msgCtrlAs.txtncwsrch' ng-change='msgCtrlAs.txtNCWSrchChg();' type='text' class='form-control' placeholder='Name' maxlength='30'/></div>"
                    + "<div id='dvscl'><ul class='msrlsts'><li style='display:none;' class='nrslt'>No results</li><li class='limns' ng-click='msgCtrlAs.createPCW(rslt.tmId,rslt.fn,rslt.pp,rslt.online,rslt.offline,rslt.gender);' ng-repeat='rslt in msgCtrlAs.ncwRslts'><a href='javascript:void(0);' class='clearfix'><img data-gender='{{rslt.gender}}' ng-src='{{msgCtrlAs.getPP(rslt.pp,rslt.gender)}}' alt='' class='img-circle'><div class='chtxt' id='name'>{{(rslt.fn.length > 15 ? (rslt.fn.trim().substring(0, 12) + '...') : rslt.fn)}}<span id='ms' class='{{(rslt.online && !rslt.offline)?\"srconclr\":\"sloffclr\"}}'></span></div></a></li></ul></div></div></div>"
                var nmcwHtml = $compile(nmcw)($scope);
                angular.element(document.getElementById("chatMsg")).append(nmcwHtml);
                //empty saved member network srch list
                vm.mnwSrchList = [];
                vm.ncwRslts = [];
                vm.txtncwsrch = "";
                var cwObj = { cwId: ctrId, status: true };
                vm.showList.push(cwObj);
                vm.setChatWindowHeight();
                vm.chgCWPos();
                vm.manageChatWindows();
                $timeout(function () { $("#txtncwsrch").focus(); }, 0);
            }
            else
                vm.moveCWFirst(ctrId);
        } catch (e) {
            console.log("vm.NCWindow  --  " + e.message);
            alert("vm.NCWindow  --  " + e.message);
        }
    };

    vm.moveCWFirst = function (cwId) {
        try {
            for (var i = 0; i < vm.showList.length; i++) {
                if (vm.showList[i].cwId == cwId) {
                    if (vm.showList[i].status == false)
                        $("#dvcwd li#" + cwId).click();
                    else {
                        var cwObj = { cwId: cwId, status: true };
                        vm.showList.splice(i, 1);
                        vm.showList.push(cwObj);
                        vm.chgCWPos();
                    }
                    break;
                }
            }
        } catch (e) {
            console.log("vm.moveCWFirst  --  " + e.message);
            alert("vm.moveCWFirst  --  " + e.message);
        }
    };

    //search network members
    vm.txtNCWSrchChg = function () {
        try {
            if (vm.txtncwsrch) {
                if (vm.txtncwsrch.length > 30) {
                    vm.txtncwsrch = "";
                    $("#txtncwsrch").attr("placeholder", "Must be < 30 characters")
                    vm.NWSrchNR();
                    return false;
                }
                else if (vm.txtncwsrch.length > 0)
                    $("#txtncwsrch").attr("placeholder", "Name");

                if (vm.txtncwsrch.length < 3) {
                    vm.ncwRslts = [];
                    vm.NWSrchNR();
                }
                else if (vm.txtncwsrch.length == 3 && !vm.checkNWSrchListExtst()) {
                    vm.mnwSrchList = [];
                    var key = vm.txtncwsrch;
                    msgSrvc.getMNWSrch(vm.mId(), key, function (response, status) {
                        if (status == 200) {
                            if (response.length > 0)
                                vm.mnwSrchList.push({ key: key, val: response });
                            vm.bindSrchMember();
                        }
                        else
                            console.log("error while search in member network\n\n" + response);
                    });
                }
                else if (vm.txtncwsrch.length >= 3) {
                    vm.bindSrchMember();
                }
            }
            else
                vm.NWSrchNR();
        } catch (e) {
            console.log("vm.txtNCWSrchChg  --  " + e.message);
            alert("vm.txtNCWSrchChg  --  " + e.message);
        }
    }

    //preparing network member search result to show
    vm.bindSrchMember = function () {
        try {
            vm.ncwRslts = [];
            if (vm.txtncwsrch) {
                var response = [];
                for (var i = 0; i < vm.mnwSrchList.length; i++) {
                    if (vm.txtncwsrch.toLowerCase().indexOf(vm.mnwSrchList[i].key.toLowerCase()) == 0) {
                        response = vm.mnwSrchList[i].val;
                        break;
                    }
                }

                for (var i = 0; i < response.length; i++) {
                    if (response[i].fn.toLowerCase().indexOf(vm.txtncwsrch.toLowerCase()) == 0)
                        vm.ncwRslts.push(response[i]);
                }
                vm.NWSrchNR();
            }
        } catch (e) {
            console.log("vm.bindSrchMember  --  " + e.message);
            alert("vm.bindSrchMember  --  " + e.message);
        }
    }

    vm.NWSrchNR = function () {
        var noRslt = $("#dvncw #dvscl ul.msrlsts .nrslt");
        if (vm.txtncwsrch && vm.txtncwsrch.length > 2) {
            if (vm.ncwRslts.length == 0)
                noRslt.show();
            else
                noRslt.hide();
        }
        else
            noRslt.hide();
    };

    //convert new message window into private chat window
    vm.createPCW = function (tmId, tmfn, tmpp, isOnline, offline, gender) {
        try {
            vm.removeNCWindow(false);
            //checking window already created then open it otherwise need to create
            if ($("#private_" + tmId).length > 0) {
                //checking window is in overflow then open
                if ($("ul#dockul li#private_" + tmId).length > 0) {
                    $("ul#dockul li#private_" + tmId).click();
                }
                else {
                    var cwId = "private_" + tmId;
                    for (var i = 0; i < vm.showList.length; i++) {
                        if (vm.showList[i].cwId == cwId) {
                            var cwObj = { cwId: cwId, status: true };
                            vm.showList.splice(i, 1);
                            vm.showList.push(cwObj);
                            vm.setChatWindowHeight();
                            vm.chgCWPos();
                            break;
                        }
                    }
                }
                vm.manageChatWindows();
            }
            else {
                var convrnId = "";
                vm.openPrivateChatWindow(tmId, tmfn, tmpp, convrnId, isOnline && !offline, gender);
            }
        } catch (e) {
            console.log("vm.createPCW  --  " + e.message);
            alert("vm.createPCW  --  " + e.message);
        }
    };

    //remove new message window
    vm.removeNCWindow = function (aw) {
        try {
            if ($("#dvncw").length > 0) {
                $("#dvncw").parent().remove();
                for (var i = 0; i < vm.showList.length; i++) {
                    if (vm.showList[i].cwId == "dvncw") {
                        vm.showList.splice(i, 1);
                    }
                    else if (aw && vm.showList[i].cwId != "dvcwd" && !vm.showList[i].status) {
                        vm.showList[i].status = true;
                        aw = false;
                    }
                }
            }
        } catch (e) {
            console.log("vm.removeNCWindow  --  " + e.message);
            alert("vm.removeNCWindow  --  " + e.message);
        }
    }

    vm.checkNWSrchListExtst = function () {
        try {
            if (vm.txtncwsrch) {
                for (var i = 0; i < vm.mnwSrchList.length; i++) {
                    var key = vm.txtncwsrch.toLowerCase();
                    if (vm.mnwSrchList[i].key.toLowerCase().indexOf(key) == 0)
                        return true;
                }
            }
            return false;
        } catch (e) {
            console.log("vm.checkNWSrchListExtst  --  " + e.message);
            alert("vm.checkNWSrchListExtst  --  " + e.message);
        }
    }
    /**********************************************************
                        New Message button click End
    **********************************************************/

    /**********************************************************
                    Chat Window functions End
    **********************************************************/
    //used to open chat window when overflow window list clicked
    $("body").on("click", "ul#dockul li", function () {
        try {
            var cwId = $(this).attr("id");
            for (var i = 1; i < vm.showList.length; i++) {
                if (vm.showList[i].cwId == cwId) {
                    cwObj = { cwId: cwId, status: true };
                    vm.showList.splice(i, 1);
                    vm.showList.push(cwObj);
                    $("ul#dockul li#" + cwId).remove();
                    if ($("#" + cwId + " #minim_chat_window").css("display") == "none") {
                        $("#" + cwId + " #minim_chat_window").css("display", "inline");
                        $("#" + cwId + " #minim_chat_window").removeClass("panel-collapsed");
                        $("#" + cwId + " #cmwbody").css("display", "block");
                    }

                    //set unread msg count to 0
                    var msgcnt = parseInt($("#" + cwId + " #msgcnt").attr("data-msgcnt"));
                    if (msgcnt > 0) {
                        $("#" + cwId + " #msgcnt").attr("data-msgcnt", 0);
                        $("#" + cwId + " #msgcnt").text("");
                    }

                    //for stop msg
                    if (parseInt($("#" + cwId + " #cmwhead").attr("data-ms")) < 30000) {
                        $("#" + cwId + " #cmwhead").removeClass("chtblank");
                        $("#" + cwId + " #cmwhead").attr("data-ms", "30500");
                    }
                    vm.checkMRS(vm.mId(), cwId.replace("private_", ""));
                    break;
                }
            }
            for (var i = 1; i < vm.showList.length; i++) {
                if (vm.showList[i].cwId !== cwId && vm.showList[i].status) {
                    vm.showList[i].status = false;
                    break;
                }
            }
            vm.chgCWPos();
            if (cwId == "dvncw")
                $("#txtncwsrch").focus();
            else
                $("#btn-input-" + cwId.replace("private_", "")).focus();
        } catch (e) {
            console.log("ul#dockul li  --  " + e.message);
            alert("ul#dockul li  --  " + e.message);
        }
    });

    //chat box list header click event
    $("body").on("click", "#cblhd", function () {
        try {
            $this = $(this);
            if ($this.find(".icon_minim").hasClass('panel-collapsed')) {
                $this.find("span.icon_minim").show();
                $this.find("span.icon_minim").removeClass('panel-collapsed');
                $this.parent().find('.panel-body').slideDown();
            }
        } catch (e) {
            console.log("pcw head click  --  " + e.message);
            alert("pcw head click  --  " + e.message);
        }
    });

    //overflow window header click event
    $("body").on("click", "#dvcwd .popup-head", function () {
        try {
            $this = $(this).parent();
            if ($this.find(".icon_minim").hasClass('panel-collapsed')) {
                $this.find("span.icon_minim").show();
                $this.parents('.panel').find('.panel-body').slideDown();
                $this.find(".icon_minim").removeClass('panel-collapsed');
                $("#dvcwd #ofcwCnt").text("");
                //stop flash
                if (parseInt($(this).attr("data-ms")) <= 30000) {
                    $(this).attr("data-ms", "30500");
                    $(this).removeClass("chtblank");
                }
            }
        } catch (e) {
            console.log("#dvcwd .popup-head  --  " + e.message);
            alert("#dvcwd .popup-head  --  " + e.message);
        }
    });

    //close private chat window click event
    $("body").on("click", ".icon_close", function (e) {
        try {
            e.preventDefault();
            e.stopPropagation();
            var cwId = $(this).attr("data-id");
            var msg = $("#btn-input-" + cwId.replace('private_', '')).val();
            if (msg && msg.length > 1) {
                vm.nawId = cwId;
                $("#naModel").modal('show');
            }
            else {
                vm.closePCW(cwId);
            }
        } catch (e) {
            console.log(".icon_close  --  " + e.message);
            alert(".icon_close  --  " + e.message);
        }
    });

    //minimize message windwos
    $("body").on("click", "span.icon_minim", function (e) {
        try {
            e.stopPropagation();
            e.preventDefault();
            var $this = $(this);
            if (!$this.hasClass('panel-collapsed')) {
                $this.parents('.panel').find('.panel-body').slideUp();
                $this.addClass('panel-collapsed');
                $this.hide();
            }

            if ($this.parents("div#dvcwd").length > 0)
                $("#dvcwd #ofcwCnt").text(" (" + $("ul#dockul li").length + ")");
        } catch (e) {
            console.log("span.icon_minim  --  " + e.message);
            alert("span.icon_minim  --  " + e.message);
        }
    });

    //private chat head button click event
    $("body").on("click", "#cmwhead", function (e) {
        try {
            var ms = parseInt($(this).attr("data-ms"));
            if (ms < 30000) {
                $(this).removeClass("chtblank");
                $(this).attr("data-ms", "30500");
            }
            $(this).find("#msgcnt").text("");
            $(this).find("#msgcnt").attr("data-msgcnt", "0");

            var $this = $(this).parent();
            var tmId = $($this).attr("id").replace("private_", "");
            $this.find("span.icon_minim").show();
            if ($this.find(".icon_minim").hasClass('panel-collapsed')) {
                $this.find('.panel-body').slideDown();
                $this.find(".icon_minim").removeClass('panel-collapsed');
                vm.checkMRS(vm.mId(), tmId);
            }
            else {
                if (tmId != "dvncw")
                    $window.open("/match/" + getSessionSrvc.pce(tmId), "_blank");
            }
        } catch (e) {
            console.log("#cmwhead  --  " + e.message);
            alert("#cmwhead  --  " + e.message);
        }
    });

    //show member chat settings
    $("body").on("click", "#drpdn", function (e) {
        try {
            if ($("#chatbox .msg_container_base").css("display") != "none") {
                $("#ulopt").toggle();
                //now set up an event listener so that clicking anywhere outside will close the menu
                $('html').click(function (event) {
                    //check up the tree of the click target to check whether user has clicked outside of menu
                    if ($(event.target).parents('#drpdn').length == 0) {
                        $("#ulopt").toggle();
                        //this event listener has done its job so we can unbind it.
                        $(this).unbind(event);
                    }
                })
            }
            e.preventDefault();
            e.stopPropagation();
        } catch (e) {
            console.log("#drpdn  --  " + e.message);
            alert("#drpdn  --  " + e.message);
        }
    });

    //create overflowWindow
    vm.createOverflowWindow = function () {
        try {
            if ($("#dvcwd").length == 0) {
                var cdwHtml = "<div  class='panel panel-heading' style='position:relative;display:table;width: 100%;margin-bottom: 0px;float:right;'>"
                            + "<div id='dvcwd' class='prvtcht popup-box chat-popup chatpp' style='display: none;bottom:0;right:0px;'>"
                            + "<div class='minm-popup chat-popup'><div class='popup-head clscwhd' data-ms='30500'><div class='col-md-7 col-xs-7 npd'><div class='panl-bx nmhd'>Open chats<span id='ofcwCnt'></span></div></div><div class='col-md-5 col-xs-5 npd trgt'><div class='popup-head-right'><a href='javascript:void(0);'><span class='icon_minim panel-collapsed' style='display:none;'><img src='https://pccdn.pyar.com/pcimgs/min-collapse.png'></span></a><img style='width:30px;margin-right:-4px;' src='https://pccdn.pyar.com/pcimgs/chwt-message.png'></div></div> <div style='clear: both'></div></div>"
                            + "<div class='panel-body npd' style='display:none;'><div class='cdwbase'><ul id='dockul' class='cdwlst'>"
                            + "</ul></div></div></div></div></div>";
            }
            $("#chatMsg").append(cdwHtml);
            vm.setChatWindowHeight();
        } catch (e) {
            console.log("vm.createOverflowWindow  --  " + e.message);
            alert("vm.createOverflowWindow  --  " + e.message);
        }
    }

    //manage private chat windows for hide,show and position
    vm.manageChatWindows = function () {
        try {
            if (vm.showList.length > 0) {
                //find all active windows count
                var actCnt = 0;
                for (var i = 0; i < vm.showList.length; i++) {
                    if (vm.showList[i].status)
                        actCnt++;
                }
                // each private chat window width
                var cwWidth = 280;
                //gap between tow chat windows
                var wgap = 15;
                //find avaliable width=total window width - 8% of window width
                // we are removing 8% of window width because over container fluid not taken left and right each 4%
                var width = $(window).width() - $(window).width() * 0.08;
                //calculating open window width and adding one extra window width
                var cwtw = (actCnt * cwWidth) + (actCnt * wgap) + cwWidth;

                //if window width is less than active windows width
                if (width < cwtw) {
                    //checking overflow window not exist
                    if (vm.showList[0].cwId != "dvcwd") {
                        //cretating overflow width
                        vm.createOverflowWindow();
                        //adding into active windows at first position
                        vm.showList.unshift({ cwId: "dvcwd", status: true });
                        //when over flow window are created we need to hide 2 windows
                        //1 for new message window
                        //2  for overflow window
                        //and we need to add both windows into overflow window
                        var loop = 0;
                        //loop to all chat windows upto inactive 2 windows
                        for (var i = 1; i < vm.showList.length; i++) {
                            //checking current window is active
                            if (vm.showList[i].status) {
                                //set window as inactive
                                vm.showList[i].status = false;
                                loop++;
                                //if inactivate reach 2 exit from loop
                                if (loop == 2)
                                    break;
                            }
                        }
                    }
                        //overflow window already exist
                    else {
                        //check overflow window is in false
                        if (vm.showList[0].status == false) {
                            vm.showList[0].status == true;
                        }
                        //loop to all windows
                        for (var i = 1; i < vm.showList.length; i++) {
                            //if window is active 
                            if (vm.showList[i].status) {
                                //set inactive and exist loop
                                vm.showList[i].status = false;
                                break;
                            }
                        }
                    }
                    //after setting inactive set positions
                    vm.chgCWPos();
                }
                    //window size > all open tab sizes and over flow window have other private chat windows
                else if (vm.showList[0].cwId == "dvcwd") {
                    //adding window width and gap between two windows width
                    cwtw = cwtw + cwWidth + wgap;
                    //checking window width is avaliable for open next private chat window
                    if (width > cwtw) {
                        //loop to all windows in max to minimum because we have to show recent one as open
                        for (var i = vm.showList.length - 1; i >= 0; i--) {
                            //if window is hide
                            if (!vm.showList[i].status) {
                                //check if overflow windows have 2 windows only then we have to show two at a time 
                                //and need to remove that overflow windows
                                if ($("#dockul li").length == 2) {
                                    //set true for visibule
                                    vm.showList[i].status = true;
                                    //removing overlow window index from show list
                                    vm.showList.splice(0, 1);

                                    //looping for 2nd window 
                                    for (var j = vm.showList.length - 1; j >= 0; j--) {
                                        //if window is hide set true 
                                        if (!vm.showList[j].status) {
                                            vm.showList[j].status = true;
                                            break;
                                        }
                                    }
                                    //remove overlfow window
                                    $("#dvcwd").parent().remove();
                                }
                                    //if overflow window contains more than 2 then
                                else {
                                    //set true for top of the over flow window
                                    vm.showList[i].status = true;
                                    //remove form overflow window
                                    $("#dockul li#" + vm.showList[i].cwId).remove();
                                }
                                break;
                            }
                        }
                    }
                    //after setting inactive set positions
                    vm.chgCWPos();
                }
            }
        } catch (e) {
            console.log("vm.manageChatWindows  --  " + e.message);
            alert("vm.manageChatWindows  --  " + e.message);
        }
    }

    //find and calculate position of private chat window while new window created or closed
    vm.chgCWPos = function () {
        try {
            var count = 0
            var cwWidth = 280;
            var wgap = 15;
            var rgap = $(window).width() * 0.04 + wgap;

            for (var i = vm.showList.length; i > 0; i--) {
                if (vm.showList[i - 1].status) {
                    var right = cwWidth + rgap + (count * cwWidth) + (count * wgap);
                    $("#" + vm.showList[i - 1].cwId).css("right", right);
                    $("div#" + vm.showList[i - 1].cwId).show();
                    count++;
                }
                else {
                    var id = vm.showList[i - 1].cwId;
                    if ($("ul#dockul li#" + id).length == 0) {
                        var name = $("#" + id + " #name").text();
                        var online = $("#" + id + " #imgonline").hasClass("onclr");
                        var msgcnt = parseInt($("#" + id + " #msgcnt").attr("data-msgcnt"));
                        $("ul#dockul").prepend("<li id='" + vm.showList[i - 1].cwId + "' data-ms='30500'><div class='minm-mltipopup'><div class='multicht'><div class='col-md-10 col-xs-10 npd'><div class='panl-bx'><span id='imgonline' class='" + (online ? "onclr" : "offclr") + "'></span>" + name + "<span id='msgcnt' data-msgcnt='" + msgcnt + "'>" + (msgcnt > 0 ? " (" + msgcnt + ")" : "") + "</span></div></div><div class='col-md-2 col-xs-2 trgt'><div class='popup-head-right'><span class='icon_close' data-id='" + id + "'><img class='nmrg' src='https://pccdn.pyar.com/pcimgs/ch-close.png'></span></div></div> <div style='clear: both'></div></div></div></li>");
                        $("div#" + vm.showList[i - 1].cwId).hide();
                    }
                }
            }

            //set count to overflow window on minimized
            if ($("#dvcwd").length > 0) {
                if ($("ul#dockul li").length > 0 && $("#dvcwd .panel-body").css("display") == "none")
                    $("#dvcwd #ofcwCnt").text(" (" + $("ul#dockul li").length + ")");
                else
                    $("#dvcwd #ofcwCnt").text("");
            }
        } catch (e) {
            console.log("vm.chgCWPos  --  " + e.message);
            alert("vm.chgCWPos  --  " + e.message);
        }
    };

    //check and activate flash window based on conditions
    vm.checkAndActivateFlash = function (ctrId) {
        try {
            //check chat window is in overflow window or not
            if ($("ul#dockul li#" + ctrId).length > 0) {
                var cwfId = "", cwmcId = "";
                //check overflow window is minimize then add to flash
                if ($("#dvcwd .panel-body").css("display") == "none") {
                    var cwfId = "#dvcwd .popup-head";
                    vm.setFlash(cwfId, "");
                }
                //adding flash to overflow window list member for flash and msg count
                cwfId = "ul#dockul li#" + ctrId;
                cwmcId = "ul#dockul li#" + ctrId + " #msgcnt";
                vm.setFlash(cwfId, cwmcId);
            }
                //check private chat window is minimized then add to flash
            else if ($("#" + ctrId + " #cmwbody").css("display") == "none") {
                var cwfId = "#" + ctrId + " #cmwhead";
                var cwmcId = "#" + ctrId + " #msgcnt";
                vm.setFlash(cwfId, cwmcId);
            }
        } catch (e) {
            console.log("vm.checkAndActivateFlash  --  " + e.message);
            alert("vm.checkAndActivateFlash  --  " + e.message);
        }
    }

    //set flash to message window headers
    vm.setFlash = function (cwfId, cwmcId) {
        try {
            //activate flash
            if (cwfId != "") {
                var ms = parseInt($(cwfId).attr("data-ms"));
                $(cwfId).attr("data-ms", "500");
                $(cwfId).addClass("chtblank");
                if (ms > 30000) {
                    $(cwfId).addClass("chtblank");
                    vm.flashWindow(cwfId);
                }
            }

            //set msg count
            if (cwmcId) {
                var msgcnt = parseInt($(cwmcId).attr("data-msgcnt")) + 1;
                $(cwmcId).attr("data-msgcnt", msgcnt);
                $(cwmcId).text(" (" + msgcnt + ")");
            }
        } catch (e) {
            console.log("vm.setFlash  --  " + e.message);
            alert("vm.setFlash  --  " + e.message);
        }
    }

    //used to flash when new msg arrive while chat window is in hide
    vm.flashWindow = function (ctrId) {
        try {
            $timeout(function () {
                $(ctrId).toggleClass("chtblank");
                var ms = parseInt($(ctrId).attr("data-ms"));
                if (ms < 30000)
                    vm.flashWindow(ctrId);
                else
                    $(ctrId).removeClass("chtblank");
                ms = ms + 500;
                $(ctrId).attr("data-ms", ms);
            }, 500);
        } catch (e) {
            console.log("vm.flashWindow  --  " + e.message);
            alert("vm.flashWindow  --  " + e.message);
        }
    };

    //this function are used for on scroll set chat windows always top of an footer
    $(document).scroll(function () {
        if ($(window).width() > 1199)
            vm.checkOffset();
    });

    $(window).scroll(function (e) {
        if ($(window).width() > 1199)
            vm.setChatWindowHeight(e);
    });

    $(window).resize(function () {
        if ($(window).width() > 1199)
            vm.manageChatWindows();
    });

    vm.checkOffset = function () {
        try {
            if ($('.chtwndw').length > 0) {
                if ($('.chtwndw').offset().top + $('.chtwndw').height() >= $('#pcFtr').offset().top - 0)
                    $('.chtwndw').css('position', 'fixed');
                if ($(document).scrollTop() + window.innerHeight < $('#pcFtr').offset().top)
                    $('.chtwndw').css('position', 'fixed'); // restore when you scroll up
            }
        } catch (e) {
            console.log("vm.checkOffset  --  " + e.message);
            alert("vm.checkOffset  --  " + e.message);
        }
    }

    vm.setChatWindowHeight = function (e) {
        try {
            var d = $(document).height();
            var w = $(window).height();

            // scroll level
            var s = $(document).scrollTop();
            var bottomBound = $("#pcFtr").outerHeight();
            if (d - (w + s) < bottomBound) {
                $('.prvtcht').css({
                    bottom: bottomBound - (d - (w + s))
                });
            } else {
                $('.prvtcht').css({
                    bottom: 0
                });
            }
        } catch (e) {
            console.log("vm.setChatWindowHeight  -- " + vm.setChatWindowHeight);
            alert("vm.setChatWindowHeight  -- " + vm.setChatWindowHeight);
        }
    }
    /**********************************************************
                        Chat Window functions End
    **********************************************************/
}]);