﻿/// <reference path="../../../scripts/angular.min.js" />
/// <reference path="../../app.js" />

var captchaVerfication = "";
function recaptchaChk() {
    captchaVerfication = "Captcha verified";
}

angular.module("app").controller("contactusCtrl", ['getSessionSrvc', '$scope', '$location', '$window', 'contactusSrvc', '$rootScope', '$interval','$sce', function (getSessionSrvc, $scope, $location, $window, contactusSrvc, $rootScope, $interval,$sce) {

    showLoader();
    var vm = this;
    var memId = null;
    vm.shwPg = false;
    vm.SrchdataShow = false;
    vm.HelpShow = false;
    vm.explanationPlaceHolder = "Describe your question";
    vm.TitlePlaceholder = "Title";
    vm.EmailPlaceholder = 'Email';
    vm.seachPlaceHolder = "Search FAQs";
    vm.ThankUMsg = false;
    vm.mtcId = 0;
    vm.priority = 0;
    //Getting memberId from cookies
    if ((getSessionSrvc.p_mId())) { var memId = getSessionSrvc.p_mId(); }
    //Showing & Hiding Email field based member login
    if (!memId) { vm.emailShow = vm.emailRequired = true; }
    else { vm.emailShow = vm.emailRequired = false; }

    //Search functionality change event
    vm.searchChnage = function () {
        if (vm.search && vm.search.length > 100) { vm.search = null; vm.seachPlaceHolder = 'Must be < 100 characters'; }
        else { vm.seachPlaceHolder = "Search FAQs"; }
    }

    //Email blur event
    vm.emailCheck = function () { emlchkBlur($rootScope, vm); }
    //Email change event
    vm.emailChnage = function () { emlchangeEvnt(vm); }
    //Email Focus event
    vm.emailFocus = function () { emlFcs(vm); }

    //title textbox change event
    vm.titleChnage = function () {
        vm.KpTitleCls = "bgWht";
        if (vm.helpTitle && vm.helpTitle.length > 50) { vm.TitlePlaceholder = "Must be < 50 characters"; vm.KpTitleCls = "eror"; vm.helpTitle = null; }
        else if (!vm.helpTitle) { vm.helpTitle = null; vm.KpTitleCls = "bgWht"; vm.TitlePlaceholder = "Title"; }
        else { vm.TitlePlaceholder = "Please enter title"; }
    }
    //title textbox blur event
    vm.titleCheck = function () { if (!vm.helpTitle) { vm.helpTitle = null; vm.KpTitleCls = "eror"; vm.TitlePlaceholder = "Please enter title"; } }
    //title focus event
    vm.helpTitleFocus = function () { vm.KpTitleCls = "bgWht"; vm.TitlePlaceholder = "Title"; }
    //Description textarea blue event
    vm.descriptionBlur = function () { vm.txtCls = "txtaraPhClr"; }

    //Description change event
    vm.explanationChange = function () {
        if (vm.explanation && vm.explanation.length > 5000) { vm.txtCls = "txtaraPhClr"; vm.explanationPlaceHolder = "Must be < 5000 characters"; vm.explanation = null; }
        else if (!vm.explanation) { vm.txtCls = "txtaraPhClr"; vm.explanationPlaceHolder = "Describe your question"; vm.explanation = null; }
        else { delete vm.txtCls; vm.explanationPlaceHolder = "Describe your question"; }
    }

    //Description blur event
    vm.explanationCheck = function () { if (!vm.explanation) { vm.txtCls = "txtaraPhClr"; vm.explanationPlaceHolder = "Describe your question"; vm.explanation = null; } }

    //Disable send button (if form not valid)
    vm.btnSendDisabled = function () {
        if (memId != null) {
            if (vm.helpTitle && vm.mtcId && vm.priority && vm.explanation && captchaVerfication) { vm.activeCls = "cnbtn"; return false; }
            else { vm.activeCls = "cnbtn sndBtn"; return true; }
        }
        else {
            if (vm.email && vm.helpTitle && vm.mtcId && vm.priority && vm.explanation && captchaVerfication) { vm.activeCls = "cnbtn"; return false; }
            else { vm.activeCls = "cnbtn sndBtn"; return true; }
        }
    }

    //this function need to after getting response from google captcha. // for send button enabling.
    $interval(function () { if (captchaVerfication) { vm.btnSendDisabled(); } }, 100);

    //Clear all form fileds
    vm.ClearAllFileds = function () {
        vm.helpTitle = null;
        vm.KpTitleCls = "bgWht";
        vm.TitlePlaceholder = "Title";

        vm.email = null;
        vm.emailKpcls = "bgWht";
        vm.EmailPlaceholder = "Email";

        vm.explanation = null;
        vm.txtCls = "";

        vm.mtcId = vm.priority = 0;
        $("#dvCatLst").html("Category");
        captchaVerfication = "";
    }

    // Clear Search content in Search textbox
    vm.clrSrchTxt = function () {
        vm.search = null;
        vm.SrchdataShow = false;
        vm.HelpShow = false;
    }

    // Services for faq categories
    contactusSrvc.faqCategories(function (response, status) {
        if (status == 200) { vm.categories = response; }
    });
    //End 

    $scope.$on("dataBindFinish", function (e, type) {
        vm.shwPg = true;
        hideLoader();
    });

    //Services for faq categories by Id
    vm.categoryFaqs = [];
    vm.catFAQS = [];
    vm.catId = function (id) {
        vm.GetCatId = id;
        if (vm.categoryFaqs.indexOf(id) == -1) {
            vm.categoryFaqs.push(id);
            contactusSrvc.faqCategoryById(vm.GetCatId, function (response, status) {
                if (status == 200 && response.length != 0) {
                    for (var i = 0; i < response.length; i++) {
                        var catFaqs = {};
                        catFaqs.faqCatId = vm.GetCatId;
                        catFaqs.faq = response[i].faq;
                        catFaqs.faqans = $sce.trustAsHtml(response[i].faqans);
                        catFaqs.priority = response[i].priority
                        vm.catFAQS.push(catFaqs);
                    }
                }
            });
        }
        var dvstatus = $("#" + id).attr("aria-expanded");
        $("img[id^='imgoc']").attr("src", "https://pccdn.pyar.com/pcimgs/expnd.png");
        if (dvstatus == undefined || dvstatus == "false") {
            $("#imgoc" + id).attr("src", "https://pccdn.pyar.com/pcimgs/clpse.png");
        }
        else {
            $("#imgoc" + id).attr("src", "https://pccdn.pyar.com/pcimgs/expnd.png");
        }
        var objFaqCat = $("a[data-target='#" + id + "']");
        var hdHeight = $("nav[ng-show='showSignInHeader']");
        //Timeout function are used wait untill close or open the faq question answer content then find the offset oather wise it will gave the worng values due to the content.
        setTimeout(function () {
            $('html, body').animate({
                scrollTop: objFaqCat.offset().top - (objFaqCat.outerHeight() + 10)
            }, 500);
        }, 1);
    }
    //End

    //Services for member ticket category
    contactusSrvc.memberTktCategory(function (response, status) {
        if (status == 200 && response.length != 0) {
            vm.memTktCat = response;
        }
    });
    //End

    vm.bindCtgryVal = function (mtcId, priority) {
        vm.mtcId = mtcId;
        vm.priority = priority;
        vm.ThankUMsg = false;
    }

    vm.Send = function () {
        if (memId != null) {
            if (vm.helpTitle && vm.mtcId && vm.priority && vm.explanation && captchaVerfication) {
                //Member ticket Service
                contactusSrvc.memberTkt(memId, vm.mtcId, vm.helpTitle, vm.explanation, function (response, status) {
                    if (response == true && status == 200) {
                        vm.ThankUMsg = true;
                    }
                });
                //end
            }
        }
        else {
            if (vm.email && vm.helpTitle && vm.mtcId && vm.priority && vm.explanation && captchaVerfication) {
                //Non-Member ticket Service
                contactusSrvc.nonMemberTkt(vm.email, vm.mtcId, vm.helpTitle, vm.explanation, function (response, status) {
                    if (response == true && status == 200) {
                        vm.ThankUMsg = true;
                    }
                });
                //end
            }
        }
        vm.ClearAllFileds();
        grecaptcha.reset();
    };

    vm.searchFaq = function ($event) {
        var keyCode = $event.which || $event.keyCode;
        if (keyCode === 13) {
            if (vm.search == "" || vm.search == null || vm.search == undefined) {
                vm.SrchdataShow = false;
                vm.HelpShow = false;
            }
            else {
                //Service for Search Faqs
                contactusSrvc.faqSearch(vm.search, function (response, status) {
                    if (status == 200 || status == 204) {
                        vm.SrchdataShow = true;
                        vm.HelpShow = true;
                        vm.searchData = response;
                        vm.Srchtxt = vm.search;
                    }
                });
                //end
            }
        }
    };
}]);