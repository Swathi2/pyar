﻿angular.module("app").service("contactusSrvc", ["$http", function ($http) {

    this.faqCategories = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/helpcontact/faqcat";
        GetServiceByURL($http, url, funCallBack);
    };

    this.faqCategoryById = function (categoryId, funCallBack) {
        var url = getApiDomainUrl() + "/api/helpcontact/catfaq/" + categoryId + "";
        GetServiceByURL($http, url, funCallBack);
    };

    //member ticket category for binding dropdown
    this.memberTktCategory = function (funCallBack) {
        //var url = "https://pcapi.pyar.com//api/helpcontact/memberTktcat";
        var url = getApiDomainUrl() + "/api/helpcontact/memberTktcat"
        GetServiceByURL($http, url, funCallBack);
    };

    //Non-Member tikcet Service
    this.nonMemberTkt = function (email, mtcId, title, desc, funCallBack) {
        var data = { email: email, mtcId: mtcId, title: title, desc: desc }
        //var url = "https://pcapi.pyar.com//api/helpcontact/nonMemberTkt";
        var url = getApiDomainUrl() + "/api/helpcontact/nonMemberTkt";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //Member tikcet Service
    this.memberTkt = function (memberId, mtcId, title, desc, funCallBack) {
        var data = { memberId: memberId, mtcId: mtcId, title: title, desc: desc }
        // var url = "https://pcapi.pyar.com//api/helpcontact/memberTkt";
        var url = getApiDomainUrl() + "/api/helpcontact/memberTkt";
        PostServiceByURL($http, url, data, funCallBack);
    };

    // faq search Service
    this.faqSearch = function (srchTxt, funCallBack) {
        var data = { srchTxt: srchTxt }
        var url = getApiDomainUrl() + "/api/helpcontact/faqSrch";
        PostServiceByURL($http, url, data, funCallBack);
    }
}]);