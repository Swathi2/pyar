﻿angular.module('app').controller('abtusCtrl', function ($scope) {

    $('.res').not('.slick-initialized').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 6,
        centerMode: true,
        slidesToScroll: 1,
        responsive: [
          {
              breakpoint: 991,
              settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1
              }
          },
          {
              breakpoint: 767,
              settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
              }
          }]
    });
  
});