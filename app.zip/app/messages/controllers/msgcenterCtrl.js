﻿/// <reference path="../../../scripts/angular-signalr-hub.min.js" />
/// <reference path="../../../scripts/angular.js" />
/// <reference path="../services/msgSrvc.js" />
angular.module("app").controller('msgcenterCtrl', ['msgSrvc', 'getSessionSrvc', '$filter', '$scope', '$rootScope', 'cmnSrvc', '$window', '$state', '$compile', '$timeout', function (msgSrvc, getSessionSrvc, $filter, $scope, $rootScope, cmnSrvc, $window, $state, $compile, $timeout) {
    var vm = this;
    /**********************************************************
                        Variabl Declaration start
    **********************************************************/
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.sId = function () { return getSessionSrvc.p_sub(); };
    vm.fn = function () { return getSessionSrvc.p_fn(); };
    vm.gndr = function () { return getSessionSrvc.p_gndr(); };
    vm.pp = function () { return getSessionSrvc.p_ppic(); };
    vm.tz = function () { return getSessionSrvc.p_tz(); };
    vm.msgMaxCnt = function () { return getSessionSrvc.p_msgMaxCnt(); };
    vm.txtMsgCnt = function () { return msgSrvc.txtOrNumDisplayForMsgCnt(vm.msgMaxCnt()); };
    vm.mobile = function () { return $(window).width() <= 991 };
    vm.mmCnt = [];
    vm.rmcPnl = true;
    if (vm.mobile())
        vm.mhPnl = false;
    else
        vm.mhPnl = true;
    vm.mngPnl = null;
    vm.msgReadScroll = true;
    vm.zone = function () { return getTimeZoneById(vm.tz()); };
    vm.imgCDN = "https://pccdn.pyar.com/";
    vm.ppm = "https://pccdn.pyar.com/pcmbr/defaults/profilemtns.jpg";
    vm.ppf = "https://pccdn.pyar.com/pcmbr/defaults/profileftns.jpg";
    vm.rmcontacts = [];
    vm.rmempList = [];
    vm.pgSize = 20;
    vm.busy = false;
    vm.mhBusy = false;
    vm.mrcPgNo = 1;
    vm.mhPgNo = 1;
    vm.mnwSrchList = [];
    vm.ncwRslts = [];
    vm.offlinemsglst = [];
    vm.networkAvail = true;
    vm.typingStatus = false;
    vm.msghistory = [];
    vm.prvHeight = 0;
    vm.rmcStopScroll = false;
    vm.mhScrollStop = false;
    vm.nmFlag = false;
    vm.lastSeen = false;
    vm.lastSeenTxt = "";
    vm.selMbr = null;
    vm.toState = null;
    vm.MsgCnSrchTextPH = "Name";
    vm.msgTxtPH = "Type a message...";
    // 1 - bind msg on selected member
    // 2 - bind previous msg on on scroll
    // 3 - bind sent msg 
    // 4 - bind receive msg
    vm.msgBindType = "";
    // 1 - show selected member msg history panel
    // 2 - show not selected member panel
    // 3 - show network member search panel
    vm.mhPanelType = "1";
    vm.msgTxt = "";
    vm.msgCnt = 0;
    vm.msgInitiator = true;
    vm.msgRestriction = false;
    vm.msgRestrictionWrng = false;

    /**********************************************************
                    Variabl Declaration End
    **********************************************************/

    /**********************************************************
                        msg service listeners start
    **********************************************************/
    $scope.$on("msgSrvcReady", function (e) {
        try {
            vm.sendOfflineMsgs();
            //need to add condition
            vm.intialLoadMemberRecentNWContacts(); //Intial load Network Contacts
        } catch (e) {
            console.log("msgSrvcReady listener  --  " + e.message);
            alert("msgSrvcReady listener  --  " + e.message);
        }
    });

    $scope.$on("receiveMsg", function (e, tmId, fn, msg, tmpp, convrnId, dt, sender) {
        try {
            if (($('body').data("user-blckdid" + tmId) == '2' || $('body').data("user-blckdid" + tmId) == '4'))
                msgSrvc.sendMbrBlockNtfn(vm.mId(), vm.fn(), vm.gndr(), vm.tmemId, true);   // calling sndblck notifctn api when a user is blocked
            else {
                vm.msgBindType = "4";
                if (sender)
                    vm.bindMsg(vm.mId(), tmId, tmpp, convrnId, msg, sender);
                else
                    vm.bindMsg(tmId, vm.mId(), tmpp, convrnId, msg, sender);

                if (tmId == vm.tmemId) {
                    if (sender)
                        vm.addMsgMaxCount();
                    else
                        vm.isBD = true;
                    vm.checkMsgMaxCount();
                }

                vm.addRMContacts(tmId);
                $scope.$digest();
            }
        } catch (e) {
            console.log("receiveMsg listener --  " + e.message);
            alert("receiveMsg listener --  " + e.message);
        }
    });

    $scope.$on("recTypeReq", function (e, mId) {
        try {
            if (mId == vm.tmemId) {
                vm.lastSeen = false;
                vm.typingStatus = true;
                $scope.$digest();
                var lstChild = $("#rctMsglist li:last-child");
                if (($("#rctMsglist").length > 0 && lstChild.length == 0) || (lstChild.length > 0 && lstChild.visible("partial"))) {
                    if (vm.mobile()) {
                        if ($("#nmcHistory").height() > $(window).height())
                            $('html, body').animate({ scrollTop: $("#nmcHistory").prop("scrollHeight") }, 1000);
                        else
                            $("#msgdvTyping").attr("style", "position:fixed;bottom:80px;");
                    }
                    else {
                        if ($("#nmcHistory div:first-child").prop("scrollHeight") > $("#nmcHistory").height())
                            $("#nmcHistory").animate({ scrollTop: $("#nmcHistory").prop("scrollHeight") }, 1000);
                        else
                            $("#msgdvTyping").addClass("type");
                    }
                }
                $timeout(function () {
                    vm.typingStatus = false;
                    $("#msgdvTyping").removeClass("type");
                    $("#msgdvTyping").attr("style", "");
                }, 4000);
            }
        } catch (e) {
            console.log("recTypeReq listener --  " + e.message);
            alert("recTypeReq listener  --  " + e.message);
        }
    });

    $scope.$on("recSeenStatus", function (e, mId, seenDT) {
        try {
            if (mId == vm.tmemId && vm.msghistory && vm.msghistory.length > 0 && vm.msghistory[vm.msghistory.length - 1].fmId == vm.mId()) {
                vm.typingStatus = false;
                vm.lastSeen = true;
                var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), seenDT);
                if (dtObj.date)
                    vm.lastSeenTxt = "Seen " + dtObj.date + " at " + dtObj.time;
                else
                    vm.lastSeenTxt = "Seen at " + dtObj.time;
                $scope.$digest();
                var lstChild = $("#rctMsglist li:last-child");
                if (lstChild.length > 0 && lstChild.visible("partial")) {
                    if (vm.mobile())
                        $('html, body').animate({ scrollTop: $("#nmcHistory").prop("scrollHeight") }, 1000);
                    else
                        $("#nmcHistory").animate({ scrollTop: $("#nmcHistory").prop("scrollHeight") }, 1000);
                }
            }
        } catch (e) {
            console.log("recSeenStatus listener  --  " + e.message);
            alert("recSeenStatus listener  --  " + e.message);
        }
    });

    $scope.$on("onlineStatusChg", function (e, mId, statusType, status) {
        try {
            for (var i = 0; i < vm.rmcontacts.length; i++) {
                if (vm.rmcontacts[i].tmId == mId) {
                    if (statusType == 1)
                        vm.rmcontacts[i].online = status;
                    else if (statusType == 2)
                        vm.rmcontacts[i].offline = status;
                    $scope.$digest();
                    break;
                }
            }
        } catch (e) {
            console.log("onlineStatusChg listener  --  " + e.message);
            alert("onlineStatusChg listener  --  " + e.message);
        }
    });

    //if a user is blocked suddenly
    $scope.$on("recBlockNtfnChg", function (e, tmId, fn, gender, status) {
        try {
            if (vm.tmemId == tmId) vm.bindBlockStatusMCWindow(tmId, fn, status, gender, false) // Blocking the user who is opened the chat already
            if (vm.rmcontacts.length > 0) vm.removeRMCById(tmId, fn, status, gender, false) // member to be disabled in leftside userList 
            $scope.$digest();
        } catch (e) {
            console.log("ntfn  --  " + e.message);
            alert("ntfn  --  " + e.message);
        }
    });

    $scope.$on("recSelfBlockNtfnChg", function (e, tmId, status) {
        try {
            if (vm.tmemId == tmId) vm.bindBlockStatusMCWindow(tmId, vm.tmName, status, vm.tgender, true) // Blocking the user who is opened the chat already
            if (vm.rmcontacts.length > 0) vm.removeRMCById(tmId, vm.tmName, status, vm.tgender, true) // member to be disabled in leftside userList 
            $scope.$digest();
        } catch (e) {
            console.log("ntfn  --  " + e.message);
            alert("ntfn  --  " + e.message);
        }
    });

    vm.removeRMCById = function (tmId, fn, blockStatus, gender, isSelfBlock) {
        // get the index of leftside chatList
        var splcindx = vm.rmcontacts.findIndex(function (obj) {
            return obj.tmId == tmId
        });
        if (splcindx != -1) {
            if (blockStatus) {
                // if user exists in the list and he/she is blocked
                if (vm.rmcontacts[splcindx].tmId == vm.tmemId) {
                    var imgbygndr = gender ? "https://pccdn.pyar.com/pcimgs/mblck.png" : "https://pccdn.pyar.com/pcimgs/fmblck.png"
                    $("#" + tmId).find('img:first').attr("src", imgbygndr);
                    $("#" + tmId).addClass("blckchatdsb");
                    $("#" + tmId + " .onlneimg").css("display", "none");
                } else
                    vm.rmcontacts.splice(splcindx, 1);
            } else {
                var blockId = '1';
                if (tmId != vm.tmemId) {
                    blockId = getMemberBlockStatus(isSelfBlock, $('body').data("user-blckdid" + tmId), blockStatus);
                    $('body').data("user-blckdid" + tmId, blockId);
                } else
                    blockId = $('body').data("user-blckdid" + tmId);
                // if user exists in the list and he/she is unblocked
                if (blockId == '1') {
                    var obj = vm.rmcontacts[splcindx];
                    $("#" + tmId).find('img:first').attr("src", vm.getPP(obj.pp, obj.gender));
                    $("#" + tmId).removeClass("blckchatdsb");
                    $("#" + tmId + " .onlneimg").css("display", "block");
                }
            }
        }
    };

    vm.bindBlockStatusMCWindow = function (mId, fn, blockStatus, gndr, isSelfBlock) {
        var blockId = getMemberBlockStatus(isSelfBlock, $('body').data("user-blckdid" + mId), blockStatus);
        $('body').data("user-blckdid" + mId, blockId);
        switch (blockId) {
            case '4'://both blocked
            case '3'://other member blocked
            case '2'://self blocked
                vm.showMsgSendDiv = true;
                vm.msgRestriction = true;
                if (blockId == '2') {
                    var imgbygndr = gndr ? "https://pccdn.pyar.com/pcimgs/mblck.png" : "https://pccdn.pyar.com/pcimgs/fmblck.png"
                    gndr = gndr ? 'him' : 'her';
                    vm.errormsgTxt = "You blocked <b>" + fn + "</b> . To send a message, please unblock " + gndr + " from your <a href='#' class='gotoAccnt'>ACCOUNT</a>. Otherwise, you may delete this message thread."
                }
                else
                    vm.errormsgTxt = "<b>" + fn + "</b> has blocked you. This conversation is now closed";
                $("#liMbr" + mId + " .pull-left img").attr("src", imgbygndr)
                vm.isBlockedUser = blockId;
                break;

            default:
            case '1'://not blocked 
                $("#liMbr" + mId + " .pull-left img").attr("src", vm.getPP(vm.tmpp, gndr));
                vm.isBlockedUser = blockId;
                vm.checkMsgMaxCount();
                break;
        }
    };
    /**********************************************************
                        msg service listeners end
    **********************************************************/

    /**********************************************************
                        other listeners start
    **********************************************************/
    $scope.$on("online", function () {
        try {
            vm.sendOfflineMsgs();
        } catch (e) {
            console.log("online listener --  " + e.message);
            alert("online listener --  " + e.message);
        }
    });

    $scope.$on("msgbindCmplt", function (e, type) {
        try {
            if (vm.msgBindType == "1") {//member click on any recent contact
                $("#msghisloader").hide();
                if (vm.mobile())
                    $(window).scrollTop($("#nmcHistory").prop("scrollHeight"));
                else
                    $("#nmcHistory").scrollTop($("#nmcHistory").prop("scrollHeight"));
                vm.getMCH(vm.msghistory);
            }
            else if (vm.msgBindType == "2") {//on  scroll load histrory
                if (vm.mobile())
                    $(window).scrollTop($("#nmcHistory").prop("scrollHeight") - vm.prvHeight);
                else
                    $("#nmcHistory").scrollTop($("#nmcHistory").prop("scrollHeight") - vm.prvHeight);
                $("#msghisloader").hide();
            }
            else if (vm.msgBindType == "3" && $("#rctMsglist li:last-child").length > 0 && $("#rctMsglist li:last-child").visible("partial")) { //sent msg
                if (vm.mobile())
                    $('html, body').animate({ scrollTop: $("#nmcHistory").prop("scrollHeight") }, 1000);
                else
                    $("#nmcHistory").animate({ scrollTop: $("#nmcHistory").prop("scrollHeight") }, 1000);
            }
            else if (vm.msgBindType == "4" && $("#rctMsglist li:last-child").length > 0 && $("#rctMsglist li:last-child").visible("partial")) { //receive msg
                if (vm.mobile())
                    $('html, body').animate({ scrollTop: $("#nmcHistory").prop("scrollHeight") }, 1000);
                else
                    $("#nmcHistory").animate({ scrollTop: $("#nmcHistory").prop("scrollHeight") }, 1000);
                vm.checkMRS(vm.mId(), vm.tmemId);
            }
        } catch (e) {
            console.log("msgbindCmplt listener  --  " + e.message);
            alert("msgbindCmplt listener  --  " + e.message);
        }
    });

    /**********************************************************
                    Self Broadcast listeners start
    **********************************************************/
    $scope.$on("openPCW", function (e, tmId) {
        try {
            //checking selected member and already shon member history are equal or not
            //if both are not equal we will opne
            if (vm.tmemId != tmId) {
                var mbr = null;
                //find contact are avaliable are in left panel or not
                for (var i = 0; i < vm.rmcontacts.length; i++) {
                    if (vm.rmcontacts[i].tmId == tmId) {
                        mbr = vm.rmcontacts[i];
                        break;
                    }
                }
                // if contact are found open member chata 
                if (mbr != null)
                    vm.openMemberChat(mbr.tmId, mbr.fn, mbr.pp, mbr.convrnId, mbr.isBD, mbr.msgInitiator, mbr.msgCnt, mbr.urExist, mbr.seenDT, mbr.gender);
                else {// if contact are not call service and find member details and open
                    msgSrvc.getmemberInfoById(tmId, function (response, status) {
                        if (status == 200) {
                            if (response == "invalid mId")
                                alert(response);
                            else
                                vm.openMemberChat(response.mId, response.fn, response.pp, "", false, true, 0, false, "", response.gender);
                        }
                        else {
                            console.log("unable to get memberInfo  --  " + response);
                            alert("unable to get memberInfo  --  " + response);
                        }
                    });
                }
            }
        } catch (e) {
            console.log("vm.openPCW listener  --  " + e.message);
            alert("vm.openPCW listener  --  " + e.message);
        }
    });

    $scope.$on("openNCW", function (e) {
        try {
            if (vm.mhPanelType != "3")
                vm.newMsgBtnClk();
        } catch (e) {
            console.log("openNCW listener  --  " + e.message);
            alert("openNCW listener  --  " + e.message);
        }
    });
    /**********************************************************
                        other listeners End
    **********************************************************/

    /**********************************************************
                recent member chat window functions start
    **********************************************************/
    //load recent chat contacts on scroll for destop
    $("#nmcnts").scroll(function () {
        try {
            if (!vm.mobile() && vm.mhPnl == true) {
                var lstChild = $("#msgfriend-list li:last-child");
                if (vm.rmcPnl && !vm.mobile() && !vm.busy && lstChild.length > 0 && lstChild.visible("partial"))
                    vm.getRMC();
            }
        } catch (e) {
            console.log("nmcnts scroll  -- " + e.message);
            alert("nmcnts scroll  -- " + e.message);
        }
    });

    $(document).scroll(function () {
        try {
            if (vm.mobile()) {
                //load recent chat contacts on scroll for mobile
                var lstChild = $("#msgfriend-list li:last-child");
                if (vm.rmcPnl && !vm.busy && lstChild.length > 0 && lstChild.visible("partial"))
                    vm.getRMC();

                if (vm.mhPanelType == "1" && vm.mhPnl == true) {
                    //load member chat histroy on scroll for mobile
                    var frstChild = $("#rctMsglist li:first-child");
                    if (!vm.mhScrollStop && vm.mhPnl && !vm.mhBusy && frstChild.length > 0 && frstChild.visible("partial")) {
                        vm.msgBindType = "2";
                        vm.getMM();
                    }

                    //check and update msg read status
                    vm.checkMRS(vm.mId(), vm.tmemId);
                }
            }
        } catch (e) {
            console.log("document scroll  --  " + e.message);
            alert("document scroll  --  " + e.message);
        }
    });

    vm.getRMC = function () {
        try {
            if (vm.rmcStopScroll) return;
            $("#rmcldr").show();
            vm.busy = true;
            msgSrvc.getMemberRecentMsgContacts(vm.mId(), vm.mrcPgNo, vm.pgSize, function (response, status) {
                vm.busy = false;
                $("#rmcldr").hide();
                if (status == 200) {
                    if (vm.mrcPgNo == 1)
                        vm.checkRMC(response);
                    if (response) {
                        //checking each recored before adding left panel is already exist or not
                        if (vm.rmcontacts.length > 0) {
                            for (var i = 0; i < response.length; i++) {
                                var nrExist = true;
                                for (var j = 0; j < vm.rmcontacts.length; j++) {
                                    if (response[i].tmId == vm.rmcontacts[j].tmId) {
                                        nrExist = false;
                                        break;
                                    }
                                }
                                if (nrExist)
                                    vm.rmcontacts.push(response[i]);
                            }
                        }
                        else
                            vm.rmcontacts = response;

                        if (response.length < vm.pgSize)
                            vm.rmcStopScroll = true;
                    }
                    vm.mrcPgNo++;
                }
                else {
                    alert("unable to get message recent contacts  --  " + response);
                    console.log("unable to get message recent contacts  --  " + response);
                }
            });
        } catch (e) {
            console.log("vm.getRMC  --  " + e.message);
            alert("vm.getRMC  --  " + e.message);
        }
    };

    vm.checkAddEmptyLines = function (rmcCount) {
        if (rmcCount < 8) {
            var limit = 8 - (rmcCount + vm.rmempList.length);
            for (i = 0; i < limit ; i++)
                vm.rmempList.push(i);
        }
    };

    vm.checkRMC = function (rmc) {
        try {
            if (rmc && rmc.length > 0) {
                if (vm.mobile()) {
                    vm.rmcPnl = true;
                    vm.mhPnl = false;
                    $("#pcFtr").show();
                }
                else
                    vm.loadRecentMemberHistory(rmc);
            }
            else {
                vm.rmcStopScroll = true;
                vm.mhPanelType = "2";
            }
            vm.checkAddEmptyLines(rmc.length);
            if (vm.sId() == 2 && vm.mobile() == false)
                $timeout(function () { $("#txtSndMsg").focus(); }, 0);
        } catch (e) {
            console.log("checkRMC  --  " + e.message);
            alert("checkRMC  --  " + e.message);
        }
    };

    vm.loadRecentMemberHistory = function (rmc) {
        try {
            if (rmc && rmc.length > 0) {
                //sorting by last msg datetime
                rmc.sort(function (a, b) {
                    return new Date(b.msgDT) - new Date(a.msgDT);
                });
                vm.setMsgHistroyData(rmc[0].tmId, rmc[0].fn, rmc[0].pp, rmc[0].convrnId, rmc[0].isBD, rmc[0].msgInitiator, rmc[0].msgCnt, rmc[0].urExist, rmc[0].seenDT, rmc[0].gender);
                vm.getMM(rmc[0].tmId, rmc[0].convrnId, rmc[0].fn);
            }
            else {
                $("msghisloader").hide();
                vm.mhPanelType = "2";
            }
        } catch (e) {
            console.log("loadRecentMemberHistory  --  " + e.message);
            alert("loadRecentMemberHistory  --  " + e.message);
        }
    };

    vm.markAllRead = function () {
        try {
            vm.tmIds = [];
            if (vm.rmcontacts.length > 0) {
                for (i = 0; i < vm.rmcontacts.length ; i++) {
                    if (vm.rmcontacts[i].urExist == true) {
                        vm.tmIds.push(vm.rmcontacts[i].tmId);
                    }
                }
            }
            if (vm.tmIds.length > 0)
                vm.markAsReadMulti(vm.mId(), vm.tmIds, false);

        } catch (e) {
            console.log("markAllRead --  " + e.message);
            alert("markAllRead --  " + e.message);
        }
    };

    vm.markAsReadUnRead = function (tmId, readStatus, event) {
        try {
            // if member try to make msg as read (or) unread status check selected member is already showing in right side panel history
            //then last recent msg is visible to screen we are not updating the read (or) unread status
            var lstChild = $("#nmcHistory #rctMsglist li:last-child");
            if (vm.mobile() || !(tmId == vm.tmemId && lstChild.length > 0 && lstChild.visible("partial")))
                vm.markAsReadMulti(vm.mId(), [tmId], readStatus);
            event.stopPropagation();
        } catch (e) {
            console.log("markAsReadUnRead --  " + e.message);
            alert("markAsReadUnRead --  " + e.message);
        }
    };

    vm.markAsReadMulti = function (mId, tmIds, readStatus) {
        try {
            msgSrvc.updateMsgConvHdMarkAsReadMulti(mId, tmIds, readStatus, function (response, status) {
                if (status == 200 && response) {
                    //update read (or) unread for messages
                    for (var i = 0; i < tmIds.length; i++) {
                        for (j = 0; j < vm.rmcontacts.length ; j++) {
                            if (tmIds[i] == vm.rmcontacts[j].tmId) {
                                vm.rmcontacts[j].urExist = readStatus;

                                //if selected member have 
                                if (tmIds[i] == vm.tmemId) {
                                    vm.urExist = readStatus;
                                    vm.urExistProcess = false;
                                }
                                break;
                            }
                        }
                        //increment or decrement count based on status
                        if (readStatus)
                            vm.incrMsgCount(tmIds[i]);
                        else
                            vm.decrMsgCount(tmIds[i]);
                    }
                    $rootScope.$broadcast("msgSeenCntChg", tmIds, readStatus);
                    $rootScope.$broadcast("chgMRS", tmIds, readStatus);
                }
            });
        } catch (e) {
            console.log("markAsReadMulti --  " + e.message);
            alert("markAsReadMulti --  " + e.message);
        }
    };

    vm.confirmMsgDel = function (tmId, convrnId, event) {
        try {
            event.stopPropagation();
            vm.tmDelId = tmId;
            vm.convrnDelId = convrnId;
            $("#msgDel").modal('show');
        } catch (e) {
            console.log("vm.confirmmsgDel  --  " + e.message);
            alert("vm.confirmmsgDel  --  " + e.message);
        }
    };

    vm.msgDelCancel = function () {
        try {
            vm.tmDelId = "";
            vm.convrnDelId = "";
        } catch (e) {
            console.log("vm.msgDelCancel  --  " + e.message);
            alert("vm.msgDelCancel  --  " + e.message);
        }
    };

    vm.memberConversationD = function (tmId, convrnId) {
        try {
            if (vm.tmDelId && vm.convrnDelId) {
                msgSrvc.updateMsgConvHdDMulti(vm.mId(), [vm.tmDelId], [vm.convrnDelId], function (response, status) {
                    if (status == 200 && response) {
                        $("#msgDel").modal('hide');
                        var index = null;
                        for (i = 0; i < vm.rmcontacts.length; i++) {
                            if (vm.rmcontacts[i].tmId == tmId) {
                                //check if delete msg has unRead msg then decrement the count from navigation menu
                                if (vm.rmcontacts[i].urExist)
                                    $rootScope.$broadcast("msgSeenCntChg", [tmId], false);
                                vm.rmcontacts.splice(i, 1);
                                index = i;
                                break;
                            }
                        }
                        vm.decrMsgCount(tmId);
                        vm.checkAddEmptyLines(vm.rmcontacts.length);
                        if (tmId == vm.tmemId) {
                            //after delete load next items
                            if (vm.rmcontacts.length > 0 && index != null) {
                                if (vm.rmcontacts.length == index)
                                    index = vm.rmcontacts.length - 1;
                                vm.openMemberChat(vm.rmcontacts[index].tmId, vm.rmcontacts[index].fn, vm.rmcontacts[index].pp, vm.rmcontacts[index].convrnId, vm.rmcontacts[index].isBD, vm.rmcontacts[index].msgInitiator, vm.rmcontacts[index].msgCnt, vm.rmcontacts[index].urExist, vm.rmcontacts[index].seenDT, vm.rmcontacts[index].gender)
                            }
                            else {
                                vm.mhPanelType = "2";
                                vm.resetMsgHistroyData();
                            }
                        }
                    }
                });
            }
        } catch (e) {
            console.log("memberConversationD --  " + e.message);
            alert("memberConversationD --  " + e.message);
        }
    };
    /**********************************************************
            recent member chat window functions end
    **********************************************************/

    /**********************************************************
                    chat histrory panel function start
    **********************************************************/
    vm.setMsgHistroyData = function (tmId, tmfn, tmpp, convrnId, isBD, msgInitiator, msgCnt, urExist, seenDT, gender) {
        try {
            vm.tmemId = tmId;
            vm.tmName = tmfn;
            vm.tgender = gender;
            vm.tmpp = tmpp;
            vm.convrnId = convrnId;
            vm.isBD = isBD;
            vm.msgInitiator = msgInitiator;
            vm.msgCnt = msgCnt;
            vm.urExist = urExist;
            vm.urExistProcess = false;
            vm.seenDT = seenDT;
            vm.msgBindType = "1";
            vm.lastseen = false;
            vm.mhPgNo = 1;
            vm.msgRestrictionWrng = false;
            vm.msgRestriction = false;
        } catch (e) {
            console.log("vm.setMsgHistroyData  --  " + e.message);
            alert("vm.setMsgHistroyData  --  " + e.message);
        }
    };

    vm.resetMsgHistroyData = function () {
        vm.tmemId = "";
        vm.tmName = "";
        vm.tgender = null;
        vm.tmpp = "";
        vm.convrnId = "";
        vm.isBD = false;
        vm.msgInitiator = true;
        vm.msgCnt = 0;
        vm.urExist = false;
        vm.urExistProcess = false;
        vm.seenDT = "";
        vm.msgBindType = "1";
        vm.lastseen = false;
        vm.mhPgNo = 1;
        vm.lastSeen = false;
        vm.msgRestriction = false;
        vm.msgRestrictionWrng = false;
    };

    vm.openMemberChat = function (tmId, tmfn, tmpp, convrnId, isBD, msgInitiator, msgCnt, urExist, seenDT, gender) {
        try {
            //if (vm.msgTxt == "") {
            vm.showMsgSendDiv = false;
            vm.msgTxt = "";
            vm.lastSeen = false;
            vm.isBlockedUser = '1';
            //mobile code
            if (vm.mobile()) {
                vm.rmcPnl = false;
                vm.mhPnl = true;
                $("#pcFtr").hide();
                $("#hlpmsgwnd").hide();
            }

            if (vm.tmemId != tmId || vm.mobile()) {
                vm.msghistory = [];
                vm.mhPanelType = "1";
                vm.mhScrollStop = false;
                vm.nmFlag = false;
                $("#dvscl").hide();
                vm.setMsgHistroyData(tmId, tmfn, tmpp, convrnId, isBD, msgInitiator, msgCnt, urExist, seenDT, gender);
                vm.getMM();
            }
            else if (vm.mhPanelType == "3") {
                vm.mhPanelType = "1";
                vm.NMDiscard();
                vm.getMemberBlockId()
            }
            else if (vm.tmemId == tmId)
                vm.showMsgSendDiv = true;
            if (vm.sId() == 2 && vm.mobile() == false)
                $timeout(function () { $("#txtSndMsg").focus(); }, 100);
            //}
            //else {
            //    vm.selMbr = { "tmId": tmId, "tmfn": tmfn, "tmpp": tmpp, "convrnId": convrnId, "isBD": isBD,"msgInitiator":msgInitiator,"msgCnt":msgCnt, "urExist": urExist, "seenDT": seenDT, "gender": gender };
            //    $("#dvNA").modal("show");
            //}
        } catch (e) {
            console.log("vm.openMemberChat  --  " + e.message);
            alert("vm.openMemberChat  --  " + e.message);
        }
    };

    vm.closeNA = function () {
        $("#dvNA").modal("hide");
        vm.msgTxt = "";
        $("#txtSndMsg").val("");
        if (vm.toState == null) {
            if (vm.selMbr != null)
                vm.openMemberChat(vm.selMbr.tmId, vm.selMbr.tmfn, vm.selMbr.tmpp, vm.selMbr.convrnId, vm.selMbr.isBD, vm.selMbr.msgInitiator, vm.selMbr.msgCnt, vm.selMbr.urExist, vm.selMbr.seenDT, vm.selMbr.gender);
            else
                vm.backClk();
        }
        else {
            $state.go(vm.toState);
            vm.toState = null;
        }
    };

    $("#nmcHistory").scroll(function () {
        try {
            var dvScroll = $("#nmcHistory");
            if (dvScroll.length > 0 && !vm.mhBusy && vm.mhPanelType == "1") {
                //check scroll on top then load previous messages
                var pos = dvScroll.scrollTop();
                if (pos == 0) {
                    vm.msgBindType = "2";
                    vm.getMM();
                }
                else {
                    //check member read status when scroll reaches the bottom of the screen 
                    var scrollTop = dvScroll.scrollTop() + dvScroll.innerHeight() + 50;
                    if (scrollTop >= dvScroll[0].scrollHeight)
                        vm.checkMRS(vm.mId(), vm.tmemId);
                }
            }
        } catch (e) {
            console.log("nmcHistory Scroll --  " + e.message);
            alert("nmcHistory Scroll   --  " + e.message);
        }
    });

    vm.getMM = function () {
        try {
            if (vm.mhScrollStop) return;
            vm.mhBusy = true;
            $("#msghisloader").show();
            vm.prvHeight = $("#nmcHistory").prop("scrollHeight");
            msgSrvc.getMemberMessages(vm.convrId, vm.mId(), vm.tmemId, vm.mhPgNo, vm.pgSize, function (response, status) {
                vm.mhBusy = false;
                if (status == 200) {
                    if (vm.mhPgNo == 1) vm.getMemberBlockId();
                    if (response && response.length > 0) {
                        for (var i = 0; i < response.length; i++)
                            vm.msghistory.unshift(response[i]);
                        vm.mhPgNo++;
                        if (response.length < vm.pgSize)
                            vm.mhScrollStop = true;
                    }
                    else {
                        $("#msghisloader").hide();
                        vm.mhScrollStop = true;
                        if (vm.mhPgNo == 1 && vm.msghistory.length == 0)
                            vm.getMCH(vm.msghistory);
                    }
                }
                else
                    $("#msghisloader").hide();
            });
        } catch (e) {
            console.log("vm.getMM --  " + e.message);
            alert("vm.getMM  --  " + e.message);
        }
    };

    vm.getMemberBlockId = function () {
        cmnSrvc.getMemberBlockId(vm.tmemId, function (response, status) {
            if (status == 200 && response) {
                $('body').data("user-blckdid" + vm.tmemId, '1');
                vm.isBlockedUser = '1';
                if (response == '1')
                    vm.checkMsgMaxCount();
                else if (response == '2') {
                    if (vm.rmcontacts.length > 0) vm.removeRMCById(vm.tmemId, vm.tmName, true, vm.tgender, true) // member to be disabled in leftside userList
                    vm.bindBlockStatusMCWindow(vm.tmemId, vm.tmName, true, vm.tgender, true);
                }
                else if (response == '3') {
                    if (vm.rmcontacts.length > 0) vm.removeRMCById(vm.tmemId, vm.tmName, true, vm.tgender, false) // member to be disabled in leftside userList
                    vm.bindBlockStatusMCWindow(vm.tmemId, vm.tmName, true, vm.tgender, false);
                }
                else if (response == '4') {
                    if (vm.rmcontacts.length > 0) vm.removeRMCById(vm.tmemId, vm.tmName, true, vm.tgender, true) // member to be disabled in leftside userList
                    vm.bindBlockStatusMCWindow(vm.tmemId, vm.tmName, true, vm.tgender, true);
                }
            };
        });
    };

    vm.getMCH = function (msgs) {
        try {
            msgSrvc.getMemberConvrnHead(vm.mId(), vm.tmemId, function (response, status) {
                if (status == 200) {
                    if (response) {
                        vm.convrnId = response.convrnId;
                        vm.isBD = response.isBD;
                        vm.urExist = response.urExist;
                        vm.seenDT = response.seenDT;
                        vm.msgCnt = response.msgCnt;
                        vm.msgInitiator = response.msgInitiator;
                        vm.msgRestrictionWrng = false;
                    } else
                        vm.msgRestrictionWrng = true;
                    vm.checkReadAndiBD(msgs);
                    vm.checkMsgMaxCount();
                }

            });
        } catch (e) {
            console.log("vm.getMCH  --  " + e.message);
            alert("vm.getMCH  --  " + e.message);
        }
    };

    vm.checkReadAndiBD = function (msgs) {
        try {
            //append last seen when last msg ins login member msg
            var showSeen = false;
            if (msgs && msgs.length > 0)
                showSeen = msgs[0].fmId == vm.mId() ? true : false;
            if (showSeen && vm.seenDT) {
                var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), vm.seenDT);
                if (dtObj.date)
                    vm.lastSeenTxt = "Seen " + dtObj.date + " at " + dtObj.time;
                else
                    vm.lastSeenTxt = "Seen at " + dtObj.time;
                vm.lastSeen = true;
                vm.typingStatus = false;
                if (vm.mobile())
                    if (vm.mhPanelType == "1")
                        $(window).scrollTop($("#nmcHistory").prop("scrollHeight"));
                    else
                        $("#nmcHistory").animate({ scrollTop: $("#nmcHistory").prop("scrollHeight") }, 1000);
            }
            else
                vm.lastSeen = false;

            //if unread exist true update to read
            if (vm.urExist)
                vm.checkMRS(vm.mId(), vm.tmemId);
            //if conversion are not bidirectional check and update 
            if (!vm.isBD)
                vm.findMBD(vm.mId(), vm.tmemId, msgs);
        } catch (e) {
            console.log("vm.checkReadAndiBD  --  " + e.message);
            alert("vm.checkReadAndiBD  --  " + e.message);
        }
    };

    vm.checkMRS = function (fmId, tmId) {
        try {
            if (vm.urExist && vm.urExistProcess == false) {
                var lstChild = $("#nmcHistory #rctMsglist li:last-child");
                if (lstChild.length > 0 && lstChild.visible("partial")) {
                    vm.updateMRS(fmId, tmId);
                }
            }
        } catch (e) {
            console.log("vm.checkMRS --  " + e.message);
            alert("vm.checkMRS --  " + e.message);
        }
    };

    vm.updateMRS = function (fmId, tmId) {
        try {
            vm.urExistProcess = true;
            msgSrvc.updateMsgReadStatus(fmId, tmId, function (response, status) {
                if (status = 200 && response) {
                    vm.urExist = false;
                    vm.urExistProcess = false;
                    for (var i = 0; i < vm.rmcontacts.length; i++) {
                        if (tmId == vm.rmcontacts[i].tmId) {
                            vm.rmcontacts[i].urExist = false;
                            break;
                        }
                    }
                    //check and decrese the count for unread msgs
                    vm.decrMsgCount(tmId);
                    $rootScope.$broadcast("msgSeenCntChg", [tmId], false);
                    $rootScope.$broadcast("chgMRS", [tmId], false);
                }
                else {
                    console.log("unable to update read status  --  " + response);
                    alert("unable to update read status  --  " + response);
                }
            });
        } catch (e) {
            console.log("vm.updateMRS --  " + e.message);
            alert("vm.updateMRS --  " + e.message);
        }
    };

    vm.findMBD = function (fmId, tmId, msgs) {
        try {
            if (vm.isBD == false && msgs && msgs.length > 0) {
                var fmCnt = 0, tmCnt = 0;
                for (var i = 0; i < msgs.length; i++) {
                    if (msgs[i].fmId == fmId)
                        fmCnt++;
                    else
                        tmCnt++;
                }
                //check who to replay for set isBD               
                if (fmCnt > 0 && tmCnt > 0) {
                    vm.updateMCHdBD(fmId, tmId);
                    vm.isBD = true;
                    vm.checkMsgMaxCount();
                }
            }
        } catch (e) {
            console.log("vm.findMBD --  " + e.message);
            alert("vm.findMBD --  " + e.message);
        }
    };

    vm.updateMCHdBD = function (fmId, tmId) {
        try {
            msgSrvc.updateMsgConvHdBiDirectional(fmId, tmId, function (response, status) {
                if (status == 200 && response == "true") {
                    vm.isBD = true;
                    vm.checkMsgMaxCount();
                    for (var i = 0; i < vm.rmcontacts.length; i++) {
                        if (tmId == vm.rmcontacts[i].tmId) {
                            vm.rmcontacts[i].isBD = true;
                            break;
                        }
                    }
                }
            });
        } catch (e) {
            console.log("vm.updateMCHdBD --  " + e.message);
            alert("vm.updateMCHdBD --  " + e.message);
        }
    };

    vm.txtSendMsgBlur = function () {
        vm.msgTxtPH = "Type a message...";
    };

    vm.sendbtnClk = function () {
        if (vm.sId() == 2) {
            vm.sendMsg();
            $("#txtSndMsg").focus();
        }
        else
            $scope.openPS("smPP");
    };

    vm.backClk = function () {
        try {
            if ($("#txtSndMsg").length == 0 || $("#txtSndMsg").val() == "") {
                vm.rmcPnl = true;
                vm.mhPnl = false;
                $("#pcFtr").show();
                $("#hlpmsgwnd").show();
                $(window).scrollTop(0);
            }
            else {
                vm.selMbr = null;
                $("#dvNA").modal("show");
            }
        } catch (e) {
            console.log("vm.backClk  --  " + e.message);
            alert("vm.backClk  --  " + e.message);
        }
    };
    /**********************************************************
                    chat histrory panel function end
    **********************************************************/

    /**********************************************************
                    Chat Service functions start
    **********************************************************/
    vm.sendMsg = function () {
        try {
            if (vm.sId() == 2) {
                if (vm.msgTxt != "") {
                    if ($rootScope.online) {
                        msgSrvc.sendMsg(vm.tmemId, vm.fn(), vm.pp(), vm.convrnId, vm.msgTxt);
                        angular.element(document.getElementById('txtSndMsg')).val("");
                        vm.addMsgMaxCount();
                        vm.addRMContacts(vm.tmemId);
                        vm.checkMCHdBD(vm.tmemId);
                    }
                    else {
                        vm.offlinemsglst.push({ tmId: vm.tmemId, fmId: vm.mId(), convrnId: vm.convrnId, dtCreated: new Date(), fn: vm.fn(), msg: vm.msgTxt });
                        angular.element(document.getElementById('txtSndMsg')).attr('disabled', true);
                        $("#dvtxt").css("background", "#ebebe4");
                    }
                    vm.msgBindType = "3";
                    vm.bindMsg(vm.mId(), vm.tmemId, vm.tmpp, vm.fn(), vm.msgTxt, true);
                    $rootScope.$broadcast("bindCWMsg", vm.tmemId, vm.fn(), vm.msgTxt, vm.pp(), vm.convrnId, new Date(), true);
                    vm.msgTxt = "";
                }
            }
            else {
                angular.element(document.getElementById('txtSndMsg')).val("");
                $scope.PSSClk("smPP");
            }
        } catch (e) {
            console.log("vm.sendMsgs --  " + e.message);
            alert("vm.sendMsgs  --  " + e.message);
        }
    };

    vm.sendOfflineMsgs = function () {
        try {
            while (vm.offlinemsglst.length > 0) {
                if ($rootScope.online && vm.offlinemsglst.length > 0 && msgSrvc.conId) {
                    msgSrvc.sendMsg(vm.offlinemsglst[0].tmId, vm.offlinemsglst[0].fn, "", "", vm.offlinemsglst[0].msg); //,true
                    vm.addMsgMaxCount();
                    vm.checkMCHdBD(vm.offlinemsglst[0].tmId);
                    vm.offlinemsglst.splice(0, 1);
                }
            }
            if (vm.offlinemsglst.length == 0) {
                angular.element(document.getElementById('txtSndMsg')).attr('disabled', false);
                angular.element(document.getElementById('txtSndMsg')).val("");
                if (vm.sId() == 2) {
                    angular.element(document.getElementById('txtSndMsg')).focus();
                }
                $("#dvtxt").css("background", "");
            }
        } catch (e) {
            console.log("vm.sendOfflineMsgs --  " + e.message);
            alert("vm.sendOfflineMsgs --  " + e.message);
        }
    };

    vm.sendTypeReq = function () {
        try {
            if (vm.msgTxt && $("#txtSndMsg").attr("data-typing") == "true") {
                msgSrvc.sendTypeRequest(vm.tmemId);
                $("#txtSndMsg").attr("data-typing", "false");
                $timeout(function () { $("#txtSndMsg").attr("data-typing", "true"); }, 5000);
            }
            vm.msgTxtPH = "Type a message...";
            if (vm.msgTxt.length > 1000) {
                vm.msgTxt = "";
                vm.msgTxtPH = "Must be < 1000 characters";
            }
        } catch (e) {
            console.log("vm.sendTypeReq --  " + e.message);
            alert("vm.sendTypeReq --  " + e.message);
        }
    };

    vm.checkMCHdBD = function (tmId) {
        //checking bidirection and updating
        try {
            if (vm.isBD == false) {
                if (vm.msgInitiator)
                    vm.checkMsgMaxCount();
                else {
                    msgSrvc.updateMsgConvHdBiDirectional(vm.mId(), tmId, function (response, status) {
                        if (status == 200) {
                            if (response) {
                                vm.isBD = true;
                                vm.checkMsgMaxCount();
                            }
                        }
                        else {
                            console.log("unable to update bidirectional  --  " + response);
                            alert("unable to update bidirectional  --  " + response);
                        }
                    });
                }
            }
        } catch (e) {
            console.log("vm.checkMCHdBD  --  " + e.message);
            alert("vm.checkMCHdBD  --  " + e.message);
        }
    };

    vm.getMemberMsgCounts = function () {
        if (getSessionSrvc.p_mId()) {
            msgSrvc.getMessagesCount(getSessionSrvc.p_mId(), function (response, status) {
                if (status == 200) {
                    vm.mmCnt = response.tmIds;
                }
            });
        }
    };
    /**********************************************************
                    Chat Service functions end
    **********************************************************/

    /**********************************************************
                new message functions start
    **********************************************************/
    vm.newMsgBtnClk = function () {
        try {
            vm.msgRestriction = false;
            if (vm.sId() == 1) {
                if (cmnSrvc.isTrialOrPrmExpired()) $scope.openPS("nmPP");
                else $scope.openPS("smPP");
                //$scope.openPS("nmPP");
                // $scope.openPS("smPP");
            }
            else {
                //mobile code
                if (vm.mobile()) {
                    vm.rmcPnl = false;
                    vm.mhPnl = true;
                    $("#pcFtr").hide();
                    $("#hlpmsgwnd").hide();
                }
                else
                    $timeout(function () { $("#txtMsgCnSrch").focus(); }, 0);
                vm.nmFlag = true;
                vm.mhPanelType = "3";
                vm.MsgCnSrchText = "";
            }
        } catch (e) {
            console.log("vm.newMsgBtnClk --  " + e.message);
            alert("vm.newMsgBtnClk  --  " + e.message);
        }
    };

    vm.NMDiscard = function () {
        try {
            vm.nmFlag = false;
            $("#dvscl").hide();
            if (vm.mobile()) {
                vm.rmcPnl = true;
                vm.mhPnl = false;
                $("#pcFtr").show();
                $("#hlpmsgwnd").show();
            }
            else {
                if (!vm.tmemId) {
                    $("#msghisloader").hide();
                    vm.mhPanelType = "2";
                }
                else
                    vm.mhPanelType = "1";
            }
        } catch (e) {
            console.log("vm.NMDiscard  --  " + e.message);
            alert("vm.NMDiscard  --  " + e.message);
        }
    };

    //search network members to display
    vm.txtNCWSrchChg = function () {
        try {
            if (vm.MsgCnSrchText.length > 30) {
                vm.MsgCnSrchText = "";
                vm.MsgCnSrchTextPH = "Must be < 30 characters";
            }
            else
                vm.MsgCnSrchTextPH = "Name";
            if (vm.MsgCnSrchText) {
                if (vm.MsgCnSrchText.length < 3) {
                    vm.ncwRslts = [];
                    vm.NWSrchNR();
                }
                else if (vm.MsgCnSrchText.length == 3 && !vm.checkNWSrchListExtst()) {
                    var key = vm.MsgCnSrchText;
                    msgSrvc.getMNWSrch(vm.mId(), key, function (response, status) {
                        if (status == 200) {
                            if (response.length > 0)
                                vm.mnwSrchList.push({ key: key, val: response })
                            vm.bindSrchMember();
                        }
                        else
                            console.log("error while search in member network\n\n" + response);
                    });
                }
                else if (vm.MsgCnSrchText.length >= 3)
                    vm.bindSrchMember();

            }
            else
                vm.NWSrchNR();
        } catch (e) {
            console.log("vm.txtNCWSrchChg --  " + e.message);
            alert("vm.txtNCWSrchChg  --  " + e.message);
        }
    }

    //srch text blur
    vm.txtNCWSrchBlr = function () {
        vm.MsgCnSrchTextPH = "Name";
    };

    //preparing network member search result to show
    vm.bindSrchMember = function () {
        try {
            if (vm.MsgCnSrchText) {
                var response = [];
                vm.ncwRslts = [];
                for (var i = 0; i < vm.mnwSrchList.length; i++) {
                    if (vm.MsgCnSrchText.toLowerCase().indexOf(vm.mnwSrchList[i].key.toLowerCase()) == 0) {
                        response = vm.mnwSrchList[i].val;
                        break;
                    }
                }
                for (var i = 0; i < response.length; i++) {
                    if (response[i].fn.toLowerCase().indexOf(vm.MsgCnSrchText.toLowerCase()) == 0)
                        vm.ncwRslts.push(response[i]);
                }
                vm.NWSrchNR();
            }
        } catch (e) {
            console.log("vm.bindSrchMember --  " + e.message);
            alert("vm.bindSrchMember  --  " + e.message);
        }
    }

    vm.checkNWSrchListExtst = function () {
        try {
            if (vm.MsgCnSrchText) {
                for (var i = 0; i < vm.mnwSrchList.length; i++) {
                    var key = vm.MsgCnSrchText.toLowerCase();
                    if (vm.mnwSrchList[i].key.toLowerCase().indexOf(key) == 0)
                        return true;
                }
            }
            return false;
        } catch (e) {
            console.log("vm.checkNWSrchListExtst --  " + e.message);
            alert("vm.checkNWSrchListExtst  --  " + e.message);
        }
    }

    vm.NWSrchNR = function () {
        try {
            var dvmwsrch = $("#dvscl");
            var noRslt = $("ul.mcdrdwnlst li.msnrslt");
            if (vm.MsgCnSrchText && vm.MsgCnSrchText.length > 2) {
                if (vm.ncwRslts.length == 0) {
                    dvmwsrch.show()
                    noRslt.show();
                }
                else {
                    dvmwsrch.show()
                    noRslt.hide();
                }
            }
            else {
                dvmwsrch.hide();
                noRslt.hide();
            }
        } catch (e) {
            console.log("vm.NWSrchNR  --  " + e.message);
            alert("vm.NWSrchNR  --  " + e.message);
        }
    };
    /**********************************************************
                new message functions end
    **********************************************************/

    /**********************************************************
                    get premium pop up start
    **********************************************************/
    vm.checkSubscription = function () {
        try {
            if (vm.sId() == 1) {
                $("#txtSndMsg").blur();
                $scope.openPS("smPP");
            }
        } catch (e) {
            console.log("vm.checkSubscription  --  " + e.message);
            alert("vm.checkSubscription  --  " + e.message);
        }
    };
    /**********************************************************
                    get premium pop up end
    **********************************************************/

    /**********************************************************
                    Message Helper functions start
    **********************************************************/
    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if (fromState.url == "/msgcenter.html" && $("#txtSndMsg").length > 0 && $("#txtSndMsg").val() != "") {
            hideLoader();
            vm.toState = toState;
            $("#dvNA").modal('show');
            $rootScope.$broadcast("chkMsgCWHide", fromState.url);
            event.preventDefault();
        }
    });

    vm.openMatchProfile = function () {
        if (vm.tmemId) {
            if ($(window).width() <= 767)
                $rootScope.$broadcast("matchbrdcast", vm.tmemId);
            else
                $window.open("/match/" + getSessionSrvc.pce(vm.tmemId), "_blank");
        }
    };

    vm.addRMContacts = function (tmId) {
        try {
            var recNE = true;
            for (var i = 0; i < vm.rmcontacts.length; i++) {
                if (vm.rmcontacts[i].tmId == tmId) {
                    recNE = false;
                    break;
                }
            }
            // if record not exist in left panel we have to get and add the contacts
            if (recNE) {
                msgSrvc.getMemberConvrnHead(vm.mId(), tmId, function (response, status) {
                    if (status == 200 && response) {
                        vm.rmcontacts.unshift(response);
                        if (vm.rmempList.length > 0)
                            vm.rmempList.splice(0, 1);
                    }
                });
            }
        } catch (e) {
            console.log("vm.addRMContacts  --  " + e.message);
            alert("vm.addRMContacts  --  " + e.message);
        }
    };

    vm.getPP = function (imgUrl, gender) {
        if (imgUrl) return vm.imgCDN + imgUrl.replace("/p/tnb/", "/p/tns/");
        else if (gender == true) return vm.ppm;
        else return vm.ppf;
    };

    vm.getblckPP = function (mId) {
        if (vm.mId() == mId)
            return vm.imgCDN + vm.pp().replace("/p/tnb/", "/p/tns/");
        else
            return vm.tgender ? "https://pccdn.pyar.com/pcimgs/mblck.png" : "https://pccdn.pyar.com/pcimgs/fmblck.png";
    };

    vm.getPPT = function (mId) {
        if (vm.mId() == mId)
            return vm.imgCDN + vm.pp().replace("/p/tnb/", "/p/tns/");
        else
            return vm.getPP(vm.tmpp, vm.tgender);
    };

    vm.bindMsg = function (fmId, tmId, tmpp, convrnId, msgTxt, sender) {
        try {
            var mId = sender ? tmId : fmId;
            var today = moment.utc(new Date()).format();
            //to update message in contacts list
            for (i = 0; i < vm.rmcontacts.length; i++) {
                if (vm.rmcontacts[i].tmId == mId) {
                    vm.rmcontacts[i].msg = msgTxt;
                    vm.rmcontacts[i].msgDT = today;
                    if (!sender)
                        vm.rmcontacts[i].urExist = true;
                    break;
                }
            }

            if (mId == vm.tmemId) {
                vm.lastSeen = false;
                vm.typingStatus = false;
                if (!sender) {
                    vm.urExist = true;
                    vm.urExistProcess = false;
                }
                vm.prvHeight = $("#nmcHistory").prop("scrollHeight");
                vm.msghistory.push({ fmId: fmId, tmId: tmId, convrnId: convrnId, dtCreated: today, msg: msgTxt });
            }
        } catch (e) {
            console.log("vm.bindMsg --  " + e.message);
            alert("vm.bindMsg  --  " + e.message);
        }
    };

    vm.getDateOrTime = function (dt) {
        try {
            var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), dt);
            if (dtObj.date)
                return dtObj.date;
            else if (dtObj.time)
                return dtObj.time;
            else
                return "";
        } catch (e) {
            console.log("vm.getDateOrTime  --  " + e.message);
            alert("vm.getDateOrTime  --  " + e.message);
        }
    };

    vm.getDate = function (zone, utcDT) {
        try {
            if (zone && utcDT) {
                if (zone.length > 0)
                    return moment.tz(moment.utc(utcDT), zone).format('MMMM D, YYYY');
                else
                    return moment.utc(utcDT).format("MMMM D, YYYY");
            }
            else
                return moment.tz(moment.utc(new Date()), zone).format('MMMM D, YYYY');
        } catch (e) {
            console.log("vm.getDate  --  " + e.message);
            alert("vm.getDate  --  " + e.message);
        }
    };

    vm.isSameDate = function (fromDt, toDt) {
        try {
            if (fromDt && toDt) {
                fromDt = new Date(fromDt);
                toDt = new Date(toDt);
                return fromDt.getMonth() == toDt.getMonth() && fromDt.getDate() == toDt.getDate() && fromDt.getFullYear() == toDt.getFullYear();
            }
            else
                return null;
        } catch (e) {
            console.log("vm.isSameDate --  " + e.message);
            alert("vm.isSameDate --  " + e.message);
        }
    };

    $(window).resize(function () {
        try {
            //this code prevent the continues calling for on resize functions
            //after 1 second it will execute the resize code
            // before 1 second again resize are call it cancel the previous calling code
            if (vm.mngPnl)
                $timeout.cancel(vm.mngPnl);
            vm.mngPnl = $timeout(function () { vm.mngPnl = null; vm.mngPnls(); }, 1000);
        } catch (e) {
            console.log("window resize  --  " + e.message);
            alert("window resize  --  " + e.message);
        }
    });

    vm.mngPnls = function () {
        try {
            if (vm.mobile()) {
                if (vm.tmemId && vm.mhPnl == true) {
                    vm.rmcPnl = false;
                    $("#pcFtr").hide();
                }
                else {
                    vm.rmcPnl = true;
                    vm.mhPnl = false;
                    $("#pcFtr").show();
                }
            }
            else {
                vm.rmcPnl = true;
                vm.mhPnl = true;
                $("#pcFtr").show();
                //if screen size moved from mobile to desktop and member not click on any of recent members
                //then we have to load first user histroy
                if (!vm.tmemId)
                    vm.loadRecentMemberHistory(vm.rmcontacts);
            }
        } catch (e) {
            console.log("vm.mngPnls  --  " + e.message);
            alert("vm.mngPnls  --  " + e.message);
        }
    };

    vm.incrMsgCount = function (mId) {
        var notExist = true;
        if (vm.mmCnt && vm.mmCnt.length > 0) {
            for (var i = 0; i < vm.mmCnt.length; i++) {
                if (vm.mmCnt[i] == mId) {
                    notExist = false;
                    break;
                }
            }
        }
        if (notExist)
            vm.mmCnt.push(mId);
    };

    vm.decrMsgCount = function (mId) {
        if (vm.mmCnt && vm.mmCnt.length > 0) {
            for (var i = 0; i < vm.mmCnt.length; i++) {
                if (vm.mmCnt[i] == mId) {
                    vm.mmCnt.splice(i, 1);
                    break;
                }
            }
        }
    };
    /**********************************************************
                    Message Helper functions end
    **********************************************************/

    /**********************************************************
                    Page Load actions start
    **********************************************************/
    angular.element(document).ready(function () {
        try {
            //hide history panel on page load event
            if (vm.mobile()) {
                vm.rmcPnl = true;
                vm.mhPnl = false;
            }
        } catch (e) {
            console.log("document ready event  --  " + e.message);
            alert("document ready event  --  " + e.message);
        }
    });

    //on page load call recent menber contacts
    vm.intialLoadMemberRecentNWContacts = function () {
        try {
            if (msgSrvc.apiHost) {
                vm.getRMC();
                vm.getMemberMsgCounts();
            }
        } catch (e) {
            console.log("vm.intialLoadMemberRecentNWContacts --  " + e.message);
            alert("vm.intialLoadMemberRecentNWContacts  --  " + e.message);
        }
    };

    vm.intialLoadMemberRecentNWContacts(); //Intial load Network Contacts
    /**********************************************************
                    Page Load actions start
    **********************************************************/

    /**********************************************************
                Member Send Message Max Functionality Start
     **********************************************************/
    vm.checkMsgMaxCount = function () {
        if (vm.msgMaxCnt() > 0 && vm.isBD == false && vm.msgInitiator == true && parseInt(vm.msgCnt) >= vm.msgMaxCnt()) {
            vm.msgRestriction = true;
            var gndr = vm.tgender ? "him" : "her"
            vm.errormsgTxt = "You have already sent <b>" + vm.tmName + "</b> " + vm.txtMsgCnt() + " messages.To send more messages,please wait for " + gndr + " to respond."
        }
        else if (vm.isBlockedUser == '1') {
            vm.msgRestriction = false;
            vm.errormsgTxt = "";
        }
        //sahu need to check
        vm.showMsgSendDiv = true;
    };

    vm.addMsgMaxCount = function () {
        if (vm.isBD == false && vm.msgInitiator == true)
            vm.msgCnt = parseInt(vm.msgCnt) + 1;
    };

    /**********************************************************
             Member Send Message Max Functionality End
    **********************************************************/


}]);