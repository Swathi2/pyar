﻿app.service('msgcenterSrvc', ['$http', function ($http) {
}]);
