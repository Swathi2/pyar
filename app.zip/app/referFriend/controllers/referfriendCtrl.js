﻿angular.module("app").controller("referfriendCtrl", ["$scope", "$timeout", "$parse", "getSessionSrvc", "referFriendSrvc", function ($scope, $timeout,$parse, getSessionSrvc, referFriendSrvc) {
    var vm = this;
    vm.email1 = vm.email2 = vm.email3 = vm.email4 = vm.email5 = "";
    vm.isEmailRyt1 = vm.isEmailRyt2 = vm.isEmailRyt3 = vm.isEmailRyt4 = vm.isEmailRyt5 = false;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.enteredMails = new Array();
    vm.btnSndInvtsCls = "ntfybtn";
    var ResponseJson = {
        null: 'invalid memberid',
        "0": 'invalid email',
        "1": 'email opted out',
        "2": 'email already registered',
        "3": 'email already invited',
        "4": 'success'
    }

    vm.savingReferrals = function () {
         showLoader();
        var emailsJson = { 'val': StringallMails() }
        referFriendSrvc.saveReferralEmails(vm.mId(), emailsJson, function (response, status) {
            if (status == 200) {
                if (response == true) {
                    vm.email1 = vm.email2 = vm.email3 = vm.email4 = vm.email5 = "";
                    vm.success = true;
                    $timeout(function () {
                        vm.success = false;
                    }, 5000);
                }
                else if (response == false) alert("Failure");
                vm.sndIvtsBtnDsbl();
                vm.enteredMails = [];
            }
             hideLoader();
        })
    }

    function StringallMails() {
        var mailsStringArry = [];
        var mails = [vm.email1, vm.email2, vm.email3, vm.email4, vm.email5];
        var i = 0
        while (i < mails.length) {
            if (mails[i]) {
                mailsStringArry.push(mails[i]);
            }
            i++;
        }
        return mailsStringArry.toString().replace(/,/g, ";");
    }

    vm.sndIvtsBtnDsbl = function () {
        if (vm.isEmailRyt1 == false && vm.isEmailRyt2 == false && vm.isEmailRyt3 == false && vm.isEmailRyt4 == false && vm.isEmailRyt5 == false) {
            vm.isValidEmail = true
            if (vm.email1 == "" && vm.email2 == "" && vm.email3 == "" && vm.email4 == "" && vm.email5 == "") {
                vm.isValidEmail = false;
            }
        }
        else {
            vm.isValidEmail = false;
        }
    }
    
    vm.sndIvtsBtnDsbl();

    vm.errorShows = function (textNum, resText) {
        $parse("emailError" + textNum).assign(vm, resText);
        $parse("isEmailRyt" + textNum).assign(vm, true);
        $parse("kpImg" + textNum).assign(vm, 'https://pccdn.pyar.com/pcimgs/cs/imgs/invald-mrk.png');
        vm.sndIvtsBtnDsbl();
    }

    vm.validateEmailOnBlurEvnt = function (textNum, enteredEmail, firstEmail, secondEmail, thirdEmail, fourhEmail) {
        if (enteredEmail && vm.enteredMails[textNum - 1] !== enteredEmail) { // allow only when particular textbox mail is not same as previously entered mail          
            if (enteredEmail == firstEmail ||enteredEmail == secondEmail ||enteredEmail == thirdEmail || enteredEmail == fourhEmail ) {
                vm.errorShows(textNum, 'Email already Entered')
            }
            else {
                if (needEmailCheck(enteredEmail)) {
                    $parse("emailError" + textNum).assign(vm, '');
                    $parse("isEmailRyt" + textNum).assign(vm, false);
                    vm.isValidEmail = false;
                    var emailJson = { 'val': enteredEmail }
                 
                    referFriendSrvc.memberRefEmailChecked(vm.mId(), emailJson, function (response, status) {
                        if (status == 200) {
                            if (ResponseJson[response] != 'success') {
                                vm.errorShows(textNum, ResponseJson[response]);
                            } else $parse("isEmailRyt" + textNum).assign(vm, false);
                        }
                        vm.sndIvtsBtnDsbl();
                    })  
                    vm.enteredMails[textNum - 1] = enteredEmail;
                }
                else 
                    vm.errorShows(textNum, 'Please enter a valid email address');               
            }
        } else 
            $parse("isEmailRyt" + textNum).assign(vm, false);
            vm.sndIvtsBtnDsbl();     
    }
    
    vm.keyupCheckallBoxes = function (textboxNum) {
        var email = $scope.$eval("referfriendCtrlAs.email" + textboxNum);
        $parse("isEmailRyt" + textboxNum).assign(vm, false);
        $parse("kpImg" + textboxNum).assign(vm, 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif');
        if (email) {
            if (needEmailCheck(email)) {
                $parse("kpImg" + textboxNum).assign(vm, 'https://pccdn.pyar.com/pcimgs/cs/imgs/chck-mrk.png');
            }
            else { $parse("kpImg" + textboxNum).assign(vm, 'https://pccdn.pyar.com/pcimgs/cs/imgs/lading.gif'); }
        }
    }
 
    function needEmailCheck(email) {
        var emailReg = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/
        return emailReg.test(email);
    }
}]);