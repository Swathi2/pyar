﻿angular.module("app").service('referFriendSrvc', ['$http', function ($http) { 

    //Service for memberRefEmailChecked
    this.memberRefEmailChecked = function (memberId, emailJson, funCallBack) {
        var data = emailJson;
        if (!memberId) memberId = "0";
        var url = getApiDomainUrl() + "/api/dashboard/frdrefc/" + memberId
        PostServiceByURL($http, url, data, funCallBack);
    }

    //Service for saveReferralEmails
    this.saveReferralEmails = function (memberId, emailsJson, funCallBack) {
        var data = emailsJson;
        if (!memberId) memberId = "0";
        var url = getApiDomainUrl() + "/api/dashboard/frdrefm/" + memberId
        PostServiceByURL($http, url, data, funCallBack);
    }

    //this.saveReferralEmails = function (mId, emailJson, callBackFun) {
    //    $http({
    //        method: "POST",
    //        url: getApiDomainUrl() + "/api/tu/saveref/" + mId,
    //        data: emailJson,
    //        headers: {
    //            'Content-Type': 'application/json; charset=utf-8',
    //            'dataType': 'json'
    //        }
    //    }).success(function (response, status) {
    //        callBackFun(response, status);
    //    }).error(function (error, status) {
    //        alert("Something Going Wrong from webmethod.!");
    //    });
    //}

    //this.memberRefEmailChecked = function (emailJson, callBackFun) {
    //    $http({
    //        method: "POST",
    //        url: getApiDomainUrl() + "/api/tu/refemlchk",
    //        data: emailJson,
    //        headers: {
    //            'Content-Type': 'application/json; charset=utf-8',
    //            'dataType': 'json'
    //        }
    //    }).success(function (response, status) {
    //        callBackFun(response, status);
    //    }).error(function (error, status) {
    //        alert("Something Going Wrong from webmethod.!");
    //    });
    //}


    this.isAlreadyRefered = function (encMrId, funCallBack) {
        var url = getApiDomainUrl() + "/api/tu/memrefchk/" + encMrId;
        GetServiceByURL($http, url, funCallBack);
    }
}]);