﻿angular.module("app").controller('notificationsCtrl', ['notificationsSrvc', 'getSessionSrvc', 'othersprofileSrvc', 'msgSrvc', '$scope', '$rootScope', '$window', '$filter', '$location', '$state', '$cookieStore', function (notificationsSrvc, getSessionSrvc, othersprofileSrvc, msgSrvc, $scope, $rootScope, $window, $filter, $location, $state, $cookieStore) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.sId = function () { return getSessionSrvc.p_sub(); };
    vm.fn = function () { return getSessionSrvc.p_fn(); };
    vm.tz = function () { return getSessionSrvc.p_tz(); };
    vm.notifyTypes = { flirt: 51, profileFillReminder: 52, profilePhoto: 53, galleryPhoto: 54, profileView: 61, profileViewMulti: 62, profileViewBasic: 63 };
    vm.busy = false;
    vm.pgSize = 20;
    vm.pgNo = 1;
    vm.pvFromDt = "";
    vm.pvToDt = "";
    vm.notifications = [];
    vm.notifyempty = null;
    vm.zone = function () { return getTimeZoneById(vm.tz()); };
    vm.imageCDN = "https://pccdn.pyar.com";
    vm.stopScroll = false;
    vm.hideNtfn = null;

    vm.getNotifications = function () {
        if (vm.stopScroll) return;
        vm.busy = true;
        showLoader();
        notificationsSrvc.getNotifications(vm.mId(), vm.sId(), vm.pgNo, vm.pgSize, vm.pvFromDt, vm.pvToDt, function (response, status) {
            if (status == 200) {
                //check respone length less than pgSize then stop calling on scroll
                if (response.notifications.length < vm.pgSize)
                    vm.stopScroll = true;

                if (vm.pgNo == 1) {
                    //check unread alerts exist reset to 0
                    resetNMCount(vm.mId(), msgSrvc, $rootScope);

                    //if notificatins are empty show empty state
                    if (response.notifications.length == 0 && response.profileViews.length == 0)
                        vm.notifyempty = true;
                    else
                        vm.notifyempty = false;
                }
                vm.pgNo++;
                //push to existing notifications
                var data = prepareNotifications(response.notifications, response.profileViews, vm.sId(), $filter, $rootScope,vm.fn());
                vm.pvToDt = data.pvToDt;
                angular.forEach(data.ntfns, function (ntfn) {
                    vm.notifications.push(ntfn);
                });             
               
            }
            vm.busy = false;
            hideLoader();
        });
    };

    //Page load start
    if ($rootScope.nmTypes && $rootScope.nmTypes.length > 0)
        vm.getNotifications();
    else {
        getNMTypes(notificationsSrvc, function (response, status) {
            if (status == 200) {
                $rootScope.nmTypes = response;
                vm.getNotifications();
            }
        });
    }
    //page load end

    vm.navigate = function (notifyType, tmId) {
        ntfnNavigate(notifyType, tmId, vm.sId(), $location, $state, $cookieStore, $rootScope, $window);
    };

    vm.chkNonSysNtfn = function (notifyType) {
        if (notifyType == vm.notifyTypes.flirt || notifyType == vm.notifyTypes.profilePhoto || notifyType == vm.notifyTypes.galleryPhoto || notifyType == vm.notifyTypes.profileFillReminder ||
            notifyType == vm.notifyTypes.profileView || notifyType == vm.notifyTypes.profileViewMulti || notifyType == vm.notifyTypes.profileViewBasic)
            return true;
        else
            return false;
    };

    vm.hideMemChk = function (event, memberId,index) {
        vm.hideUnHideTxt = "";
        vm.hideType = null;
        $("#tileImg" + index).show();
        notificationsSrvc.memberHideCheck(vm.mId(), memberId, function (response, status) {
            if (status == 200) {
                if (response == true) {
                    vm.hideUnHideTxt = "Unhide";
                    vm.hideType = 1;
                }
                else {
                    vm.hideUnHideTxt = "Hide"
                    vm.hideType = 2;
                }
                $("#tileImg" + index).hide();
            }
        });
    };

    vm.hideMemClk = function (ntfn) {
        vm.hideNtfn = ntfn;
        if (vm.hideType == 2) {
            //vm.hideImage = vm.getPP(ntfn.pp, ntfn.gender);
            vm.hideImage = ntfn.pp;
            vm.hideGender = ntfn.gender ? "he" : "she";
            vm.hideName = ntfn.fn;
            $("#hidPopup").modal();
        }
        else if (vm.hideType == 1)
            vm.unhideMember();
    };

    vm.hideMember = function () {
        if (vm.hideNtfn) {
            showLoader();
            notificationsSrvc.addHide(vm.mId(), vm.hideNtfn.mId, function (response, status) {
                hideLoader();
                if (status == 200 && response == true)
                    $("#hideCfrm").modal();
            });
        }
    };

    vm.unhideMember = function () {
        if (vm.hideNtfn) {
            vm.hideUnHideTxt = "";
            $("#tileImg").show();
            notificationsSrvc.removeHide(vm.mId(), vm.hideNtfn.mId, function (response, status) {
                if (status == 200 && response == true) {
                    vm.hideNtfn = null;
                    vm.hideUnHideTxt = "Hide";
                    vm.hideType = 2;
                    $("#tileImg").hide();
                }
            });
        }
    };

    

    vm.getDateOrTime = function (dt) {
        try {
            var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), dt);
            if (dtObj.date)
                return dtObj.date;
            else if (dtObj.time)
                return dtObj.time;
            else
                return "";
        } catch (e) {
            console.log("vm.getDateOrTime notifications  --  " + e.message);
            alert("vm.getDateOrTime notifications  --  " + e.message);
        }
    };

    $scope.$on("addNtfn", function (e, ntfns) {
        //vm.addNotifications(ntfns);
        for (var i = 0; i < ntfns.length; i++)
            vm.notifications.unshift(ntfns[i]);
        //check if previouslly notifications empty 
        if (vm.notifyempty == true && vm.notifications.length > 0)
            vm.notifyempty = false;
    });
}]);