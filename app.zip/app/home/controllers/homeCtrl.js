﻿// used in home.html page
angular.module("app").controller('homeCtrl', function ($timeout) {
    var vm = this;
    //smart banner functionality
    var IS_ANDROID = navigator.userAgent.match(/android/i) != null;
    if (IS_ANDROID && window.screen.width <= 767) {
        var hideSmartBnr = sessionStorage.getItem('smrtbnrHide');
        if (hideSmartBnr != "true") {
            var smtBnr = '<div class="smartbanner smartbanner-android"><div class="smartbanner-container"><a href="javascript:void(0);" class="smartbanner-close"><img style="width:18px;" src="https://pccdn.pyar.com/pcimgs/smrtbnrcls.png"></a><span class="smartbanner-icon" style="background-image:url(https://pccdn.pyar.com/pcimgs/icsmrtbnr.png)"></span><div class="smartbanner-info"><div class="smartbanner-title">GET - Pyar for  Android</div><a href="javascript:void(0);" class="smartbanner-button" id="smartbnrbtn"><span class="smartbanner-button-text">OPEN</span></a></div></div></div>';
            $("#dvSmrtBnr").append(smtBnr);
            $("#dvSmrtBnr").addClass("smrtbnr");

            $("#smartbnrbtn").click(function () {
                if (IS_ANDROID) {
                    window.location.href = "intent://www.pyar.com#Intent;scheme=pyarcomapp;action=android.intent.action.VIEW;package=com.pyarinc.pyar;end";
                }
                return false;
            });
            $(".smartbanner-close").click(function () {
                sessionStorage.setItem('smrtbnrHide', true);
                $("#dvSmrtBnr").remove();
            });
        }
    }

  
    //image slider timing 8 sec
    $('#carousel-example-generic').carousel({ interval: 8000 });
        $('#carousel-example-generic').bind('slide.bs.carousel', function (e) { //for every slide changing event
        scrollHdr("slider1");
            //if ($(window).scrollTop() > 50) {
            //    $('.rgsnvbr').addClass('scrlactv');
            //    $('.rgsnvbr').removeClass('scrlstrpclr');
            //    $("#img1").hide();
            //    $("#img2").show();
            //}
            //else {
            //    if (window.location.pathname == "/" || window.location.pathname == "/default.aspx") {
            //        if ($("#slider1").hasClass("active")) {
            //            $('.rgsnvbr').removeClass('scrlactv');
            //            $('.rgsnvbr').removeClass('scrlstrpclr');
            //            $("#img1").show();
            //            $("#img2").hide();
            //        } else {
            //            $('.rgsnvbr').addClass('scrlactv')
            //            $('.rgsnvbr').addClass("scrlstrpclr");
            //            $("#img1").hide();
            //            $("#img2").show();
            //        }
            //    }
            //    else {
            //        $('.rgsnvbr').removeClass('scrlactv');
            //        $('.rgsnvbr').removeClass('scrlstrpclr');
            //        $("#img1").show();
            //        $("#img2").hide();
            //    }
            //}
        });
     
    headerStripScroll();

});