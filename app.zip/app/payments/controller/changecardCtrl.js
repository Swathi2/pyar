﻿angular.module("app").controller('changecardCtrl', ["$scope", "$window", "$state", '$timeout', "$location", "paymntValidtnSrvc", "getSessionSrvc", 'cmnSrvc', 'paymentrSrvc', function ($scope, $window, $state,$timeout, $location, paymntValidtnSrvc, getSessionSrvc, cmnSrvc, paymentrSrvc) {
    var vm = this;
    vm.cntryName = function () { return getSessionSrvc.p_cntry(); };
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.countriesList = [];
    var spanCountryError = "spanCountryError"; 
    vm.changeCardVisible = false;
    vm.cardChangedSuccess = false;

    function cardDetails() {
        showLoader();
        cmnSrvc.getCardDetails(vm.mId(), function (response, status) {
            if (status == 200 && response) {
                setCardDetails(response);
            } else {
                vm.goToAccount();
                return;
            }
            hideLoader();
            vm.changeCardVisible = true;
            $timeout(function () { paymntValidtnSrvc.cardNumbervalidator(vm); }, 0)
        })
    };
    cardDetails();

    function setCardDetails(response) {
        if (response.CardType.toUpperCase() == "VISA") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/visaCard.png"; }
        else if (response.CardType.toUpperCase() == "AMERICAN EXPRESS") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/amexCard.png"; }
        else if (response.CardType.toUpperCase() == "MASTERCARD") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/masterCard.png"; }
        else if (response.CardType.toUpperCase() == "DISCOVER") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/DiscoverCard.png"; }
        else if (response.CardType.toUpperCase() == "JCB") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/JcbCard.png"; }
        else if (response.CardType.toUpperCase() == "DINERS CLUB") { vm.cardImg = "https://pccdn.pyar.com/pcimgs/payments/DinersClub.png"; }
        else { vm.cardImg = response.CardImageUrl; }
        vm.cardNo = response.MaskedNumber;
        vm.cardTyp = response.CardType;
    }
    function toSetCntryVal() {
        var cntryObj = paymntValidtnSrvc.getCountryCode(vm.countriesList,vm.cntryName());
        if (cntryObj) {
            $("#pymtCntry").html(cntryObj.countryName);
            vm.countryName = cntryObj.countryName;
            vm.countryCode = cntryObj.countryShortName;
        }
    }
    function getCountriesList() {
        paymntValidtnSrvc.countriesList(function (response, status) {
            if (status == 200 && response) {
                vm.countriesList = response
                toSetCntryVal();
            };
        });
    }
    getCountriesList();
     
    //Gettting contry from country dropdwon
    vm.countryChg = function (countryName, countryCode) {
        vm.countryName = countryName;
        vm.countryCode = countryCode;
    };
    vm.countriesList = paymntValidtnSrvc.countriesList();

    //vm.crdHldrNameChangeEvnt = function () { paymntValidtnSrvc.crdHldrNameChangeEvnt(); } 
    vm.crdHldrNameFocusEvnt = function () { paymntValidtnSrvc.crdHldrNameFocusEvnt(); }
    vm.crdHldrNameBlurEvnt = function () { paymntValidtnSrvc.crdHldrNameBlurEvnt(vm); }
    vm.cardNumberFocus = function () { paymntValidtnSrvc.cardNumberFocus(); }
    vm.expDateChangeEvnt = function () { paymntValidtnSrvc.expDateChangeEvnt(); }
    vm.expDateFocusEvnt = function () { paymntValidtnSrvc.expDateFocusEvnt(); }
    vm.expDateBlurEvnt = function () { paymntValidtnSrvc.expDateBlurEvnt(vm); }
    vm.cvvChangeEvnt = function (cvvValue) { paymntValidtnSrvc.cvvChangeEvnt(vm, cvvValue); }
    vm.cvvFocusEvnt = function () { paymntValidtnSrvc.cvvFocusEvnt(); }
    vm.cvvBlurEvnt = function () { paymntValidtnSrvc.cvvBlurEvnt(vm); }
    vm.expDatekeyUpEvnt = function (event) { paymntValidtnSrvc.expDatekeyUpEvnt(event, vm); }
    //vm.ppClick = function () { paymntValidtnSrvc.ppClick(vm); };
    //vm.tcClick = function () { paymntValidtnSrvc.tcClick(vm); };

    vm.changeCard = function () {
        $("#" + spanCountryError).html("");
        if (paymntValidtnSrvc.validatingBillingInfo(vm)) {
            if (vm.streetAddress && vm.state && vm.postalCode && vm.countryCode) {
                if (vm.agree) {
                    showLoader();
                    var obj = new changeCardObj();
                    paymentrSrvc.changeCard(obj, function (response, status) {
                        vm.cardChangedSuccess = true;
                        setCardDetails(response);
                        hideLoader();
                        $('html, body').scrollTop(0);
                        paymntValidtnSrvc.resetCardFields(vm, $scope);
                    })
                   
                } else {
                    $("#" + spanCountryError).html("* Please indicate that you agree to the Terms of Use & Privacy Policy");
                }
            } else {
                $("#" + spanCountryError).html("* Please fill Billing Address");
            }
        }
    }

    function changeCardObj() {
        this.memberId = vm.mId();
        this.ccName = vm.ccName;
        this.ccNumber = vm.cardNumber;
        this.ccExpDate = vm.expDate;
        this.ccCVV = vm.cvv;
        this.address1 = vm.streetAddress;
        this.address2 = vm.extendedAddress;
        this.city = vm.city;
        this.state = vm.state;
        this.zipCode = vm.postalCode;
        this.countryCodeAlpha2 = vm.countryCode;
        return this;
    }

    vm.goToAccount = function () {
        $state.go("account", { 'tb': 'mship' });
    }

}]);