﻿angular.module("app").controller('paymentCtrl', ['$scope', '$window', '$location', '$rootScope', 'paymentrSrvc', '$timeout', '$interval', 'getSessionSrvc', 'paymntValidtnSrvc', 'cmnSrvc', '$state', '$filter', function ($scope, $window, $location, $rootScope, paymentrSrvc, $timeout, $interval, getSessionSrvc, paymntValidtnSrvc, cmnSrvc, $state, $filter) {
    var vm = this;

    vm.paymentPageVisible = false;
    vm.tabColor = 1; //tabs colors value carry
    vm.pgShortNameSelected = "";
    vm.subPlanIdSelected = "";

    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.cntryName = function () { return getSessionSrvc.p_cntry(); };
    vm.countryId = function () { return getSessionSrvc.p_cntryId(); };
    vm.fn = function () { return getSessionSrvc.p_fn(); };
    vm.dtNow = new Date();
    vm.tax = 0;
    vm.nonce = "";
    vm.cardType = "";   //VISA or MASTERCARD etc form BT

    vm.divcollapseTwo = "";
    vm.divcollapseThree = "";
    vm.shwMaskCrdNo = false;
    vm.cardValid = false;


    vm.pgSubPlans = [];
    //storing display objects(cntryPgObj) of gateways from api
    vm.cntryPaymentGateways = [];
    vm.countriesList = [];  // For countries dropdown

    var availablePGs = ['BT', 'BTPAYPAL'];
    var cardNumber = "txtcard-number";
    var spancrdErrs = "spancrdErrs";
    var memberPlansInfo = "";

    var cntryPgObj = function (index, img, pgShortName, txt) {
        this.index = index;
        this.img = img;
        this.pgShortName = pgShortName;
    };

    var unselectedImages = {
        'BT': "https://pccdn.pyar.com/pcimgs/payments/CCUnselected.png",
        'BTPAYPAL': "https://pccdn.pyar.com/pcimgs/payments/PPUnselected.png"
    };

    var selectedImages = {
        'BT': "https://pccdn.pyar.com/pcimgs/payments/CCSelected.png",
        'BTPAYPAL': "https://pccdn.pyar.com/pcimgs/payments/PPSelected.png"
    };

    // Calling the PGs response on page init
    function getmembrPlansInfo(callback) {
        showLoader();
        paymentrSrvc.getMemberPalns(vm.mId(), function (response, status) {
            if (response && status == 200) {
                memberPlansInfo = response;
                callback(response);
            }
        });
    };

    getmembrPlansInfo(function (response) {
        var cntryPgsSpltdArray = response.cntryPaymentGateways.split(",");
        if (cntryPgsSpltdArray && cntryPgsSpltdArray.length > 0) {
            cntryPgsSpltdArray.forEach(function (elemnt, indx) {
                var obj = new cntryPgObj(indx, unselectedImages[elemnt], elemnt);
                if (availablePGs.indexOf(obj.pgShortName) != -1) {     // check if the PGs response has available plans(BT,BTPAYPAL)
                    if (obj.pgShortName == 'BT') obj.text = "Credit Card";
                    else if (obj.pgShortName == 'BTPAYPAL') obj.text = "PayPal"
                    vm.cntryPaymentGateways.push(obj);
                }
            })
        };
        if (vm.cntryPaymentGateways.length > 0) {
            vm.paymentPageVisible = true; // Make the Page data visible
            //paymntValidtnSrvc.resetCardFields(vm, $scope, 'init');    //for reset fields in page init
        } else {
            vm.paymentPageVisible = false;
            paymntValidtnSrvc.pymtShowModalPOP("noPlansErr");
        }
        hideLoader();
    })
    // End of the PGs response on page init


    //apply the class to the 3 tabs('Selected Payment method','Billing Info','Address Info')
    function tglsClass(tglClass1, tglClass2, tglClass3) {
        vm.tgl_1 = tglClass1;
        vm.tgl_2 = tglClass2;
        vm.tgl_3 = tglClass3;
    }
    tglsClass("", "opcty", "opcty");  //By Default , 'Selected Payment method' is with enabled(openable) class


    //function for any of the PGs is clicked
    vm.selectedPg = function (pgShortName) {
        if (pgShortName == 'BT' && vm.pgShortNameSelected != pgShortName) {
            vm.pgSubPlans = memberPlansInfo.subPlans.BT;  // 'BT' plans 
            if (!checkSubPlansAvail()) return;
            vm.pgShortNameSelected = pgShortName;
            setSlctdPgImg();
            vm.divcollapseTwo = "#divcollapseTwo";
            tglsClass("", "", "opcty");
            vm.divcollapseThree = "";
            vm.tabColor = 2;
            vm.PlanSelection(vm.pgSubPlans[0]);
            $timeout(function () {
                $("#divcollapseTwo").collapse('show');
                paymntValidtnSrvc.cardNumbervalidator(vm);  // Vaildation of CardNumber for keyup and blur events
            }, 0);
            if (vm.countriesList && vm.countriesList.length == 0) {
                paymntValidtnSrvc.countriesList(function (response, status) {
                    if (status == 200 && response) {
                        vm.countriesList = response
                    };
                });
            };
        } else if (pgShortName == 'BTPAYPAL' && vm.pgShortNameSelected != pgShortName) {
            vm.pgSubPlans = memberPlansInfo.subPlans.BTPAYPAL;  // 'BTPAYPAL' plans 
            if (!checkSubPlansAvail()) return;
            vm.pgShortNameSelected = pgShortName;
            setSlctdPgImg();
            tglsClass("", "opcty", "opcty");
            vm.divcollapseThree = "";
            vm.divcollapseTwo = "";
            $("#divcollapseTwo").collapse('hide');
            $("#divcollapseThree").collapse('hide');
            vm.tabColor = 1;
            vm.PlanSelection(vm.pgSubPlans[0]);
            $timeout(function () {
                ppFnlOder();      //PayPal Button display
                $('body, html').animate({ scrollTop: $('#divpymntsummary').offset().top - (window.innerHeight || document.documentElement.clientHeight) + $('#divpymntsummary').height() + 15 }, 'fast');
            }, 0);
            paymntValidtnSrvc.resetCardFields(vm, $scope);  //Reset all the fields in BillingInfo and Billing Address

        };

    };

    function checkSubPlansAvail() {
        if (vm.pgSubPlans && vm.pgSubPlans.length > 0) return true;
        else {
            paymntValidtnSrvc.pymtShowModalPOP("noPlansErr");
            vm.paymentPageVisible = false;
            return false
        };
    };

    //Set Selected PG image as per the selection
    function setSlctdPgImg() {
        vm.cntryPaymentGateways.forEach(function (elemnt, indx) {
            if (vm.pgShortNameSelected != elemnt.pgShortName) {
                vm.cntryPaymentGateways[indx].img = unselectedImages[elemnt.pgShortName];  // Set unselected Img
            } else {
                vm.cntryPaymentGateways[indx].img = selectedImages[elemnt.pgShortName];   // Set selected Img
            };
        })

    };

    // Subplans selection of PGs 
    vm.PlanSelection = function (plan) {        
        vm.subPlanIdSelected = plan.spId;
        vm.currencySymbol = plan.currencySymbol;
        vm.currencyType = plan.currencyType;
        vm.price = plan.price;
        vm.tax = plan.tax;
        vm.substDt = plan.subscribeStrtDT;
        vm.subexDt = plan.subscribeExprDT;
        vm.subRenewDt = plan.subscribeRenewDT;
        vm.selectedctId = plan.ctId;
    }

    //Billing Info tab clicks
    vm.tbgClick_2 = function () {
        if (vm.pgShortNameSelected == "BT") {
            if (vm.divcollapseTwo)
                vm.tabColor = 2;
        } else {
            vm.divcollapseTwo = "";
            $("#divcollapseTwo").collapse('hide');
        }
    };


    //Address tab clicks
    vm.tbgClick_3 = function (istabclick) {
        if (vm.pgShortNameSelected == "BT") {
            if (vm.divcollapseThree == "#divcollapseThree" && (istabclick ? paymntValidtnSrvc.validatingBillingInfo(vm) : true)) {
                tglsClass("", "", "");
                vm.tabColor = 3;
                $("#divcollapseTwo").collapse('hide');
            } else {
                vm.divcollapseThree = "";
                $("#divcollapseThree").collapse('hide');
            }
        } else {
            vm.divcollapseThree = "";
            $("#divcollapseThree").collapse('hide');
        }
    };


    function errEmpty(txtBox, errlabel) { $("#" + txtBox).css("border-color", "#ccc"); $("#" + errlabel).html(''); }
    function errValidation(txtBox, errlabel, errMsg) { $("#" + txtBox).css("border-color", "#b21724"); $("#" + errlabel).html(errMsg); }


    //Change and blur events for the text boxes('NameOnCard','CardNumber','Cvv','ExpiryDate') in Billing Info
    //vm.crdHldrNameChangeEvnt = function () { paymntValidtnSrvc.crdHldrNameChangeEvnt(); }
    vm.crdHldrNameFocusEvnt = function () { paymntValidtnSrvc.crdHldrNameFocusEvnt(); }
    vm.crdHldrNameBlurEvnt = function () { paymntValidtnSrvc.crdHldrNameBlurEvnt(vm); }
    vm.cardNumberFocus = function () { paymntValidtnSrvc.cardNumberFocus(); }
    vm.expDateChangeEvnt = function () { paymntValidtnSrvc.expDateChangeEvnt(vm); }
    vm.expDateFocusEvnt = function () { paymntValidtnSrvc.expDateFocusEvnt(); }
    vm.expDateBlurEvnt = function () { paymntValidtnSrvc.expDateBlurEvnt(vm); }
    vm.cvvChangeEvnt = function (cvvValue) { paymntValidtnSrvc.cvvChangeEvnt(vm, cvvValue); }
    vm.cvvFocusEvnt = function () { paymntValidtnSrvc.cvvFocusEvnt(); }
    vm.cvvBlurEvnt = function () { paymntValidtnSrvc.cvvBlurEvnt(vm); }
    vm.expDatekeyUpEvnt = function (event) { paymntValidtnSrvc.expDatekeyUpEvnt(event, vm); }
    //End of the Change and blur events 



    //function to Check all the card details are valid or not for Braintree and Paymentwall
    vm.billingInfoNextClick = function () {
        if (vm.pgShortNameSelected == "BT" && vm.subPlanIdSelected) { //BrainTree
            if (paymntValidtnSrvc.validatingBillingInfo(vm)) {
                vm.divcollapseThree = "#divcollapseThree";
                $timeout(function () {
                    BtcountryBind();
                    $("#divcollapseThree").collapse('show');
                    vm.shwMaskCrdNo = true;
                    vm.tbgClick_3(false);
                    collapseThreeOpend();
                }, 0);
            } else {
                vm.divcollapseThree = "";
                $("#divcollapseThree").collapse('hide');
            };

        }
            //else if (vm.pgShortNameSelected == "PW") { //PaymentWall
            //    var crdNum = vm.cardNumber.replace(/ /g, "");
            //    if (crdNum && vm.expDate && vm.cvv) {
            //        pcShowLoader("divcollapseTwo");
            //        paymentrSrvc.pwGetToken(crdNum, vm.expDate, vm.cvv, function (response, status) {
            //            if (status == 200) {
            //                if (response.token) {
            //                    vm.pwToken = response.token;
            //                    vm.divcollapseThree = "#divcollapseThree";
            //                    $("#divcollapseThree").collapse('show');
            //                    vm.shwMaskCrdNo = true;
            //                    vm.tbgClick_3(false);
            //                    $("#" + spancrdErrs).html("");
            //                    hideLoader();
            //                }
            //                else {
            //                    errValidation(cardNumber, spancrdErrs, response.error);
            //                    vm.divcollapseThree = "";
            //                    $("#divcollapseThree").collapse('hide');
            //                    hideLoader();
            //                }
            //            }
            //            hideLoader();
            //        });
            //    }
            //}
        else {
            $("#" + spancrdErrs).html("Something went wrong!");
            clpsTab("divcollapseTwo");
        }
    };
    //End of Checking all the card details are valid or not 

    function collapseThreeOpend() { // scroll to the bottom of the page when Billing Address tab opens 
        $('#accordion #divcollapseThree').one('shown.bs.collapse', function () {
            $('body, html').animate({ scrollTop: $('#divcollapseThree').offset().top - (window.innerHeight || document.documentElement.clientHeight) + $('#divcollapseThree').height() + 15 }, 'fast');
        });
        PanelCollasping();
    }

    //Bind the user country in the dropdown by default when 'Address Info tab opens'
    function BtcountryBind() {
        var cntryObj = paymntValidtnSrvc.getCountryCode(vm.countriesList, vm.cntryName());
        if (cntryObj) {
            $("#pymtCntry").html(cntryObj.countryName);
            vm.countryChg(cntryObj.countryName, cntryObj.countryShortName);
        }
    };

    //Getting selected country from countries dropdwon
    vm.countryChg = function (countryName, countryCode) {
        vm.countryName = countryName;
        vm.countryCode = countryCode;
    };

    //Auto space after four digits
    function autoSpaceCard(cardNum) {
        cardNum = cardNum.replace(/ /g, "");//remove spaces
        cardNum = cardNum.replace(/(.{4})/g, '$1 '); // adding spaces after 4 digits
        cardNum = $.trim(cardNum); //removing first & last space if contains.        
        return cardNum;
    };

    vm.maskCard = function (cardNum) { // for masked card
        if (cardNum) {
            cardNum = cardNum.replace(/ /g, "");//remove spaces            
            var lastDigits = cardNum.slice(-4);
            for (var i = 0; i < cardNum.length ; i++) {
                if (i <= 11)
                    cardNum = cardNum.replace(cardNum[i], "*");
            }
            cardNum = cardNum.slice(0, cardNum.lastIndexOf("*") + 1);
            return autoSpaceCard(cardNum + lastDigits);
        }
    };

    function BilingInfoError(errMsg) { //for error messsge
        $("#spanCountryError").html(errMsg);
        $('body, html').animate({ scrollTop: $('#spanCountryError').offset().top - (window.innerHeight || document.documentElement.clientHeight) + $('#spanCountryError').height() + 15 }, 'fast');
        unfreezePage();
    }

    function freezePage() {  // To freeze untill the payment gives response
        var div = document.createElement("div");
        div.className += "freezepay";
        document.body.appendChild(div);
        showLoader();
    }

    function unfreezePage() {  // Removing screen freeze
        $(".freezepay").remove();
        $("#btnFnlOrdr").attr("disabled", false).css("background-color", "rgba(192, 35, 74, 0.85)");
        hideLoader();
    }

    vm.processBtnDsbl = function () {  // Disabling process btn in Billing Address
        if (paymntValidtnSrvc.disablingBillingInfo(vm) && vm.streetAddress && vm.city && vm.state && vm.postalCode && vm.countryCode)
            return false;
        else
            return true;
    }

    vm.btNextBtnDsbl = function () { // Disabling process btn in Billing Info
        if (paymntValidtnSrvc.disablingBillingInfo(vm)) return false;
        else  return true;
    }

    function PanelCollasping() { // opening one panel makes other panel closing
        $('#accordion #divcollapseThree').on('show.bs.collapse', function () { $("#divcollapseTwo").collapse('hide'); $timeout(function () { vm.shwMaskCrdNo = true }, 0) });
        $('#accordion #divcollapseTwo').on('show.bs.collapse', function () { $("#divcollapseThree").collapse('hide'); $timeout(function () { vm.shwMaskCrdNo = false }, 0) });
        $('#accordion #divcollapseTwo').on('hide.bs.collapse', function () { $timeout(function () { if(vm.divcollapseThree) vm.shwMaskCrdNo = true }, 0) });
    }

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  Braintree and Payment wall checkouts )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    var threeDSecure;

    vm.btFnlOder = function () {
        if (vm.agree) {
            if (vm.pgShortNameSelected == "BT") { //BrainTree        
                if (!$(".freezepay").length) setTimeout(function () { freezePage(); }, 0);
                $("#btnFnlOrdr").attr("disabled", true).css("background-color", "rgba(160, 159, 159, 0.85)");
                if (vm.mId() && vm.fn() && vm.ccName && vm.cardType && vm.cardNumber && vm.cvv && vm.expDate && vm.streetAddress && vm.countryName && vm.countryId() && vm.state && vm.city && vm.postalCode && vm.countryCode && vm.subPlanIdSelected) {
                    $("#spanCountryError").html("");

                    //https://developers.braintreepayments.com/reference/client-reference/javascript/v2/credit-cards  ref

                    var btClient = new braintree.api.Client({ authorization: getBrainTreeAuth() });
                    var cardNo = vm.cardNumber.replace(/ /g, "");
                    btClient.tokenizeCard({
                        number: cardNo,
                        cardholderName: vm.ccName,
                        expirationDate: vm.expDate,
                        cvv: vm.cvv,

                        billingAddress: {
                            FirstName: vm.ccName,
                            StreetAddress: vm.streetAddress,
                            ExtendedAddress: vm.extendedAddress,
                            Locality: vm.city,
                            Region: vm.state,
                            PostalCode: vm.postalCode,
                            CountryCodeAlpha2: vm.countryCode,
                        }
                    }, function (err, nonce) {
                        if (err) {
                            BilingInfoError("Something went wrong! Please try after some time");
                            return;
                        }
                        else if (nonce && vm.selectedctId) {
                            vm.nonce = nonce;
                            paymentrSrvc.GetClientToken(vm.selectedctId, function (response, status) {
                                if (status == 200 && response) {
                                    braintree.client.create({ authorization: response }, //ClientToken
                                    function (clientErr, clientInstance) {
                                        if (clientErr) {
                                            BilingInfoError("Something went wrong! Please try after some time");
                                            return;
                                        }
                                        else if (clientInstance) {
                                            braintree.threeDSecure.create({ client: clientInstance },
                                             function (threeDSecureErr, threeDSecureInstance) {
                                                 if (threeDSecureErr) {
                                                     BilingInfoError("Something went wrong! Please try after some time");
                                                     return;
                                                 }
                                                 else if (threeDSecureInstance) {
                                                     threeDSecure = threeDSecureInstance;
                                                     vm.btOTPCheck();
                                                 }
                                             });
                                        }
                                    });
                                }
                                else {
                                    BilingInfoError("Something went wrong! Please try after some time");
                                }
                            });
                        }
                    });
                }
                else {
                    BilingInfoError("* Please fill valid Billing Info and Billing Address");
                }
            }
            //else if (vm.pgShortNameSelected == "PW") { //PaymentWall
            //    pcShowLoader("divpaypnlthree");
            //    $("#btnFnlOrdr").attr("disabled", true).css("background-color", "rgba(160, 159, 159, 0.85)");
            //    //payment through saved card
            //    if (vm.mpccID && vm.mId() && vm.countryId() && vm.cvv && vm.pwToken && vm.countryCode)
            //        paymentrSrvc.pwSCSubimt(vm.mpccID, vm.mId(), vm.fn(), vm.cvv, vm.pwToken, 2, "", vm.countryId(), vm.countryCode, vm.pwTrnsCmplete);
            //        //new card
            //    else if (vm.mId() && vm.fn() && vm.ccName && vm.cardType && vm.cardNumber && vm.cvv && vm.expDate && vm.streetAddress && vm.countryName && vm.countryId() && vm.state && vm.city && vm.postalCode && vm.pwToken && vm.countryCode)
            //        paymentrSrvc.pwSubmit(vm.mId(), vm.fn(), vm.ccName, vm.cardType, vm.cardNumber, vm.cvv, vm.expDate, vm.streetAddress,
            //            vm.extendedAddress, vm.countryName, vm.countryId(), vm.state, vm.city, vm.postalCode, vm.svCardChk, 2, "", vm.pwToken, vm.countryCode, vm.pwTrnsCmplete);
            //    else {
            //        BilingInfoError("* Please fill Billing Address");
            //    }
            //}
            //else if (vm.pgShortNameSelected == "ADN") {
            //    // AuthorizeDotNet payment.
            //}
        }
        else {
            BilingInfoError("* Please indicate that you agree to the Terms of Use & Privacy Policy");
        }
    };

    //Braintree Security check
    vm.btOTPCheck = function () {
        $("#3DsecureIframe iframe").remove(); //removing iframe from div.

        //https://developers.braintreepayments.com/guides/3d-secure/client-side/javascript/v3

        //setTimeout(function () { freezePage(); }, 0);
        threeDSecure.verifyCard({
            amount: vm.price,
            nonce: vm.nonce,
            addFrame: function (err, iframe) {
                if (!err) {
                    document.getElementById('3DsecureIframe').appendChild(iframe);
                    unfreezePage();
                    $("#otpCheckPopup").modal("show");
                }
                else
                    BilingInfoError("Something went wrong!");
                hideLoader();
            },
            removeFrame: function () {
                showLoader();
                $("#otpCheckPopup").modal("hide");
            }
        }, function (err, response) {
            if (!$(".freezepay").length) setTimeout(function () { freezePage(); }, 0);

            if (response) {
                if (vm.mId() && vm.fn() && vm.ccName && vm.cardType && vm.cardNumber && vm.cvv && vm.expDate && vm.streetAddress && vm.countryName && vm.countryId() && vm.state && vm.city && vm.postalCode && vm.countryCode && vm.subPlanIdSelected, response && response.nonce) {
                    paymentrSrvc.btSubmit(vm.mId(), vm.fn(), vm.ccName, vm.cardType, vm.cardNumber, vm.cvv, vm.expDate, vm.streetAddress, vm.extendedAddress, vm.countryName, vm.countryId(), vm.state, vm.city, vm.postalCode, vm.svCardChk, "", response.nonce, vm.countryCode, vm.subPlanIdSelected, vm.btTrnsCmplete);
                }
                else { BilingInfoError("Please provide all valid details"); }
            }
            else if (err) { BilingInfoError(err.message);}
            else { BilingInfoError("Something went wrong!"); }

        });
    }

    //callback response of Braintree
    vm.btTrnsCmplete = function (response, status) {
        $("#btnFnlOrdr").attr("disabled", false).css("background-color", "rgba(192, 35, 74, 0.85)");
        if (status == 200) {
            if (response && response.error) {
                //PYAR Errors
                if (response.error == 'Active subscription found') {
                    BilingInfoError("You have already Subscription plan");
                }
                else if (response.error == 'error in customer creation') {
                    BilingInfoError("error in customer creation");
                }
                else if (response.error == 'invlid subscription plan') {
                    BilingInfoError("invlid subscription plan.");
                }
                else if (response.error == 'Invalid Input') {
                    BilingInfoError("Please provide all valid details");
                }
                    //Braintree Errors
                else if (response.error.indexOf("payment_method_nonce does not contain a valid payment instrument type.") >= 0 || response.error == '91569') { //91569
                    $("#" + spancrdErrs).html("Please provide all valid details");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Extended address is too long") >= 0 || response.error == '81804') { //81804
                    BilingInfoError("Extended address is too long. Maximum 255 characters.");
                }
                else if (response.error.indexOf("First name is too long") >= 0 || response.error == '81805') { //81805
                    $("#spancvvError").html("First name is too long. Maximum 255 characters.");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Locality is too long") >= 0 || response.error == '81807') { //81807
                    BilingInfoError("Locality is too long. Maximum 255 characters.");
                }
                else if (response.error.indexOf("Postal code can only contain letters, numbers, spaces, and hyphens") >= 0 || response.error == '81813') { //81813
                    BilingInfoError("Invalid Postal Code.");
                }
                else if (response.error.indexOf("Postal code is required") >= 0 || response.error == '81808') { //81808
                    BilingInfoError("Postal code is required.");
                }
                else if (response.error.indexOf("Postal code may contain no more than 9 letter or number characters") >= 0 || response.error == '81809') { //81809
                    BilingInfoError("Postal code is too long. Maximum 9 characters.");
                }
                else if (response.error.indexOf("Region is too long") >= 0 || response.error == '81810') { //81810
                    BilingInfoError("Region is too long. Maximum 255 characters.");
                }
                else if (response.error.indexOf("Street address is required") >= 0 || response.error == '81811') { //81811
                    BilingInfoError("Street address is required.");
                }
                else if (response.error.indexOf("Street address is too long") >= 0 || response.error == '81812') { //81812
                    BilingInfoError("Street address is too long. Maximum 255 characters.");
                }
                else if (response.error.indexOf("Country name is not an accepted country") >= 0 || response.error == '91803') { //91803
                    BilingInfoError("Country name is not an accepted country.");
                }
                else if (response.error.indexOf("Provided country information is inconsistent.") >= 0 || response.error == '91815') { //91815
                    BilingInfoError("Country Name invalid");
                }
                else if (response.error.indexOf("Customer has already reached the maximum of 50 addresses") >= 0 || response.error == '91818') { //91818
                    BilingInfoError("Payment not allowed because you reached maximum of 50 addresses");
                }
                else if (response.error.indexOf("First name must be a string") >= 0 || response.error == '91819') { //91819
                    $("#spancvvError").html("First Name Must be alphabetical.");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Street address must be a string") >= 0 || response.error == '91822') { //91822
                    BilingInfoError("Street address must be alphabetical.");
                }
                else if (response.error.indexOf("Extended address must be a string") >= 0 || response.error == '91823') { //91823
                    BilingInfoError("Extended address must be alphabetical.");
                }
                else if (response.error.indexOf("Locality must be a string") >= 0 || response.error == '91824') { //91824
                    BilingInfoError("Locality must be alphabetical.");
                }
                else if (response.error.indexOf("Region must be a string.") >= 0 || response.error == '91825') { //91825
                    BilingInfoError("Region must be alphabetical.");
                }
                else if (response.error.indexOf("Postal code must be a string.") >= 0 || response.error == '91826') { //91826
                    BilingInfoError("Postal code must be alphabetical.");
                }
                else if (response.error.indexOf("Address is invalid.") >= 0 || response.error == '91828') { //91828
                    BilingInfoError("Invalid address details");
                }
                else if (response.error.indexOf("Customer ID has already been taken") >= 0 || response.error == '91609') { //91609
                    BilingInfoError("Sorry we cannot process payment with this account.");
                }
                else if (response.error.indexOf("US bank account verification method is invalid") >= 0 || response.error == '93121') { //93121
                    BilingInfoError("US bank account verification failed");
                }
                else if (response.error.indexOf("US bank account is not accepted by merchant account" || response.error == '93122') >= 0) { //93122
                    BilingInfoError("US bank account is not accepting you payment.");
                }
                else if (response.error.indexOf("Cardholder name is too long") >= 0 || response.error == '81723') { //81723
                    $("#spancvvError").html("Cardholder name is too long.");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Credit card type is not accepted by this merchant account") >= 0 || response.error == '81703') { //81703
                    $("#spancvvError").html("Credit card type is not accepted.");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Credit card number cannot be updated to an unsupported card type when it is associated to subscriptions") >= 0 || response.error == '81718') { //81718
                    $("#spancvvError").html("card not accepted.");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("CVV is required.") >= 0 || response.error == '81706') { //81706
                    $("#spancvvError").html("CVV is required.");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Expiration year is invalid. It must be between 1975 and 2201.") >= 0 || response.error == '81711') { //81711
                    $("#spancvvError").html("Expiration year is invalid.");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Expiration month is invalid.") >= 0 || response.error == '81712') { //81712
                    $("#spancvvError").html("Expiration month is invalid.");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Expiration year is invalid.") >= 0 || response.error == '81713') { //81713
                    $("#spancvvError").html("Expiration year is invalid.");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Credit card number is not an accepted test number") >= 0 || response.error == '81717') { //81717
                    $("#spancvvError").html("Credit card number is invalid.");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Duplicate card exists in the vault") >= 0 || response.error == '81724') { //81724
                    $("#spancvvError").html("Credit card number alredy taken.");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Credit card type is not accepted by this merchant account") >= 0 || response.error == '81509') { //81509
                    BilingInfoError("Payment not accepted with this card.");
                }
                else if (response.error.indexOf("Cannot use a payment_method_nonce more than once") >= 0 || response.error == '93107') { //93107
                    BilingInfoError("Please try after some time");
                }
                else if (response.error.indexOf("Unknown or expired payment_method_nonce") >= 0 || response.error == '93505') { //93505
                    BilingInfoError("Something went wrong! Please try after some time");
                }
                else if (response.error.indexOf("Payment method nonce locked.") >= 0 || response.error == '91733') { //91733
                    BilingInfoError("Something went wrong! Please try after some time");
                }
                else if (response.error.indexOf("Credit card type is not accepted by this merchant account") >= 0 || response.error == '91734') { //91734
                    BilingInfoError("Payment not allowed with this card.");
                }
                else if (response.error.indexOf("Payment method is not a credit card payment method") >= 0 || response.error == '91738') { //91738
                    BilingInfoError("Something went wrong! Please try after some time");
                }
                else if (response.error.indexOf("Verification Merchant Account is suspended") >= 0 || response.error == '94205') { //94205
                    BilingInfoError("Something went wrong! Please try after some time");
                }
                else if (response.error.indexOf("CVV verification failed") >= 0 || response.error == '81736') { //81736
                    BilingInfoError("CVV verification failed.");
                }
                else if (response.error.indexOf("Postal code verification failed") >= 0 || response.error == '81737') { //81737
                    BilingInfoError("Postal code verification failed");
                }
                else if (response.error.indexOf("Credit card number is prohibited") >= 0 || response.error == '81750') { //81750
                    BilingInfoError("Credit card number is prohibited.");
                }
                else if (response.error.indexOf("Plan ID is invalid") >= 0 || response.error == '91904') { //91904
                    BilingInfoError("Something went wrong! Please try after some time");
                }
                else if (response.error.indexOf("Credit card type is not accepted by this merchant account") >= 0 || response.error == '81509') { //81509
                    BilingInfoError("Payment not accepted with this card.");
                }
                else if (response.error.indexOf("Phone number is invalid") >= 0 || response.error == '92202') { //92202
                    BilingInfoError("Phone number is invalid.");
                }
                else if (response.error.indexOf("Country code (alpha2) is not an accepted country") >= 0 || response.error == '91814') { //91814
                    BilingInfoError("* Please select country");
                }
                else if (response.error.indexOf("CVV must be 4 digits for American Express and 3 digits for other card types") >= 0 || response.error == '81707') { //81707
                    $("#spancvvError").html("Invalid CVV Number");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Expiration date is required") >= 0 || response.error == '81709') { //81709
                    $("#spanExpDateError").html("Please Enter Expiration date");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Expiration date is invalid") >= 0 || response.error == '81710') { //81710
                    $("#spanExpDateError").html("Expiration date is invalid");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Credit card number is required") >= 0 || response.error == '81714') { //81714
                    $("#spancardError").html("Credit card number is required");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Credit card number must be 12-19 digits") >= 0 || response.error == '81716') { //81716
                    $("#spancardError").html("Credit card number must be 12-19 digits");
                    clpsTab("divcollapseTwo");
                }
                else if (response.error.indexOf("Credit card number is invalid") >= 0 || response.error == '81715') { //81715
                    $("#spancardError").html("Credit card number is invalid");
                    clpsTab("divcollapseTwo");
                }
                else {
                    $("#" + spancrdErrs).html("Please provide all valid details");
                    clpsTab("divcollapseTwo");
                }
            }
            else if (response && response.transactionId) {
                //update session values
                vm.updateSession(response.ssnObj);
                if (response && !response.error)
                    $window.location.href = "/pts/bt/" + response.transactionId;
            }
            else {
                $window.location.href = "/ptf/bt/";
                $("#" + spancrdErrs).html("Invalid request, please try again later!!");
            };

        }
        else {
            $window.location.href = "/ptf/bt/";
            //alert("unable to process your request");
        };
        unfreezePage();
        $('body, html').animate({ scrollTop: $('#divcollapseThree').offset().top - (window.innerHeight || document.documentElement.clientHeight) + $('#divcollapseThree').height() + 15 }, 'fast');
    };

    ////callback response of Paymentwall
    //vm.pwTrnsCmplete = function (response, status) {
    //    $("#btnFnlOrdr").attr("disabled", false).css("background-color", "rgba(192, 35, 74, 0.85)");
    //    if (status == 200) {
    //        if (response && response.error) {
    //            if (response.errCode == "3003") {
    //                //3003 Card number is missing or invalid
    //                $("#spancardError").html("Credit card number must be 12-19 digits");
    //                clpsTab("divcollapseTwo");
    //            }
    //            else if (response.errCode == "3004" || response.errCode == "3005" || response.errCode == "3006") {
    //                //3004 Expiration month is invalid
    //                //3005 Expiration year is invalid
    //                //3006 Expiration date is invalid
    //                $("#spanExpDateError").html("Expiration date is invalid");
    //                clpsTab("divcollapseTwo");
    //            }
    //            else if (response.errCode == "3010" || response.errCode == "3011") {
    //                //3010 Please contact your credit card company to approve your payment
    //                //3011 Please contact your credit card company to check your available balance
    //                $("#spanExpDateError").html("Please check your avaliable balance");
    //                clpsTab("divcollapseTwo");
    //            }
    //            else if (response.errCode == "3012" || response.errCode == "3013") {
    //                //3012 Transaction was declined
    //                //3013 Transaction was declined due to issues with the card
    //                BilingInfoError("Transaction was declined due to issues with the card");
    //            }
    //            else if (response.errCode == "3014") {
    //                //3014 Wrong CVV
    //                $("#spancvvError").html("Invalid CVV Number");
    //                clpsTab("divcollapseTwo");
    //            }
    //            else if (response.errCode == "3016") {
    //                //3016 Transaction was declined due to failed 3D Secure check
    //                BilingInfoError("Transaction was declined due to failed 3D Secure check");
    //            }
    //            else if (response.errCode == "3101" || response.errCode == "3102") {
    //                //3101 Please verify the credit card number and retry the transaction
    //                //3102 You submitted an expired credit card number. Please ensure the credit card is valid
    //                $("#spancardError").html("Please verify the credit card number and retry the transaction");
    //                clpsTab("divcollapseTwo");
    //            }
    //            else if (response.errCode == "3103") {
    //                //3103 You have submitted a card which is not supported. Please, use Visa, MasterCard, AmEx or Discover credit card
    //                BilingInfoError("You have submitted a card which is not supported. Please, use Visa, MasterCard, AmEx or Discover credit card");
    //            }
    //            else if (response.errCode == "3104") {
    //                //3104 Country of the card is not supported
    //                BilingInfoError("Country of the card is not supported");
    //            }
    //            else if (response.errCode == "3200") {
    //                //3200 Please retry the transaction or use another credit card
    //                BilingInfoError("Please retry the transaction or use another credit card");
    //            }
    //            else if (response.errCode == "3301") {
    //                //3301 Please check first name
    //                $("#spancardHldrNameError").html("Card name missmatch");
    //                clpsTab("divcollapseTwo");
    //            }
    //            else if (response.errCode == "3009" || response.errCode == "3302" || response.errCode == "3303" || response.errCode == "3304" || response.errCode == "3305" || response.errCode == "3306") {
    //                //3009 Please correct the billing address and retry the transaction
    //                //3302 Please check last name
    //                //3303 Please check address
    //                //3304 Please check city
    //                //3305 Please check state
    //                //3306 Please check Zip / Postal Code
    //                BilingInfoError("Invalid billing address");
    //            }
    //            else
    //                BilingInfoError("Unable to process your request !! Please try again later");
    //        }
    //        else if (response.transactionId) {
    //            //update session values
    //            vm.updateSession(response.ssnObj);
    //            if (response && !response.error)
    //                $window.location.href = "/paymentsuccess/pw/" + response.transactionId;
    //        }
    //        else
    //            $("#" + spancrdErrs).html("Invalid request, please try again later!!");
    //    }
    //    else
    //        alert("unable to process your request");
    //    hideLoader();
    //};


    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  End of Braintree and Payment wall checkouts )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    function clpsTab(tabId) {
        vm.divcollapseTwo = "#" + tabId;
        $(vm.divcollapseTwo).collapse('show');
    };

    //Updating the session after payment success
    vm.updateSession = function (ssnObj) {
        if (Object.keys(ssnObj).length > 0) {
            for (var key in ssnObj) {
                getSessionSrvc.u_ssnd(key, ssnObj[key]);
            }
        }
    };

    ////Privacy Policy popup
    //vm.ppClick = function () {
    //    paymntValidtnSrvc.ppClick(vm);
    //};

    ////Terms n Condition popup
    //vm.tcClick = function () {
    //    paymntValidtnSrvc.tcClick(vm);
    //};

    //Navigate to profile when error occurs
    vm.navigteErr = function () {
        $("#noPlansErr").on("hidden.bs.modal", function () {  // when error modal hides
            $state.go("profile");
        });
    };

    //Exit popup event 
    vm.ExitPopup = function () { $("#paymentNavAway").modal("hide"); $timeout(function () { $state.go("dashboard"); }, 400) };

    //navigate away condtion checking
    vm.logoClick = function () {
        if (vm.divcollapseTwo || vm.tabColor == 1) {
            paymntValidtnSrvc.pymtShowModalPOP("paymentNavAway");
        } else {
            vm.GetNonce = ""; $state.go("dashboard");
        }
    };


    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PayPal checkout )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    //PayPal CheckOut
    function ppFnlOder() {
        braintree.client.create({ authorization: getBrainTreeAuth() }, function (clientErr, clientInstance) {
            if (clientErr) {
                console.log('Error creating client:', clientErr);
                paymntValidtnSrvc.pymtShowModalPOP("ErrAlert");
                return;
            }

            // Create a PayPal Checkout component.
            braintree.paypalCheckout.create({
                client: clientInstance
            }, function (paypalCheckoutErr, paypalCheckoutInstance) {
                // Stop if there was a problem creating PayPal Checkout.
                // This could happen if there was a network error or if it's incorrectly configured.
                if (paypalCheckoutErr) {
                    console.error('Error creating PayPal:', paypalCheckoutErr);
                    return;
                }

                // Set up PayPal with the checkout.js library
                paypal.Button.render({
                    env: 'sandbox', // or Local 'sandbox', Live 'production'
                    commit: true, // This will add the transaction amount to the PayPal button

                    style: {
                        size: 'medium',
                        color: 'silver',
                        shape: 'rect',
                        label: 'pay',
                        branding: true,
                        tagline: true,
                    },

                    payment: function () {
                        return paypalCheckoutInstance.createPayment({
                            flow: 'vault', // Required            // checkout for one time payment , vault for recurring payment
                            //amount: vm.price, // not Required for recurring payments
                            //currency: 'USD', // not Required for recurring payments
                            enableShippingAddress: true,
                            shippingAddressEditable: true,
                        });
                    },

                    onAuthorize: function (data, actions) {
                        return paypalCheckoutInstance.tokenizePayment(data)
                          .then(function (payload) {
                              if (!$(".freezepay").length) setTimeout(function () { freezePage(); }, 0);

                              if (payload != "" && payload.nonce != "" && payload.details != "") {
                                  paymentrSrvc.btppSubmit(vm.mId(),
                                                payload.details.email,
                                                payload.details.firstName,
                                                payload.details.lastName,
                                                payload.details.shippingAddress.recipientName,
                                                payload.details.shippingAddress.line1,
                                                payload.details.shippingAddress.line2,
                                                payload.details.shippingAddress.city,
                                                payload.details.shippingAddress.state,
                                                payload.details.shippingAddress.postalCode,
                                                payload.details.shippingAddress.countryCode,
                                                payload.nonce,
                                                vm.countryId(),
                                                vm.subPlanIdSelected,
                                    function (response, status) {
                                        unfreezePage();
                                        if (status == 200 && response && response.transactionId) {
                                            //update session values
                                            vm.updateSession(response.ssnObj);
                                            if (response && !response.error)
                                                $window.location.href = "/pts/pp/" + response.transactionId;
                                            else
                                                $window.location.href = "/ptf/pp/" + response.transactionId;
                                        }
                                        else {
                                            if (response && response.error) {
                                                $("#ApiErrMsg").html(response.error);
                                                paymntValidtnSrvc.pymtShowModalPOP("ErrAlert");
                                            } else {
                                                $window.location.href = "/ptf/pp/" + response.transactionId;
                                            };
                                        }
                                        hideLoader();
                                    });
                              }
                              else {
                                  hideLoader();
                                  paymntValidtnSrvc.pymtShowModalPOP("ErrAlert");
                              }
                          });
                    },

                    onCancel: function (data) {
                        //console.log('payment cancelled', JSON.stringify(data));
                    },

                    onError: function (err) {
                        // console.log('Error: ', err);
                        //paymntValidtnSrvc.pymtShowModalPOP("ErrAlert");
                    }
                }, '#paypal-button').then(function () {
                    $("#paypalLdr").hide();
                    $("#paypal-button").show();
                });
            });
        });
    };

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( End of PayPal checkout )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    function autofillData() {

        vm.ccName = "Tester";
        vm.cardNumber = "4111 1111 1111 1111";
        vm.expDate = "12/2020";
        vm.cvv = "123";

        vm.streetAddress = "ameerpet";
        vm.extendedAddress = "410";
        vm.city = "Hyderabad";
        vm.state = "Telangana";
        vm.postalCode = "500038";
    }
    //remove this function in Live
    // autofillData();
}]);