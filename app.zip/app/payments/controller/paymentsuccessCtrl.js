﻿
angular.module("app").controller('paymentsuccessCtrl', ['paymentrSrvc', 'getSessionSrvc', '$scope', '$window', '$location', '$state', '$timeout', '$rootScope', function (paymentrSrvc, getSessionSrvc, $scope, $window, $location, $state,$timeout, $rootScope) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.fn = function () { return getSessionSrvc.p_fn(); };
    vm.iscard = vm.ispaypal = false;
    vm.paysuccVsble = false;
    showLoader();
    var urlArr =location.pathname.split("/");
    vm.transId = urlArr[urlArr.length - 1];
    vm.transType = urlArr[urlArr.length - 2];
    vm.paymntstatus = urlArr[1];
    vm.paymentSuccess = false;
    vm.paymentFailure = false;
   

    vm.printPage = function () {
        var contents = $("#paymntPrintpagediv").html();
        var frame1 = $('<iframe />');
        frame1[0].name = "frame1";
        frame1.css({ "position": "absolute", "top": "-1000000px" });
        $("body").append(frame1);
        var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
        frameDoc.document.open();
        frameDoc.document.write('<html><head><title></title></head><body><link href="../../../styles/pc.css" rel="stylesheet" type="text/css" />' + contents + '</body></html>'); //Create a new HTML document.
        frameDoc.document.close();
        setTimeout(function () { window.frames["frame1"].focus(); window.frames["frame1"].print(); frame1.remove();}, 500);   
    }
    
    vm.getTrnsInfoById = function (transId, transType, funCallBack) {
        if (transType == "bt")
            paymentrSrvc.btGetTransById(vm.mId(), transId, funCallBack);
        else if (transType == "pw")
            paymentrSrvc.pwGetTransById(vm.mId(), transId, funCallBack);
        else if(transType == "pp")
            paymentrSrvc.btGetTransById(vm.mId(), transId, funCallBack);
    };

    if (vm.paymntstatus == 'pts' && vm.transId && vm.transType) {
        vm.getTrnsInfoById(vm.transId, vm.transType, function (response, status) {
            if (status == 200){
                if (response && response.cardNo){
                    vm.paymentSuccess = true; vm.iscard = true; vm.ispaypal = false;
                }else if(response){
                    vm.paymentSuccess = true; vm.iscard = false; vm.ispaypal = true;
                }
                else
                    $window.location.href = "/payment.html";
                vm.transDetails = response;
            }
            else
                $window.location.href = "/payment.html";
            hideLoader();
            //vm.paysuccVsble = true;
        });
    } else if (vm.paymntstatus == 'ptf') {
        vm.paymentFailure = true;
        hideLoader();
    }
    else
        $window.location.href = "/payment.html";

    vm.GotoAccnt = function () {
        $state.go("account", { 'tb': 'mship' });
    }

    vm.DtConversnLclTime = function(date) {
        var localDate = new Date(date);
        var localTime = localDate.getTime();
        var localOffset = localDate.getTimezoneOffset() * 60000;
        return new Date(localTime + localOffset);
    }
  
}]);