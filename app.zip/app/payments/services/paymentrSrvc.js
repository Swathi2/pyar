﻿
angular.module("app").service('paymentrSrvc', ['$http', '$window', function ($http, $window) {

    this.getMemberPalns = function (mId, funCallBack) {
        var url = getApiDomainUrl() + "/api/pmthlpr/gpipymt/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    //BrainTree
    this.btSubmit = function (memberId, fn, ccName, ccType, ccNumber, ccCVV, ccExpDate, address1, address2, countryName, countryId, state, city, zipCode, ccSave, couponCode, nonce, countryCodeAlpha2, spId, funCallBack) {
        var data = {
            "memberId": memberId, "firstName": fn, "ccName": ccName, "ccType": ccType, "ccNumber": ccNumber, "ccCVV": ccCVV, "ccExpDate": ccExpDate,
            "address1": address1, "address2": address2, "countryName": countryName, "countryId": countryId, "state": state,
            "city": city, "zipCode": zipCode, "ccSave": ccSave, "couponCode": couponCode,
            "nonce": nonce, "countryCodeAlpha2": countryCodeAlpha2, "spId": spId
        };
        var url = getApiDomainUrl() + "/api/bt/recpay";
        PostServiceByURL($http, url, data, funCallBack)
    };

    this.btGetTransById = function (memberId, id, funCallBack) {
        var url = getApiDomainUrl() + "/api/bt/rectrns/" + memberId + "/" + id;
        GetServiceByURL($http, url, funCallBack);
    };

    //PaymentWall
    //this.pwGetToken = function (ccNumber, ccExpDate, cvv, funCallBack) {
    //    var url = getApiDomainUrl() + "/api/pw/gt";
    //    var data = { "ccNumber": ccNumber, "ccExpDate": ccExpDate, "ccCVV": cvv };
    //    PostServiceByURL($http, url, data, funCallBack);
    //};

    //this.pwSubmit = function (memberId, fn, ccName, ccType, ccNumber, ccCVV, ccExpDate, address1, address2, countryName, countryId, state, city, zipCode, ccSave, couponCode, token, countryCodeAlpha2, funCallBack) {
    //    var data = {
    //        "memberId": memberId, "firstName": fn, "ccName": ccName, "ccType": ccType, "ccNumber": ccNumber, "ccCVV": ccCVV, "ccExpDate": ccExpDate,
    //        "address1": address1, "address2": address2, "countryName": countryName, "countryId": countryId, "state": state,
    //        "city": city, "zipCode": zipCode, "ccSave": ccSave, "couponCode": couponCode,
    //        "nonce": token, "countryCodeAlpha2": countryCodeAlpha2
    //    };
    //    var url = getApiDomainUrl() + "/api/pw/pay";
    //    PostServiceByURL($http, url, data, funCallBack);
    //};

    //this.pwSCSubimt = function (mpccId, memberId, firstName, ccCVV, nonce, couponCode, countryId, countryCodeAlpha2, funCallBack) {
    //    var data = {
    //        "mpccId": mpccId, "memberId": memberId, "firstName": firstName, "ccCVV": ccCVV, "nonce": nonce,
    //        "couponCode": couponCode, "countryId": countryId, "countryCodeAlpha2": countryCodeAlpha2
    //    };
    //    var url = getApiDomainUrl() + "/api/pw/scpay";
    //    PostServiceByURL($http, url, data, funCallBack)
    //};

    //this.pwGetTransById = function (memberId, id, funCallBack) {
    //    var url = getApiDomainUrl() + "/api/pw/trns/" + memberId + "/" + id;
    //    GetServiceByURL($http, url, funCallBack);
    //};


    this.btppSubmit = function (memberId, email, firstName, lastName, recipientName, line1, line2, city, state, postalCode, countryCode, nonce, countryId, spId, funCallBack) {
        var data = {
            "memberId": memberId,
            "email": email,
            "firstName": firstName,
            "lastName": lastName,
            "recipientName": recipientName,
            "line1": line1,
            "line2": line2,
            "city": city,
            "state": state,
            "postalCode": postalCode,
            "countryCode": countryCode,
            "nonce": nonce,
            "countryId": countryId,
            "spId": spId
        };
        var url = getApiDomainUrl() + "/api/bt/recpppay";
        PostServiceByURL($http, url, data, funCallBack)
    };

    this.changeCard = function (data, funCallBack) {
        var url = getApiDomainUrl() + "/api/bt/recchangecard";
        PostServiceByURL($http, url, data, funCallBack)
    };

    this.GetClientToken = function (ctId, funCallBack) {
        var url = getApiDomainUrl() + "/api/bt/clnttkn/" + ctId;
        GetServiceByURL($http, url, funCallBack);
    };

}]);