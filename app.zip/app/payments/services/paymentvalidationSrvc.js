﻿
angular.module("app").service('paymntValidtnSrvc', ['$http', '$timeout', '$rootScope', function ($http, $timeout, $rootScope) {
    var txtCrdHlder = "txtCrdHlder";
    var spancardHldrNameError = "spancardHldrNameError";
    var cardNumber = "txtcard-number";
    var spancardError = "spancardError";
    var expirationDate = "txtexpiration-date";
    var spanExpDateError = "spanExpDateError";
    var txtcvv = "txtcvv";
    var spancvvError = "spancvvError";
    var spancrdErrs = "spancrdErrs";
    var spanCountryError = "spanCountryError";
    var crdmultiImgs = "crdmultiImgs";
     
    //reset all payment fileds
    this.resetCardFields = function (vm, $scope, pginit) {
        vm.mpccID = null;
        vm.ccName = "";
        vm.cardNumber = "";
        vm.expDate = "";
        vm.cvv = "";
        vm.streetAddress = "";
        vm.extendedAddress = "";
        vm.city = "";
        vm.state = "";
        vm.postalCode = "";
        vm.countryCode = "";
        vm.agree = false;
        vm.cardNumberStatus = false
        vm.dateValid = false
        vm.cardValid = false 
        $("#pymtCntry").html("Country");
        $("#pymtCntry").removeClass('pymtddldsbl');
        vm.cardType = "";
        //$("#" + crdmultiImgs).find("img").attr("src", "https://pccdn.pyar.com/pcimgs/payments/CCSelected.png");
        $("#" + crdmultiImgs).css("width", "110px").find("img").css("width", "100px");
        this.emptyErrMsgs(vm, $scope, pginit);
    };

    //removing error all messages
    this.emptyErrMsgs = function (vm, $scope, pginit) {
        errEmpty(txtCrdHlder, spancardHldrNameError);
        errEmpty(cardNumber, spancardError);
        errEmpty(expirationDate, spanExpDateError);
        errEmpty(txtcvv, spancvvError);
        $("#" + spanCountryError).html('');
        $("#" + spancrdErrs).html('');
        vm.svCardChk = false; //uncheck saved card checkbox
        if (pginit != 'init') $scope.$apply();
    }

    function errEmpty(txtBox, errlabel) { $("#" + txtBox).css("border-color", "#ccc");$("#" + errlabel).html(''); }
    function errValidation(txtBox, errlabel, errMsg) { $("#" + txtBox).css("border-color", "#b21724"); $("#" + errlabel).html(errMsg); }

    //this.crdHldrNameChangeEvnt = function () { errEmpty(txtCrdHlder, spancardHldrNameError); };
    this.crdHldrNameFocusEvnt = function () { errEmpty(txtCrdHlder, spancardHldrNameError); };
    this.crdHldrNameBlurEvnt = function (vm) { if (vm.ccName) { errEmpty(txtCrdHlder, spancardHldrNameError); } else { errValidation(txtCrdHlder, spancardHldrNameError, "* Please Enter Name on Card"); } };
    this.cardNumberFocus = function () { errEmpty(cardNumber, spancardError); };
    this.expDateChangeEvnt = function (vm) { validateExpDate(vm, false); };
    this.expDateFocusEvnt = function () { errEmpty(expirationDate, spanExpDateError);}
    this.expDateBlurEvnt = function (vm) { validateExpDate(vm,true); }
    this.cvvChangeEvnt = function (vm, cvvValue) { validateCvvNo(vm, false, cvvValue); };
    this.cvvFocusEvnt = function () { errEmpty(txtcvv, spancvvError); }
    this.cvvBlurEvnt = function (vm) { validateCvvNo(vm, true); }
    this.expDatekeyUpEvnt = function (event,vm) { if (vm.expDate) { if (event.which != 8) { if (vm.expDate.length === 2) { vm.expDate += '/'; } } } };


    this.cardNumbervalidator = function (vm) {
    $('#' + cardNumber).bind('focus', function () { $('#' + spancardError).hide(); });// When the user focuses on the credit card input field, hide the status
    $('#' + cardNumber).bind('blur', function () {
        $('#' + spancardError).show();
        if ($('#' + cardNumber).val() == "") {
            //$("#" + crdmultiImgs).find("img").attr("src", "https://pccdn.pyar.com/pcimgs/payments/CCSelected.png");
        }
    });// When the user tabs or clicks away from the credit card input field, show the status    
    $('#' + cardNumber).cardcheck({
        callback: function (result) {
            var status = (result.validLen && result.validLuhn) ? 'valid' : 'invalid',
            message = '';
            vm.cardNumberStatus = status == 'valid' ? true : false;
            if (result.len < 1) { message = "*Please Enter Credit Card Number"; $(this).css("border-color", "#b21724"); }
            else if (!result.cardClass) { message = "This is not a valid card number"; $(this).css("border-color", "#b21724"); }
            else if (!result.validLen) { message = "This is not a valid card number"; $(this).css("border-color", "#b21724"); }
            else if (!result.validLuhn) { message = "invalid card type"; $(this).css("border-color", "#b21724"); }
            else { message = ""; vm.cardType = result.cardName; $(this).css("border-color", "#ccc"); vm.cardValid = true; }
            $("#" + spancardError).html(message);
        }
    });

       // $("#" + crdmultiImgs).find("img").attr("src", "https://pccdn.pyar.com/pcimgs/payments/CCSelected.png");
        $("#" + crdmultiImgs).css("width", "110px").find("img").css("width", "100px");

        $('#' + cardNumber).cardcheckKeyUp({
            callback: function (result) {
                var status = (result.validLen && result.validLuhn) ? 'valid' : 'invalid',
                message = '';
                $timeout(function () { vm.cardNumberStatus = status == 'valid' ? true : false; }, 0)
                if (result.cardName.toUpperCase() != "DISCOVER") $("#" + crdmultiImgs).css({ "width": "40px", 'top': '0px', 'right': '0px' }).find("img").css("width", "40px");
                else $("#" + crdmultiImgs).css({ "width": "40px", 'top': '1px', 'right': '3px' }).find("img").css("width", "40px"); 
                function crdImgSrc(src) { $("#" + crdmultiImgs).find("img").attr("src", src); }

                if (result.cardName.toUpperCase() == "VISA") { crdImgSrc("https://pccdn.pyar.com/pcimgs/payments/visaCard.png"); }
                else if (result.cardName.toUpperCase() == "AMERICAN EXPRESS") { crdImgSrc("https://pccdn.pyar.com/pcimgs/payments/amexCard.png"); }
                else if (result.cardName.toUpperCase() == "MASTERCARD") { crdImgSrc("https://pccdn.pyar.com/pcimgs/payments/masterCard.png"); }
                else if (result.cardName.toUpperCase() == "DISCOVER") { crdImgSrc("https://pccdn.pyar.com/pcimgs/payments/DiscoverCard.png"); }
                else if (result.cardName.toUpperCase() == "JCB") { crdImgSrc("https://pccdn.pyar.com/pcimgs/payments/JcbCard.png"); }
                else if (result.cardName.toUpperCase() == "DINERS CLUB") { crdImgSrc("https://pccdn.pyar.com/pcimgs/payments/DinersClub.png"); }
                else {
                    if ($(this).val() == "") {
                        crdImgSrc("");
                        //crdImgSrc("https://pccdn.pyar.com/pcimgs/payments/CCSelected.png");
                    }
                    else { crdImgSrc(""); }
                    $("#" + crdmultiImgs).css("width", "110px").find("img").css("width", "100px");
                }
            }
        });
        //help image show
        $("#cvvInfo,#cvvDiv").click(function () { $("#cvvDiv").fadeIn(); });
        $("#cvvInfo,#cvvDiv").hover(function () { $("#cvvDiv").show(); }, function () { $("#cvvDiv").hide(); });
    }
        


    function validateExpDate(vm,msgdisplay) {
        if (vm.expDate && vm.expDate.length == 5) {
            var month = vm.expDate.substr(0, 2);
            var year = vm.expDate.substr(3, 4);

            var date = new Date();
            var crntYr = date.getFullYear().toString().substr(2, 4);

            if (month > 0 && month < 13 && parseInt(crntYr) <= year) {
                var creditCardDate = moment(year + month, "YYMM");// credit card date validation
                var today = moment();
                if ((creditCardDate.isValid() && (today < creditCardDate.add(1, 'months'))) == true) {
                    if (msgdisplay) errEmpty(expirationDate, spanExpDateError);
                    vm.dateValid = true;
                }
                else {if (msgdisplay) errValidation(expirationDate, spanExpDateError, "Invalid Expiry Date");vm.dateValid = false; }
            }
            else { if (msgdisplay) errValidation(expirationDate, spanExpDateError, "Invalid Expiry Date");vm.dateValid = false; }
        }
        else {
            if (vm.expDate) {if (msgdisplay) errValidation(expirationDate, spanExpDateError, "* Please Enter Valid Date");vm.dateValid = false; }
            else {if (msgdisplay) errValidation(expirationDate, spanExpDateError, "* Invalid Expiry Date");vm.dateValid = false; }

        }
    };

    function validateCvvNo(vm,msgdisplay, cvvValue) {
        if (cvvValue != undefined) vm.cvv = cvvValue;
        if (vm.cardType) {
            if (vm.cardType.toUpperCase() == "American Express".toUpperCase()) {
                if (vm.cvv && vm.cvv.length == 4) {if (msgdisplay) errEmpty(txtcvv, spancvvError); vm.cardValid = true; }
                else {if (msgdisplay) errValidation(txtcvv, spancvvError, "Invalid CVV No.");vm.cardValid = false; }
            }
            else {
                if (vm.cvv && vm.cvv.length == 3) {
                    if (vm.cardNumberStatus) {
                        if (msgdisplay) errEmpty(txtcvv, spancvvError);
                        vm.cardValid = true;
                    } else {
                        vm.cardValid = false;
                    }
                }
                else {
                    if (msgdisplay) errValidation(txtcvv, spancvvError, "Invalid CVV No."); vm.cardValid = false;
                }
            }
        }
        else if (!vm.cvv) { if (msgdisplay) errValidation(txtcvv, spancvvError, "* Please Enter CVV No.");vm.cardValid = false; }
        else if (vm.cvv.length < 3) {
            if (msgdisplay) errValidation(txtcvv, spancvvError, "Please Enter Valid CVV No."); vm.cardValid = false;
        }
    };

    this.validatingBillingInfo = function (vm) {
        if (vm.ccName) { errEmpty(txtCrdHlder, spancardHldrNameError); } else { errValidation(txtCrdHlder, spancardHldrNameError, "* Please Enter Name on Card"); }
        if (!vm.cardNumber) { errValidation(cardNumber, spancardError, "* Please Enter Card Number"); }
        if (!vm.expDate) { errValidation(expirationDate, spanExpDateError, "* Please Enter Expiry Date") }
        if (!vm.cvv) { errValidation(txtcvv, spancvvError, "* Please Enter CVV No"); }
        validateExpDate(vm);
        validateCvvNo(vm);
        if (vm.ccName && vm.cardValid && vm.dateValid && vm.cvv) return true;
        else return false;
    }

    this.disablingBillingInfo = function (vm) {
        if (vm.ccName && vm.cardNumberStatus && vm.dateValid && vm.cardValid && vm.cvv) return true;
        else return false;
    }

    ////Privacy policy click event
    //this.ppClick = function (vm) {
    //    cmnSrvc.PPService(function (response, status) {
    //        if (status == 204) {
    //            alert("the content is not there (take the appropriate action)");
    //            return false;
    //        }
    //        else if (status == 200) {
    //            vm.ppVersion = "Version " + eval(JSON.stringify(response.version));
    //            vm.lstUpdated = "Last updated: " + $filter('date')(eval(JSON.stringify(response.dateCreated)), "MMMM d, yyyy");
    //            vm.ppContent = $sce.trustAsHtml(response.policytext);
    //            $("#ppModal").modal("show");
    //        }
    //    });
    //};

    ////Terms condtions click event
    //this.tcClick = function (vm) {
    //    cmnSrvc.TCService(function (response, status) {
    //        if (status == 204) {
    //            alert("the content is not there (take the appropriate action)");
    //            return false;
    //        }
    //        else if (status == 200) {
    //            vm.tcVersion = "Version " + eval(JSON.stringify(response.version));
    //            vm.lstUpdated = "Last updated: " + $filter('date')(eval(JSON.stringify(response.dateCreated)), "MMMM d, yyyy");
    //            vm.tcContent = $sce.trustAsHtml(response.policytext);
    //            $("#tcModal").modal("show");
    //        }
    //    });
    //};


    this.countriesList = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/utils/countries";
        GetServiceByURL($http, url,funCallBack)
    }

    this.pymtShowModalPOP = function (modalElementId) {
        $("#" + modalElementId).modal({show: true, keyboard: false,backdrop: 'static'});
    };
    //Get Country code
    this.getCountryCode = function (countriesArray,countryName) {
        var cntryObj;
        if (countryName) {
            angular.forEach(countriesArray, function (country) {
                if (country.countryName.toLowerCase() == countryName.toLowerCase()) {
                    cntryObj = country;
                    return false;
                }
            });
        }
        return cntryObj;
    };

   

    
}]).directive("customCvv", function (paymntValidtnSrvc) {
    return {
        restrict: "A",
        scope: {
            customCvv: '=',
            cvvchangeFun : '&'
        },
        require: "ngModel",
        link: function (scope, element, attrs, ngModel) {
            ngModel.$parsers.unshift(function (value) {
                if (!scope.customPassword) scope.customPassword = "";
                if (!value || value.length == 0)
                    scope.customPassword = "";
                else if (value.length < scope.customPassword.length)
                    scope.customPassword = scope.customPassword.replace(/\u2022/g, "").substring(0, scope.customPassword.length - 1);
                else
                    scope.customPassword = scope.customPassword.replace(/\u2022/g, "") + value.substring(value.length - 1).replace(/\u2022/g, "");

                var star = (value || "").replace(/[\S]/g, "\u2022");
                document.getElementById("txtcvv").value = star;
                scope.cvvchangeFun({ cvvValue: scope.customPassword });
            });
        }
    };
});
