﻿
angular.module("app").service('signinSrvc', ['$http', function ($http) {

    //Service for Signin Members // Passing chkbx as extra parameter for Remember-Me checkbox 
    this.signInMember_New = function (email, pwd, chkbx, funCallBack) {
        var data = { email: email, pwd: pwd, }
        var url = getApiDomainUrl() + "/api/registersignin/signin_New";
        PostServiceByURL($http, url, data, funCallBack);
    }

    //Service for Password Rotation after 90days
    this.pwdrotation = function (memberId, currentpassword, newpassword, funCallBack) {
        var data = { memberId: memberId, currentpassword: currentpassword, newpassword: newpassword }
        var url = getApiDomainUrl() + "/api/registersignin/cgpd";
        PostServiceByURL($http, url, data, funCallBack);
    }

    //remove member profile hide
    this.removepflhd = function (ids, funCallBack) {
        var data = {}
        var url = getApiDomainUrl() + "/api/registersignin/rmprflhd/" + ids;
        PostServiceByURL($http, url, data, funCallBack);
    }
}]);
