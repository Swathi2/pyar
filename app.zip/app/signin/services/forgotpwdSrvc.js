﻿
angular.module("app").service('forgotpwdSrvc', ['$http', '$window', function ($http, $window) {

    //Service for forgot password
    //Step:1
    this.forgotPwd = function (email, dob, funCallBack) {
        var data = { email: email, dob: dob }
        var url = getApiDomainUrl() + "/api/registersignin/fpemlval";
        PostServiceByURL($http, url, data, funCallBack);
    }

    //Step:1
    this.forgotPwdn = function (email, funCallBack) {
        var data = { val: email}
        var url = getApiDomainUrl() + "/api/registersignin/frgtpd";
        PostServiceByURL($http, url, data, funCallBack);
    }


    //Service for Reset Password
    //Step:2
    this.resetPwd = function (memberId, secanswer, funCallBack) {
        var data = { memberId: memberId, secanswer: secanswer }
        var url = getApiDomainUrl() + "/api/registersignin/fpsecaval";
        PostServiceByURL($http, url, data, funCallBack);
    }
    //Service for Resend forgotpassword Link
    //Step:2.1
    this.rsndfrgtpwdlnk = function (memberId, funCallBack) {
        var url = getApiDomainUrl() + "/api/registersignin/fprsndeml/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    }

    //Service for Change Password
    //Step:3
    this.changePwd = function (memberId, newpassword, funCallBack) {
        var data = { memberId: memberId, newpassword: newpassword }
        var url = getApiDomainUrl() + "/api/registersignin/fprstpwd";
        PostServiceByURL($http, url, data, funCallBack);
    }

}]);
