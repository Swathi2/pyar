﻿
angular.module("app").directive("signInTemplate", function () {
    return {
        restrict: 'EA',
        templateUrl: 'app/signin/templates/signInTemplate.html',
        link: function (scope, elem, attr) {
            scope.loginType = attr["signInTemplate"];
            window.sessionStorage.setItem("DtpsNtP", scope.loginType);
        }
    }
});
angular.module("app").directive("signInSocialTemplate", function () {
    return {
        restrict: 'EA',
        templateUrl: 'app/signin/templates/signInSocialTemplate.html',
        link: function (scope, elem, attr) {

        }
    }
});

