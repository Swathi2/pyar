﻿angular.module("app").controller('signinCtrl', ['$scope', '$window', '$rootScope', '$http', 'signinSrvc', 'socialLgnSrvc', 'getSessionSrvc', 'abndnSrvc', '$location', '$state', '$timeout', '$interval',
    function ($scope, $window, $rootScope, $http, signinSrvc, socialLgnSrvc, getSessionSrvc, abndnSrvc, $location, $state, $timeout, $interval) {
        //for header strip change on scroll
        headerStripScroll();

        var vm = this;

        //Profile Hide pop showing on profilehide.html Page_Load
        $("#profileHidePopup").modal("show");

        vm.EmailPlaceholder = 'Email';
        vm.PwdPlaceholder = 'Password';
        //vm.NPwdPlaceholder = 'New Password';
        //vm.CnfPwdPlaceholder = "Confirm Password";
        //vm.CurrentPwdPlaceholder = "Current Password";

        $(document).ready(function () {
            setTimeout(function () {
                var autofilled = document.querySelectorAll('input:-webkit-autofill');
                if (autofilled.length > 0) $("#signinbtnId").addClass("btn-bg regBtn")
            }, 500);
        })


        //signIn button disabled function
        vm.signInBtnDsbl = function () {
            if (vm.email && vm.password) {
                if ($rootScope.emailRegex.test(vm.email) && vm.password.length > 7) {
                    vm.btnSignInCls = "btn-bg regBtn"; return false;
                }
                else { vm.btnSignInCls = "btn-bg"; return true; }
            }
            else { vm.btnSignInCls = "btn-bg"; return true; }
        }
       

        $interval(function () { vm.signInBtnDsbl(); }, 100);

        //Email blur event
        vm.emailCheck = function () { emlchkBlur($rootScope, vm); }
        //Email change event
        vm.emailChnage = function () { emlchangeEvnt(vm); }
        //Email Focus event
        vm.emailFocus = function () { emlFcs(vm); }
        //new Password chnage event
        vm.passwordChnage = function () {
            if (vm.password && vm.password.length > 30) {
                $("#txtPwd").blur();
            }
        }
        //new Password blur event
        vm.pwdCheck = function () {
            if (vm.password && vm.password.length > 30) {
                vm.password = null;
                vm.pwdKpcls = "eror";
                vm.PwdPlaceholder = "Must be < 30 characters";
            }
            else if (vm.password && vm.password.length < 8 || !vm.password) {
                vm.password = null;
                vm.pwdKpcls = "eror";
                vm.PwdPlaceholder = "Invalid Password";
            }
        }
        //new Password Focus event
        vm.pwdFocus = function () { pwdFcs(vm); }
        //Confirm password change event 
        //vm.confirmPwdChnage = function () {
        //    if (vm.confirmPassword && vm.confirmPassword.length > 30) {
        //        $("#txtCnfPwd").blur();
        //    }
        //}
        //Confirm password blur event 
        //vm.cnfPwdCheck = function () { CnfPwdchkBlur(vm); }
        //Confirm password Focus event 
        //vm.cnfPwdFocus = function () { CnfPwdFcs(vm); }

        //function CrntPwdDtEmty(phTxt) {
        //    vm.CurrentPassword = null;
        //    vm.curpwdKpcls = "eror";
        //    vm.CurrentPwdPlaceholder = phTxt;
        //}

        //current password change event 
        //vm.currentPwdChnage = function () {
        //    vm.curpwdKpcls = "bgWht";
        //    if (vm.CurrentPassword && vm.CurrentPassword.length > 30) { $("#txtCurrPwd").blur(); }
        //}


        //current password blur event 
        //vm.currentPwdBlur = function () {if (vm.CurrentPassword && vm.CurrentPassword.length > 30) { CrntPwdDtEmty('Must be < 30 characters'); }}


        //current password focus event
        //vm.CurrentpwdFocus = function () {
        //    vm.curpwdKpcls = "bgWht";
        //    vm.CurrentPwdPlaceholder = "Current Password";
        //}

        vm.check = false;

        function rememberMe() {
            var win = $window.localStorage.p_558;
            if (win) {
                var chkbox = getSessionSrvc.pcd(win.split("#")[2]);
                if (chkbox == true || chkbox == "true") {
                    vm.email = getSessionSrvc.pcd(win.split("#")[0]);
                    vm.password = getSessionSrvc.pcd(win.split("#")[1]);
                    vm.check = chkbox;
                }
            }
        }
        rememberMe();


        vm.rememberCheck = function () {
            vm.check = !vm.check;
        }
        //vm.errMsg = function (curpwdKpcls, email, emailKpcls, EmailPlaceholder, password, pwdKpcls, PwdPlaceholder) {
        vm.errMsg = function (email, emailKpcls, EmailPlaceholder, password, pwdKpcls, PwdPlaceholder) {
            //vm.curpwdKpcls = curpwdKpcls;
            vm.email = email;
            vm.emailKpcls = emailKpcls;
            vm.EmailPlaceholder = EmailPlaceholder;
            vm.password = password;
            vm.pwdKpcls = pwdKpcls;
            vm.PwdPlaceholder = PwdPlaceholder;
        }

        //function change url
        function navigate(response, url) {
            $window.sessionStorage.setItem("8B3414FB", response.id);
            hideLoader();
            $state.go(url);
        }

        //function for getting response Id's based on index
        function rspStaus(id, response) {
            if (response.refId) {
                return response.refId.indexOf(id) > -1;
            }
        }

        //memebers signin
        vm.SignIn = function () {
            pcShowLoader("signldrdiv");
            if ($scope.frmSignIn.$valid) {
                if (vm.email && vm.password) {
                    signinSrvc.signInMember_New(vm.email, vm.password, vm.check, function (response, status) {
                        if (status == 200) {
                            if (rspStaus(10, response) == true) { $("#ErrAlert").modal("show"); hideLoader(); }
                                // Profile Enabling checking First
                            else if (rspStaus(3, response) == true) { navigate(response, "profilehide"); } //alert("profile enabling");
                            else if (rspStaus(1, response) == true) { navigate(response, "privacy-policy-pop"); } //alert("pp Update");
                            else if (rspStaus(2, response) == true) { navigate(response, "terms-conditionspop"); } //alert("tc update");
                            //else if (rspStaus(5, response) == true) { vm.errMsg(vm.curpwdKpcls, vm.email, "", vm.EmailPlaceholder, null, "", 'Incorrect password - please try again'); hideLoader(); }//alert("password missmatch");
                            else if (rspStaus(5, response) == true) { vm.errMsg(vm.email, "", vm.EmailPlaceholder, null, "", 'Incorrect password - please try again'); hideLoader(); }//alert("password missmatch");
                            //else if (rspStaus(6, response) == true) { vm.errMsg("", null, "eror", 'Please sign in with your social network', null, "bgWht", 'Password'); hideLoader(); }//alert("facebook login only");
                            else if (rspStaus(6, response) == true) { vm.errMsg(null, "eror", 'Please sign in with your social network', null, "bgWht", 'Password'); hideLoader(); }//alert("facebook login only");
                            //else if (rspStaus(7, response) == true) { vm.errMsg("", null, "eror", 'Please sign in with your social network', null, "bgWht", 'Password'); hideLoader(); }//alert("linkdin login only");
                            else if (rspStaus(7, response) == true) { vm.errMsg(null, "eror", 'Please sign in with your social network', null, "bgWht", 'Password'); hideLoader(); }//alert("linkdin login only");
                            else if (rspStaus(8, response) == true) { vm.acntSuspndErrMsg = true; hideLoader(); }//alert("account disabled (suspended/deleted)");
                            //else if (rspStaus(9, response) == true) { vm.errMsg("", null, "eror", 'Unregistered email, try social login', null, "bgWht", 'Password'); hideLoader(); }//alert("invalid email");                        
                            else if (rspStaus(9, response) == true) { vm.errMsg(null, "eror", 'Unregistered email, try social login', null, "bgWht", 'Password'); hideLoader(); }//alert("invalid email");                        
                            else if (getSessionSrvc.validateSessionInfo(response)) {

                                //for remeberme checkbox
                                var win = $window.localStorage;
                                if (vm.check == true || vm.check == "true") { // for remeberme email & password.
                                    win.p_558 = getSessionSrvc.pce(vm.email) + "#" + getSessionSrvc.pce(vm.password) + "#" + getSessionSrvc.pce("true");
                                }
                                else {
                                    $window.localStorage.removeItem("p_558");
                                }
                                var loginType = window.sessionStorage.getItem("DtpsNtP");
                                var fromLink = $window.localStorage.getItem("frmLnk");
                                var p_adul = $window.localStorage.getItem("p_adul");
                                var lgbBackUrl=$window.localStorage.getItem("lgnBackUrl");
                                $window.sessionStorage.removeItem("8B3414FB");
                                getSessionSrvc.setLoginData(response);

                                if (fromLink) { //when the member is coming from link
                                    hideLoader();
                                    $window.location.href = "/match/" + fromLink;
                                }
                                else if (p_adul) {
                                    hideLoader();
                                    $window.location.href = "/accountdel.html?" + p_adul;
                                }
                                else if (loginType == "DT") {
                                    hideLoader();
                                    $window.location.href = "/dating-tip" + $rootScope.pgName + "";
                                }
                                else {
                                    hideLoader();
                                    if (lgbBackUrl) {
                                        {
                                            $window.location.href = lgbBackUrl;
                                            $window.localStorage.removeItem("lgnBackUrl");
                                        }
                                    } else
                                        $state.go('dashboard');
                                }
                            }

                        }
                    });
                }
            }
            else {
                alert("Please fill all fileds!");
                hideLoader();
                return false;
            }
        };

        

        //Enable profile hide
        vm.pflhdCnfrm = function () {
            var ids = $window.sessionStorage.getItem("8B3414FB");
            showLoader();
            if (ids) {
                signinSrvc.removepflhd(ids, function (response, status) {
                    if (status == 200) {
                        if (rspStaus(10, response) == true) { $("#ErrAlert").modal("show"); hideLoader(); }
                        else if (rspStaus(1, response) == true) { navigate(response, "privacy-policy-pop"); }
                        else if (rspStaus(2, response) == true) { navigate(response, "terms-conditionspop"); }
                        else if (rspStaus(3, response) == true) { navigate(response, "profilehide"); }
                        else if (response == false) { alert("Incurrect current password."); hideLoader(); }
                        else if (response.mId != "" && response.mId != null) {
                            $window.sessionStorage.removeItem("DtpsNtP");
                            $window.sessionStorage.removeItem("8B3414FB");
                            getSessionSrvc.setLoginData(response);
                            hideLoader();
                            $window.location.href = "/dashboard.html";
                        }
                    }
                });
            }
            else
                $window.location.href = "/signin.html";
        }

        //redirect to signin page when use click on cancel button in profile hide popup
        vm.pflhdCancel = function () {
            $window.sessionStorage.removeItem("8B3414FB");
            $("#profileHidePopup").modal("hide");
            //Waiting for popup close
            $timeout(function () {
                abndnSrvc.rmvSsn();
            }, 300);
        }

        //forgot Password page Redirecting
        vm.forgotPwdRdrct = function () {
            $window.location.href = '/forgotpwd.html';
        }


    }]);