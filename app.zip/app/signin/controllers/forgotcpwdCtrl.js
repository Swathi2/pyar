﻿angular.module("app").controller('forgotcpwdCtrl', ['getSessionSrvc', 'abndnSrvc', '$scope', '$window', 'forgotpwdSrvc', '$rootScope', '$location', '$state', '$interval', function (getSessionSrvc, abndnSrvc, $scope, $window, forgotpwdSrvc, $rootScope, $location, $state, $interval) {
    //Variable Declration
    var vm = this;
    vm.EmailPlaceholder = 'Email';
    vm.PwdPlaceholder = 'New Password';
    vm.CnfPwdPlaceholder = "Confirm Password";
    var urlMemId = $location.absUrl().split('?')[1];
    var lgnSsn = $window.localStorage.getItem("A5D7FPD45");
    var emailSend = true; //avoid multiple emails sending (continuous button click)
    //Variable Declration End

    if (lgnSsn != null && lgnSsn.length != 0) {
        var getDtls = JSON.parse(getSessionSrvc.pcd(lgnSsn));
        vm.mId = getDtls["mId"];
    }

    //forgot pwd Step-1 button disabled function
    vm.BtnfrgtPwdStep1Dsbl = function () {
        if (vm.email) {
            if ($rootScope.emailRegex.test(vm.email)) {
                vm.BtnfrgtPwdStep1Cls = "regBtn"; return false;
            }
            else { vm.BtnfrgtPwdStep1Cls = ""; return true; }
        }
        else { vm.BtnfrgtPwdStep1Cls = ""; return true; }
    }

    //forgot pwd Step-3 button disabled function
    vm.BtnfrgtPwdStep3Dsbl = function () {
        if (vm.password && vm.confirmPassword) {
            if (vm.password == vm.confirmPassword) {
                vm.BtnfrgtPwdStep3Cls = "regBtn"; return false;
            }
            else { vm.BtnfrgtPwdStep3Cls = ""; return true; }
        }
        else { vm.BtnfrgtPwdStep3Cls = ""; return true; }
    }

    //Email blur event
    vm.emailCheck = function () { emlchkBlur($rootScope, vm); }
    //Email change event
    vm.emailChnage = function () { emlchangeEvnt(vm); }
    //Email Focus Event
    vm.emailFocus = function () { emlFcs(vm); vm.acntSuspndErrMsg = false; }

    //new Password chnage event
    vm.passwordChnage = function () {
        if (vm.password && vm.password.length > 30) { $("#txtPwd").blur(); }
    }
    //new Password blur event
    vm.pwdCheck = function () { pwdchkBlur(vm); }
    //New Password Focus Event
    vm.pwdFocus = function () { vm.pwdGuideLineMsg = true; pwdFcs(vm) }

    //Confirm password change event 
    vm.confirmPwdChnage = function () {
        if (vm.confirmPassword && vm.confirmPassword.length > 30) { $("#txtCPwd").blur(); }
    }
    //Confirm password blur event 
    vm.cnfPwdCheck = function () { CnfPwdchkBlur(vm); }
    //Confirm password Focus event 
    vm.cnfPwdFocus = function () { CnfPwdFcs(vm); }

    vm.frgtPwdStep1 = function () {
        if ($scope.frmFrgtPwd.$valid && emailSend) {
            emailSend = false;
            pcShowLoader("fgPwdstp1");
            forgotpwdSrvc.forgotPwdn(vm.email, function (response, status) {
                emailSend = true;
                if (status == 200) {
                    if (response.status == false) {
                        if (response.errType == "1" || response.errType == "3") emailDtEmty(vm, 'Unregistered Email,Try social login')
                        else if (response.errType == "2") emptyemltxt()
                        else $("#ErrAlert").modal("show")
                    }
                    else {
                        $window.localStorage.setItem("A5D7FPD45", getSessionSrvc.pce(JSON.stringify(response)));
                        $state.go('forgotpwdreseteml');
                    }
                }
                pcHideLoader();
            });
        };
    }

    function emptyemltxt() {
        vm.acntSuspndErrMsg = true;
        vm.email = "";
    }

    vm.frgtPwdStep3 = function () {
        if ($scope.frmFrgtPwd.$valid && emailSend) {
            emailSend = false;
            pcShowLoader("dvFgotPwdStep3");
            if (urlMemId != "" && urlMemId != undefined) {
                forgotpwdSrvc.changePwd(urlMemId, vm.password, function (response, status) {
                    emailSend = true;
                    if (status == 200) {
                        if (response == "1")
                            alert("invalid id");
                        else if (response == "3")
                            abndnSrvc.rmvSsn();
                    }
                    else
                        alert("Password resetting failed...!");
                    hideLoader();                 
                });
            }
        }
    }  

    //Displaying Time to resend the mail and Disabling the resend mail button
    if ($location.path() == "/forgotpwdreseteml.html") {
        startInterval(vm, $interval);
    }

    //Resend forgotpassword email link
    vm.rsndEmlLnk = function () {
        if (vm.mId && emailSend) {
            emailSend = false;
            pcShowLoader("resendingEmail");
            forgotpwdSrvc.rsndfrgtpwdlnk(vm.mId, function (response, status) {
                emailSend = true;
                pcHideLoader();
                if (status == 200 && response == true)
                    startInterval(vm, $interval);
                else
                    alert("Email sending failed...!");
                hideLoader();
            });
        }
    }
}]);