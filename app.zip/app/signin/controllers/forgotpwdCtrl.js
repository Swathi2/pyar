﻿var captchaVerfication = "";
function recaptchaChk() {
    captchaVerfication = "Captcha verified";
}

angular.module("app").controller('forgotpwdCtrl', ['getSessionSrvc', '$scope', '$window', 'forgotpwdSrvc', '$rootScope', '$location', '$state', '$interval', function (getSessionSrvc, $scope, $window, forgotpwdSrvc, $rootScope, $location, $state, $interval) {

    //Variable Declration
    var vm = this;
    vm.answerPlaceholder = 'Answer question';
    vm.EmailPlaceholder = 'Email';
    vm.DOBPlaceHolder = "MM / DD / YYYY";
    vm.PwdPlaceholder = 'New Password';
    vm.CnfPwdPlaceholder = "Confirm Password";
    var urlMemId = $location.absUrl().split('?')[1];
    var lgnSsn = $window.localStorage.getItem("A5D7FPD45");
    //Variable Declration End


    //forgot pwd Step-1 button disabled function
    vm.BtnfrgtPwdStep1Dsbl = function () {
        if (vm.email && vm.dateOfBirth) {
            if ($rootScope.emailRegex.test(vm.email) && captchaVerfication && check_date(vm.dateOfBirth) == "") {
                vm.BtnfrgtPwdStep1Cls = "nxtbtntb nxtbtnhr"; return false;
            }
            else { vm.BtnfrgtPwdStep1Cls = "nxtbtntb"; return true; }
        }
        else { vm.BtnfrgtPwdStep1Cls = "nxtbtntb"; return true; }
    }

    //this function need to after getting response from google captcha. // for send button enabling.
    $interval(function () { if (captchaVerfication) { vm.BtnfrgtPwdStep1Dsbl(); } }, 100);

    //forgot pwd Step-3 button disabled function
    vm.BtnfrgtPwdStep3Dsbl = function () {
        if (vm.password && vm.confirmPassword) {
            if (vm.password == vm.confirmPassword) {
                vm.BtnfrgtPwdStep3Cls = "nxtbtntb nxtbtnhr"; return false;
            }
            else { vm.BtnfrgtPwdStep3Cls = "nxtbtntb"; return true; }
        }
        else { vm.BtnfrgtPwdStep3Cls = "nxtbtntb"; return true; }
    }

    //Email blur event
    vm.emailCheck = function () { emlchkBlur($rootScope, vm); }
    //Email change event
    vm.emailChnage = function () { emlchangeEvnt(vm); }
    //Email Focus Event
    vm.emailFocus = function () { emlFcs(vm) }

    //new Password chnage event
    //vm.passwordChnage = function () { pwdchangeEvnt(vm); }
    vm.passwordChnage = function () {
        if (vm.password && vm.password.length > 30) { $("#txtPwd").blur(); }
    }
    //new Password blur event
    vm.pwdCheck = function () { pwdchkBlur(vm); }
    //New Password Focus Event
    vm.pwdFocus = function () { vm.pwdGuideLineMsg = true; pwdFcs(vm) }

    //Confirm password change event 
    //vm.confirmPwdChnage = function () { CnfPwdchangeEvnt(vm); }
    vm.confirmPwdChnage = function () {
        if (vm.confirmPassword && vm.confirmPassword.length > 30) { $("#txtCPwd").blur(); }
    }
    //Confirm password blur event 
    vm.cnfPwdCheck = function () { CnfPwdchkBlur(vm); }
    //Confirm password Focus event 
    vm.cnfPwdFocus = function () { CnfPwdFcs(vm); }


    //answer blur event
    vm.AnswerCheck = function () {
        if (vm.answer && vm.answer.length > 50) { vm.answerPlaceholder = "Must be < 50 characters"; vm.ansKpcls = "eror"; vm.answer = null; }
        else if (!vm.answer) { vm.answer = null; vm.ansKpcls = "eror"; vm.answerPlaceholder = "Please Answer Question"; }
    }

    //answer chanage evnt
    vm.answerChnage = function () {
        vm.ansKpcls = "bgWht";
        if (vm.answer && vm.answer.length > 50) { $("#txtAns").blur(); }
    }
    //Answer Focus Event
    vm.AnswerFocus = function () {
        vm.ansKpcls = "bgWht";
        vm.answerPlaceholder = 'Answer question';
    }

    vm.dobChange = function (event) {
        vm.bodError = false;
        vm.DOBPlaceHolder = "MM / DD / YYYY";
        if (vm.dateOfBirth) {
            var numChars = vm.dateOfBirth.length;
            var thisVal = vm.dateOfBirth;
            if (event.keyCode != 8) {
                if (numChars === 2) {
                    thisVal += '/';
                    vm.dateOfBirth = thisVal;
                }
                else if (numChars === 5) {
                    thisVal += '/';
                    vm.dateOfBirth = thisVal;
                }
            }
        }
    };

    vm.dobFocus = function () {
        vm.DOBPlaceHolder = "MM / DD / YYYY";
        vm.bodError = false;
        vm.Kpcls2 = "bgWht";
    }

    vm.dobBlur = function () {
        if (check_date(vm.dateOfBirth) != "") //checking date is valid or not
        {
            vm.DOBPlaceHolder = "Please enter a valid date";
            vm.dateOfBirth = null;
            vm.Kpcls2 = "eror";
        }
    }

    if (lgnSsn != null && lgnSsn.length != 0) {
        var getDtls = JSON.parse(getSessionSrvc.pcd(lgnSsn));
        vm.SecQuestion = getDtls["SecQuestion"];
        vm.mId = getDtls["MemberId"];
    }

    vm.frgtPwdStep1 = function () {
        if ($scope.frmFrgtPwd.$valid) {
            pcShowLoader("fgPwdstp1");
            forgotpwdSrvc.forgotPwd(vm.email, vm.dateOfBirth, function (response, status) {
                if (status == 200) {
                    if (response == "1" || response == "2") {
                        vm.errMsg = true;
                        grecaptcha.reset();
                    }
                    else {
                        $window.localStorage.setItem("A5D7FPD45", getSessionSrvc.pce(JSON.stringify(response)));
                        $state.go('forgotpwdsec');
                    }
                }
                captchaVerfication = "";
                pcHideLoader();
            });
        }
    }


    vm.frgtPwdStep2 = function () {
        if ($scope.frmFrgtPwd.$valid) {
            pcShowLoader("fgPwdstp2");
            forgotpwdSrvc.resetPwd(vm.mId, vm.answer, function (response, status) {
                if (status == 200) {
                    if (JSON.stringify(response) === "true") {
                        $state.go('forgotpwdreseteml');
                    }
                    else if (JSON.stringify(response) === "false") { alert("email sending failed"); }
                    else if (response == "1") {
                        vm.errMsg2 = true;
                        vm.answer = "";
                        vm.ansKpcls = "eror";
                        vm.answerPlaceholder = "Sorry, that’s incorrect";
                    }
                }
                pcHideLoader();
            });
        }
    }

    vm.frgtPwdStep3 = function () {
        if ($scope.frmFrgtPwd.$valid) {
            pcShowLoader("dvFgotPwdStep3");
            if (urlMemId != "" && urlMemId != undefined) {
                forgotpwdSrvc.changePwd(urlMemId, vm.password, function (response, status) {
                    if (status == 200) {
                        if (response == "1") {
                            alert("invalid id");
                        }
                        else if (response == "3") {
                            $state.go('signinpwdreset');
                        }
                    }
                    else {
                        alert("Password resetting failed...!");
                    }
                    hideLoader();
                });
            }
        }
    }

    //Displaying Time to resend the mail and Disabling the resend mail button

    if ($location.path() == "/forgotpwdreseteml.html") {
        startInterval(vm, $interval);
    }

    //Resend forgotpassword email link
    vm.rsndEmlLnk = function () {
        if (vm.mId != "" || vm.mId != null) {
            pcShowLoader("resendingEmail");
            forgotpwdSrvc.rsndfrgtpwdlnk(vm.mId, function (response, status) {
                pcHideLoader();
                if (status == 200 && response == true) {
                    startInterval(vm, $interval);
                }
                else {
                    alert("Email sending failed...!");
                }
                hideLoader();
            });
        }
    }
}]);