﻿angular.module('app').controller('basicsrchCtrl', ['getSessionSrvc', 'srchSrvc', '$rootScope', 'cmnSrvc', '$window', '$timeout', 'hbySearchFact',
    function (getSessionSrvc, srchSrvc, $rootScope, cmnSrvc, $window, $timeout, hbySearchFact) {
        var vm = this;

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  VARAIBLE DECLARATION   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        var mId = function () { return getSessionSrvc.p_mId(); };
        var units = function () { return getSessionSrvc.p_uts(); };
        vm.srchBySrt = 2;
        vm.locType = 1;
        var pyrUnits = pyrUntsTxt(units());
        var SrchLocRadiusDistance = calculateRadius(units(), 500);
        var stopScrooling = false;
        var SrchLocRadius = 5;
        vm.pgLdCmplt = false;
        vm.srchLocation = "Within 500" + " " + pyrUnits;
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  VARAIBLE DECLARATION END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BIND WITH DEFAULTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        getMemData(function () {
            vm.memGender = vm.memSearchResponse.gender;
            searchObj();
            vm.searchObj["countryId"] = vm.countryId = vm.memSearchResponse.countryId;
            vm.searchObj["lat"] = vm.curlat = vm.memSearchResponse.lat;
            vm.searchObj["long"] = vm.curlong = vm.memSearchResponse.long;
            vm.searchObj["sId"] = vm.memSearchResponse.sId;
            vm.memGenderPref = vm.memSearchResponse.genderPref;
            vm.memAge = calculateAge(vm.memSearchResponse.dob);
            setMMAgeByMemAge(vm.memAge);
            vm.srchGender = vm.memSearchResponse.genderPref;
            vm.srchGenderTxt = vm.memSearchResponse.genderPref ? "Men" : "Women";
            var hbySearch = hbySearchFact.gethbySearchData();
            if (hbySearch != undefined && hbySearch != null && hbySearch != '') {
                hbySearch = jQuery.parseJSON(hbySearchFact.gethbySearchData());
                bindSearchSuggetion(hbySearch.refId, hbySearch.refType, hbySearch.sugName);
                hbySearchFact.sethbySearchData(null);
            }
            vm.pgLdCmplt = true;
            hideLoader();
        });

        function getMemData(callBackBasicData) {
            if ($("#dvMemData").attr("data-memData") == "Y") {
                srchSrvc.getMemberData(mId(), function (response, status) {
                    if (status == 200) {
                        vm.memSearchResponse = response;
                        $("#dvMemData").attr("data-memData", "N");
                        callBackBasicData();
                    }
                });
            }
        }

        function defaults() {
            vm.dvbscMoreInfErr = false;
            vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
            vm.sortOrder = 1;
            vm.srchRslt = [];
            // vm.SortByShow = false;
        }

        //location radius bind function
        SearchDistanceFuncG();

        function SearchDistanceFuncG(callBackBasicData) {
            showLoader();
            srchSrvc.prefRadius(function (response, status) {
                if (status == 200)
                    vm.ddlRadius = response;
                hideLoader();
            });
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BIND WITH DEFAULTS END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BASIC MODULE   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.selGender = function (gender) {
            vm.srchGender = gender;
        };

        function setMMAgeByMemAge(memAge) {
            var age = memAge;
            vm.minAge = age - 5;
            if (vm.minAge < 18)
                vm.minAge = 18;
            vm.maxAge = age + 5;
            if (vm.maxAge > 99)
                vm.maxAge = 99;
        };

        vm.ageCheck = function () {
            if (vm.minAge || vm.maxAge) {
                vm.minAge = parseInt(vm.minAge);
                vm.maxAge = parseInt(vm.maxAge);

                if (vm.minAge < 18 || vm.minAge > 99)
                    vm.minAge = 18;

                if (vm.maxAge > 99 || vm.maxAge < 18)
                    vm.maxAge = 99;

                if (vm.minAge > vm.maxAge) {
                    var tempVal = vm.minAge;
                    vm.minAge = vm.maxAge;
                    vm.maxAge = tempVal;
                }
            }
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BASIC MODULE   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH OBJECT WITH DEFAULT VALUES ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        function searchObj() {
            vm.searchObj =
                   {
                       "memberId": mId(),
                       "sId": 1,
                       "minAge": vm.minAge,
                       "maxAge": vm.maxAge,
                       "gender": vm.srchGender,
                       "genderPref": vm.memGender,
                       "locRadius": null,
                       "locRadiusDistance": null,
                       "countryId": null,
                       "cityId": null,
                       "lat": "",
                       "long": "",
                       "rsStatus": "",
                       "sortBy": vm.srchBySrt,

                       //need to remove
                       "firstName": "",
                       "isOnline": null,
                       "isProfilePicUpld": null,
                       "locType": null
                   }
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH OBJECT WITH DEFAULT VALUES END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH BUTTON CLICK MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.BasicSearch = function () {
            vm.ShowViewMore = false;
            $(document).height(screen.height);
            vm.searchType = 1;
            if (!vm.minAge || !vm.maxAge)
                vm.dvbscMoreInfErr = true;
            else {
                defaults();
                stopScrooling = false;
                prepareSearchObject();
                searchMembers(vm.pgNo, vm.pgSize, false);
            }
        }

        function resetSearchResult() {
            //vm.SortByShow = false;
            vm.pgNo = 1;
            vm.pgSize = 200;
            vm.srchRslt = [];
            vm.limitToMemTileCnt = 40;
            vm.contentExists = true;
            //vm.dvNoResult = false;
            $("#noSrchRslt").hide();
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH BUTTON CLICK MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PREPARE SEARCH OBJECT  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        //**********************************************************************************************************************************************************************/

        function prepareSearchObject() {
            //BASIC MODULE
            // need to change country id based on location type selected .
            vm.searchObj["gender"] = vm.srchGender;
            vm.searchObj["minAge"] = parseInt(vm.minAge);
            vm.searchObj["maxAge"] = parseInt(vm.maxAge);
            vm.searchObj["locRadius"] = SrchLocRadius;
            vm.searchObj["locRadiusDistance"] = SrchLocRadiusDistance;
            //BASIC MODULE END             

            //SORTBY MODULE
            vm.searchObj["sortBy"] = vm.srchBySrt;
            //SORTBY MODULE END
        }

        vm.sortOrder = 1;
        vm.sortBySearch = function () {
            stopScrooling = true;
            if ($("#imgSrt").attr('src') == "https://pccdn.pyar.com/pcimgs/asndng.png") {
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/dsndng.png";
                vm.sortOrder = 0;
                searchMembers(vm.pgNo, vm.pgSize, false);
            } else {
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
                vm.sortOrder = 1;
                searchMembers(vm.pgNo, vm.pgSize, false);
            }
        }

        vm.clearSortData = function () {
            vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
            stopScrooling = true;
            vm.pgNo = 1;
            vm.pgSize = 200;
            vm.sortOrder = 1;
            vm.srchBySrt = 2;
            prepareSearchObject();
            searchMembers(vm.pgNo, vm.pgSize, false);
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PREPARE SEARCH OBJECT END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH API CALL ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        //vm.SortByShow = false;
        vm.pgNo = 1;
        vm.pgSize = 200;
        vm.srchRslt = [];
        vm.localPgSize = 40;
        vm.limitToMemTileCnt = 40;
        vm.contentExists = true;
        //vm.dvNoResult = false;
        $("#noSrchRslt").hide();
        vm.ShowViewMore = false;

        function searchMembers(pageNo, pgSize, fromAutoScroll) {
            showLoader();
            $("#blcktile").css("padding-bottom", "0px");
            //vm.dvNoResult = false;
            $("#noSrchRslt").hide();

            //vm.searchType == 1 for Basic search
            if (vm.searchType == 1) {
                vm.srchRspMsg = "Success! I think we did good!";
                srchSrvc.getBasicSearchResponse(vm.searchObj, pageNo, pgSize, vm.sortOrder, function (response, status) {
                    vm.BindSearchCallBack(response, status, fromAutoScroll)
                });
            }
                //vm.searchType ==  for suggestion search
            else if (vm.searchType == 2) {
                vm.srchRspMsg = "Success! We found matches for '" + vm.sugName + "'";
                vm.SugSearchObj.sortBy = vm.srchBySrt;
                srchSrvc.MemSuggestionSrch(vm.SugSearchObj, vm.pgNo, vm.pgSize, vm.sortOrder, function (response, status) {
                    vm.BindSearchCallBack(response, status, fromAutoScroll)
                });
            }
        }

        vm.BindSearchCallBack = function (response, status, fromAutoScroll) {
            if (status == 200 && response.length > 0) {
                vm.isSrchCmplt = true;
                if (response.length <= vm.localPgSize)
                    vm.ShowViewMore = false;
                else
                    vm.ShowViewMore = true;
                if (response.length < vm.pgSize)
                    vm.contentExists = false;
                else
                    vm.contentExists = true;
                // vm.SortByShow = true;
                if (fromAutoScroll) {
                    angular.forEach(response, function (data) {
                        vm.srchRslt.push(data);
                    });
                    hideLoader();
                } else {
                    vm.srchRslt = response;
                    hideLoader();
                }
                if (vm.localPgSize == vm.limitToMemTileCnt) {
                    if (stopScrooling == false) {
                        $("html, body").animate({
                            scrollTop: $("#searchResults").offset().top - 80
                        }, 1000);
                        $timeout(function () {
                            hideLoader();
                        }, 500, true);
                    }
                }
                //}
                if (response.length <= 5) {
                    $("#blcktile").css("padding-bottom", "300px");
                    if (vm.searchType == 1) {
                        vm.srchRspMsg = "Oh no… looks kinda deserted here. Try expanding your filter!";
                    } else if (vm.searchType == 2) {
                        vm.srchRspMsg = "Oh no… looks kinda deserted here for '" + vm.sugName + "'. Try another filter!";
                    }
                }
            } else if (status == 204 || response.length == 0) {
                $("#blcktile").css("padding-bottom", "0px");
                vm.contentExists = false;
                vm.ShowViewMore = false;
                if (vm.srchRslt.length == 0)
                    //vm.dvNoResult = true;
                    $("#noSrchRslt").show();
                $('#noSrchRslt').isInViewport();
                $timeout(function () {
                    hideLoader();
                }, 500, true);
            }
        }

        vm.viewMore = function () {
            if (vm.contentExists && (vm.srchRslt.length == (vm.pgNo * vm.pgSize))) {
                //vm.shwScrollDiv = true;
                if ((vm.limitToMemTileCnt == (vm.srchRslt.length))) {
                    vm.pgNo++;
                    searchMembers(vm.pgNo, vm.pgSize, true);
                }
            }
            vm.limitToMemTileCnt += vm.localPgSize;
            if (vm.srchRslt.length < vm.limitToMemTileCnt)
                vm.ShowViewMore = false;
        }
        // view more call in tile repeater when we block the tiles 
        $rootScope.$on("tileBlockSearch", function (e, tileIndex) { // calling from matchTile     
            vm.srchRslt.splice(tileIndex, 1);
            if (vm.srchRslt.length <= vm.localPgSize && vm.ShowViewMore == true)
                vm.viewMore();
            else if (vm.srchRslt.length == 0) {
                vm.pgNo++;
                searchMembers(vm.pgNo, vm.pgSize, true);
            }
        });

        vm.isSrchCmplt = true;
        vm.searchBySort = function () {
            if (vm.isSrchCmplt == true) {
                vm.isSrchCmplt = false;
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
                vm.sortOrder = 1;
                stopScrooling = true;
                prepareSearchObject();
                searchMembers(vm.pgNo, vm.pgSize, false);
            }
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH API CALL END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        //SEARCH SUGGESTIONS MODULE START
        vm.bindSearchSuggestions = function () {
            srchSrvc.getSearchSuggestions(mId(), function (response, status) {
                if (status == 200) {
                    vm.SrchSuggestionLst = response;
                }
            });
        }

        vm.bindSearchSuggestions();
        //refType 1 for pt and 2 for hobby
        vm.searchBySuggestion = function (refId, refType, sugName) {
            vm.ShowViewMore = false;
            bindSearchSuggetion(refId, refType, sugName);
        }

        function bindSearchSuggetion(refId, refType, sugName) {
            vm.sugName = sugName;
            vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
            vm.searchType = 2;
            resetSearchResult();
            srchSrvc.GetMemberBasicSearchSuggestionInfo(mId(), function (response, status) {
                if (status == 200) {
                    vm.suggestion = refId;
                    vm.suggestionType = refType;
                    var minAge = 0, maxAge = 0;
                    if (response.minAge)
                        minAge = response.minAge;
                    else {
                        minAge = vm.minAge;
                    }
                    if (response.maxAge)
                        maxAge = response.maxAge;
                    else
                        maxAge = vm.maxAge;
                    angular.forEach(vm.ddlRadius, function (data) {
                        if (data.rdId == response.locRadius) {
                            var locRadiusDistance = calculateRadius(units(), data.radius);
                            vm.SugSearchObj = {
                                "memberId": mId(), "gender": vm.memGenderPref, "genderPref": vm.memGender, "minAge": minAge,
                                "maxAge": maxAge, "locRadius": response.locRadius, "locRadiusDistance": locRadiusDistance, "countryId": response.countryId, "lat": response.latitude,
                                "long": response.longitute, "suggestionType": vm.suggestionType, "suggestion": vm.suggestion, "sortBy": vm.srchBySrt
                            };
                            showLoader();
                            searchMembers();
                        }
                    });
                }
            });
        }

        //SEARCH SUGGESTIONS MODULE  END

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS END )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.advanceSearch = function () {
            if (cmnSrvc.isTrialOrPrmExpired()) $("#getPremiumPopup").modal('show'); //check trail expired or premium expired
            else showMobileVerificationPop();
        };

        vm.GetPremium = function () {
            $("#getPremiumPopup").modal('hide');
            //showMobileVerificationPop();
            $window.location.href = '/payment.html';
        };
    }]);