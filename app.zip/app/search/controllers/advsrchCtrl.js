﻿angular.module("app").controller('advsrchCtrl', ['getSessionSrvc', 'srchSrvc', 'countryIntlSrv', '$scope', '$state', '$rootScope', '$timeout', 'hbySearchFact',
    function (getSessionSrvc, srchSrvc, countryIntlSrv, $scope, $state, $rootScope, $timeout, hbySearchFact) {
        var vm = this;
        var mId = function () { return getSessionSrvc.p_mId(); };
        var memberType = function () { return getSessionSrvc.p_sub(); };
        var units = function () { return getSessionSrvc.p_uts(); };
        if (memberType() == 1)
            $state.go("basicsearch");

        //variable declaration    
        vm.txtsearchByName = "";
        vm.txtsearchPlaceHolder = "Name";
        vm.srchBySrt = 2;
        var defaultLocRadius = 5;
        var locationCity = null;
        vm.locType = 1;
        vm.profilePhotos = true;
        vm.onlineMatches = false;
        vm.srchLocation = "";
        var cityId = null;
        var stopScrooling = false;
        vm.pgLdCmplt = false;
        //variable declaration end

        //pyar units setting       
        vm.pyrUnits = pyrUntsTxt(units());
        var locRadiusDistance = calculateRadius(units(), 500);
        var SrchLocRadius = defaultLocRadius;
        //pyar units setting end

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PAGE LOAD MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        //on page load binding member default data like gender , genderPref, age , country ..etc   
        function BindMemBasicData() {
            getMemData(function (response, status) {
                vm.memGender = response.gender;
                searchObj();
                vm.defaultCntryId = response.countryId;
                vm.searchObj["countryId"] = vm.countryId = response.countryId;
                vm.searchObj["cityId"] = cityId = response.cityId;
                vm.searchObj["lat"] = vm.curlat = response.lat;
                vm.searchObj["long"] = vm.curlong = response.long;
                vm.searchObj["sId"] = response.sId;
                vm.memGenderPref = response.genderPref;
                vm.memAge = calculateAge(response.dob);
                setMMAgeByMemAge(vm.memAge);

                var hbySearch = hbySearchFact.gethbySearchData();
                if (hbySearch != undefined && hbySearch != null && hbySearch != '') {
                    hbySearch = jQuery.parseJSON(hbySearchFact.gethbySearchData());
                    bindSearchSuggetion(hbySearch.refId, hbySearch.refType, hbySearch.sugName);
                    hbySearchFact.sethbySearchData(null);
                }
                vm.srchGender = response.genderPref;
                vm.srchGenderTxt = response.genderPref ? "Men" : "Women";
                //vm.gndrTxtHisOrHer = response.genderPref ? "he" : "she";
                hideLoader();
                vm.pgLdCmplt = true;
            });
        }

        function getMemData(callBackBasicData) {
            if ($("#dvMemData").attr("data-memData") == "Y") {
                showLoader();
                srchSrvc.getMemberData(mId(), function (response, status) {
                    callBackBasicData(response, status);
                    $("#dvMemData").attr("data-memData", "N");
                });
            }
        }

        BindMemBasicData();
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PAGE LOAD MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BINDING DROPDOWNS MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        //location radius bind function
        mpDistanceFuncG(function (response) {
            angular.forEach(response, function (data) {
                if (data.rdId == defaultLocRadius) {
                    var rds = data.rdId == 6 ? (data.radius + "+") : data.radius;
                    vm.srchLocation = "Within " + rds + " " + vm.pyrUnits;
                }
            });
        });

        function mpDistanceFuncG(callBackBasicData) {
            showLoader();
            srchSrvc.prefRadius(function (response, status) {
                if (status == 200) {
                    vm.ddlRadius = response;
                    callBackBasicData(response);
                    hideLoader();
                } else
                    hideLoader();
            });
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BINDING DROPDOWNS MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BASIC MODULE   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.selGender = function (gender) {
            vm.srchGender = gender;
            //vm.gndrTxtHisOrHer = gender ? "he" : "she";
        }

        function setMMAgeByMemAge(memAge) {
            var age = memAge;
            vm.minAge = age - 5;
            if (vm.minAge < 18)
                vm.minAge = 18;
            vm.maxAge = age + 5;
            if (vm.maxAge > 99)
                vm.maxAge = 99;
        }

        vm.ageCheck = function () {
            if (vm.minAge || vm.maxAge) {
                vm.minAge = parseInt(vm.minAge);
                vm.maxAge = parseInt(vm.maxAge);

                if (vm.minAge < 18 || vm.minAge > 99)
                    vm.minAge = 18;

                if (vm.maxAge > 99 || vm.maxAge < 18)
                    vm.maxAge = 99;

                if (vm.minAge > vm.maxAge) {
                    var tempVal = vm.minAge;
                    vm.minAge = vm.maxAge;
                    vm.maxAge = tempVal;
                }
            }
        }

        vm.locationhide = function () {
            vm.dvbscMoreInfErr = false;
            vm.otherLocation = false;
            vm.countryId = null;
            locationCity = null;
        }

        vm.locationvisible = function () {
            vm.otherLocation = true;
            countryIntlSrv.resetCountry("txtAsrchCurrLocCity", "dvSrchCountry");
        }

        vm.setRadius = function (rdsId, radius) {
            locRadiusDistance = calculateRadius(units(), radius);
            SrchLocRadius = rdsId;
        }

        vm.profilePhotosChk = function () {
            vm.profilePhotos = !vm.profilePhotos;
        }

        vm.onlineMatchesChk = function () {
            vm.onlineMatches = !vm.onlineMatches;
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BASIC MODULE   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH OBJECT WITH DEFAULT VALUES ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        function searchObj() {
            vm.searchObj =
                   {
                       "memberId": mId(),
                       "sId": 1,
                       "firstName": "",
                       "isOnline": false,
                       "isProfilePicUpld": true,
                       "gender": vm.srchGender,
                       "genderPref": vm.memGender,
                       "minAge": vm.minAge,
                       "maxAge": vm.maxAge,
                       "locRadius": null,
                       "locType": vm.locType,
                       "locRadiusDistance": null,
                       "countryId": null,
                       "cityId": null,
                       "lat": "",
                       "long": "",
                       "rsStatus": "",
                       "sortBy": vm.srchBySrt,
                   }
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH OBJECT WITH DEFAULT VALUES END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH API CALL ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        // vm.SortByShow = false;
        vm.pgNo = 1;
        vm.pgSize = 200;
        vm.srchRslt = [];
        vm.localPgSize = 40;
        vm.limitToMemTileCnt = 40;
        vm.contentExists = true;
        //vm.dvNoResult = false;
        $("#noSrchRslt").hide();
        vm.ShowViewMore = false;

        function searchMembers(pageNo, pgSize, fromAutoScroll) {
            showLoader();
            $("#hidefter").css("padding-bottom", "0px");
            //vm.dvNoResult = false;
            $("#noSrchRslt").hide();

            //vm.searchType == 1 for advanced search
            if (vm.searchType == 1) {
                vm.srchRspMsg = "Success! I think we did good!";
                srchSrvc.getAdvSearchResponse(vm.searchObj, pageNo, pgSize, vm.sortOrder, function (response, status) {
                    vm.BindSearchCallBack(response, status, fromAutoScroll)
                });
            }
                //vm.searchType ==  for suggestion search
            else if (vm.searchType == 2) {
                vm.srchRspMsg = "Success! We found matches for '" + vm.sugName + "'";
                vm.SugSearchObj.sortBy = vm.srchBySrt;
                srchSrvc.MemSuggestionSrch(vm.SugSearchObj, vm.pgNo, vm.pgSize, vm.sortOrder, function (response, status) {
                    vm.BindSearchCallBack(response, status, fromAutoScroll)
                });
            }
        }

        vm.BindSearchCallBack = function (response, status, fromAutoScroll) {
            if (status == 200 && response.length > 0) {
                vm.isSrchCmplt = true;
                if (response.length <= vm.localPgSize)
                    vm.ShowViewMore = false;
                else
                    vm.ShowViewMore = true;
                if (response.length < vm.pgSize)
                    vm.contentExists = false;
                else
                    vm.contentExists = true;
                // vm.SortByShow = true;
                if (fromAutoScroll) {
                    angular.forEach(response, function (data) {
                        vm.srchRslt.push(data);
                    });
                    hideLoader();
                    vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
                } else {
                    vm.srchRslt = response;
                    hideLoader();
                    vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
                }
                //for the first time scrool the window to middle
                if (vm.localPgSize == vm.limitToMemTileCnt) {
                    if (stopScrooling == false) {
                        $("html, body").animate({
                            scrollTop: $("#searchResults").offset().top - 80
                        }, 1000);
                        //$("html, body").animate({
                        //    scrollTop: $(document).height() / 2 + 180
                        //}, 500);
                        $timeout(function () {
                            hideLoader();
                            vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
                        }, 500, true);
                    }
                }
                if (response.length <= 5) {
                    $("#hidefter").css("padding-bottom", "300px");
                    if (vm.searchType == 1) {
                        vm.srchRspMsg = "Oh no… looks kinda deserted here. Try expanding your filter!";
                    } else if (vm.searchType == 2) {
                        vm.srchRspMsg = "Oh no… looks kinda deserted here for '" + vm.sugName + "'. Try another filter!";
                    }
                }
            } else if (status == 204 || response.length == 0) {
                $("#hidefter").css("padding-bottom", "0px");
                vm.contentExists = false;
                vm.ShowViewMore = false;
                if (vm.srchRslt.length == 0)
                    //vm.dvNoResult = true;
                    $("#noSrchRslt").show();
                $('#noSrchRslt').isInViewport();
                $timeout(function () {
                    hideLoader();
                    vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
                }, 500, true);
            }
        }

        vm.viewMore = function () {
            vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/acnLdr.svg";
            if (vm.contentExists && (vm.srchRslt.length == (vm.pgNo * vm.pgSize))) {
                //vm.shwScrollDiv = true;
                if ((vm.limitToMemTileCnt == (vm.srchRslt.length))) {
                    vm.pgNo++;
                    searchMembers(vm.pgNo, vm.pgSize, true);
                }
            }
            vm.limitToMemTileCnt += vm.localPgSize;
            if (vm.srchRslt.length < vm.limitToMemTileCnt)
                vm.ShowViewMore = false;
        }

        // view more call in tile repeater when we block the tiles 
        $rootScope.$on("tileBlockSearch", function (e, tileIndex) { // calling from matchTile   
            vm.srchRslt.splice(tileIndex, 1);
            if (vm.srchRslt.length <= vm.localPgSize && vm.ShowViewMore == true)
                vm.ShowViewMore = false;
            else if (vm.srchRslt.length == 0) {
                vm.pgNo++;
                searchMembers(vm.pgNo, vm.pgSize, true);
            }
        });

        $scope.$on('onMatchTileImageLoad', function () {
            vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
        });

        vm.isSrchCmplt = true;
        vm.searchBySort = function () {
            if (vm.isSrchCmplt == true) {
                vm.isSrchCmplt = false;
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
                vm.sortOrder = 1;
                stopScrooling = true;
                prepareSearchObject();
                searchMembers(vm.pgNo, vm.pgSize, false);
            }
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH API CALL END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PREPARE SEARCH OBJECT  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        //**********************************************************************************************************************************************************************/

        function prepareSearchObject() {
            //BASIC MODULE
            // need to change country id based on location type selected .
            vm.searchObj["firstName"] = vm.txtsearchByName;
            vm.searchObj["gender"] = vm.srchGender;
            vm.searchObj["minAge"] = parseInt(vm.minAge);
            vm.searchObj["maxAge"] = parseInt(vm.maxAge);
            vm.searchObj["isOnline"] = vm.onlineMatches;
            vm.searchObj["isProfilePicUpld"] = vm.profilePhotos == true ? true : false;
            vm.searchObj["locRadius"] = SrchLocRadius;
            vm.searchObj["locRadiusDistance"] = locRadiusDistance;
            vm.searchObj["locType"] = vm.locType;
            if (vm.locType == 1) {
                vm.searchObj["lat"] = vm.curlat;
                vm.searchObj["long"] = vm.curlong;
                vm.searchObj["countryId"] = vm.defaultCntryId;
                vm.searchObj["cityId"] = cityId;
            } else if (vm.locType == 2) {
                vm.searchObj["lat"] = vm.MyLocLatitude;
                vm.searchObj["long"] = vm.MyLocLongitude;
                vm.searchObj["countryId"] = vm.countryId;
                vm.searchObj["cityId"] = locationCity;
            } else if (vm.locType == 3) {
                vm.searchObj["lat"] = vm.OtherLocLatitude;
                vm.searchObj["long"] = vm.OtherLocLongitude;
                vm.searchObj["countryId"] = vm.countryId;
                vm.searchObj["cityId"] = locationCity;
            }
            vm.searchObj["sortBy"] = vm.srchBySrt;
            //BASIC MODULE END                  
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PREPARE SEARCH OBJECT END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH BUTTON CLICK MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.advanceSearch = function () {
            vm.ShowViewMore = false;
            $(document).height(screen.height);
            vm.searchType = 1;
            resetSearchResult();
            if ((vm.locType == 3) && (vm.countryId == null || locationCity == null))
                vm.dvbscMoreInfErr = true;
                //if (locationCity == null && vm.countryId != null)
                //    vm.CtyrErr = 'eror';           
            else if (!vm.minAge || !vm.maxAge)
                vm.dvbscMoreInfErr = true;
            else if (vm.HTCountryId != null && vm.htCityId == "")
                vm.dvabtMoreInfErr = true;
                //vm.hmCtyrErr = 'eror';            
            else {
                vm.dvbscMoreInfErr = false;
                vm.dvabtMoreInfErr = false;
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
                vm.sortOrder = 1;
                vm.srchRslt = [];
                // vm.SortByShow = false;
                stopScrooling = false;
                prepareSearchObject();
                searchMembers(vm.pgNo, vm.pgSize, false);
            }
        }

        function resetSearchResult() {
            // vm.SortByShow = false;
            vm.pgNo = 1;
            vm.pgSize = 200;
            vm.srchRslt = [];
            vm.limitToMemTileCnt = 40;
            vm.contentExists = true;
            //vm.dvNoResult = false;
            $("#noSrchRslt").hide();
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH BUTTON CLICK MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        vm.clearSortData = function () {
            vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
            stopScrooling = true;
            vm.pgNo = 1;
            vm.pgSize = 200;
            vm.sortOrder = 1;
            vm.srchBySrt = 2;
            prepareSearchObject();
            searchMembers(vm.pgNo, vm.pgSize, false);
        }

        vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
        vm.sortOrder = 1;
        vm.sortBySearch = function () {
            stopScrooling = true;
            if ($("#imgSrt").attr('src') == "https://pccdn.pyar.com/pcimgs/asndng.png") {
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/dsndng.png";
                vm.sortOrder = 0;
                searchMembers(vm.pgNo, vm.pgSize, false);
            } else {
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
                vm.sortOrder = 1;
                searchMembers(vm.pgNo, vm.pgSize, false);
            }
        }


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        //city intelligence module
        $scope.$on("countryBind", function (e, txtId, countryId, data) {
            if (txtId == "txtAsrchCurrLocCity") {
                vm.countryId = data.countryId;
                locationCity = data.cityId;
                vm.OtherLocLatitude = data.lat;
                vm.OtherLocLongitude = data.long;
            }
            else if (txtId == "txtSrchHomeCity") {
                vm.HTCountryId = data.countryId;
                vm.htCityId = data.cityId;
            }
            //console.log("bind : " + txtId + "  --  " + countryId + "  --  " + JSON.stringify(data));
        });

        $scope.$on("countryUnBind", function (e, txtId, countryId) {
            //console.log("unbind : " + txtId + "  --  " + countryId);
            if (txtId == "txtAsrchCurrLocCity") {
                vm.countryId = null;
                locationCity = null;
                vm.OtherLocLatitude = null;
                vm.OtherLocLongitude = null;
            }
            else if (txtId == "txtSrchHomeCity") {
                vm.HTCountryId = null;
                vm.htCityId = null;
            }
        });

        $rootScope.$on("bindCountry", function (e, countries) {
            vm.countries = countries;
        });

        vm.setCountry = function (txtId, dvId, countryId) {
            //$("#txtCityName").prop('disabled', false);
            // $("#txtHomeCityName").prop('disabled', false);
            countryIntlSrv.SetCountry(txtId, dvId, countryId);
        }

        vm.setDfaultCntry = function () {
            $("#txtAsrchCurrLocCity").val('');
            $("#txtAsrchCurrLocCity").prop('disabled', true);
            vm.countryId = null;
            locationCity = null;
            vm.OtherLocLatitude = null;
            vm.OtherLocLongitude = null;
            vm.HTCountryId = null;
            vm.htCityId = null;
        }

        vm.sethmDfaultCntry = function () {
            $("#txtSrchHomeCity").val('');
            $("#txtSrchHomeCity").prop('disabled', true);
        }
        countryIntlSrv.initSrvc();
        //city intelligence module

        //SEARCH SUGGESTIONS MODULE START
        vm.bindSearchSuggestions = function () {
            srchSrvc.getSearchSuggestions(mId(), function (response, status) {
                if (status == 200)
                    vm.SrchSuggestionLst = response;
            });
        }

        vm.bindSearchSuggestions();
        //refType 1 for pt and 2 for hobby       
        vm.searchBySuggestion = function (refId, refType, sugName) {
            vm.ShowViewMore = false;
            bindSearchSuggetion(refId, refType, sugName);
        }

        function bindSearchSuggetion(refId, refType, sugName) {
            vm.srchRspMsg = "Success! We found matches for  '" + sugName + "'";
            vm.sugName = sugName;
            vm.searchType = 2;
            resetSearchResult();
            srchSrvc.GetMemberBasicSearchSuggestionInfo(mId(), function (response, status) {
                if (status == 200) {
                    vm.suggestion = refId;
                    vm.suggestionType = refType;
                    var minAge = 0, maxAge = 0;
                    if (response.minAge)
                        minAge = response.minAge;
                    else
                        minAge = vm.minAge;
                    if (response.maxAge)
                        maxAge = response.maxAge;
                    else
                        maxAge = vm.maxAge;

                    //console.log(response);

                    angular.forEach(vm.ddlRadius, function (data) {
                        if (data.rdId == response.locRadius) {
                            var radiusDistance = calculateRadius(units(), data.radius);
                            vm.SugSearchObj = {
                                "memberId": mId(), "gender": vm.memGenderPref, "genderPref": vm.memGender, "minAge": minAge,
                                "maxAge": maxAge, "locRadius": response.locRadius, "locRadiusDistance": radiusDistance, "countryId": response.countryId, "lat": response.latitude,
                                "long": response.longitute, "suggestionType": vm.suggestionType, "suggestion": vm.suggestion, "sortBy": vm.srchBySrt
                            };
                            showLoader();
                            searchMembers();
                        }
                    });
                }
            });
        }

        //SEARCH SUGGESTIONS MODULE START END

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS END )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.txtsearchChange = function () {
            vm.kpCls = 'bgWht';
            if (vm.txtsearchByName && vm.txtsearchByName.length > 30) {
                vm.txtsearchByName = ""; vm.kpCls = 'eror'; vm.txtsearchPlaceHolder = "Must be < 30 characters";
                vm.srchTxt = true;
            }
        }

        vm.txtsearchCheck = function () {
            if (vm.srchTxt == true) {
                vm.txtsearchByName = ""; vm.kpCls = ''; vm.txtsearchPlaceHolder = "Name";
                vm.srchTxt = false;
            }
        }
    }]);
