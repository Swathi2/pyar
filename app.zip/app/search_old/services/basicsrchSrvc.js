﻿angular.module("app").service('basicsrchSrvc', ['$http', function ($http) {
    //service for getting all the radius
    this.prefRadius = function (funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/utils/radius/";
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    //service for getting member basic data with default search result
    this.getMemberData = function (memId, funCallBack) {
        var liveURL = getApiDomainUrl() + "/api/search/bsdata/" + memId;
        GetServiceByURL($http, liveURL, funCallBack);
    }

    this.getCountryIdByShortName = function (countryShortName, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/utils/getcntrybysn/" + countryShortName;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    //service for get all the  save the search data
    this.getSearchResponse = function (searchObj, pgNo, pgSize, sortOrder, funCallBack) {
        if (searchObj.sortBy == 2) {
            if (sortOrder == 1)
                sortOrder = 0;
            else if (sortOrder == 0)
                sortOrder = 1;
        }
        var data = {
            "memberId": searchObj.memberId,
            "firstName": searchObj.firstName,
            "gender": searchObj.gender,
            "genderPref": searchObj.genderPref,
            "minAge": searchObj.minAge,
            "maxAge": searchObj.maxAge,
            "locRadius": searchObj.locRadius,
            "locRadiusDistance": searchObj.locRadiusDistance,
            "countryId": searchObj.countryId,
            "lat": searchObj.lat,
            "long": searchObj.long,
            "isProfilePicUpld": searchObj.isProfilePicUpld,
            "isOnline": searchObj.isOnline,
        }
        var liveURL = getApiDomainUrl() + "/api/search/bscsrch/" + pgNo + "/" + pgSize + "/" + searchObj.sortBy + "/" + sortOrder;
        PostServiceByURL($http, liveURL, data, funCallBack);
    }

    this.getSearchSuggestions = function (memberId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/search/srchsgtns/" + memberId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    //this.MemberHideCheck = function (memberId, memHideId, funCallBack) {
    //    var liveUrl = getApiDomainUrl() + "/api/actions/hdchk/" + memberId + "/" + memHideId;
    //    GetServiceByURL($http, liveUrl, funCallBack);
    //}
    this.GetMemberBasicSearchSuggestionInfo = function (memberId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/search/srchsgprefinfo/" + memberId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }


    //service for get all the  save the search data
    this.MemSuggestionSrch = function (searchObj, pgNo, pgSize, sortOrder, funCallBack) {
        var data = {
            "memberId": searchObj.memberId,
            "gender": searchObj.gender,
            "genderPref": searchObj.genderPref,
            "minAge": searchObj.minAge,
            "maxAge": searchObj.maxAge,
            "locRadius": searchObj.locRadius,
            "locRadiusDistance": searchObj.locRadiusDistance,
            "countryId": searchObj.countryId,
            "lat": searchObj.lat,
            "long": searchObj.long,
            "suggestionType": searchObj.suggestionType,
            "suggestion": searchObj.suggestion,
            "sortBy": searchObj.sortBy
        }
        if (searchObj.sortBy == 2) {
            if (sortOrder == 1)
                sortOrder = 0;
            else if (sortOrder == 0)
                sortOrder = 1;
        }
        var liveURL = getApiDomainUrl() + "/api/search/srchsgsg/" + pgNo + "/" + pgSize + "/" + searchObj.sortBy + "/" + sortOrder;
        PostServiceByURL($http, liveURL, data, funCallBack);
    }
}]);