﻿angular.module("app").service('advsrchSrvc', ['$http', function ($http) {

    //service for getting all the radius
    this.prefRadius = function (funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/utils/radius/";
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    //service for getting member basic data with default search result
    this.getMemberData = function (memId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/search/bsdata/" + memId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    //service for get all the  save the search data
    this.getSearchResponse = function (searchObj, pgNo, pgSize, sortOrder, funCallBack) {
        var data = {
            "memberId": searchObj.memberId,
            "sId": searchObj.sId,
            "locRadius": searchObj.locRadius,
            "locRadiusDistance": searchObj.locRadiusDistance,
            "locType": searchObj.locType,
            "gender": searchObj.gender,
            "countryId": searchObj.countryId,
            "cityId": searchObj.cityId,
            "genderPref": searchObj.genderPref,
            "latitude": searchObj.latitude,
            "longitute": searchObj.longitute,
            "minAge": searchObj.minAge,
            "maxAge": searchObj.maxAge,
            "isOnline": searchObj.isOnline,
            "isProfilePicUpld": searchObj.isProfilePicUpld,
            "firstName": searchObj.firstName,
            "rShipStatus": searchObj.rShipStatus,
            "eyeColor": searchObj.eyeColor,
            "hairColor": searchObj.hairColor,
            "build": searchObj.build,
            "minHeight": searchObj.minHeight,
            "maxHeight": searchObj.maxHeight,
            "diet": searchObj.diet,
            "smoke": searchObj.smoke,
            "drink": searchObj.drink,
            "highestEdu": searchObj.highestEdu,
            "childrenCnt": searchObj.childrenCnt,
            "children": searchObj.children,
            "petsCnt": searchObj.petsCnt,
            "pets": searchObj.pets,
            "religions": searchObj.religions,
            "ethinicities": searchObj.ethinicities,
            "religious": searchObj.religious,
            "traditional": searchObj.traditional,
            "areaWork": searchObj.areaWork,
            "idealRelationship": searchObj.idealRelationship,
            "htCountry": searchObj.htCountry,
            "htCity": searchObj.htCity,
            "languages": searchObj.languages,
            "fmlyLanguages": searchObj.fmlyLanguages,
            "hobbies": searchObj.hobbies,
            "personalityTraits": searchObj.personalityTraits,
        }
        if (searchObj.sortBy == 2 || searchObj.sortBy == 4) {
            if (sortOrder == 1)
                sortOrder = 0;
            else if (sortOrder == 0)
                sortOrder = 1;
        }
        var liveUrl = getApiDomainUrl() + "/api/search/advsrch/" + pgNo + "/" + pgSize + "/" + searchObj.sortBy + "/" + sortOrder;
        PostServiceByURL($http, liveUrl, data, funCallBack);
    }
    //service for save the search 
    this.saveSearch = function (searchObj, title, funCallBack) {
        var data = {
            "memberId": searchObj.memberId,
            "locRadius": searchObj.locRadius,
            "locRadiusDistance": searchObj.locRadiusDistance,
            "locType": searchObj.locType,
            "gender": searchObj.gender,
            "countryId": searchObj.countryId,
            "cityId": searchObj.cityId,
            "genderPref": searchObj.genderPref,
            "latitude": searchObj.latitude,
            "longitute": searchObj.longitute,
            "minAge": searchObj.minAge,
            "maxAge": searchObj.maxAge,
            "isOnline": searchObj.isOnline,
            "isProfilePicUpld": searchObj.isProfilePicUpld,
            "firstName": searchObj.firstName,
            "rShipStatus": searchObj.rShipStatus,
            "eyeColor": searchObj.eyeColor,
            "hairColor": searchObj.hairColor,
            "build": searchObj.build,
            "minHeight": searchObj.minHeight,
            "maxHeight": searchObj.maxHeight,
            "diet": searchObj.diet,
            "smoke": searchObj.smoke,
            "drink": searchObj.drink,
            "highestEdu": searchObj.highestEdu,
            "childrenCnt": searchObj.childrenCnt,
            "children": searchObj.children,
            "petsCnt": searchObj.petsCnt,
            "pets": searchObj.pets,
            "religions": searchObj.religions,
            "ethinicities": searchObj.ethinicities,
            "religious": searchObj.religious,
            "traditional": searchObj.traditional,
            "areaWork": searchObj.areaWork,
            "idealRelationship": searchObj.idealRelationship,
            "htCountry": searchObj.htCountry,
            "htCity": searchObj.htCity,
            "languages": searchObj.languages,
            "fmlyLanguages": searchObj.fmlyLanguages,
            "hobbies": searchObj.hobbies,
            "personalityTraits": searchObj.personalityTraits
        }
        var liveUrl = getApiDomainUrl() + "/api/search/saveSrch/" + title;
        PostServiceByURL($http, liveUrl, data, funCallBack);
    }

    //get all the saved search data to display
    this.getSaveSearchData = function (memId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/search/getsavesrch/" + memId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    //get all the dropdown data to bind default search
    this.getAllDdlData = function (funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/profile/getalldrpdwndata";
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    //service for mark saved search as default saved search
    this.SetRemoveDafaultSearch = function (mssid, memberId, status, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/search/dfltsrch/" + mssid + "/" + memberId + "/" + status;
        PostServiceByURL($http, liveUrl, status, funCallBack);
    }
    //service for delete the saved search
    this.DeleteSaveSearch = function (mssid, memberId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/search/dltdfltsrch/" + mssid + "/" + memberId;
        PostServiceByURL($http, liveUrl, '', funCallBack);
    }

    this.MemberHideCheck = function (memberId, memHideId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/actions/hdchk/" + memberId + "/" + memHideId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    this.getCountryIdByShortName = function (countryShortName, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/utils/getcntrybysn/" + countryShortName;
        GetServiceByURL($http, liveUrl, funCallBack);
    }


    this.getSavedSearchById = function (mssid, memberId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/search/savesrchbyid/" + mssid + "/" + memberId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    this.getSearchSuggestions = function (memberId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/search/srchsgtns/" + memberId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    this.saveSearchCount = function (memberId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/search/savesrchcnt/" + memberId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    this.GetMemberBasicSearchSuggestionInfo = function (memberId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/search/srchsgprefinfo/" + memberId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    //service for get all the  save the search data
    this.MemSuggestionSrch = function (searchObj, pgNo, pgSize, sortOrder, funCallBack) {
        var data = {
            "memberId": searchObj.memberId,
            "gender": searchObj.gender,
            "genderPref": searchObj.genderPref,
            "minAge": searchObj.minAge,
            "maxAge": searchObj.maxAge,
            "locRadius": searchObj.locRadius,
            "locRadiusDistance": searchObj.locRadiusDistance,
            "countryId": searchObj.countryId,
            "lat": searchObj.lat,
            "long": searchObj.long,
            "suggestionType": searchObj.suggestionType,
            "suggestion": searchObj.suggestion,
            "sortBy": searchObj.sortBy
        }
        if (searchObj.sortBy == 2) {
            if (sortOrder == 1)
                sortOrder = 0;
            else if (sortOrder == 0)
                sortOrder = 1;
        }
        var liveUrl = getApiDomainUrl() + "/api/search/srchsgsg/" + pgNo + "/" + pgSize + "/" + searchObj.sortBy + "/" + sortOrder;
        PostServiceByURL($http, liveUrl, data, funCallBack);
    }
}]);