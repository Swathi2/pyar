﻿angular.module("app").controller('advsrchCtrl', ['getSessionSrvc', 'advsrchSrvc', 'selfprofileSrvc','countryIntlSrv', 'msgSrvc', '$scope', '$window', '$state', '$rootScope', '$timeout', 'hbySearchFact',
    function (getSessionSrvc, advsrchSrvc, selfprofileSrvc, countryIntlSrv, msgSrvc, $scope, $window, $state, $rootScope, $timeout, hbySearchFact) {
        tabMenu();       
        var vm = this;
        var mId = getSessionSrvc.p_mId();
        var memberType = getSessionSrvc.p_sub();
        if (memberType == 1) {
            $state.go("basicsearch");
        }
        //variable declaration
        vm.checkedSrchECIds = [];
        vm.checkedmpRlgnIds = [];
        vm.checkedSrchRSSIds = [];
        vm.checkedTrIds = [];
        vm.checkedSrchEyeClrIds = [];
        vm.checkedSrchHairClrIds = [];
        vm.checkedSrchBuildClrIds = [];
        vm.checkedmpDtIds = [];
        vm.checkedmpPrefLangIds = [];
        vm.checkedmpFmlyLangIds = [];
        vm.checkedmphbIds = [];
        vm.srchBySrt = 2;
        vm.AwId = null;
        vm.defaultLocRadius = 5;
        vm.locationCity = null;
        vm.locType = 1;
        vm.profilePhotos = true;
        vm.onlineMatches = false;
        //vm.imageStorage = "https://pccdn.pyar.com";
        //vm.imageCDN = "https://pccdn.pyar.com";
        vm.cityId = null;
        vm.stopScrooling = false;
        vm.selectedHbs = [];
        vm.highestDegree = "Heighest degree";
        vm.pgLdCmplt = false;
        //variable declaration end

        //pyar units setting
        var units = getSessionSrvc.p_uts();
        vm.pyrUnits = pyrUntsTxt(units);
        vm.locRadiusDistance = calculateRadius(units, 500);
        vm.SrchLocRadius = vm.defaultLocRadius;
        //pyar units setting end

        //bind all the dropdown value when the default search is present else they were binding on tag click
        function bindAllDllData(callBackFun) {
            showLoader();
            advsrchSrvc.getAllDdlData(function (response, status) {
                callBackFun(response);
                hideLoader();
            });
        }
        //bind all the dropdown value when the default search is present else they were binding on tag click end


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PAGE LOAD MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        //on page load binding member default data like gender , genderPref, age , country ..etc   
        function BindMemBasicData() {
            getMemData(function (response, status) {
                vm.memGender = response.gender;
                searchObj();
                vm.defaultCntryId = response.countryId;
                vm.searchObj["countryId"] = vm.countryId = response.countryId;
                vm.searchObj["cityId"] = vm.cityId = response.cityId;
                vm.searchObj["latitude"] = vm.curlat = response.lat;
                vm.searchObj["longitute"] = vm.curlong = response.long;
                vm.searchObj["sId"] = response.sId;
                vm.memGenderPref = response.genderPref;
                vm.memAge = calculateAge(response.dob);
                setMMAgeByMemAge(vm.memAge);

                var hbySearch = hbySearchFact.gethbySearchData();
                if (hbySearch != undefined && hbySearch != null && hbySearch != '') {
                    hbySearch = jQuery.parseJSON(hbySearchFact.gethbySearchData());
                    bindSearchSuggetion(hbySearch.refId, hbySearch.refType, hbySearch.sugName);
                    hbySearchFact.sethbySearchData(null);
                }

                if (response.defaultSearchData != null && response.defaultSearchData != "") {
                    vm.pgLdCmplt = true;
                    bindDefaultSearchData(response.defaultSearchData, function () { });
                } else {                    
                    vm.srchGender = response.genderPref;
                    vm.srchGenderTxt = response.genderPref ? "Men" : "Women";
                    //vm.gndrTxtHisOrHer = response.genderPref ? "he" : "she";
                    hideLoader();
                    vm.pgLdCmplt = true;
                }
            });
        }
        function getMemData(callBackBasicData) {
            if ($("#dvMemData").attr("data-memData") == "Y") {
                showLoader();
                advsrchSrvc.getMemberData(mId, function (response, status) {
                    callBackBasicData(response, status);
                    $("#dvMemData").attr("data-memData", "N");
                });
            }
        }
        BindMemBasicData();
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PAGE LOAD MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BINDING THE MODELS WITH DEFAULT SEARCH  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        /*********************************************************************************************************************************************************************/
        function bindDefaultSearchData(savedSearchData, calBackFun) {
            if (savedSearchData != null) {
                vm.checkedSrchECIds = [];
                vm.checkedmpRlgnIds = [];
                vm.checkedSrchRSSIds = [];
                vm.checkedTrIds = [];
                vm.checkedSrchEyeClrIds = [];
                vm.checkedSrchHairClrIds = [];
                vm.checkedSrchBuildClrIds = [];
                vm.checkedmpDtIds = [];
                vm.checkedmpPrefLangIds = [];
                vm.checkedmpFmlyLangIds = [];
                vm.checkedmphbIds = [];
                bindAllDllData(function (response) {
                    //BASIC MODULE
                    vm.searchObj["firstName"] = vm.txtsearchByName = savedSearchData.firstName;

                    vm.srchGenderTxt = savedSearchData.gender ? "Men" : "Women";
                    //vm.gndrTxtHisOrHer = savedSearchData.gender ? "he" : "she";
                    vm.searchObj["gender"] = vm.srchGender = savedSearchData.gender;
                    if (savedSearchData.minAge)
                        vm.searchObj["minAge"] = vm.minAge = savedSearchData.minAge;
                    else
                        vm.searchObj["minAge"] = vm.minAge;
                    if (savedSearchData.maxAge)
                        vm.searchObj["maxAge"] = vm.maxAge = savedSearchData.maxAge;
                    else
                        vm.searchObj["maxAge"] = vm.maxAge;

                    var savedRadius = savedSearchData.locRadius;
                    mpDistanceFuncG(function (response) {
                        angular.forEach(response, function (data) {
                            if (data.rdId == savedRadius) {
                                var rds = data.rdId == 6 ? (data.radius + "+") : data.radius;
                                vm.srchLocation = "Within " + rds + vm.pyrUnits;
                                vm.searchObj["locRadiusDistance"] = vm.locRadiusDistance = calculateRadius(units, rds);
                                vm.searchObj["locRadius"] = vm.SrchLocRadius = savedRadius;
                            }
                        });
                    });
                    vm.searchObj["isOnline"] = vm.onlineMatches = savedSearchData.isOnline;
                    vm.searchObj["isProfilePicUpld"] = vm.profilePhotos = savedSearchData.isProfilePicUpld;
                    vm.locType = savedSearchData.locType;

                    if (vm.locType == 1) {
                        vm.searchObj["latitude"] = vm.curlat;
                        vm.searchObj["longitute"] = vm.curlong;
                        vm.countryId = savedSearchData.countryId;
                        vm.searchObj["cityId"] = savedSearchData.cityId;
                    } else if (vm.locType == 2) {
                        vm.getMylocation();
                    } else if (vm.locType == 3) {
                        vm.otherLocation = true;
                        vm.searchObj["latitude"] = vm.OtherLocLatitude = savedSearchData.latitude;
                        vm.searchObj["longitute"] = vm.OtherLocLongitude = savedSearchData.longitute;
                        vm.locationCity = savedSearchData.cityId;
                        vm.countryId = savedSearchData.countryId;
                        if (savedSearchData.countryId != null && savedSearchData.cityId != null)
                            countryIntlSrv.BindCity('txtAsrchCurrLocCity', 'dvSrchCountry', savedSearchData.countryId, savedSearchData.cityId);
                    }

                    //BASIC MODULE END   

                    //ABOUT MODULE
                    vm.ethnicitiesDdl = response.aboutmeData.Ethnicity;
                    vm.religionsDdl = response.aboutmeData.Religion;
                    vm.areaofworksDdl = response.aboutmeData.AreaOfWork;
                    vm.statusDdl = response.aboutmeData.Status;
                    vm.degreeDdl = response.aboutmeData.Degree;
                    //vm.countriesDdl = response.aboutmeData.Countries;
                    //vm.statesDdl = response.aboutmeData.States;
                    //vm.citiesDdl = response.aboutmeData.Cities;
                    $("#tb2").attr("data-advnSrchAbt", "N");
                    if (savedSearchData.ethinicities) {
                        angular.forEach(savedSearchData.ethinicities.split(','), function (data) {
                            vm.checkedSrchECIds.push(parseInt(data));
                        });
                    }
                    vm.searchObj["ethinicities"] = vm.checkedSrchECIds.join();

                    vm.searchObj["areaWork"] = vm.AwId = savedSearchData.areaWork;
                    angular.forEach(vm.areaofworksDdl, function (data) {
                        if (data.awId == vm.AwId)
                            vm.awName = data.awName;
                    });

                    vm.searchObj["highestEdu"] = vm.hghtDgr = savedSearchData.highestEdu;
                    angular.forEach(vm.degreeDdl, function (data) {
                        if (data.val == vm.hghtDgr)
                            vm.highestDegree = data.txt;
                    });

                    if (savedSearchData.religions) {
                        angular.forEach(savedSearchData.religions.split(','), function (data) {
                            vm.checkedmpRlgnIds.push(parseInt(data));
                        });
                    }
                    vm.searchObj["religions"] = vm.checkedmpRlgnIds.join();
                    angular.forEach(vm.religionsDdl, function (data) {
                        if (vm.checkedmpRlgnIds != null) {
                            if (vm.checkedmpRlgnIds.indexOf(data.religionId) !== -1)
                                vm.checkedmpRlgnName.push(data.religionName);
                        }
                    });

                    if (savedSearchData.rShipStatus) {
                        angular.forEach(savedSearchData.rShipStatus.split(','), function (data) {
                            vm.checkedSrchRSSIds.push(parseInt(data));
                        });
                    }
                    vm.searchObj["rShipStatus"] = vm.checkedSrchRSSIds.join();

                    vm.searchObj["htCountry"] = vm.HTCountryId = savedSearchData.htCountry;
                    vm.searchObj["htCity"] = vm.htCityId = savedSearchData.htCity;
                    if (savedSearchData.htCountry != null && savedSearchData.htCity != null)
                        countryIntlSrv.BindCity('txtSrchHomeCity', 'dvSrchHomeCountry', savedSearchData.htCountry, savedSearchData.htCity);
                    //ABOUT MODULE END


                    //PERSONALITY MODULE
                    vm.ptraits = response.ptData;
                    if (savedSearchData.personalityTraits) {
                        angular.forEach(savedSearchData.personalityTraits.split(','), function (data) {
                            vm.checkedTrIds.push(parseInt(data));
                        });
                    }
                    vm.searchObj["personalityTraits"] = vm.checkedTrIds.join();

                    var result = [];
                    angular.forEach(vm.ptraits, function (data) {
                        if (vm.checkedTrIds != null) {
                            if (vm.checkedTrIds.indexOf(data.ptId) != -1) {
                                result.push(data);
                            }
                        }
                    });
                    vm.srchselectedTrts = result;
                    //PERSONALITY MODULE END

                    //APPEARANCE MODULE
                    vm.build = response.appearanceData.build;
                    vm.height = response.appearanceData.height;
                    vm.eyecolor = response.appearanceData.eyecolor;
                    vm.haircolor = response.appearanceData.haircolor;
                    $("#tb4").attr("data-advnSrchAprns", "N");

                    if (savedSearchData.eyeColor) {
                        angular.forEach(savedSearchData.eyeColor.split(','), function (data) {
                            vm.checkedSrchEyeClrIds.push(parseInt(data));
                        });
                    }
                    vm.searchObj["eyeColor"] = vm.checkedSrchEyeClrIds.join();

                    if (savedSearchData.hairColor) {
                        angular.forEach(savedSearchData.hairColor.split(','), function (data) {
                            vm.checkedSrchHairClrIds.push(parseInt(data));
                        });
                    }
                    vm.searchObj["hairColor"] = vm.checkedSrchHairClrIds.join();

                    if (savedSearchData.build) {
                        angular.forEach(savedSearchData.build.split(','), function (data) {
                            vm.checkedSrchBuildClrIds.push(parseInt(data));
                        });
                    }
                    vm.searchObj["build"] = vm.checkedSrchBuildClrIds.join();

                    vm.maxHeight = savedSearchData.maxHeight;
                    vm.searchObj["maxHeight"] = vm.maxHeight;
                    angular.forEach(response.appearanceData.height, function (data) {
                        if (data.val == vm.maxHeight)
                            vm.maxHeighttxt = data.txt;
                    });

                    vm.minHeight = savedSearchData.minHeight;
                    vm.searchObj["minHeight"] = vm.minHeight;
                    angular.forEach(response.appearanceData.height, function (data) {
                        if (data.val == vm.minHeight)
                            vm.minHeighttxt = data.txt;
                    });
                    //APPEARANCE MODULE END

                    //LIFE STYLE MODULE
                    vm.dietDdl = response.lifeStyleData.diet;
                    vm.smokeDdl = response.lifeStyleData.smoke;
                    vm.drinkDdl = response.lifeStyleData.drink;
                    vm.idealRelationshipDdl = response.lifeStyleData.IdealRelationShip;
                    //vm.childrenCntDdl = response.lifeStyleData.numOfChildren;
                    vm.childrenPrefDdl = response.lifeStyleData.childrenPref;
                    //vm.petsCntDdl = response.lifeStyleData.numOfPets;
                    vm.petsPrefDdl = response.lifeStyleData.petPref;
                    vm.langPrefDdl = response.lifeStyleData.language;
                    vm.familyLangDdl = response.lifeStyleData.language;
                    vm.religiousDdl = response.lifeStyleData.Religious;
                    vm.traditionalDdl = response.lifeStyleData.traditional;
                    $("#tb5").attr("data-advnSrchLfyStyl", "N");

                    if (savedSearchData.diet) {
                        angular.forEach(savedSearchData.diet.split(','), function (data) {
                            vm.checkedmpDtIds.push(parseInt(data));
                        });
                    }
                    vm.searchObj["diet"] = vm.checkedmpDtIds.join();


                    vm.smokeId = savedSearchData.smoke;
                    vm.searchObj["smoke"] = vm.smokeId;
                    angular.forEach(vm.smokeDdl, function (data) {
                        if (data.val == vm.smokeId)
                            vm.srchSmoke = data.txt;
                    });

                    vm.drinkId = savedSearchData.drink;
                    vm.searchObj["drink"] = vm.drinkId;
                    angular.forEach(vm.drinkDdl, function (data) {
                        if (data.val == vm.drinkId)
                            vm.srchDrink = data.txt;
                    });

                     $scope.selectedchildVal = savedSearchData.childrenCnt;
                    if (savedSearchData.childrenCnt != null)
                        vm.isChkChldrnCnt = false;
                    vm.searchObj["childrenCnt"] = $scope.selectedchildVal;
                    $scope.childrnCnt = $scope.selectedchildVal - 1;

                    vm.childPref = savedSearchData.children;
                    vm.searchObj["children"] = vm.childPref;
                    angular.forEach(vm.childrenPrefDdl, function (data) {
                        if (data.val == vm.childPref)
                            vm.srchChildPref = data.txt;
                    });

                    vm.religiosId = savedSearchData.religious;
                    vm.searchObj["religious"] = vm.religiosId;
                    angular.forEach(vm.religiousDdl, function (data) {
                        if (data.val == vm.religiosId)
                            vm.srchReligious = data.txt;
                    });

                    $scope.selectedpetVal = savedSearchData.petsCnt;
                    //vm.sliderValuePetsCnt = savedSearchData.religious;                   
                    if (savedSearchData.petsCnt != null)
                        vm.isChkPetsrnCnt = false;
                    vm.searchObj["petsCnt"] = $scope.selectedpetVal;
                    $scope.petsCnt = $scope.selectedpetVal - 1;

                    vm.petsPrefId = savedSearchData.pets;
                    vm.searchObj["pets"] = vm.petsPrefId;
                    angular.forEach(vm.petsPrefDdl, function (data) {
                        if (data.val == vm.petsPrefId)
                            vm.srchPetPref = data.txt;
                    });

                    vm.clrlHbtId = savedSearchData.traditional;
                    vm.searchObj["traditional"] = vm.clrlHbtId;
                    angular.forEach(vm.traditionalDdl, function (data) {
                        if (data.val == vm.clrlHbtId)
                            vm.srchCulturalHbts = data.txt;
                    });

                    vm.IdlRsId = savedSearchData.idealRelationship;
                    vm.searchObj["idealRelationship"] = vm.IdlRsId;
                    angular.forEach(vm.idealRelationshipDdl, function (data) {
                        if (data.val == vm.IdlRsId)
                            vm.srchIdlRlsp = data.txt;
                    });

                    if (savedSearchData.languages) {
                        angular.forEach(savedSearchData.languages.split(','), function (data) {
                            vm.checkedmpPrefLangIds.push(parseInt(data));
                        });
                    }
                    vm.searchObj["languages"] = vm.checkedmpPrefLangIds.join();
                    angular.forEach(vm.langPrefDdl, function (data) {
                        if (vm.checkedmpPrefLangIds != null) {
                            if (vm.checkedmpPrefLangIds.indexOf(data.val) !== -1)
                                vm.checkedmpPrefLangName.push(data.txt);
                        }
                    });
                    if (savedSearchData.fmlyLanguages) {
                        angular.forEach(savedSearchData.fmlyLanguages.split(','), function (data) {
                            vm.checkedmpFmlyLangIds.push(parseInt(data));
                        });
                    }
                    vm.searchObj["fmlyLanguages"] = vm.checkedmpFmlyLangIds.join();
                    angular.forEach(vm.langPrefDdl, function (data) {
                        if (vm.checkedmpFmlyLangIds != null) {
                            if (vm.checkedmpFmlyLangIds.indexOf(data.val) !== -1)
                                vm.checkedmpFmlyLangName.push(data.txt);
                        }
                    });

                    //LIFE STYLE MODULE END

                    //HOBBIES MODULE               
                    if (savedSearchData.hobbies) {
                        angular.forEach(savedSearchData.hobbies.split(','), function (data) {
                            vm.checkedmphbIds.push(parseInt(data));
                        });
                    }
                    vm.searchObj["hobbies"] = vm.checkedmphbIds.join();
                    var hbyResult = [];
                    angular.forEach(response.hbyData, function (data) {
                        if (vm.checkedmphbIds != null) {
                            if (vm.checkedmphbIds.indexOf(data.HobbyId) != -1) {
                                hbyResult.push(data);
                            }
                        }
                    });
                    vm.selectedHbs = hbyResult;

                    //HOBBIES MODULE END

                    //SORTBY MODULE               
                    vm.searchObj["sortBy"] = vm.srchBySrt;
                    //SORTBY MODULE END
                    calBackFun();
                    hideLoader();
                });
            }
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BINDING THE MODELS WITH DEFAULT SEARCH END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BINDING DROPDOWNS MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.ddlAbtMe = function () {
            // about me dropdowns service called
            if ($("#tb2").attr("data-advnSrchAbt") == "Y") {
                showLoader();
                selfprofileSrvc.StaticDropDownList(function (response, status) {
                    vm.ethnicitiesDdl = response.Ethnicity;
                    vm.religionsDdl = response.Religion;
                    vm.areaofworksDdl = response.AreaOfWork;
                    vm.statusDdl = response.Status;
                    vm.degreeDdl = response.Degree;
                    //vm.countriesDdl = response.Countries;
                    //vm.statesDdl = response.States;
                    //vm.citiesDdl = response.Cities;
                    $("#tb2").attr("data-advnSrchAbt", "N");
                    hideLoader();
                });
            }
        }

        vm.srchLocation = "";
        //location radius bind function
        mpDistanceFuncG(function (response) {
            angular.forEach(response, function (data) {
                if (data.rdId == vm.defaultLocRadius) {
                    var rds = data.rdId == 6 ? (data.radius + "+") : data.radius;
                    vm.srchLocation = "Within " + rds + " " + vm.pyrUnits;
                }
            });
        });
        function mpDistanceFuncG(callBackBasicData) {
            showLoader();
            advsrchSrvc.prefRadius(function (response, status) {
                if (status == 200) {
                    vm.ddlRadius = response;
                    callBackBasicData(response);
                    hideLoader();
                } else
                    hideLoader();
            });
        }

        vm.myAprnceDdls = function () {
            //My appearance ddls service called starts
            if ($("#tb4").attr("data-advnSrchAprns") == "Y") {
                showLoader();
                selfprofileSrvc.ddlsMyAppearence(function (response, status) {
                    vm.build = response.build;
                    vm.height = response.height;
                    vm.eyecolor = response.eyecolor;
                    vm.haircolor = response.haircolor;
                    $("#tb4").attr("data-advnSrchAprns", "N");
                    hideLoader();
                });
            }
        }
        vm.myLifeStyleDdls = function () {
            if ($("#tb5").attr("data-advnSrchLfyStyl") == "Y") {
                showLoader();
                selfprofileSrvc.ddlsMyLifeStyleDDlData(function (response, status) {
                    vm.dietDdl = response.diet;
                    vm.smokeDdl = response.smoke;
                    vm.drinkDdl = response.drink;
                    vm.idealRelationshipDdl = response.IdealRelationShip;
                    //vm.childrenCntDdl = response.numOfChildren;
                    vm.childrenPrefDdl = response.childrenPref;
                    //vm.petsCntDdl = response.numOfPets;
                    vm.petsPrefDdl = response.petPref;
                    vm.langPrefDdl = response.language;
                    vm.familyLangDdl = response.language;
                    vm.religiousDdl = response.Religious;
                    vm.traditionalDdl = response.traditional;
                    $("#tb5").attr("data-advnSrchLfyStyl", "N");
                    hideLoader();
                });
            }
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BINDING DROPDOWNS MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BASIC MODULE   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.selGender = function (gender) {
            vm.srchGender = gender;
            //vm.gndrTxtHisOrHer = gender ? "he" : "she";
        }
        vm.txtsearchByName = "";

        function setMMAgeByMemAge(memAge) {
            var age = memAge;
            vm.minAge = age - 5;
            if (vm.minAge < 18)
                vm.minAge = 18;
            vm.maxAge = age + 5;
            if (vm.maxAge > 99)
                vm.maxAge = 99;
        }
        vm.ageCheck = function () {
            if (vm.minAge || vm.maxAge) {
                vm.minAge = parseInt(vm.minAge);
                vm.maxAge = parseInt(vm.maxAge);

                if (vm.minAge < 18 || vm.minAge > 99)
                    vm.minAge = 18;

                if (vm.maxAge > 99 || vm.maxAge < 18)
                    vm.maxAge = 99;

                if (vm.minAge > vm.maxAge) {
                    var tempVal = vm.minAge;
                    vm.minAge = vm.maxAge;
                    vm.maxAge = tempVal;
                }
            }
        }

        vm.locationhide = function () {
            vm.dvbscMoreInfErr = false;
            vm.otherLocation = false;
        }
        vm.getMylocation = function () {
            vm.otherLocation = false;
            vm.dvbscMoreInfErr = false;
            getLatitudeLangitude();
        }
        function getLatitudeLangitude() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition, showError);
            } else {
                alert("Geolocation is not supported by this browser.");
            }
        }
        function showPosition(position) {
            vm.MyLocLatitude = position.coords.latitude;
            vm.MyLocLongitude = position.coords.longitude;
            if (vm.MyLocLatitude != "" && vm.MyLocLongitude != "") {
                getCountryCodeUsingLatLong(vm.MyLocLatitude, vm.MyLocLongitude, function (response) {
                    vm.countryId = response;
                });
            } else {
                vm.locType = 1;
            }
        }
        function showError() {
            vm.locType = 1;
            switch (error.code) {
                case error.PERMISSION_DENIED:
                    alert("User denied the request for Geolocation.");
                    break;
                case error.POSITION_UNAVAILABLE:
                    alert("Location information is unavailable.");
                    break;
                case error.TIMEOUT:
                    alert("The request to get user location timed out.");
                    break;
                case error.UNKNOWN_ERROR:
                    alert("An unknown error occurred.");
                    break;
            }
        }
        vm.locationvisible = function () {
            vm.otherLocation = true;
            countryIntlSrv.resetCountry("txtAsrchCurrLocCity", "dvSrchCountry");
        }
        vm.setRadius = function (rdsId, radius) {
            vm.locRadiusDistance = calculateRadius(units, radius);
            vm.SrchLocRadius = rdsId;
        }

        vm.profilePhotosChk = function () {
            vm.profilePhotos = !vm.profilePhotos;
        }

        vm.onlineMatchesChk = function () {
            vm.onlineMatches = !vm.onlineMatches;
        }

        //vm.CtyrErr = '';
        //vm.ctyCngEvnt = function () {
        //    if (vm.locationCity.length > 0)
        //        vm.CtyrErr = '';
        //    else
        //        vm.CtyrErr = 'eror';
        //}
        //vm.hmCtyCngEvnt = function () {
        //    if (vm.locationCity.length > 0)
        //        vm.hmCtyrErr = '';
        //    else
        //        vm.hmCtyrErr = 'eror';
        //}

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BASIC MODULE   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  ABOUT MODULE   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.ethnicityIdFunc = function (ethnicityId) {
            if (vm.checkedSrchECIds.indexOf(ethnicityId) == -1) {
                vm.checkedSrchECIds.push(ethnicityId);
            } else {
                var index = vm.checkedSrchECIds.indexOf(ethnicityId);
                vm.checkedSrchECIds.splice(index, 1);
            }
        }

        vm.awName = "Area of work";
        vm.areaofworkIdFunc = function (awId) {
            vm.AwId = awId;
        }

        vm.statusIdFunc = function (rsId) {
            if (vm.checkedSrchRSSIds.indexOf(rsId) == -1) {
                vm.checkedSrchRSSIds.push(rsId);
            } else {
                var index = vm.checkedSrchRSSIds.indexOf(rsId);
                vm.checkedSrchRSSIds.splice(index, 1);
            }
        }

        vm.checkedmpRlgnName = [];
        //displaying array in html view
        vm.RlgnIdTostring = function () {
            return vm.checkedmpRlgnName.join(",");
        };

        vm.RlgnIdFuncG = function (rlgnId) {
            if (vm.checkedmpRlgnIds.indexOf(rlgnId) == -1) {
                vm.checkedmpRlgnIds.push(rlgnId);
                for (var i = 0; i < vm.religionsDdl.length; i++) {
                    if (vm.religionsDdl[i].religionId == rlgnId) {
                        vm.checkedmpRlgnName.push(vm.religionsDdl[i].religionName);
                        break;
                    }
                }
            }
            else {
                var index = vm.checkedmpRlgnIds.indexOf(rlgnId);
                vm.checkedmpRlgnIds.splice(index, 1);
                vm.checkedmpRlgnName.splice(index, 1);
            }
        }

        vm.noRlgnPref = function () {
            vm.checkedmpRlgnIds = [];
            vm.checkedmpRlgnName = [];
            //$("#dvSrchRlgn").html("Religion");
        }


        vm.hghtDgr = null;
        vm.degreeIdFunc = function (hgstDegree) {
            vm.hghtDgr = hgstDegree;
        }

        vm.HTCountryId = null;
        vm.homeCountry = "Home country";
        //vm.HmcountryIdFunc = function (htCtryId) {
        //    vm.HTCountryId = htCtryId;
        //}
        vm.htCityId = null;

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  ABOUT MODULE END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PERSONALITY MODULE  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        vm.srchPrsnltyPop = function () {
            vm.myPrsnltyPopUp = true;
            selfprofileSrvc.PrsnltyTraitsListG(function (response) {
                if ($("#btnPtPopup").attr("data-mydata") == "N") {
                    var result = {
                    };
                    var key = 'ptcId';
                    for (var i = 0; i < response.length; i++) {
                        if (!result[response[i][key]]) {
                            result[response[i][key]] = [];
                        }
                        result[response[i][key]].push(response[i])
                    }
                    vm.PrsnltyTraitsList = result;
                    $("#btnPtPopup").attr("data-mydata", "Y");
                }
                else if ($("#btnPtPopup").attr("data-mydata") == "Y") {
                    vm.PrsnltyTraitsList;
                }
                vm.ptraits = response;
            });
            vm.bindPtIds();
        }
        vm.bindPtIds = function () {
            vm.checkedTrIds = [];
            angular.forEach(vm.srchselectedTrts, function (data) {
                vm.checkedTrIds.push(data.ptId);
            });
        }

        vm.srchprsnltyChkClick = function (ptId) {
            if (vm.checkedTrIds.indexOf(ptId) == -1) {
                vm.checkedTrIds.push(ptId);
            }
            else {
                var index = vm.checkedTrIds.indexOf(ptId);
                vm.checkedTrIds.splice(index, 1);
            }
        }
        vm.srchPrsnltyTrtsI = function () {
            var result = [];
            angular.forEach(vm.ptraits, function (data) {
                if (vm.checkedTrIds.indexOf(data.ptId) != -1) {
                    result.push(data);
                }
            });
            vm.srchselectedTrts = result;
        }
        vm.srchPTDel = function (ptId) {
            var index = vm.checkedTrIds.indexOf(ptId);
            vm.checkedTrIds.splice(index, 1);
            for (var i = vm.srchselectedTrts.length - 1; i >= 0; i--) {
                if (vm.srchselectedTrts[i].ptId == ptId) {
                    vm.srchselectedTrts.splice(i, 1);
                }
            }
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PERSONALITY MODULE END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  APPEARANCE MODULE    ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        vm.eyecolorIdFunc = function (eyeClrid) {
            if (vm.checkedSrchEyeClrIds.indexOf(eyeClrid) == -1) {
                vm.checkedSrchEyeClrIds.push(eyeClrid);
            } else {
                var index = vm.checkedSrchEyeClrIds.indexOf(eyeClrid);
                vm.checkedSrchEyeClrIds.splice(index, 1);
            }
        }
        vm.haircolorIdFunc = function (hairClrId) {
            if (vm.checkedSrchHairClrIds.indexOf(hairClrId) == -1) {
                vm.checkedSrchHairClrIds.push(hairClrId);
            } else {
                var index = vm.checkedSrchHairClrIds.indexOf(hairClrId);
                vm.checkedSrchHairClrIds.splice(index, 1);
            }
        }

        vm.buildIdFunc = function (buildId) {
            if (vm.checkedSrchBuildClrIds.indexOf(buildId) == -1) {
                vm.checkedSrchBuildClrIds.push(buildId);
            } else {
                var index = vm.checkedSrchBuildClrIds.indexOf(buildId);
                vm.checkedSrchBuildClrIds.splice(index, 1);
            }
        }
        vm.opnDdlhgt = function (event) {
            if (vm.minHeight != null)
                opnDdlhgt(event.target.id);
        }

        vm.maxHeighttxt = "Max Height";
        vm.maxHeightTextPrep = function () {
            return vm.maxHeighttxt;
        }

        vm.minHeighttxt = "Min Height";
        vm.minHeightTextPrep = function () {
            return vm.minHeighttxt;
        }
        vm.maxHeight = null;
        vm.maxNopreference = function () {
            vm.maxHeight = null;
            vm.maxHeighttxt = "Max Height";
        }
        vm.minHeight = null;
        vm.minNoPreference = function () {
            vm.minHeight = null;
            vm.minHeighttxt = "Min Height";
        }

        vm.maxHeightIdFunc = function (maxHeight, val) {
            if (vm.minHeight > maxHeight) {
                vm.maxHeight = vm.minHeight;
                vm.minHeight = maxHeight;
                for (var i = 0; i < vm.height.length; i++) {
                    if (vm.maxHeight == vm.height[i].val) {
                        vm.maxHeighttxt = vm.height[i].txt;
                    }
                    if (vm.minHeight == vm.height[i].val) {
                        vm.minHeighttxt = vm.height[i].txt;
                    }
                }
            } else {
                vm.maxHeight = maxHeight;
                vm.maxHeighttxt = val;
            }
        }
        vm.minHeightIdFunc = function (minHeight, val) {
            if (vm.maxHeight == null) {
                vm.minHeight = minHeight;
                for (var i = 0; i < vm.height.length; i++) {
                    if (vm.minHeight == vm.height[i].val) {
                        vm.minHeighttxt = vm.height[i].txt;
                    }
                }
            } else {
                if (vm.maxHeight >= minHeight) {
                    vm.minHeight = minHeight;
                    vm.minHeighttxt = val;
                } else {
                    vm.minHeight = vm.maxHeight;
                    vm.maxHeight = minHeight;
                    for (var i = 0; i < vm.height.length; i++) {
                        if (vm.maxHeight == vm.height[i].val) {
                            vm.maxHeighttxt = vm.height[i].txt;
                        }
                        if (vm.minHeight == vm.height[i].val) {
                            vm.minHeighttxt = vm.height[i].txt;
                        }
                    }
                }
            }
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  APPEARANCE MODULE END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/



        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  LIFESTYLE MODULE    ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.dietIdFunc = function (dietId) {
            if (vm.checkedmpDtIds.indexOf(dietId) == -1) {
                vm.checkedmpDtIds.push(dietId);
            }
            else {
                var index = vm.checkedmpDtIds.indexOf(dietId);
                vm.checkedmpDtIds.splice(index, 1);
            }
        }
        vm.srchSmoke = "Smoke";
        vm.smokeId = null;
        vm.smokeIdFunc = function (smkId) {
            vm.smokeId = smkId;
        }

        vm.srchDrink = "Drink";
        vm.drinkId = null;
        vm.drinkIdFunc = function (dnkId) {
            vm.drinkId = dnkId;
        }

        //CHILDREN SLIDER MODULE
        $scope.childrnCnt = null;
        vm.isChkChldrnCnt = true;
        vm.enableChldSlrd = function () { vm.isChkChldrnCnt = false; }
        //var ticksChldrnCnt = [0, 1, 2, 3, 4, 5];
        //vm.tickslabels = [1, 2, 3, 4, 5, 6]
        //vm.sliderTicksChldrnCnt = function () {
        //    return ticksChldrnCnt;
        //}
        $scope.childrnCnt = [{ 'val': 1, 'txt': 0 }, { 'val': 2, 'txt': 1 }, { 'val': 3, 'txt': 2 }, { 'val': 4, 'txt': 3 }, { 'val': 5, 'txt': 4 }, { 'val': 6, 'txt': 5 }]
        function getChldAttrs(chdrnCntArry, attr) {
            var ChldCntArray = [];
            angular.forEach(chdrnCntArry, function (item) {
                ChldCntArray.push(item[attr]);
            });
            return ChldCntArray;
        }
        $scope.chidrnCntLbls = {
                ticks: getChldAttrs($scope.childrnCnt, 'txt'),
                    ticks_labels: getChldAttrs($scope.childrnCnt, 'val'),
        };

        $scope.selectedchildVal = '';

        $scope.selectChldCnt = function ($event, value, chdrnCntArry) {
            $scope.selectedchildVal = chdrnCntArry[value];

        };

        vm.resetChldCnt = function () {
            vm.isChkChldrnCnt = true;
            $scope.childrnCnt = null;
            $scope.selectedchildVal = '';
        }
        vm.sldrChlClk = function () {
            if ($scope.selectedchildVal == '')
                $scope.selectedchildVal = 1;
        }
        //CHILDREN SLIDER MODULE END

        vm.srchChildPref = "Child preference";
        vm.childPref = null;

        vm.childrenPrefIdFunc = function (childPref) {
            vm.childPref = childPref;
        }

        vm.srchReligious = "Religious";
        vm.religiosId = null;
        vm.religiousIdFunc = function (rlglsId) {
            vm.religiosId = rlglsId;
        }

        //PETS SLIDER MODULE
        $scope.petsCnt = null;
        //var ticksPetsCnt = [0, 1, 2, 3];
        $scope.petsCnt = [{ 'val': 1, 'txt': 0 }, { 'val': 2, 'txt': 1 }, { 'val': 3, 'txt': 2 }, { 'val': 4, 'txt': 3 }]
        vm.isChkPetsrnCnt = true;
        vm.enablePetsSlrd = function () { vm.isChkPetsrnCnt = false; }
        //vm.sliderTicksPetsCnt = function () {
        //    return ticksPetsCnt;
        //}
        //vm.myFormatterPetsCnt = function (value) {
        //    return value;
        //}
        function getPtsAttrs(ptsArry, attr) {
            var petsCntArry = [];
            angular.forEach(ptsArry, function (item) {
                petsCntArry.push(item[attr]);
            })
            return petsCntArry;
        }
        $scope.petsCntLbls = {
                ticks: getPtsAttrs($scope.petsCnt, 'txt'),
                ticks_labels: getPtsAttrs($scope.petsCnt, 'val'),
        };

        $scope.selectedpetVal = '';

        $scope.selectpetCnt = function ($event, value, ptsArry) {
            $scope.selectedpetVal = ptsArry[value];

        };
        vm.resetPetsCnt = function () {
            $scope.selectedpetVal = '';
            $scope.petsCnt = null;
            vm.isChkPetsrnCnt = true;
        }
        vm.sldrPetsCnt = function () {
            if ($scope.selectedpetVal == '')
                $scope.selectedpetVal = 1;
        }
        //PETS SLIDER MODULE END

        vm.srchPetPref = "Pet Preference";
        vm.petsPrefId = null;
        vm.petsCntIdFunc = function (petsId) {
            vm.petsPrefId = petsId;
        }

        vm.srchCulturalHbts = "Traditional";
        vm.clrlHbtId = null;
        vm.traditionalIdFunc = function (clrlHbt) {
            vm.clrlHbtId = clrlHbt;
        }

        vm.srchIdlRlsp = "Relationship type";
        vm.IdlRsId = null;
        vm.idealRelationshipIdFunc = function (rsId) {
            vm.IdlRsId = rsId;
        }

        vm.checkedmpPrefLangName = [];
        vm.PrefLangIdTostring = function () {
            return vm.checkedmpPrefLangName.join(",");
        };
        vm.langPrefIdFunc = function (langId) {
            if (vm.checkedmpPrefLangIds.indexOf(langId) == -1) {
                vm.checkedmpPrefLangIds.push(langId);
                for (var i = 0; i < vm.langPrefDdl.length; i++) {
                    if (vm.langPrefDdl[i].val == langId) {
                        vm.checkedmpPrefLangName.push(vm.langPrefDdl[i].txt);
                        break;
                    }
                }
            }
            else {
                var index = vm.checkedmpPrefLangIds.indexOf(langId);
                vm.checkedmpPrefLangIds.splice(index, 1);
                vm.checkedmpPrefLangName.splice(index, 1);
            }
        }
        vm.noPrefLangPref = function () {
            vm.checkedmpPrefLangIds = [];
            vm.checkedmpPrefLangName = [];
            //$("#dvSrchPL").html("Preferred language");
        }

        vm.checkedmpFmlyLangName = [];

        vm.FmlyLangIdTostring = function () {
            return vm.checkedmpFmlyLangName.join(",");
        };

        //for getting selected checkboxes Ids on checkbox click event
        vm.FmlyLangIdFuncG = function (langId) {
            if (vm.checkedmpFmlyLangIds.indexOf(langId) == -1) {
                vm.checkedmpFmlyLangIds.push(langId);
                for (var i = 0; i < vm.familyLangDdl.length; i++) {
                    if (vm.familyLangDdl[i].val == langId) {
                        vm.checkedmpFmlyLangName.push(vm.familyLangDdl[i].txt);
                        break;
                    }
                }
            }
            else {
                var index = vm.checkedmpFmlyLangIds.indexOf(langId);
                vm.checkedmpFmlyLangIds.splice(index, 1);
                vm.checkedmpFmlyLangName.splice(index, 1);
            }
        }

        vm.noFmlyLangPref = function () {
            vm.checkedmpFmlyLangIds = [];
            vm.checkedmpFmlyLangName = [];
            //$("#dvSrchFL").html("Family language");
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  LIFESTYLE MODULE END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  HOBBIES MODULE    ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        vm.hbList = function () {
            vm.srchShowHbPop = true;
            selfprofileSrvc.HobbiesList(function (response) {
                if ($("#btnAddHobby").attr("data-mydata") == "N") {
                    var result = {
                    };
                    var key = 'categoryName';
                    for (var i = 0; i < response.length; i++) {
                        if (!result[response[i][key]]) {
                            result[response[i][key]] = [];
                        }
                        result[response[i][key]].push(response[i]);
                    }
                    // finding key length from Json Object
                    var keyLength = Object.keys(result).length;
                    var totalLength = response.length;
                    var lengthByArray = totalLength / keyLength;

                    vm.hbTblL1 = Math.round(lengthByArray / 2);
                    vm.hbTblL2 = (lengthByArray) - vm.hbTblL1;
                    vm.hobbylst = response;
                    vm.lstHobbies = result;
                    $("#btnAddHobby").attr("data-mydata", "Y");
                }
                else if ($("#btnAddHobby").attr("data-mydata") == "Y") {
                    vm.lstHobbies;
                }
            });
            vm.bindHobbyids();
        }
        vm.bindHobbyids = function () {
            vm.checkedmphbIds = [];
            angular.forEach(vm.selectedHbs, function (data) {
                vm.checkedmphbIds.push(data.HobbyId);
            });
        }
        vm.hobbyChkClick = function (hbId) {
            if (vm.checkedmphbIds.indexOf(hbId) == -1) {
                vm.checkedmphbIds.push(hbId);
            }
            else {
                var index = vm.checkedmphbIds.indexOf(hbId);
                vm.checkedmphbIds.splice(index, 1);
            }
        }
        vm.saveHobbies = function () {
            var result = [];
            angular.forEach(vm.hobbylst, function (data) {
                if (vm.checkedmphbIds.indexOf(data.HobbyId) != -1) {
                    result.push(data);
                }
            });
            vm.selectedHbs = result;
        }
        vm.hbyDel = function (hobbyId) {
            var indx = vm.checkedmphbIds.indexOf(hobbyId);
            vm.checkedmphbIds.splice(indx, 1);
            for (var i = vm.selectedHbs.length - 1; i >= 0; i--) {
                if (vm.selectedHbs[i].HobbyId == hobbyId) {
                    vm.selectedHbs.splice(i, 1);
                }
            }
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  HOBBIES MODULE END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  CLEAR/RESET  SEARCH DATA  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        vm.searchClear = function () {
            // BASIC MODULE
            vm.txtsearchByName = "";
            vm.srchGender = vm.memGenderPref;
            vm.srchGenderTxt = vm.srchGender == true ? "Men" : "Women";
            //vm.gndrTxtHisOrHer = vm.srchGender == true ? "he" : "she";
            $("#dvSrchGender").html(vm.srchGenderTxt);
            setMMAgeByMemAge(vm.memAge);
            $("#dvSrchLocation").html(vm.srchLocation);
            vm.locRadiusDistance = calculateRadius(units, 500);
            vm.SrchLocRadius = vm.defaultLocRadius;
            $("#dvSrchCountry").html(vm.locationCntry);
            $("#dvSrchCountry").html('Country');
            vm.countryId = vm.defaultCntryId;
            vm.locType = 1;
            vm.locationhide();
            vm.profilePhotos = true;
            vm.onlineMatches = false;
            vm.locationCity = null;
            vm.MyLocLatitude = "";
            vm.MyLocLongitude = "";
            vm.OtherLocLatitude = "";
            vm.OtherLocLongitude = "";
            vm.dvbscMoreInfErr = false;
            // BASIC MODULE

            //ABOUT
            vm.checkedSrchECIds = [];
            $('#dvECchk').find('input[type=checkbox]:checked').removeAttr('checked');
            $("#dvSrchAoW").html(vm.awName);
            vm.AwId = null;
            vm.checkedSrchRSSIds = [];
            $('#dvRsChk').find('input[type=checkbox]:checked').removeAttr('checked');
            vm.checkedmpRlgnIds = [];
            vm.checkedmpRlgnName = [];
            //$("#dvSrchRlgn").html("No Preference");
            $("#dvSrchHD").html(vm.highestDegree);
            vm.hghtDgr = null;
            vm.HTCountryId = null;
            $("#dvSrchHCountry").html(vm.homeCountry);
            countryIntlSrv.resetCountry("txtAsrchCurrLocCity", "dvSrchCountry");
            countryIntlSrv.resetCountry("txtSrchHomeCity", "dvSrchHomeCountry");
            vm.htCityId = null;
            //ABOUT END

            //PERSONALITY
            vm.checkedTrIds = [];
            vm.srchselectedTrts = [];
            //PERSONALITY END

            //APPEARANCE
            vm.checkedSrchEyeClrIds = [];
            $('#dvEyeClr').find('input[type=checkbox]:checked').removeAttr('checked');
            vm.checkedSrchHairClrIds = [];
            $('#dvHrClr').find('input[type=checkbox]:checked').removeAttr('checked');
            vm.checkedSrchBuildClrIds = [];
            $('#dvBld').find('input[type=checkbox]:checked').removeAttr('checked');
            vm.maxHeight = null;
            vm.maxHeighttxt = "Max Height";
            vm.minHeight = null;
            vm.minHeighttxt = "Min Height";
            vm.minHeightTextPrep();
            vm.maxHeightTextPrep();
            //APPEARANCE END

            //LIFESTYLE
            $scope.petsCnt = null;
            $scope.childrnCnt = null;
            $scope.selectedchildVal = '';
            $scope.selectedpetVal = '';
            vm.isChkChldrnCnt = true;
            vm.isChkPetsrnCnt = true;
            vm.checkedmpDtIds = [];
            $('#dvDiet').find('input[type=checkbox]:checked').removeAttr('checked');
            vm.smokeId = null;
            $("#dvSrchSH").html(vm.srchSmoke);
            vm.drinkId = null;
            $("#dvSrchDH").html(vm.srchDrink);
            vm.childPref = null;
            $("#dvSrchWC").html(vm.srchChildPref);
            vm.religiosId = null;
            $("#dvSrchRH").html(vm.srchReligious);
            vm.petsPrefId = null;
            $("#dvSrchWP").html(vm.srchPetPref);
            vm.clrlHbtId = null;
            $("#dvSrchCH").html(vm.srchCulturalHbts);
            vm.IdlRsId = null;
            $("#dvSrchHCountryIR").html(vm.srchIdlRlsp);
            vm.checkedmpPrefLangIds = [];
            vm.checkedmpPrefLangName = [];
            //$("#dvSrchPL").html("Preferred language");
            vm.checkedmpFmlyLangIds = [];
            vm.checkedmpFmlyLangName = [];
            //$("#dvSrchFL").html("Family language");
            //LIFESTYLE END

            //HOBBIES
            vm.checkedmphbIds = [];
            vm.selectedHbs = [];
            //HOBBIES END
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  CLEAR/RESET  SEARCH DATA END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH OBJECT WITH DEFAULT VALUES ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        function searchObj() {
            vm.searchObj =
                   {
                       "memberId": getSessionSrvc.p_mId(),
                       "sId": 1,
                       "locRadius": null,
                       "locType": vm.locType,
                       "gender": vm.srchGender,
                       "countryId": null,
                       "cityId": null,
                       "genderPref": vm.memGender,
                       "latitude": "",
                       "longitute": "",
                       "minAge": vm.minAge,
                       "maxAge": vm.maxAge,
                       "isOnline": false,
                       "isProfilePicUpld": true,
                       "firstName": "",
                       "rShipStatus": "",
                       "eyeColor": "",
                       "hairColor": "",
                       "build": "",
                       "minHeight": null,
                       "maxHeight": null,
                       "diet": "",
                       "smoke": null,
                       "drink": null,
                       "highestEdu": null,
                       "childrenCnt": null,
                       "children": null,
                       "petsCnt": null,
                       "pets": null,
                       "religions": "",
                       "ethinicities": "",
                       "religious": null,
                       "traditional": null,
                       "areaWork": null,
                       "idealRelationship": null,
                       "htCountry": null,
                       "htCity": null,
                       "languages": null,
                       "fmlyLanguages": null,
                       "hobbies": null,
                       "personalityTraits": "",
                       "sortBy": vm.srchBySrt,
                       "locRadiusDistance": null,
                   }
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH OBJECT WITH DEFAULT VALUES END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH API CALL ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.SortByShow = false;
        vm.pgNo = 1;
        vm.pgSize = 200;
        vm.srchRslt = [];
        vm.localPgSize = 40;
        vm.limitToMemTileCnt = 40;
        vm.contentExists = true;
        //vm.dvNoResult = false;
        $("#noSrchRslt").hide();
        vm.ShowViewMore = false;

        function searchMembers(pageNo, pgSize, fromAutoScroll) {
            showLoader();
            $("#hidefter").css("padding-bottom", "0px");
            //vm.dvNoResult = false;
            $("#noSrchRslt").hide();

            //vm.searchType == 1 for advanced search
            if (vm.searchType == 1) {
                vm.srchRspMsg = "Success! I think we did good!";
                advsrchSrvc.getSearchResponse(vm.searchObj, pageNo, pgSize, vm.sortOrder, function (response, status) {
                    vm.BindSearchCallBack(response, status, fromAutoScroll)
                });
            }
                //vm.searchType ==  for suggestion search
            else if (vm.searchType == 2) {
                vm.srchRspMsg = "Success! We found matches for '" + vm.sugName + "'";
                vm.SugSearchObj.sortBy = vm.srchBySrt;
                advsrchSrvc.MemSuggestionSrch(vm.SugSearchObj, vm.pgNo, vm.pgSize, vm.sortOrder, function (response, status) {
                    vm.BindSearchCallBack(response, status, fromAutoScroll)
                });
            }
        }

        vm.BindSearchCallBack = function (response, status, fromAutoScroll) {
            if (status == 200 && response.length > 0) {
                vm.isSrchCmplt = true;
                if (response.length < vm.localPgSize)
                    vm.ShowViewMore = false;
                else
                    vm.ShowViewMore = true;
                if (response.length < vm.pgSize)
                    vm.contentExists = false;
                else
                    vm.contentExists = true;
                vm.SortByShow = true;
                if (fromAutoScroll) {
                    angular.forEach(response, function (data) {
                        vm.srchRslt.push(data);
                    });
                    hideLoader();
                    vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
                } else {
                    vm.srchRslt = response;
                    hideLoader();
                    vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
                }
                //for the first time scrool the window to middle
                if (vm.localPgSize == vm.limitToMemTileCnt) {
                    if (vm.stopScrooling == false) {
                        $("html, body").animate({
                            scrollTop: $("#searchResults").offset().top - 80
                        }, 1000);
                        //$("html, body").animate({
                        //    scrollTop: $(document).height() / 2 + 180
                        //}, 500);
                        $timeout(function () {
                            hideLoader();
                            vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
                        }, 500, true);
                    }
                }
                if (response.length <= 5) {
                    $("#hidefter").css("padding-bottom", "300px");
                    if (vm.searchType == 1) {
                        vm.srchRspMsg = "Oh no… looks kinda deserted here. Try expanding your filter!";
                    } else if (vm.searchType == 2) {
                        vm.srchRspMsg = "Oh no… looks kinda deserted here for '" + vm.sugName + "'. Try another filter!";
                    }
                }
            } else if (status == 204 || response.length == 0) {
                $("#hidefter").css("padding-bottom", "0px");
                vm.contentExists = false;
                vm.ShowViewMore = false;
                if (vm.srchRslt.length == 0)
                    //vm.dvNoResult = true;
                    $("#noSrchRslt").show();
                $('#noSrchRslt').isInViewport();
                $timeout(function () {
                    hideLoader();
                    vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
                }, 500, true);
            }
        }
        vm.viewMore = function () {
            vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/acnLdr.svg";
            if (vm.contentExists && (vm.srchRslt.length == (vm.pgNo * vm.pgSize))) {
                //vm.shwScrollDiv = true;
                if ((vm.limitToMemTileCnt == (vm.srchRslt.length))) {
                    vm.pgNo++;
                    searchMembers(vm.pgNo, vm.pgSize, true);
                }
            }
            vm.limitToMemTileCnt += vm.localPgSize;
            if (vm.srchRslt.length < vm.limitToMemTileCnt)
                vm.ShowViewMore = false;
        }
        // view more call in tile repeater when we block the tiles 
        $rootScope.$on("tileBlockSearch", function () { // calling from matchTile         
            if (vm.ShowViewMore == true) { vm.viewMore(); }
            else if ($('#blcktile match-tile').length == 0) {
                vm.ShowViewMore = false;
                //vm.myFavDataEmptyDv = true;
            };
        });
        $scope.$on('onMatchTileImageLoad', function () {
            vm.vmImgSrc = "https://pccdn.pyar.com/pcimgs/viewmore.png";
        });
        vm.isSrchCmplt = true;
        vm.searchBySort = function () {
            if (vm.isSrchCmplt == true) {
                vm.isSrchCmplt = false;
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
                vm.sortOrder = 1;
                vm.stopScrooling = true;
                prepareSearchObject();
                searchMembers(vm.pgNo, vm.pgSize, false);
            }
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH API CALL END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PREPARE SEARCH OBJECT  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        //**********************************************************************************************************************************************************************/

        function prepareSearchObject() {
            //BASIC MODULE
            // need to change country id based on location type selected .
            vm.searchObj["firstName"] = vm.txtsearchByName;
            vm.searchObj["gender"] = vm.srchGender;
            vm.searchObj["minAge"] = parseInt(vm.minAge);
            vm.searchObj["maxAge"] = parseInt(vm.maxAge);
            vm.searchObj["isOnline"] = vm.onlineMatches;
            vm.searchObj["isProfilePicUpld"] = vm.profilePhotos == true ? true : false;
            vm.searchObj["locRadius"] = vm.SrchLocRadius;
            vm.searchObj["locRadiusDistance"] = vm.locRadiusDistance;
            vm.searchObj["locType"] = vm.locType;
            if (vm.locType == 1) {
                vm.searchObj["latitude"] = vm.curlat;
                vm.searchObj["longitute"] = vm.curlong;
                vm.searchObj["countryId"] = vm.defaultCntryId;
                vm.searchObj["cityId"] = vm.cityId;
            } else if (vm.locType == 2) {
                vm.searchObj["latitude"] = vm.MyLocLatitude;
                vm.searchObj["longitute"] = vm.MyLocLongitude;
                vm.searchObj["countryId"] = vm.countryId;
                vm.searchObj["cityId"] = vm.locationCity;
            } else if (vm.locType == 3) {
                vm.searchObj["latitude"] = vm.OtherLocLatitude;
                vm.searchObj["longitute"] = vm.OtherLocLongitude;
                vm.searchObj["countryId"] = vm.countryId;
                vm.searchObj["cityId"] = vm.locationCity;
            }
            //BASIC MODULE END             

            //ABOUT MODULE
            vm.searchObj["ethinicities"] = vm.checkedSrchECIds.join();
            vm.searchObj["areaWork"] = vm.AwId;
            vm.searchObj["rShipStatus"] = vm.checkedSrchRSSIds.join();
            vm.searchObj["religions"] = vm.checkedmpRlgnIds.join();
            vm.searchObj["highestEdu"] = vm.hghtDgr;
            vm.searchObj["htCountry"] = vm.HTCountryId;
            vm.searchObj["htCity"] = vm.htCityId;
            //ABOUT MODULE END

            //PERSONALITY MODULE
            vm.bindPtIds();
            vm.searchObj["personalityTraits"] = vm.checkedTrIds.join();
            //PERSONALITY MODULE END

            //APPEARANCE MODULE
            vm.searchObj["eyeColor"] = vm.checkedSrchEyeClrIds.join();
            vm.searchObj["hairColor"] = vm.checkedSrchHairClrIds.join();
            vm.searchObj["build"] = vm.checkedSrchBuildClrIds.join();
            vm.searchObj["minHeight"] = vm.minHeight;
            vm.searchObj["maxHeight"] = vm.maxHeight;
            //APPEARANCE MODULE END

            //LIFE STYLE MODULE
            vm.searchObj["diet"] = vm.checkedmpDtIds.join();
            vm.searchObj["smoke"] = vm.smokeId;
            vm.searchObj["drink"] = vm.drinkId;
            vm.searchObj["childrenCnt"] = $scope.selectedchildVal;
            vm.searchObj["children"] = vm.childPref;
            vm.searchObj["religious"] = vm.religiosId;
            vm.searchObj["pets"] = vm.petsPrefId;
            vm.searchObj["petsCnt"] = $scope.selectedpetVal;
            vm.searchObj["traditional"] = vm.clrlHbtId;
            vm.searchObj["idealRelationship"] = vm.IdlRsId;
            vm.searchObj["languages"] = vm.checkedmpPrefLangIds.join();
            vm.searchObj["fmlyLanguages"] = vm.checkedmpFmlyLangIds.join();
            //LIFE STYLE MODULE END

            //HOBBIES MODULE
            vm.bindHobbyids();
            vm.searchObj["hobbies"] = vm.checkedmphbIds.join();
            //HOBBIES MODULE END

            //SORTBY MODULE
            vm.searchObj["sortBy"] = vm.srchBySrt;
            //SORTBY MODULE END
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PREPARE SEARCH OBJECT END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH BUTTON CLICK MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.advanceSearch = function () {
            vm.ShowViewMore = false;
            $(document).height(screen.height);
            vm.searchType = 1;
            resetSearchResult();
            if ((vm.locType == 3) && (vm.countryId == null || vm.locationCity == null)) {
                vm.dvbscMoreInfErr = true;
                //if (vm.locationCity == null && vm.countryId != null)
                //    vm.CtyrErr = 'eror';
            }
            else if (!vm.minAge || !vm.maxAge)
                vm.dvbscMoreInfErr = true;
            else if (vm.HTCountryId != null && vm.htCityId == "") {
                vm.dvabtMoreInfErr = true;
                //vm.hmCtyrErr = 'eror';
            }
            else {
                vm.dvbscMoreInfErr = false;
                vm.dvabtMoreInfErr = false;
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
                vm.sortOrder = 1;
                vm.srchRslt = [];
                vm.SortByShow = false;
                vm.stopScrooling = false;
                prepareSearchObject();
                searchMembers(vm.pgNo, vm.pgSize, false);
            }
        }
        vm.advanceSavedSearchSearch = function () {
            vm.getSavedSearchById(function () {
                vm.dvbscMoreInfErr = false;
                vm.dvabtMoreInfErr = false;
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
                vm.sortOrder = 1;
                vm.srchRslt = [];
                vm.SortByShow = false;
                vm.stopScrooling = false;
                vm.searchType = 1;
                prepareSearchObject();
                searchMembers(vm.pgNo, vm.pgSize, false);
            });
        }
        function resetSearchResult() {
            vm.SortByShow = false;
            vm.pgNo = 1;
            vm.pgSize = 200;
            vm.srchRslt = [];
            vm.limitToMemTileCnt = 40;
            vm.contentExists = true;
            //vm.dvNoResult = false;
            $("#noSrchRslt").hide();
        }
        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH BUTTON CLICK MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        vm.clearSortData = function () {
            vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
            vm.stopScrooling = true;
            vm.pgNo = 1;
            vm.pgSize = 200;
            vm.sortOrder = 1;
            vm.srchBySrt = 2;
            prepareSearchObject();
            searchMembers(vm.pgNo, vm.pgSize, false);
        }


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SAVE SEARCH MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.markRemovetxt = "Marks";
        //bind the save search on tab click
        vm.BindSavedSearchData = function () {
            bindSavedSearch();
        }
        //bind the save search on tab click end

        //function for getting the saved seach
        function bindSavedSearch() {
            if ($("#tb7").attr("data-advnSrchSvdSrch") == "Y") {
                showLoader();
                advsrchSrvc.getSaveSearchData(mId, function (response, status) {
                    if (status == 200) {
                        vm.savedSrch = response;
                        angular.forEach(vm.savedSrch, function (data) {
                            if (data.isDefault == 1) {
                                vm.mssId = data.mssId;
                                vm.markRemovetxt = "Remove";
                            }
                        });
                        isSaveChkd(vm.savedSrch);
                        $("#tb7").attr("data-advnSrchSvdSrch", "N");
                        hideLoader();
                    }
                });
            }
        }
        //function for getting the saved seach

        //save search button click
        vm.btnSaveSearch = function () {
            vm.txtSaveSearchName = "";
            vm.kpSvdSrcCls = "";
            advsrchSrvc.saveSearchCount(mId, function (response, status) {
                $("#mdlSrchName").modal("show");
                if (status == 200 && response == 10) {
                    vm.saveSearchPopup = false;
                    vm.mnySaveSrchPopup = true;
                } else {
                    vm.saveSearchPopup = true;
                    vm.mnySaveSrchPopup = false;
                    $timeout(function () { $("#txtSrchName").focus() }, 200);
                }

            });
        }
        //save search button click end

        //save search service call
        vm.SaveSearch = function () {
            if (vm.txtSaveSearchName) {
                prepareSearchObject();
                //this holds  primary key of radius 
                vm.searchObj["locRadius"] = vm.SrchLocRadius;
                //this holds calculated radius value (based on units)
                vm.searchObj["locRadiusDistance"] = vm.locRadiusDistance;
                showLoader();
                advsrchSrvc.saveSearch(vm.searchObj, vm.txtSaveSearchName, function (response, status) {
                    if (response && status == 200) {
                        vm.txtSaveSearchName = "";
                        $("#mdlSrchName").modal("hide");
                        vm.saveSearchPopup = false;
                        vm.mnySaveSrchPopup = false;
                        $("#tb7").attr("data-advnSrchSvdSrch", "Y");
                        bindSavedSearch();
                    }
                    hideLoader();
                });
            } else {
                vm.kpSvdSrcCls = 'eror';
                vm.txtSvdSrchPlhldr = "Search Name";
            }
        }
        vm.viewSavedSrch = function () {
            $("#mdlSrchName").modal('hide');
            vm.saveSearchPopup = false;
            vm.mnySaveSrchPopup = false;
            bindSavedSearch();
            $("#tb1,#tb2,#tb3,#tb4,#tb5,#tb6").parent().removeClass('active');
            $("#tb7").parent().addClass('active');
            $("#tb7").click();
        }
        vm.deleteSavedSrch = function () {
            if (vm.mssId != "" && vm.mssId != null && vm.mssId != undefined && mId != null) {
                $("#mdlSrchDlt").modal('show');
            }
        }
        //save search service call end
        vm.isdltimgDisabled = function () {
            if (!vm.noSelected || vm.savedSrch.length == 0) {
                return 'https://pccdn.pyar.com/pcimgs/deletedsbl.png ';
            } else {
                return 'https://pccdn.pyar.com/pcimgs/delete.png';
            }
        }

        //default search text bold and select dropdown
        vm.savedRdBtnClk = function (mssId) {
            vm.dftStatus = true;
            vm.noSelected = true;
            vm.mssId = mssId;
            vm.markRemovetxt = "Marks";
            defaultSearchBold(mssId);
        }

        //bind the model with saved data
        vm.getSavedSearchById = function (calBackFun) {
            vm.ShowViewMore = false;
            if (vm.mssId != "" && vm.mssId != null && vm.mssId != undefined && mId != null) {
                advsrchSrvc.getSavedSearchById(vm.mssId, mId, function (response, status) {
                    if (status == 200) {
                        bindDefaultSearchData(response, calBackFun);
                    }
                });
            }
        }
        //check if any radiobutton checked for saved results
        function isSaveChkd(savedRslt) {
            if (savedRslt) {
                vm.noSelected = savedRslt.some(function (item) {
                    return item.isDefault == true || item.isDefault == 1;
                });
            }
        }
        //bind the model with saved data
        function defaultSearchBold(mssId) {
            for (var i = 0; i < vm.savedSrch.length; i++) {
                if (vm.savedSrch[i].mssId == mssId && vm.savedSrch[i].isDefault == 1) {
                    vm.markRemovetxt = "Remove";
                    vm.dftStatus = false;
                }
            }
        }
        //default search text bold and select dropdown end

        //set default and remove default service call
        vm.dftStatus = false;
        vm.MarkandRemoveDefault = function () {
            if (vm.mssId != "" && vm.mssId != null && vm.mssId != undefined) {
                showLoader();
                advsrchSrvc.SetRemoveDafaultSearch(vm.mssId, mId, vm.dftStatus, function (response, status) {
                    if (status == 200) {
                        updateSearchObject();
                    }
                    if (vm.dftStatus == true) {
                        vm.searchClear();
                        vm.noSelected = false;
                    } else { vm.noSelected = true; }

                    hideLoader();
                });
            }
        }
        //set default and remove default service call

        //delete save search button click
        vm.DeleteSearch = function () {
            if (vm.mssId != "" && vm.mssId != null && vm.mssId != undefined) {
                advsrchSrvc.DeleteSaveSearch(vm.mssId, mId, function (response, status) {
                    if (status == 200) {
                        $("#mdlSrchDlt").modal('hide');
                        vm.searchClear();
                        vm.noSelected = false;
                        vm.markRemovetxt = "Marks";
                        angular.forEach(vm.savedSrch, function (data) {
                            if (data.mssId == vm.mssId)
                                vm.savedSrch.splice(vm.savedSrch.indexOf(data), 1);
                        });
                        vm.mssId = null;
                    }
                });
            }
        }
        //delete save search button click

        //manage save search object if database get updated successfully
        function updateSearchObject() {
            if (vm.dftStatus == false) {
                vm.markRemovetxt = "Marks";
                vm.dftStatus = true;
                for (var i = 0; i < vm.savedSrch.length; i++) {
                    vm.savedSrch[i].isDefault = 0;
                }
                vm.mssId = null;
            } else {
                for (var i = 0; i < vm.savedSrch.length; i++) {
                    if (vm.savedSrch[i].isDefault == 1)
                        vm.savedSrch[i].isDefault = 0;
                    if (vm.savedSrch[i].mssId == vm.mssId) {
                        vm.savedSrch[i].isDefault = 1;
                        defaultSearchBold(vm.mssId);
                    }
                }
            }
        }
        //manage save search object if database get updated successfully end


        vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
        vm.sortOrder = 1;
        vm.sortBySearch = function () {
            vm.stopScrooling = true;
            if ($("#imgSrt").attr('src') == "https://pccdn.pyar.com/pcimgs/asndng.png") {
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/dsndng.png";
                vm.sortOrder = 0;
                searchMembers(vm.pgNo, vm.pgSize, false);
            } else {
                vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
                vm.sortOrder = 1;
                searchMembers(vm.pgNo, vm.pgSize, false);
            }
        }

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SAVE SEARCH MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        //Gettting Profile Pic in action popups
        //function GetPopPic(popPic, gender) {
        //    if (popPic == null) {
        //        if (gender == true) { return "https://pccdn.pyar.com/pcimgs/profilePicM.jpg"; }
        //        else if (gender == false) {
        //            return "https://pccdn.pyar.com/pcimgs/profilePicF.jpg";
        //        }
        //    }
        //    else {
        //        return popPic;
        //    }
        //}

        //city intelligence module
        $scope.$on("countryBind", function (e, txtId, countryId, data) {
            if (txtId == "txtAsrchCurrLocCity") {
                vm.countryId = data.countryId;
                vm.locationCity = data.cityId;
                vm.OtherLocLatitude = data.lat;
                vm.OtherLocLongitude = data.long;
            }
            else if (txtId == "txtSrchHomeCity") {

                vm.HTCountryId = data.countryId;
                vm.htCityId = data.cityId;
            }
            //console.log("bind : " + txtId + "  --  " + countryId + "  --  " + JSON.stringify(data));
        });

        $scope.$on("countryUnBind", function (e, txtId, countryId) {
            //console.log("unbind : " + txtId + "  --  " + countryId);
            if (txtId == "txtAsrchCurrLocCity") {
                vm.countryId = null;
                vm.locationCity = null;
                vm.OtherLocLatitude = null; 
                vm.OtherLocLongitude = null;
            }
            else if (txtId == "txtSrchHomeCity") {
                vm.HTCountryId = null;
                vm.htCityId = null;
            }
        });

        $rootScope.$on("bindCountry", function (e, countries) {
            vm.countries = countries;
        });

        vm.setCountry = function (txtId, dvId, countryId) {
            //$("#txtCityName").prop('disabled', false);
           // $("#txtHomeCityName").prop('disabled', false);
            countryIntlSrv.SetCountry(txtId, dvId, countryId);
        }
        vm.setDfaultCntry = function () {
            $("#txtAsrchCurrLocCity").val('');
            $("#txtAsrchCurrLocCity").prop('disabled', true);
            vm.countryId = null;
            vm.locationCity = null;
            vm.OtherLocLatitude = null;
            vm.OtherLocLongitude = null;
            vm.HTCountryId = null;
            vm.htCityId = null;
        }
        vm.sethmDfaultCntry = function () {
            $("#txtSrchHomeCity").val('');
            $("#txtSrchHomeCity").prop('disabled', true);
        }
        countryIntlSrv.initSrvc();
        //city intelligence module


        //country short name using lattitude and longitude
        function getCountryCodeUsingLatLong(lat, long, callBackFun) {
            if (lat != "" && long != "") {
                $.ajax({
                    url: 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' + lat + ',' + long + '&sensor=true',
                    success: function (response) {
                        if (response.results.length > 0) {
                            var formatted_address = response.results[0].formatted_address;
                            var addressArray = formatted_address.split(",");
                            var cntryName = addressArray[addressArray.length - 1];
                            angular.forEach(response, function (key1) {
                                angular.forEach(key1[0].address_components, function (key2) {
                                    if (key2.long_name.trim().toLowerCase() == cntryName.trim().toLowerCase()) {
                                        var shortName = key2.short_name;
                                        advsrchSrvc.getCountryIdByShortName(shortName, function (response, status) {
                                            if (status == 200) {
                                                //alert(response);
                                                callBackFun(response);
                                            }
                                        });
                                    }
                                });
                            });
                        }
                        else {
                            alert("No location available for provided details.");
                        }
                    }
                });
            }
            else {
                alert("latitude and longitudes are required");
            }
        }
        //country short name using lattitude and longitude end

        //SEARCH SUGGESTIONS MODULE START
        vm.bindSearchSuggestions = function () {
            advsrchSrvc.getSearchSuggestions(mId, function (response, status) {
                if (status == 200) {
                    vm.SrchSuggestionLst = response;
                }
            });
        }
        vm.bindSearchSuggestions();
        //refType 1 for pt and 2 for hobby       
        vm.searchBySuggestion = function (refId, refType, sugName) {
            vm.ShowViewMore = false;
            bindSearchSuggetion(refId, refType, sugName);
        }
        function bindSearchSuggetion(refId, refType, sugName) {
            vm.srchRspMsg = "Success! We found matches for  '" + sugName + "'";
            vm.sugName = sugName;
            vm.searchType = 2;
            resetSearchResult();
            advsrchSrvc.GetMemberBasicSearchSuggestionInfo(mId, function (response, status) {
                if (status == 200) {
                    vm.suggestion = refId;
                    vm.suggestionType = refType;
                    var minAge = 0, maxAge = 0;
                    if (response.minAge)
                        minAge = response.minAge;
                    else {
                        minAge = vm.minAge;
                    }
                    if (response.maxAge)
                        maxAge = response.maxAge;
                    else
                        maxAge = vm.maxAge;

                    //console.log(response);

                    angular.forEach(vm.ddlRadius, function (data) {
                        if (data.rdId == response.locRadius) {
                            var radiusDistance = calculateRadius(units, data.radius);
                            vm.SugSearchObj = {
                                "memberId": mId, "gender": vm.memGenderPref, "genderPref": vm.memGender, "minAge": minAge,
                                "maxAge": maxAge, "locRadius": response.locRadius, "locRadiusDistance": radiusDistance, "countryId": response.countryId, "lat": response.latitude,
                                "long": response.longitute, "suggestionType": vm.suggestionType, "suggestion": vm.suggestion, "sortBy": vm.srchBySrt
                            };
                            MemberSuggestionSrch();
                        }
                    });
                }
            });
        }
        function MemberSuggestionSrch() {
            searchMembers();
        }
        //SEARCH SUGGESTIONS MODULE START END

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS END )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        //vm.NameLimit = 15; //Memeber Name Limit. after 15 Letters showing 3dots.
        vm.stateCntryLimit = 20; //State & country Limit. after 20 Letters showing 3dots. 
        //vm.flirtlgtImg = "https://pccdn.pyar.com/pcimgs/actions/flirt-red.svg";
        //vm.flirtImg = "https://pccdn.pyar.com/pcimgs/actions/flirt.svg";
        //vm.fvrtdImg = "https://pccdn.pyar.com/pcimgs/actions/fvrtd.svg";
        //vm.fvImg = "https://pccdn.pyar.com/pcimgs/actions/fvrt.svg";
        //vm.setFavIcnImg = function (favType) {
        //    if (favType == 1) return vm.fvrtdImg;
        //    else return vm.fvImg;
        //}

        //vm.setFlirtIcnImg = function (flirtType) {
        //    if (flirtType == 1) return vm.flirtlgtImg;
        //    else return vm.flirtImg;
        //}

        vm.txtsearchPlaceHolder = "Name";

        vm.txtsearchChnage = function () {
            vm.kpCls = 'bgWht';
            if (vm.txtsearchByName && vm.txtsearchByName.length > 30) {
                vm.txtsearchByName = ""; vm.kpCls = 'eror'; vm.txtsearchPlaceHolder = "Must be < 30 characters";
                vm.searchTxtBlur = "searchTxt";
                $("#searchTextNm").blur();
            }
            else if (!vm.txtsearchByName) { vm.txtsearchByName = ""; vm.kpCls = ''; vm.txtsearchPlaceHolder = "Name"; }
            else { vm.txtsearchPlaceHolder = "Name"; }
        }

        vm.txtsearchCheck = function () {
            if (vm.searchTxtBlur != "searchTxt") {
                vm.searchTxtBlur = "";
                if (!vm.txtsearchByName) {
                    vm.txtsearchByName = ""; vm.kpCls = ''; vm.txtsearchPlaceHolder = "Name";
                }
            } else {
                vm.searchTxtBlur = "";
            }
        }

        $(document).ready(function () {
            $("body").click(function (event) {
                if (event.target.id != "searchTextNm") {
                    if (!vm.txtsearchByName) {
                        vm.txtsearchByName = ""; vm.kpCls = ''; vm.txtsearchPlaceHolder = "Name";
                        $scope.$digest();
                    }
                }
            });
        });

        vm.txtSvdSrchPlhldr = "Search Name";
        vm.txtSaveSearchChnage = function () {
            vm.kpSvdSrcCls = 'bgWht';
            if (vm.txtSaveSearchName && vm.txtSaveSearchName.length > 150) {
                vm.txtSaveSearchName = ""; vm.kpSvdSrcCls = 'eror'; vm.txtSvdSrchPlhldr = "Must be < 150 characters";
            }
            else if (!vm.txtSaveSearchName) { vm.txtSaveSearchName = ""; vm.kpSvdSrcCls = ''; vm.txtSvdSrchPlhldr = "Search Name"; }
            else { vm.txtSvdSrchPlhldr = "Search Name"; vm.kpSvdSrcCls = ''; }
        }

        vm.txtSaveSearchCheck = function () {
            if (!vm.txtSaveSearchName) {
                vm.txtSaveSearchName = ""; vm.kpSvdSrcCls = ''; vm.txtSvdSrchPlhldr = "Search Name";
            }
        }

    }]);
