﻿angular.module('app').controller('basicsrchCtrl', ['getSessionSrvc', 'basicsrchSrvc', '$scope', '$location', '$rootScope', 'countryIntlSrv', 'msgSrvc', 'cmnSrvc', '$window', '$state', '$timeout', 'hbySearchFact',
    function (getSessionSrvc, basicsrchSrvc, $scope, $location, $rootScope, countryIntlSrv, msgSrvc,cmnSrvc, $window, $state, $timeout, hbySearchFact) {
    var vm = this;

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  VARAIBLE DECLARATION   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.txtsearchByName = "";
    vm.profilePhotos = true;
    vm.onlineMatches = false;
    var mId = getSessionSrvc.p_mId();
    vm.srchBySrt = 2;
    vm.defaultLocRadius = 5;
    vm.locationCity = null;
    vm.locType = 1;
    var units = getSessionSrvc.p_uts();
    vm.pyrUnits = pyrUntsTxt(units);
    vm.SrchLocRadiusDistance = calculateRadius(units, 500);
    //vm.frmClrSrch = false;
    vm.stopScrooling = false;
    vm.SrchLocRadius = vm.defaultLocRadius;
    vm.pgLdCmplt = false;
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  VARAIBLE DECLARATION END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BIND WITH DEFAULTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    getMemData(function () {
        vm.memGender = vm.memSearchResponse.gender;
        searchObj();
        vm.defaultCntryId = vm.memSearchResponse.countryId;
        vm.searchObj["countryId"] = vm.countryId = vm.memSearchResponse.countryId;
        //vm.curstateId = vm.memSearchResponse.stateId;
        vm.searchObj["lat"] = vm.curlat = vm.memSearchResponse.lat;
        vm.searchObj["long"] = vm.curlong = vm.memSearchResponse.long;
        vm.searchObj["sId"] = vm.memSearchResponse.sId;
        vm.memGenderPref = vm.memSearchResponse.genderPref;
        vm.memAge = calculateAge(vm.memSearchResponse.dob);
        setMMAgeByMemAge(vm.memAge);
        vm.srchGender = vm.memSearchResponse.genderPref;
        vm.srchGenderTxt = vm.memSearchResponse.genderPref ? "Men" : "Women";
        var hbySearch = hbySearchFact.gethbySearchData();
        if (hbySearch != undefined && hbySearch != null && hbySearch != '') {
            hbySearch = jQuery.parseJSON(hbySearchFact.gethbySearchData());
            bindSearchSuggetion(hbySearch.refId, hbySearch.refType, hbySearch.sugName);
            hbySearchFact.sethbySearchData(null);
        }
        vm.pgLdCmplt = true;
        hideLoader();
    });
    function getMemData(callBackBasicData) {
        if ($("#dvMemData").attr("data-memData") == "Y") {
            basicsrchSrvc.getMemberData(mId, function (response, status) {
                if (status == 200) {
                    vm.memSearchResponse = response;
                    $("#dvMemData").attr("data-memData", "N");
                    callBackBasicData();
                }
            });
        }
    }

    function defaults() {
        vm.dvbscMoreInfErr = false;
        vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
        vm.sortOrder = 1;
        vm.srchRslt = [];
        vm.SortByShow = false;
    }
    //location radius bind function
    SearchDistanceFuncG(function (response) {
        angular.forEach(response, function (data) {
            if (data.rdId == vm.defaultLocRadius) {
                var rds = data.rdId == 6 ? (data.radius + "+") : data.radius;
                vm.srchLocation = "Within " + rds + " " + vm.pyrUnits;
            }
        });
    });
    function SearchDistanceFuncG(callBackBasicData) {
        showLoader();
        basicsrchSrvc.prefRadius(function (response, status) {
            if (status == 200) {
                vm.ddlRadius = response;
                callBackBasicData(response);
            }
            hideLoader();
            //    hideLoader();
            //} else
            //    hideLoader();
        });
    }


    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BIND WITH DEFAULTS END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BASIC MODULE   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.selGender = function (gender) {
        vm.srchGender = gender;
    }
    function setMMAgeByMemAge(memAge) {
        var age = memAge;
        vm.minAge = age - 5;
        if (vm.minAge < 18)
            vm.minAge = 18;
        vm.maxAge = age + 5;
        if (vm.maxAge > 99)
            vm.maxAge = 99;
    }
    vm.ageCheck = function () {
        if (vm.minAge || vm.maxAge) {
            vm.minAge = parseInt(vm.minAge);
            vm.maxAge = parseInt(vm.maxAge);

            if (vm.minAge < 18 || vm.minAge > 99)
                vm.minAge = 18;

            if (vm.maxAge > 99 || vm.maxAge < 18)
                vm.maxAge = 99;

            if (vm.minAge > vm.maxAge) {
                var tempVal = vm.minAge;
                vm.minAge = vm.maxAge;
                vm.maxAge = tempVal;
            }
        }
    }

    vm.locationhide = function () {
        vm.dvbscMoreInfErr = false;
        vm.otherLocation = false;
    }
    vm.getMylocation = function () {
        vm.otherLocation = false;
        vm.dvbscMoreInfErr = false;
        getLatitudeLangitude();
    }
    function getLatitudeLangitude() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition, showError);
        } else {
            alert("Geolocation is not supported by this browser.");
        }
    }
    function showPosition(position) {
        vm.MyLocLatitude = position.coords.latitude;
        vm.MyLocLongitude = position.coords.longitude;
        if (vm.MyLocLatitude != "" && vm.MyLocLongitude != "") {
            getCountryCodeUsingLatLong(vm.MyLocLatitude, vm.MyLocLongitude, function (response) {
                vm.countryId = response;
            });
        } else {
            vm.locType = 1;
        }
    }
    function showError() {
        vm.locType = 1;
        switch (error.code) {
            case error.PERMISSION_DENIED:
                alert("User denied the request for Geolocation.");
                break;
            case error.POSITION_UNAVAILABLE:
                alert("Location information is unavailable.");
                break;
            case error.TIMEOUT:
                alert("The request to get user location timed out.");
                break;
            case error.UNKNOWN_ERROR:
                alert("An unknown error occurred.");
                break;
        }
    }
    vm.locationvisible = function () {
        countryIntlSrv.resetCountry("txtBsrchCurrLocCity", "dvSrchCountry");
        vm.otherLocation = true;
    }
    vm.setRadius = function (rdsId, radius) {
        vm.SrchLocRadiusDistance = calculateRadius(units, radius);
        vm.SrchLocRadius = rdsId;
    }

    vm.profilePhotosChk = function () {
        vm.profilePhotos = !vm.profilePhotos;
    }

    vm.onlineMatchesChk = function () {
        vm.onlineMatches = !vm.onlineMatches;
    }

    //vm.CtyrErr = '';
    //vm.ctyCngEvnt = function () {
    //    if (vm.locationCity.length > 0)
    //        vm.CtyrErr = '';
    //    else
    //        vm.CtyrErr = 'eror';
    //}
    //vm.hmCtyCngEvnt = function () {
    //    if (vm.locationCity.length > 0)
    //        vm.hmCtyrErr = '';
    //    else
    //        vm.hmCtyrErr = 'eror';
    //}

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BASIC MODULE   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH OBJECT WITH DEFAULT VALUES ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    function searchObj() {
        vm.searchObj =
               {
                   "memberId": getSessionSrvc.p_mId(),
                   "sId": 1,
                   "locRadius": null,
                   "locRadiusDistance": null,
                   "locType": vm.locType,
                   "gender": vm.srchGender,
                   "countryId": null,
                   "cityId": null,
                   "genderPref": vm.memGender,
                   "lat": "",
                   "long": "",
                   "minAge": vm.minAge,
                   "maxAge": vm.maxAge,
                   "isOnline": false,
                   "isProfilePicUpld": true,
                   "firstName": "",
                   "rsStatus": "",
                   "sortBy": vm.srchBySrt
               }
    }
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH OBJECT WITH DEFAULT VALUES END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/




    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  CLEAR/RESET  SEARCH DATA  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    vm.searchClear = function () {
        // BASIC MODULE
        vm.txtsearchByName = "";
        vm.srchGender = vm.memGenderPref;
        vm.srchGenderTxt = vm.srchGender == true ? "Men" : "Women";
        $("#sbscsgndr").html(vm.srchGenderTxt);
        setMMAgeByMemAge(vm.memAge);
        $("#sbscslcn").html(vm.srchLocation);
        vm.SrchLocRadiusDistance = calculateRadius(units, 500);
        vm.SrchLocRadius = vm.defaultLocRadius;
        $("#dvSrchCountry").html(vm.locationCntry);
        countryIntlSrv.resetCountry("txtBsrchCurrLocCity", "dvSrchCountry");
        vm.countryId = vm.defaultCntryId;
        vm.locType = 1;
        vm.curlat = vm.memSearchResponse.lat;
        vm.curlong = vm.memSearchResponse.long;
        vm.locationhide();
        vm.profilePhotos = true;
        vm.onlineMatches = false;
        vm.locationCity = null;
        vm.MyLocLatitude = "";
        vm.MyLocLongitude = "";
        vm.OtherLocLatitude = "";
        vm.OtherLocLongitude = "";
        // BASIC MODULE
    }
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  CLEAR/RESET  SEARCH DATA END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/



    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH BUTTON CLICK MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.BasicSearch = function () {
        vm.ShowViewMore = false;
        $(document).height(screen.height);
        vm.searchType = 1;
        if ((vm.locType == 3) && (vm.countryId == null || vm.locationCity == null)) {
            vm.dvbscMoreInfErr = true;
            //if (vm.locationCity == null && vm.countryId != null)
            //    vm.CtyrErr = 'eror';
        }
        else if (!vm.minAge || !vm.maxAge)
            vm.dvbscMoreInfErr = true;
        else {
            defaults();
            vm.stopScrooling = false;
            prepareSearchObject();
            searchMembers(vm.pgNo, vm.pgSize, false);
        }
    }
    function resetSearchResult() {
        vm.SortByShow = false;
        vm.pgNo = 1;
        vm.pgSize = 200;
        vm.srchRslt = [];
        vm.limitToMemTileCnt = 40;
        vm.contentExists = true;
        //vm.dvNoResult = false;
        $("#noSrchRslt").hide();

    }
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH BUTTON CLICK MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    vm.clearSortData = function () {
        vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
        vm.stopScrooling = true;
        vm.pgNo = 1;
        vm.pgSize = 200;
        vm.sortOrder = 1;
        vm.srchBySrt = 2;
        //vm.frmClrSrch = true;
        prepareSearchObject();
        searchMembers(vm.pgNo, vm.pgSize, false);
    }
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PREPARE SEARCH OBJECT  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    //**********************************************************************************************************************************************************************/

    function prepareSearchObject() {
        //BASIC MODULE
        // need to change country id based on location type selected .
        vm.searchObj["firstName"] = vm.txtsearchByName;
        vm.searchObj["gender"] = vm.srchGender;
        vm.searchObj["minAge"] = parseInt(vm.minAge);
        vm.searchObj["maxAge"] = parseInt(vm.maxAge);
        vm.searchObj["isOnline"] = vm.onlineMatches;
        vm.searchObj["isProfilePicUpld"] = vm.profilePhotos == true ? true : false;
        vm.searchObj["locRadius"] = vm.SrchLocRadius;
        vm.searchObj["locRadiusDistance"] = vm.SrchLocRadiusDistance;
        vm.searchObj["locType"] = vm.locType;
        if (vm.locType == 1) {
            vm.searchObj["lat"] = vm.curlat;
            vm.searchObj["long"] = vm.curlong;
            vm.searchObj["countryId"] = vm.defaultCntryId;
        } else if (vm.locType == 2) {
            vm.searchObj["lat"] = vm.MyLocLatitude;
            vm.searchObj["long"] = vm.MyLocLongitude;
            vm.searchObj["countryId"] = vm.countryId;
            vm.searchObj["cityId"] = vm.locationCity;
        } else if (vm.locType == 3) {
            vm.searchObj["lat"] = vm.OtherLocLatitude;
            vm.searchObj["long"] = vm.OtherLocLongitude;
            vm.searchObj["countryId"] = vm.countryId;
            vm.searchObj["cityId"] = vm.locationCity;
        }
        //BASIC MODULE END             

        //SORTBY MODULE
        vm.searchObj["sortBy"] = vm.srchBySrt;
        //SORTBY MODULE END
    }

    vm.sortOrder = 1;
    vm.sortBySearch = function () {
        vm.stopScrooling = true;
        if ($("#imgSrt").attr('src') == "https://pccdn.pyar.com/pcimgs/asndng.png") {
            vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/dsndng.png";
            vm.sortOrder = 0;
            searchMembers(vm.pgNo, vm.pgSize, false);
        } else {
            vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
            vm.sortOrder = 1;
            searchMembers(vm.pgNo, vm.pgSize, false);
        }
    }
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PREPARE SEARCH OBJECT END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/


    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH API CALL ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.SortByShow = false;
    vm.pgNo = 1;
    vm.pgSize = 200;
    vm.srchRslt = [];
    vm.localPgSize = 40;
    vm.limitToMemTileCnt = 40;
    vm.contentExists = true;
    //vm.dvNoResult = false;
    $("#noSrchRslt").hide();
    vm.ShowViewMore = false;

    function searchMembers(pageNo, pgSize, fromAutoScroll) {
        showLoader();
        $("#blcktile").css("padding-bottom", "0px");
        //vm.dvNoResult = false;
        $("#noSrchRslt").hide();

        //vm.searchType == 1 for Basic search
        if (vm.searchType == 1) {
            vm.srchRspMsg = "Success! I think we did good!";
            basicsrchSrvc.getSearchResponse(vm.searchObj, pageNo, pgSize, vm.sortOrder, function (response, status) {
                vm.BindSearchCallBack(response, status, fromAutoScroll)
            });
        }
            //vm.searchType ==  for suggestion search
        else if (vm.searchType == 2) {
            vm.srchRspMsg = "Success! We found matches for '" + vm.sugName + "'";
            vm.SugSearchObj.sortBy = vm.srchBySrt;
            basicsrchSrvc.MemSuggestionSrch(vm.SugSearchObj, vm.pgNo, vm.pgSize, vm.sortOrder, function (response, status) {
                vm.BindSearchCallBack(response, status, fromAutoScroll)
            });
        }
    }

    vm.BindSearchCallBack = function (response, status, fromAutoScroll) {
        if (status == 200 && response.length > 0) {
            vm.isSrchCmplt = true;
            if (response.length < vm.localPgSize)
                vm.ShowViewMore = false;
            else
                vm.ShowViewMore = true;
            if (response.length < vm.pgSize)
                vm.contentExists = false;
            else
                vm.contentExists = true;
            vm.SortByShow = true;
            if (fromAutoScroll) {
                angular.forEach(response, function (data) {
                    vm.srchRslt.push(data);
                });
                hideLoader();
            } else {
                vm.srchRslt = response;
                hideLoader();
            }
            if (vm.localPgSize == vm.limitToMemTileCnt) {
                if (vm.stopScrooling == false) {
                    $("html, body").animate({
                        scrollTop: $("#searchResults").offset().top - 80
                    }, 1000);
                    //$("html, body").animate({
                    //    scrollTop: $(document).height() / 2 + 180
                    //}, 500);
                    $timeout(function () {
                        hideLoader();
                    }, 500, true);
                }
            }
            //}
            if (response.length <= 5) {
                $("#blcktile").css("padding-bottom", "300px");
                if (vm.searchType == 1) {
                    vm.srchRspMsg = "Oh no… looks kinda deserted here. Try expanding your filter!";
                } else if (vm.searchType == 2) {
                    vm.srchRspMsg = "Oh no… looks kinda deserted here for '" + vm.sugName + "'. Try another filter!";
                }
            }
        } else if (status == 204 || response.length == 0) {
            $("#blcktile").css("padding-bottom", "0px");
            vm.contentExists = false;
            vm.ShowViewMore = false;
            if (vm.srchRslt.length == 0)
                //vm.dvNoResult = true;
                $("#noSrchRslt").show();
            $('#noSrchRslt').isInViewport();
            $timeout(function () {
                hideLoader();
            }, 500, true);
        }
    }

    vm.viewMore = function () {
        if (vm.contentExists && (vm.srchRslt.length == (vm.pgNo * vm.pgSize))) {
            //vm.shwScrollDiv = true;
            if ((vm.limitToMemTileCnt == (vm.srchRslt.length))) {
                vm.pgNo++;
                searchMembers(vm.pgNo, vm.pgSize, true);
            }
        }
        vm.limitToMemTileCnt += vm.localPgSize;
        if (vm.srchRslt.length < vm.limitToMemTileCnt)
            vm.ShowViewMore = false;
    }
        // view more call in tile repeater when we block the tiles 
    $rootScope.$on("tileBlockSearch", function () { // calling from matchTile         
        if (vm.ShowViewMore == true) { vm.viewMore(); }
        else if ($('#blcktile match-tile').length == 0) {
            vm.ShowViewMore = false;
            //vm.myFavDataEmptyDv = true;
        };
    });

    vm.isSrchCmplt = true;
    vm.searchBySort = function () {
        if (vm.isSrchCmplt == true) {
            vm.isSrchCmplt = false;
            vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
            vm.sortOrder = 1;
            vm.stopScrooling = true;
            prepareSearchObject();
            searchMembers(vm.pgNo, vm.pgSize, false);
        }
    }

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH API CALL END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/


    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    //Gettting Profile Pic in action popups
    //function GetPopPic(popPic, gender) {
    //    if (popPic == null) {
    //        if (gender == true) { return "https://pccdn.pyar.com/pcimgs/profilePicM.jpg"; }
    //        else if (gender == false) {
    //            return "https://pccdn.pyar.com/pcimgs/profilePicF.jpg";
    //        }
    //    }
    //    else {
    //        return popPic;
    //    }
    //}



    //city intelligence module
    $scope.$on("countryBind", function (e, txtId, countryId, data) {
        if (txtId == "txtBsrchCurrLocCity") {
            vm.countryId = data.countryId;
            vm.locationCity = data.cityId;
            vm.OtherLocLatitude = data.lat;
            vm.OtherLocLongitude = data.long;
        }
        //else if (txtId == "txtHomeCityName") {
        //    vm.HTCountryId = data.countryId;
        //    vm.htCityId = data.cityId;
        //}
        console.log("bind : " + txtId + "  --  " + countryId + "  --  " + JSON.stringify(data));
    });

    $scope.$on("countryUnBind", function (e, txtId, countryId) {
        console.log("unbind : " + txtId + "  --  " + countryId);
        vm.countryId = null;
        vm.locationCity = null;
    });

    $rootScope.$on("bindCountry", function (e, countries) {
        vm.countries = countries;
    });

    vm.setCountry = function (txtId, dvId, countryId) {
        //$("#txtBsrchCurrLocCity").prop('disabled', false);
        countryIntlSrv.SetCountry(txtId, dvId, countryId);
    }
    vm.setDfaultCntry = function () {
        $("#txtBsrchCurrLocCity").val('');
        $("#txtBsrchCurrLocCity").prop('disabled', true);
        vm.countryId = null;
        vm.locationCity = null;
    }
    countryIntlSrv.initSrvc();
    //city intelligence module


    //country short name using lattitude and longitude
    function getCountryCodeUsingLatLong(lat, long, callBackFun) {
        if (lat != "" && long != "") {
            $.ajax({
                url: 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' + lat + ',' + long + '&sensor=true',
                success: function (response) {
                    if (response.results.length > 0) {
                        var formatted_address = response.results[0].formatted_address;
                        var addressArray = formatted_address.split(",");
                        var cntryName = addressArray[addressArray.length - 1];
                        angular.forEach(response, function (key1) {
                            angular.forEach(key1[0].address_components, function (key2) {
                                if (key2.long_name.trim().toLowerCase() == cntryName.trim().toLowerCase()) {
                                    //callBackFun(key2.short_name);
                                    var shortName = key2.short_name;
                                    //alert(shortName);
                                    basicsrchSrvc.getCountryIdByShortName(shortName, function (response, status) {
                                        if (status == 200) {
                                            //alert(response);
                                            callBackFun(response);
                                        }
                                    });
                                }
                            });
                        });
                    }
                    else {
                        alert("No location available for provided details.");
                    }
                }
            });
        }
        else {
            alert("latitude and longitudes are required");
        }
    }
    //country short name using lattitude and longitude end

    //SEARCH SUGGESTIONS MODULE START
    vm.bindSearchSuggestions = function () {
        basicsrchSrvc.getSearchSuggestions(mId, function (response, status) {
            if (status == 200) {
                vm.SrchSuggestionLst = response;
            }
        });
    }
    vm.bindSearchSuggestions();
    //refType 1 for pt and 2 for hobby
    vm.searchBySuggestion = function (refId, refType, sugName) {
        vm.ShowViewMore = false;
        bindSearchSuggetion(refId, refType, sugName);
    }
    function bindSearchSuggetion(refId, refType, sugName) {
        vm.sugName = sugName;
        vm.sortingImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.png";
        vm.searchType = 2;
        resetSearchResult();
        basicsrchSrvc.GetMemberBasicSearchSuggestionInfo(mId, function (response, status) {
            if (status == 200) {
                vm.suggestion = refId;
                vm.suggestionType = refType;
                var minAge = 0, maxAge = 0;
                if (response.minAge)
                    minAge = response.minAge;
                else {
                    minAge = vm.minAge;
                }
                if (response.maxAge)
                    maxAge = response.maxAge;
                else
                    maxAge = vm.maxAge;

                angular.forEach(vm.ddlRadius, function (data) {
                    if (data.rdId == response.locRadius) {
                        var locRadiusDistance = calculateRadius(units, data.radius);
                        vm.SugSearchObj = {
                            "memberId": mId, "gender": vm.memGenderPref, "genderPref": vm.memGender, "minAge": minAge,
                            "maxAge": maxAge, "locRadius": response.locRadius, "locRadiusDistance": locRadiusDistance, "countryId": response.countryId, "lat": response.latitude,
                            "long": response.longitute, "suggestionType": vm.suggestionType, "suggestion": vm.suggestion, "sortBy": vm.srchBySrt
                        };
                        MemberSuggestionSrch();
                    }
                });
            }
        });
    }
    function MemberSuggestionSrch() {
        searchMembers();
    }
    //SEARCH SUGGESTIONS MODULE START END


    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS END )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.advanceSearch = function () {
        if (cmnSrvc.isTrialOrPrmExpired()) $("#getPremiumPopup").modal('show'); //check trail expired or premium expired
        else showMobileVerificationPop();
    };
    vm.GetPremium = function () {
        $("#getPremiumPopup").modal('hide');
        //showMobileVerificationPop();
        $window.location.href = '/payment.html';
    }

    vm.txtsearchPlaceHolder = "Name";
    vm.txtsearchChnage = function () {
        vm.kpCls = 'bgWht';
        if (vm.txtsearchByName && vm.txtsearchByName.length > 30) {
            vm.txtsearchByName = ""; vm.kpCls = 'eror'; vm.txtsearchPlaceHolder = "Must be < 30 characters";
            vm.searchTxtBlur = "searchTxt";
            $("#searchTextNm").blur();
        }
        else if (!vm.txtsearchByName) { vm.txtsearchByName = ""; vm.kpCls = ''; vm.txtsearchPlaceHolder = "Name"; }
        else { vm.txtsearchPlaceHolder = "Name"; }
    }
    vm.txtsearchCheck = function () {
        if (vm.searchTxtBlur != "searchTxt") {
            vm.searchTxtBlur = "";
            if (!vm.txtsearchByName) {
                vm.txtsearchByName = ""; vm.kpCls = ''; vm.txtsearchPlaceHolder = "Name";
            }
        } else {
            vm.searchTxtBlur = "";
        }
    }
    $(document).ready(function () {
        $("body").click(function (event) {
            if (event.target.id != "searchTextNm") {
                if (!vm.txtsearchByName) {
                    vm.txtsearchByName = ""; vm.kpCls = ''; vm.txtsearchPlaceHolder = "Name";
                    $scope.$digest();
                }
            }
        });
    });


}]);