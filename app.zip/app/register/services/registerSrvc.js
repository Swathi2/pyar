﻿angular.module("app").service('registerSrvc', ['$http', function ($http) {

    // Step-1: Email cheking
    this.RegEmailCheck = function (fn, eml, Pwd, funCallBack) {
        var data = { fn: fn, eml: eml, Pwd: Pwd }
        var url = getApiDomainUrl() + "/api/registersignin/pcemlreg";
       // var url = getApiDomainUrl() + "/api/registersignin/regs";
        //var url = "http://localhost:64055/api/registersignin/regs";
        PostServiceByURL($http, url, data, funCallBack);
    }
    //end

    //Step-2: registering member
    this.Register = function (memberId, secQ, secA, funCallBack) {
        //Response Code:  1. invalid Id , 2: no recored found (or) loginType mismatch, 3: email sent fail 4: email sent success
        var data = { id: memberId, secQ: secQ, secA: secA }
        var url = getApiDomainUrl() + "/api/registersignin/regss";
        //var url = "http://localhost:64055/api/registersignin/regss";
        PostServiceByURL($http, url, data, funCallBack);
    }
    //end

    //resend email verification link in pyar registration
    this.ResendEmlLink = function (memberId, funCallBack) {
        var url = getApiDomainUrl() + "/api/registersignin/regsslnkrs/" + memberId;
        //var url = "http://localhost:64055/api/registersignin/regsslnkrs/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    }

    //validate the registration activation link

    //pyrregactlnkchk   bool
    this.emlLinkValidChk = function (memberId, funCallBack) {
        var url = getApiDomainUrl() + "/api/registersignin/regsslnkc/" + memberId;
        //var url = "http://localhost:64055/api/registersignin/regsslnkc/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    }
    //End


    //email verification and signin member
    this.emlVerificationSignin = function (memberId, gender, genderPref, dob, countryId, cityId, timeZone, funCallBack) {

        if (gender == 1)
            gender = true;
        else
            gender = false;
        if (genderPref == 1)
            genderPref = true;
        else
            genderPref = false;

        var data = { memberId: memberId, gender: gender, genderPref: genderPref, dob: dob, countryId: countryId, cityId: cityId, timeZone: timeZone };
        var url = getApiDomainUrl() + "/api/registersignin/regact";
        //var url = "http://localhost:64055/api/registersignin/regact";
        PostServiceByURL($http, url, data, funCallBack);
    };
    //End

    //for Security Questions List
    this.securityQuns = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/utils/secq";
        //var url = "http://localhost:64055/api/utils/secq";
        GetServiceByURL($http, url, funCallBack);
    }

    this.sendPhoneNumber = function (memberId, countryCode, mobileNo, funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/v2/sndphvc";
        //var url = "http://localhost:64055/api/profile/sndphvc";
        var data = { memberId: memberId, countryCode: countryCode, mobileNo: mobileNo };
        PostServiceByURL($http, url, data, funCallBack);
    }

    this.reSendPhoneNumber = function (memberId, countryCode, mobileNo, funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/v2/resndphvc";
        //var url = "http://localhost:64055/api/profile/resndphvc";
        var data = { memberId: memberId, countryCode: countryCode, mobileNo: mobileNo };
        PostServiceByURL($http, url, data, funCallBack);
    }

    this.checkPhoneNoVerification = function (memberId, codeId, code, funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/v2_1/chkphvc/" + memberId + "/" + codeId + "/" + code;
        //var url = "http://localhost:64055/api/profile/chkphvc/" + memberId + "/" + codeId + "/" + code;
        GetServiceByURL($http, url, funCallBack);
    }

    this.CountryCodeG = function (countryId, funCallBack) {
        var url = getApiDomainUrl() + "/api/utils/countrycode/" + countryId;
        //var url = "http://localhost:64055/api/utils/countrycode/" + countryId;
        GetServiceByURL($http, url, funCallBack);
    }

    //upload blur image
    this.uploadBlrImages = function (memberId, formData, funCallBack) {
        var request = {
            method: 'POST',
            url: getApiDomainUrl() + "/api/mbrphotos/prfblrImg/" + memberId,
            data: formData,
            headers: {
                'Content-Type': undefined
            }
        };
        $http(request).success(function (response, status) { funCallBack(response, status); }).error(function () { });
    }
}]);