﻿angular.module("app").controller("registerdtlsCtrl", ['$scope', '$location', '$window', 'socialLgnSrvc', 'registerSrvc', 'signinSrvc', '$rootScope', 'getSessionSrvc', '$state', 'countryIntlSrv', '$timeout', 'abndnSrvc', '$cookieStore',
function ($scope, $location, $window, socialLgnSrvc, registerSrvc, signinSrvc, $rootScope, getSessionSrvc, $state, countryIntlSrv, $timeout, abndnSrvc, $cookieStore) {

    //removing all cookies in page_Load because if a memeber already login with pyar it will directly go to dashboard.
    abndnSrvc.rmvSsn();

    //variable declaration
    var vm = this;
    vm.DOBPlaceHolder = "MM / DD / YYYY";
    vm.countryId = null;
    vm.cityId = null;
    vm.lnkExpErrDv = vm.alrdyAccntErrDv = false;
    var urlMemId = $location.absUrl().split('?')[1];
    vm.alrdyAccntErrDv = vm.lnkExpErrDv = false;
    //variable declaration end;

    if (urlMemId) {
        registerSrvc.emlLinkValidChk(urlMemId, function (response, status) {
            //1: invalid email link, 2: link expired ,3: already register ,4: not a recent link ,5: valid and recent link
            if (status == 200) {
                if (response == 1 || response == 2 || response == 4) { vm.regDtlDv = vm.alrdyAccntErrDv = false; vm.lnkExpErrDv = true; }
                else if (response == 3) { vm.regDtlDv = vm.lnkExpErrDv = false; vm.alrdyAccntErrDv = true; }
                else if (response == 5) {
                    vm.alrdyAccntErrDv = vm.lnkExpErrDv = false; vm.regDtlDv = true;
                    $timeout(function () { countryIntlSrv.BindIntelligence(); }, 100);
                }
                else $window.location.href = "/register.html";
            }
            else $window.location.href = "/register.html";
        });
    }
    else { $window.location.href = "/register.html"; }

    //calculate Timezone
    vm.timeZone = getTZIdByZone(null);

    vm.dobChange = function (event) {
        vm.bodError = false;
        if (vm.dateOfBirth) {
            var numChars = vm.dateOfBirth.length;
            var thisVal = vm.dateOfBirth;
            if (event.keyCode != 8) {
                if (numChars === 2) {
                    thisVal += '/';
                    vm.dateOfBirth = thisVal;
                }
                else if (numChars === 5) {
                    thisVal += '/';
                    vm.dateOfBirth = thisVal;
                }
            }
        }
    };

    vm.dobFocus = function () {
        vm.DOBPlaceHolder = "MM / DD / YYYY";
        vm.dobKpCls = "bgWht";
    }

    vm.dobBlur = function () {
        //var now = new Date()
        //var born = new Date(vm.dateOfBirth);
        //var years = Math.floor((now.getTime() - born.getTime()) / (365 * 24 * 60 * 60 * 1000));
        //vm.memAge = years;
        years = Math.floor(moment(new Date()).diff(moment(vm.dateOfBirth, "MM/DD/YYYY"), 'years', true));
        if (years < 0 || isNaN(years)) //checking date is valid or not
        {
            vm.DOBPlaceHolder = "Please enter a valid date";
            vm.dateOfBirth = null;
            vm.dobKpCls = "eror";
        }
        else if (years < 18) {
            vm.dateOfBirth = null;
            vm.DOBPlaceHolder = "You must be at least 18 to register";
            vm.dobKpCls = "eror";
        }
        else if (years > 99) {
            vm.DOBPlaceHolder = "Are you really " + years + " years old?";
            vm.dateOfBirth = null;
            vm.dobKpCls = "eror";
        }
    }

    vm.btnDisabled = function () {
        if (vm.countryId && vm.cityId && vm.dateOfBirth && vm.matchA && vm.matchB && vm.txtCityName) { vm.activeCls = "btn-bg regBtn"; return false; }
        else { vm.activeCls = "btn-bg"; return true; }
    }

    vm.Register = function () {
        pcShowLoader("dvmemdtls");
        if (urlMemId) {
            vm.btnDisabled = function () { return true; } //button disabling.
            //Register Service Calling starts            
            if (vm.countryId && vm.cityId && vm.dateOfBirth && vm.matchA && vm.matchB && vm.txtCityName) {
                registerSrvc.emlVerificationSignin(urlMemId, vm.matchA, vm.matchB, vm.dateOfBirth, vm.countryId, vm.cityId, vm.timeZone, function (response, status) {
                    if (status == 200) {
                        //response codes: 1:/invalid email link, 2:link expired, 3:incorrect code, 4:no record found, 5:already register
                        if (response == 1 || response == 2 || response == 3 || response == 4) {
                            vm.regDtlDv = vm.alrdyAccntErrDv = false;
                            vm.lnkExpErrDv = true;
                            hideLoader();
                        }
                        else if (response == 5) {
                            vm.regDtlDv = vm.lnkExpErrDv = false;
                            vm.alrdyAccntErrDv = true;
                            hideLoader();
                        }
                        else if (getSessionSrvc.validateSessionInfo(response)) {
                            var lgnPg = window.sessionStorage.getItem("DtpsNtP");
                            $window.sessionStorage.removeItem("8B3414FB");
                            getSessionSrvc.setLoginData(response);
                            var mId = getSessionSrvc.p_mId();
                            var loginType = getSessionSrvc.p_lt();
                            var profilePicExist = getSessionSrvc.p_ppicexst();
                            if (mId && profilePicExist && (loginType == 2 || loginType == 3)) {
                                var profilePicPath = "https://pccdn.pyar.com" + getSessionSrvc.p_ppic();
                                convertFileToDataURLviaFileReader(profilePicPath, function (img430Response) {
                                    createBlurImage((img430Response), function (blurResponseBlob) {
                                        var data = new FormData();
                                        data.append("blurResponseBlob", blurResponseBlob);
                                        registerSrvc.uploadBlrImages(mId, data, function (response, status) {
                                            processLogin(lgnPg);
                                        });
                                    });
                                });
                            }
                            else
                                processLogin(lgnPg);

                            hideLoader();
                        }
                    }
                    else {
                        vm.btnDisabled = function () { return false; } //button Enabling.
                        hideLoader();
                    }
                });
            }
            //Register Service Calling End                
        }
    }

    function processLogin(lgnPg) {
        if (lgnPg == "DT") {
            $window.sessionStorage.removeItem("DtpsNtP");
            $window.location.href = "/dating-tip" + $rootScope.pgName + "";
        }
        else {
            $window.sessionStorage.removeItem("DtpsNtP");
            $window.localStorage.setItem("P_ftrl", 1);
            $state.go("freeTrial");
        }
    }

    //city intelligence module
    $scope.$on("countryBind", function (e, txtId, countryId, data) {
        vm.countryId = data.countryId;
        vm.cityId = data.cityId;
        vm.stateId = data.stateId;
        $scope.$digest();
    });

    $scope.$on("countryUnBind", function (e, txtId, countryId) {
    });

    $rootScope.$on("bindCountry", function (e, countries) {
        vm.countries = countries;
    });

    vm.setCountry = function (txtId, dvId, countryId) {
        //$("#txtRstrCurrLocCity").prop('disabled', false);
        countryIntlSrv.SetCountry(txtId, dvId, countryId);
    }
    vm.setDfaultCntry = function () {
        vm.countryId = null;
        vm.cityId = null;
        $("#txtRstrCurrLocCity").val('');
        $("#txtRstrCurrLocCity").prop('disabled', true);
    }
    countryIntlSrv.initSrvc();
    //city intelligence module

    function convertFileToDataURLviaFileReader(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.onload = function () {
            var reader = new FileReader();
            reader.onloadend = function () {
                callback(reader.result);
            }
            reader.readAsDataURL(xhr.response);
        };
        xhr.open('GET', url);
        xhr.responseType = 'blob';
        xhr.send();
    }

    function createBlurImage(imgSrc, callBackFun) {
        var canvas = document.createElement('canvas');
        canvas.setAttribute('id', "backgroud_div");
        $(canvas).blurIt(imgSrc, 20, function (resonse) {
            callBackFun(resonse);
        });
    }
}]);