﻿// used in Register.html page
angular.module("app").controller('freetrialCtrl', ['$scope', '$window', '$http', '$location', '$state', 'membershipSrvc', 'registerSrvc', 'getSessionSrvc', '$timeout', '$interval', '$rootScope', '$cookieStore', function ($scope, $window, $http, $location, $state, membershipSrvc, registerSrvc, getSessionSrvc, $timeout, $interval, $rootScope, $cookieStore) {
    var vm = this;
    var mId = getSessionSrvc.p_mId();

    //checking member come from registration details page or not   
    vm.sendCodeStep1 = true;
    vm.sendCodeStep2 = false;
    vm.premBenfits = true;
    vm.sendBtnCls = "prmtnbtndsbld";
    vm.phNoPlshldr = "Enter Mobile Number";
    vm.sendCodedsbld = true;
    vm.mailSent = true;
    vm.countryId = getSessionSrvc.p_cntryId();
    showLoader();


    registerSrvc.CountryCodeG(vm.countryId, function (response) {
        if (response)
            vm.countrycode = response;       
    });
    //get premium features 
    membershipSrvc.memberPremiumTbl(function (response, status) {
        if (status = 200 && response != null) {
            vm.premiumTbl = response;
            hideLoader();
        }
    });
    //bind image source for premium features
    vm.bindImgSrc = function (imgPath) {
        return addCdnPath(imgPath);
    }

    //phone no text box blur event
    vm.phNoKeyUp = function () {      
        if (vm.phoneNo) {
            vm.errCls = "";
            vm.phNoPlshldr = "";
        } else {
            vm.phNoPlshldr = "Enter Mobile Number";
        }
        cntryAndNumberVlded();
        }
    
    //country code textbox keyup event
    vm.cntryCodeKeyUp = function () {
        cntryAndNumberVlded();
    }

    // button validation based on country code and phone number
    function cntryAndNumberVlded() {
        if (vm.countrycode && vm.phoneNo) {
            if (vm.countrycode == "91" && vm.phoneNo.length == 10) {
                vm.sendCodedsbld = false;
                vm.sendBtnCls = "prmtnbtn curptr";
            }
            else if (vm.countrycode != "91" && vm.phoneNo.length > 6) {
                vm.sendCodedsbld = false;
                vm.sendBtnCls = "prmtnbtn curptr";
            } else {
                vm.sendCodedsbld = true;
                vm.sendBtnCls = "prmtnbtndsbld";
            }
        } else {
            vm.sendCodedsbld = true;
            vm.sendBtnCls = "prmtnbtndsbld";
        }
    }
    
    //otp code enter textboxes keyup events
    vm.OtpDigit1keyup = function () {
        if (vm.OtpDigit1) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.otpCheck();
            } else
                $("#otpDigit2").focus();
        }
    }
    vm.OtpDigit2keyup = function () {
        if (vm.OtpDigit2) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.otpCheck();
            } else
                $("#otpDigit3").focus();
        }
    }
    vm.OtpDigit3keyup = function () {
        if (vm.OtpDigit3) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.otpCheck();
            } else
                $("#otpDigit4").focus();
        }
    }
    vm.OtpDigit4keyup = function () {
        if (vm.OtpDigit4) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.otpCheck();
            } else
                $("#otpDigit5").focus();
        }
    }
    vm.OtpDigit5keyup = function () {
        if (vm.OtpDigit5) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.otpCheck();
            } else
                $("#otpDigit6").focus();
        }
    }
    vm.OtpDigit6keyup = function () {
        if (vm.OtpDigit6) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.otpCheck();
                $("#otpDigit6").blur();
            }
            else if (!vm.OtpDigit1)
                $("#otpDigit1").focus();
            else if (!vm.OtpDigit2)
                $("#otpDigit2").focus();
            else if (!vm.OtpDigit3)
                $("#otpDigit3").focus();
            else if (!vm.OtpDigit4)
                $("#otpDigit4").focus();
            else if (!vm.OtpDigit5)
                $("#otpDigit5").focus();
        }
    }

    //need to call api
    vm.otpCheck = function () {
        $("[id^='otpDigit']").blur();
        vm.OtpDigit1dsbld = true;
        vm.OtpDigit2dsbld = true;
        vm.OtpDigit3dsbld = true;
        vm.OtpDigit4dsbld = true;
        vm.OtpDigit5dsbld = true;
        vm.OtpDigit6dsbld = true;
        if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
            vm.otpCodeStr = vm.OtpDigit1 + vm.OtpDigit2 + vm.OtpDigit3 + vm.OtpDigit4 + vm.OtpDigit5 + vm.OtpDigit6;
            registerSrvc.checkPhoneNoVerification(mId, vm.otpResponseId, vm.otpCodeStr, function (response, status) {
                if (status == 200) {
                    if (response) {
                        updateMblVrfySession(response, getSessionSrvc, $rootScope, $window, true);
                        $state.go('dashboard');
                        //var sid = "", subDays = "", subStartDay = "", subEndDay = "", trailMember = false, trailType = "";
                        //angular.forEach(response, function (key, value) {
                        //    var values = Object.values(key);
                        //    if (values[0] == "sId")
                        //        sid = values[1];
                        //    else if (values[0] == "subscribeDays")
                        //        subDays = values[1];
                        //    else if (values[0] == "subscribeStrtDT")
                        //        subStartDay = values[1];
                        //    else if (values[0] == "subscribeExprDT")
                        //        subEndDay = values[1];
                        //    else if (values[0] == "trailMember")
                        //        trailMember = values[1];
                        //    else if (values[0] == "trailType")
                        //        trailType = values[1];
                        //});

                        //var trailObj = { subDays: subDays, fromfreetrialPage: true, trailType: trailType };
                        //getSessionSrvc.u_ssnd("sId", sid);
                        //getSessionSrvc.u_ssnd("dateTimeSubscrbSt", subStartDay);
                        //getSessionSrvc.u_ssnd("dateTimeSubscrbExp", subEndDay);
                        //getSessionSrvc.u_ssnd("trailMember", trailMember);

                        //$rootScope.trailObj = trailObj;
                        //$window.localStorage.setItem("P_ftrl", null);
                    } else {
                        $("#errCodePopup").modal('show');
                    }
                }
            });
        }
    }


    //send code button click
    vm.sendCode = function () {
        if (mId && vm.phoneNo && vm.countrycode && vm.countrycode.length <= 3) {
            showLoader();        
            registerSrvc.sendPhoneNumber(mId, vm.countrycode, vm.phoneNo, function (response, status) {
                if (status == 200) {
                    if (parseInt(response) == 0) {
                        vm.errCls = "eror";
                        vm.phoneNo = "";
                        vm.phNoPlshldr = "Number in use";
                    }
                    else if ((parseInt(response) == -1) || (parseInt(response) == -2)) {
                        vm.errCls = "eror";
                        vm.phoneNo = "";
                        vm.phNoPlshldr = "Message sending failed";
                    }
                    else {
                        vm.sendCodeStep1 = false;
                        vm.sendCodeStep2 = true;
                        vm.otpResponseId = response;
                        vm.errCls = '';
                    }
                } else {
                    vm.errCls = "eror";
                    vm.phoneNo = "";
                    vm.phNoPlshldr = "Invalid member info";
                }
                hideLoader();
            });
        }
    }


    //resed otp code button click
    vm.resendCode = function (sendType) {
        if (sendType == true)
            $("#errCodePopup").modal('hide');
        startInterval(vm, $interval);
        vm.OtpDigit1 = ""; vm.OtpDigit2 = ""; vm.OtpDigit3 = ""; vm.OtpDigit4 = ""; vm.OtpDigit5 = ""; vm.OtpDigit6 = "";
        vm.OtpDigit1dsbld = false; vm.OtpDigit2dsbld = false; vm.OtpDigit3dsbld = false; vm.OtpDigit4dsbld = false; vm.OtpDigit5dsbld = false; vm.OtpDigit6dsbld = false;
        if (mId && vm.phoneNo && vm.countrycode && vm.countrycode.length <= 3) {          
            registerSrvc.reSendPhoneNumber(mId, vm.countrycode, vm.phoneNo, function (response, status) {
                if (status == 200 && response) {
                    vm.sendCodeStep1 = false;
                    vm.sendCodeStep2 = true;
                    vm.otpResponseId = response;
                }
            });
        }
    }

    vm.clgErrPopUp = function () {
        vm.OtpDigit1 = ""; vm.OtpDigit2 = ""; vm.OtpDigit3 = ""; vm.OtpDigit4 = ""; vm.OtpDigit5 = ""; vm.OtpDigit6 = "";
        vm.OtpDigit1dsbld = false; vm.OtpDigit2dsbld = false; vm.OtpDigit3dsbld = false; vm.OtpDigit4dsbld = false; vm.OtpDigit5dsbld = false; vm.OtpDigit6dsbld = false;
    }
    vm.mbleEntPg = function () {
        vm.sendCodeStep1 = true;
        vm.sendCodeStep2 = false;
    }
    vm.activeState = "";
    vm.goHome = function (state) {
        vm.activeState = state;
        $("#premModal").modal('show');
    }

    //i will be basic button click
    vm.basicClick = function () {
        showLoader();
        $("#premModal").modal('hide');
        $window.localStorage.setItem("P_ftrl", null);
        //need to check  
        $timeout(function () { $state.go(vm.activeState); }, 1000);
    }
    //i want premium button click
    vm.premClick = function () {
        $("#premModal").modal('hide');
    }


}]);