﻿angular.module("app").controller('registersendemlCtrl', ['$window', 'registerSrvc', '$state', '$interval', function ($window, registerSrvc, $state, $interval) {
    var vm = this;
    if ($window.localStorage.getItem("memreg"))
        var memberId = JSON.parse($window.localStorage.getItem("memreg")).mid;
    else  
    $state.go("register");

    startInterval(vm, $interval);

    vm.ResendLink = function () {
        pcShowLoader("dvrsndeml");
        if (memberId) {
            registerSrvc.ResendEmlLink(memberId, function (response, status) {             
                if (status == 200) {
                    if (response == "4") 
                        startInterval(vm, $interval);                    
                    else if (response == "3") {
                        alert("Email sending failed..!.");
                        startInterval(vm, $interval);
                    }
                }
                else if (status == 204) 
                    alert("Email not exist");              
                hideLoader();
            });
        }
        else 
            hideLoader();       
    }
}]);