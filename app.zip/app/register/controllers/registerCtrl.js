﻿// used in Register.html page
angular.module("app").controller('registerCtrl', ['$scope', '$window', '$http',  'registerSrvc', '$state', '$rootScope', function ($scope, $window, $http, registerSrvc, $state, $rootScope) {

    //for header strip change on scroll
    headerStripScroll();

    var vm = this;
    //vm.bnrImg = 'https://pccdn.pyar.com/pcimgs/regimg.jpg';
    vm.NamePlaceholder = 'First Name';
    vm.EmailPlaceholder = 'Email';
    vm.PwdPlaceholder = 'Password';
    vm.CnfPwdPlaceholder = 'Confirm Password';
    vm.bgWht = "bgWht";

    //register button disabled function
    vm.regBtnDsbl = function () {
        if (vm.name && vm.email && vm.password) {
            if ((vm.password.length >= 8 && vm.password.length <= 30) && $rootScope.emailRegex.test(vm.email)) {
                vm.btnRegCls = "btn-bg regBtn"; return false;
            }
            else { vm.btnRegCls = "btn-bg"; return true; }
        }
        else { vm.btnRegCls = "btn-bg"; return true; }
    }

    function nameEmpty(phTxt) {
        vm.name = null;
        vm.NamePlaceholder = phTxt;
        vm.nameKpcls = "eror";
    }
    //first Name blur event
    vm.fNameCheck = function () {
        if (vm.name && vm.name.length > 30)
            nameEmpty("Must be < 30 characters");
        else if ((vm.name && vm.name.length == 1) || !vm.name) { nameEmpty("Please enter a valid first name"); }
    }
    //firstName chanage evnt
    vm.nameChnage = function () {
        vm.nameKpcls = "bgWht";
        if (vm.name && vm.name.length > 30) { $("#txtName").blur(); }
        else if (!vm.name) { vm.fNameFocus(); }
    }

    //FirstName Focus event
    vm.fNameFocus = function () {
        vm.NamePlaceholder = "First Name";
        vm.nameKpcls = "bgWht";
    }

    //Email blur event
    vm.emailCheck = function () { emlchkBlur($rootScope, vm); }
    //Email change event
    vm.emailChnage = function () { emlchangeEvnt(vm); }
    //Email Focus event
    vm.emailFocus = function () { emlFcs(vm); }
    //new Password chnage event
    vm.passwordChnage = function () {
        vm.pwdKpcls = "bgWht"; 
        if (vm.password && vm.password.length > 30) { $("#txtPwd").blur(); } // for Internet Explore , to show the msg
    }
    //new Password blur event
    vm.pwdCheck = function (){ pwdchkBlur(vm); }
    //Password Focus event
    vm.pwdFocus = function () { vm.pwdGuideLineMsg = true; pwdFcs(vm); }
    //Confirm password change event 
    //vm.confirmPwdChnage = function () {
    //    vm.cnfPwdKpcls = "bgWht";
    //    if (vm.confirmPassword && vm.confirmPassword.length > 30) { $("#txtCnfrmPwd").blur(); } //for Internet Explore , to show the msg
    //}
    //Confirm password blur event 
   // vm.cnfPwdCheck = function () { CnfPwdchkBlur(vm); }
    //Confirm password Focus event 
    //vm.cnfPwdFocus = function () { CnfPwdFcs(vm); }

    vm.errMsg = function (nameKpcls, name, NamePlaceholder, emailKpcls, email, EmailPlaceholder, pwdKpcls, password, PwdPlaceholder) {
        vm.nameKpcls = nameKpcls;
        vm.name = name;
        vm.NamePlaceholder = NamePlaceholder;
        vm.emailKpcls = emailKpcls;
        vm.email = email;
        vm.EmailPlaceholder = EmailPlaceholder;
        vm.pwdKpcls = pwdKpcls;
        vm.password = password;
        vm.PwdPlaceholder = PwdPlaceholder;
        //vm.cnfPwdKpcls = cnfPwdKpcls;
        //vm.confirmPassword = confirmPassword;
        //vm.CnfPwdPlaceholder = CnfPwdPlaceholder;
    }

    // function to submit the form after all validation has occurred
    vm.RegisterNext = function () {
        if ($scope.frmRegister.$valid) {
            pcShowLoader("dvsignIn");
            vm.name = captlFname(vm.name);
            if (vm.name && vm.email && vm.password) {
                registerSrvc.RegEmailCheck(vm.name, vm.email, vm.password, function (response, status) {
                    if (status == 200) {
                        if (response.status == true) {
                            vm.memreg = { "mid": response.refId };
                            $window.localStorage.setItem("memreg", JSON.stringify(vm.memreg));
                            $state.go('register/emailsend');
                        }
                        else if (response.status == false) {                         
                            if (response.errType == "0") alert("Inavalid request");
                       else {
                            var error = "";
                            if (response.errType == "1") error = "Invalid email";
                            else if (response.errType == "2") error = "This is already a registered email";
                            else if (response.errType == "3") error = "Email sending failed";
                                vm.errMsg(vm.bgWht, null, "First Name", "", null, error, vm.bgWht, null, "Password");
                            }
                        }
                    }
                    hideLoader();
                });
            }
        }
        else {
            alert("Please fill all fileds!");
            return false;
        }
    };
}]);