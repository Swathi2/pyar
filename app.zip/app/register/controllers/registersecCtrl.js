﻿var captchaVerfication = "";
function recaptchaChk() {
    captchaVerfication = "Captcha verified";
}

angular.module("app").controller('registersecCtrl', ['$scope', '$window', '$http', '$filter', '$sce', '$location', 'chkregsessionSrvc', 'registerSrvc','cmnSrvc', '$state', '$rootScope', '$interval', 'ppSrvc', 'tcSrvc', function ($scope, $window, $http, $filter, $sce, $location, chkregsessionSrvc, registerSrvc,cmnSrvc, $state, $rootScope, $interval, ppSrvc, tcSrvc) {

    var vm = this;
    vm.secAnsPlaceholder = "Answer Question";
    vm.scrAnswrDsbl = true;
    var memberId = JSON.parse($window.localStorage.getItem("memreg")).mid;

    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if (memberId == null) {
            $location.path("/register.html");
            return false;
        }
    });

    vm.secAnsChange = function () {
        vm.secAnsKpCls = "bgWht";
        if (vm.secAns != undefined && vm.secAns.length > 75) {
            $("#txtSecAns").blur();
        }
    }

    vm.secAnsCheck = function () {
        if (vm.secAns != undefined && vm.secAns.length > 75) { vm.secAns = null; vm.secAnsKpCls = "eror"; vm.secAnsPlaceholder = 'Must be < 75 characters'; }
        else if (!vm.secAns) { vm.secAns = null; vm.secAnsKpCls = "eror"; vm.secAnsPlaceholder = 'Answer Question'; }
    }

    vm.secAnsFocus = function () { vm.secAnsKpCls = "bgWht"; vm.secAnsPlaceholder = 'Answer Question'; }

    vm.bindSecQval = function (value) {
        vm.selcectSecQval = value;
        vm.scrAnswrDsbl = false;
    }

    vm.btnDisabled = function () {
        if (vm.selcectSecQval && vm.selcectSecQval && vm.secAns && vm.ageCnfrm && vm.agree && captchaVerfication) {
            vm.activeCls = "nxtbtntb nxtbtnhr"; return false;
        }
        else { vm.activeCls = "nxtbtntb"; return true; }
    }

    //this function need to after getting response from google captcha. // for next button enabling.
    $interval(function () { if (captchaVerfication) { vm.btnDisabled(); } }, 100);

    //service for getting security questions List
    registerSrvc.securityQuns(function (response, status) {
        vm.secQnsRes = response;
    });

    vm.submitForm = function () {
        if ($scope.frmSecurity.$valid) {
            pcShowLoader("dvSecFrm");
            if (memberId && vm.selcectSecQval && vm.secAns) {
                registerSrvc.Register(memberId, vm.selcectSecQval, vm.secAns, function (response, status) {
                    //1: invalid id, 2: no recored found (or) loginType mismatch, 3: email sent fail, 4: email sent success
                    if (status == 200) {
                        if (response == 1 || response == 2) {
                            $window.localStorage.removeItem("memreg");
                            $state.go('register');
                        }
                        else if (response == 3) {
                            $window.localStorage.removeItem("memreg");
                            $state.go("err500");
                        }
                        else if (response == 4) {
                            $state.go("register/security/email");
                        }
                    }
                    hideLoader();
                });
            }
            else {
                hideLoader();
            }
            grecaptcha.reset();
            captchaVerfication = "";
        }
        else {
            alert("Please fill all fileds!");
        }
    };
    //privacy policy click event
    //vm.ppClick = function () {
    //    cmnSrvc.PPService(function (response, status) {
    //        if (status == 204) {
    //            alert("the content is not there (take the appropriate action)");
    //            return false;
    //        }
    //        else if (status == 200) {
    //            vm.ppVersion = "Version " + eval(JSON.stringify(response.version));
    //            vm.lstUpdated = "Last updated: " + $filter('date')(eval(JSON.stringify(response.dateCreated)), "MMMM d, yyyy");
    //            vm.ppContent = $sce.trustAsHtml(response.policytext);
    //            $("#ppModal").modal("show");
    //        }
    //    });
    //};

    //Terms condtions click event
    //vm.tcClick = function () {
    //    cmnSrvc.TCService(function (response, status) {
    //        if (status == 204) {
    //            alert("the content is not there (take the appropriate action)");
    //            return false;
    //        }
    //        else if (status == 200) {
    //            vm.tcVersion = "Version " + eval(JSON.stringify(response.version));
    //            vm.lstUpdated = "Last updated: " + $filter('date')(eval(JSON.stringify(response.dateCreated)), "MMMM d, yyyy");
    //            vm.tcContent = $sce.trustAsHtml(response.policytext);
    //            $("#tcModal").modal("show");
    //        }
    //    });
    //};
    //Displaying Time to resend the mail and Disabling the resend mail button

    if ($location.path() == "/register/security/email.html") {
        startInterval(vm, $interval);
    }

    vm.ResendLink = function () {
        pcShowLoader("dvrsndeml");
        if (memberId) {
            registerSrvc.ResendEmlLink(memberId, function (response, status) {
                //alert(JSON.stringify(response));
                if (status == 200) {
                    if (response == "4") {
                        startInterval(vm, $interval);
                    }

                    else if (response == "3") {
                        alert("Email sending failed..!.");
                        startInterval(vm, $interval);
                    }

                }
                else if (status == 204) {
                    alert("Email not exist");
                }
                hideLoader();
            });
        }
        else {
            hideLoader();
        }
    }
}]);