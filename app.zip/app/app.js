var slicksliderJS = '/scripts/slick.min.js';
var slicksliderCss = '/styles/slick-theme.css';
var fblgn = '/app/social/scripts/fblgn.js';
var matchAnalysis = '/app/profile/others/scripts/matchAnalysis.js';
var infinitescroll = '/scripts/ng-infinite-scroll.min.js';
var addThis = '//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-58c79badfd3a742e';
var swiperJS = '/scripts/swiper.min.js';
var wowminJS = '/scripts/wow.min.js';
//var smartBannerJs = '../scripts/smart-app-banner.js';

//Controllers Section
var homeCtrl = '/app/home/controllers/homeCtrl.js';
var registerCtrl = '/app/register/controllers/registerCtrl.js'
var registersendemlCtrl = '/app/register/controllers/registersendemlCtrl.js';
var registersecCtrl = '/app/register/controllers/registersecCtrl.js';
var registerdtlsCtrl = '/app/register/controllers/registerdtlsCtrl.js';
var freetrialCtrl = '/app/register/controllers/freetrialCtrl.js';
var signinCtrl = '/app/signin/controllers/signinCtrl.js';
var sociallgnCtrl = '/app/social/controllers/sociallgnCtrl.js';
var registerfbemlCtrl = '/app/social/controllers/registerfbemlCtrl.js';
//var registersocialemlCtrl = "/app/signin/controllers/registersocialemlCtrl.js"
var forgotpwdCtrl = '/app/signin/controllers/forgotpwdCtrl.js';
var forgotcpwdCtrl = '/app/signin/controllers/forgotcpwdCtrl.js';
var contactusCtrl = '/app/help/controllers/contactusCtrl.js';
var ppCtrl = '/app/policies/controllers/ppCtrl.js';
var tcCtrl = '/app/policies/controllers/tcCtrl.js';
var registersocialsecCtrl = '/app/social/controllers/registersocialsecCtrl.js';
var abtusCtrl = '/app/aboutus/controllers/abtusCtrl.js';
var dtiplstCtrl = '/app/datingTips/controllers/dtiplstCtrl.js';
var dtipsrchCtrl = '/app/datingTips/controllers/dtipsrchCtrl.js';
var dtipCtrl = '/app/datingTips/controllers/dtipCtrl.js';
var membershipCtrl = '/app/membership/controllers/membershipCtrl.js';
var selfprofileCtrl = '/app/profile/self/controllers/selfprofileCtrl.js';
var selfmatchprefCtrl = '/app/profile/self/controllers/selfmatchprefCtrl.js';
var socialPhotosCtrl = '/app/social/controllers/socialPhotosCtrl.js';
var othersprofileCtrl = '/app/profile/others/controllers/otherprofileCtrl.js';
var accountCtrl = '/app/account/controllers/accountCtrl.js';
var accountdeleteCtrl = '/app/account/controllers/accountdeleteCtrl.js';
var changeGenderCtrl = '/app/account/controllers/changeGenderCtrl.js';
var basicsrchCtrl = '/app/search/controllers/basicsrchCtrl.js';
var advsrchCtrl = '/app/search/controllers/advsrchCtrl.js';
var msgcenterCtrl = '/app/messages/controllers/msgcenterCtrl.js';
var notificationsCtrl = '/app/notifications/controllers/notificationsCtrl.js';
var dashboardCtrl = '/app/dashboard/controllers/dashboardCtrl.js';
var countryCtrl = '/app/common/controllers/countryCtrl.js';
var feedbackCtrl = '/app/feedback/controllers/feedbackCtrl.js';
var msgCtrl = "/app/chat/controllers/msgCtrl.js";
var msgMCtrl = "/app/chat/controllers/msgMCtrl.js";
var inphotosCtrl = "/app/social/controllers/inphotosCtrl.js";
var fblgnCtrl = "/app/social/controllers/fbCtrl.js";
var mbrtcktrplyCtrl = "/app/support/controllers/mbrtcktrplyCtrl.js";
var mbremltcktrplyCtrl = "/app/support/controllers/mbremltcktrplyCtrl.js";
var emlunsubCtrl = '/app/common/controllers/emlunsubCtrl.js';
var paymentCtrl = "/app/payments/controller/paymentCtrl.js";
var paymentsuccessCtrl = "/app/payments/controller/paymentsuccessCtrl.js";
var referfriendCtrl = "/app/referfriend/controllers/referfriendctrl.js";
var changecardCtrl = '/app/payments/controller/changecardCtrl.js';
var eventsCtrl = '/app/events/controller/eventsCtrl.js';
//Controllers Section End

//Services Section
var ppSrvc = '/app/policies/services/ppSrvc.js';
var tcSrvc = '/app/policies/services/tcSrvc.js';
var registerSrvc = '/app/register/services/registerSrvc.js';
var socialLgnSrvc = '/app/social/services/socialLgnSrvc.js';
var signinSrvc = 'app/signin/services/signinSrvc.js';
var dtipSrvc = '/app/datingTips/services/dtipSrvc.js';
var dtipcmtSrvc = '/app/datingTips/services/dtipcmtSrvc.js';
var contactusSrvc = '/app/help/services/contactusSrvc.js'
var dtipdataSrvc = '/app/datingTips/services/dtipdataSrvc.js';
var membershipSrvc = "/app/membership/services/membershipSrvc.js";
var selfprofileSrvc = '/app/profile/self/services/selfprofileSrvc.js';
var socialphotosSrvc = '/app/social/services/socialphotosSrvc.js';
var prflphotodataSrvc = '/app/profile/self/services/prflphotodataSrvc.js';
var selfmatchprefSrvc = '/app/profile/self/services/selfmatchprefSrvc.js';
var othersprofileSrvc = '/app/profile/others/services/othersprofileSrvc.js';
var accountSrvc = '/app/account/services/accountSrvc.js';
var accountdeleteSrvc = '/app/account/services/accountdeleteSrvc.js';
var changeGenderSrvc = '/app/account/services/changeGenderSrvc.js';
var srchSrvc = '/app/search/services/srchSrvc.js';
var msgcenterSrvc = '/app/messages/services/msgcenterSrvc.js';
var dashboardSrvc = '/app/dashboard/services/dashboardSrvc.js';
var forgotpwdSrvc = '/app/signin/services/forgotpwdSrvc.js';
var countryIntlSrv = '/app/common/services/countryIntlSrv.js';
var mbrtckreplySrvc = "/app/support/services/mbrtckreplySrvc.js";
var mbremltckreplySrvc = "/app/support/services/mbremltckreplySrvc.js";
var paymentrSrvc = "/app/payments/services/paymentrSrvc.js";
var referFriendSrvc = "/app/referFriend/services/referFriendSrvc.js";
var paymntValidtnSrvc = '/app/payments/services/paymentvalidationSrvc.js';
//Services Section End

//Directives Section
var signinDirts = "/app/signin/directives/signinDirts.js";
var glryphotosDirts = "/app/profile/self/directives/glryphotosDirts.js";
var sliderDrctve = "/app/profile/self/directives/sliderDrctve.js";
//Directives Section end

//Filters Section Starts
var selfprofileFltr = "/app/profile/self/filters/selfprofileFltr.js";
//Filters Section End

//Scripts Section
var selfprofileSrpt = '/app/profile/self/scripts/selfprofileSrpt.js';
var pchtabSrpt = '/app/common/scripts/pchtabSrpt.js';
var JqrySldr = "/app/profile/self/scripts/addSlider.js";
var rangeSldr = "/app/profile/self/scripts/slider.js";
var objMinSldr = "/app/profile/self/scripts/Obj.min.js"
var imgCrop = "app/profile/self/scripts/croppie.js";
var imgOrient = "/app/profile/self/scripts/orient.js";
//var exif = "app/profile/self/scripts/exif.js";
var chat = "/scripts/chatboxManager.js";
var momment = "/scripts/moment.min.js";
var mommentTZ = "/scripts/moment-timezone-with-data-2012-2022.min.js";
var signalr = "/scripts/signalr.js";
var blurIt = "/scripts/blurIt.js";
var resizeIt = "/scripts/resizeit.js";
var jQueryCardChk = "/app/payments/scripts/jquery.cardcheck.js";
var paypalCheckout = "https://www.paypalobjects.com/api/checkout.js";
var paypalHostedFields = "https://js.braintreegateway.com/web/3.31.0/js/hosted-fields.min.js";
var braintreeClient = "https://js.braintreegateway.com/web/3.31.0/js/client.min.js";
var btPaypalCheckout = "https://js.braintreegateway.com/web/3.31.0/js/paypal-checkout.min.js";
var bt3DSecure = "https://js.braintreegateway.com/web/3.31.0/js/three-d-secure.min.js";


//Scripts Section End

//Factories Section starts
var dashboardFact = "/app/dashboard/factories/dashboardFact.js";
//Factories Section End

var app = angular.module("app", ["ui.router", "oc.lazyLoad", "ngSanitize", "angularjs-crypto", "ngCookies"]);
app.run(['cfCryptoHttpInterceptor', '$rootScope', '$interval', '$http', '$document', '$window', '$cookieStore', 'abndnSrvc', 'msgSrvc', 'cmnSrvc', '$location', '$filter', function (cfCryptoHttpInterceptor, $rootScope, $interval, $http,$document, $window, $cookieStore, abndnSrvc, msgSrvc, cmnSrvc, $location, $filter) {
    $rootScope.base64Key = CryptoJS.enc.Hex.parse('0123456789abcdef0123456789abcdef')
    $rootScope.iv = CryptoJS.enc.Hex.parse('abcdef9876543210abcdef9876543210');
    $rootScope.crYear = $filter('date')(new Date(), "yyyy");
    $rootScope.browser = browserDetection();

    $rootScope.ntfnData = [];
    //this function is fired when the url changes
    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        showLoader();

        // Cancel All Pending Requests 
        $http.pendingRequests.forEach(function (pendingReq) {
            if (pendingReq.cancel) {
                pendingReq.cancel.resolve();
            }
        });
        //if (window.location.href.indexOf('www') == -1) {
        //    var newurl = "https://www." + window.location.host + window.location.pathname
        //    window.location.href = newurl;
        //}     
        //to collapse the header in mobile view
        navclose();
        //Function for dynamically loading title, keywords & description(this function present inside common functions)
        pyrTitles($rootScope, toState);
    });
    $rootScope.$on("$stateChangeSuccess", function (event, toState, toParams, fromState, fromParams) {
        //Adding padding to body dynamically based on page conditions
        bodyStyles($rootScope, toState);
        var path = toState.url;
        localStorage.setItem("toPath", path);
        hideLoader();
        $('html, body').scrollTop(0);
        if (path != "/signin.html") {
            $window.localStorage.removeItem("frmLnk");
        }
        if (path != "/" && $(window).width() <= 767) { // to remove smartbanner strip on all pages except home page
            $("#displaysmtbnr").remove();
            $("html").removeClass("smartbanner-show")
        }

        $rootScope.trialExpired = cmnSrvc.isTrialOrPrmExpired(); // for popup changing
    });
    msgSrvc.connectServer(true);


    //Email Regular Expression
    $rootScope.emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,10}$/;

    //network lose
    $rootScope.online = navigator.onLine;
    $window.addEventListener("offline", function () {
        $rootScope.$apply(function () {
            $rootScope.online = false;
            $rootScope.$broadcast("offline");
        });
    }, false);

    $window.addEventListener("online", function () {
        $rootScope.$apply(function () {
            $rootScope.online = true;
            $rootScope.$broadcast("online");
        });
    }, false);
    //End here
}]);

app.config(function ($provide) {
    $provide.decorator("$exceptionHandler", ['$delegate', '$injector', function ($delegate, $injector) {
        return function (exception, cause) {
            var $http = $injector.get("$http");
            var $state = $injector.get("$state");
            var url = getApiDomainUrl() + "/api/utils/webers";
            //web site errors log - error type need to be allocate and change ..
            var ExceptionData = angular.toJson({ errorType: 1, referrerURL: $state.current.templateUrl, exception: exception.message, innerexception: exception.stack, errorCode: "", trace: exception.stack });
            PostServiceByURL($http, url, ExceptionData, function (response, status) { });
        }
    }]);
});

//Interceptor for setting Defer object to all the API Requests
app.config(function ($httpProvider) {
    $httpProvider.interceptors.push(function ($q) {
        return {
            request: function (config) {
                if (!config.timeout) {
                    config.cancel  = $q.defer();
                    config.timeout = config.cancel.promise;            
                }
                return config;
            }
        }
    });
});

app.config(function ($stateProvider, $locationProvider, $urlRouterProvider, $urlMatcherFactoryProvider) {
    $urlRouterProvider.otherwise('/'); // default route
    $urlMatcherFactoryProvider.caseInsensitive(true); // Remove casesensitive from urls
    $locationProvider.html5Mode(true); // Remove # from url

    $stateProvider
        //This state contains header & footer
        .state("masterpage", {
            url: "",
            parent: "masterpage2",
            templateUrl: "/app/common/templates/masterpage.html",
            abstract: true
        })

        //This state contains only footer
        .state("masterpage2", {
            url: "",
            templateUrl: "/app/common/templates/masterpage2.html",
            abstract: true,

            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [msgCtrl, msgMCtrl, swiperJS, othersprofileCtrl, othersprofileSrvc, selfprofileSrpt, selfprofileCtrl, matchAnalysis, selfprofileSrvc, selfprofileFltr, selfmatchprefSrvc, srchSrvc, dashboardFact, feedbackCtrl, membershipSrvc, registerSrvc] }]); }]
            }
        })

        .state('countryTest', {
            url: "/countryTest.html",
            views: {
                '': {
                    templateUrl: "/app/common/templates/countryTest.html",
                    controller: 'countryTestCtrl',
                    controllerAs: 'countryTestCtrlAs',
                    resolve: {
                        lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load([{
                                name: 'app', files:
                                    [
                                        '/app/common/services/countryIntlSrv.js',
                                        '/app/common/controllers/countryTestCtrl.js'
                                    ]
                            }]);
                        }]
                    }
                }
            },
        })

        .state("home", {
            url: "/",
            parent: "masterpage2",
            templateUrl: "app/home/templates/home.html",
            controller: 'homeCtrl',
            controllerAs: 'homeCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [homeCtrl] }]);
                }]
            }
        })

		.state("register", {
		    url: "/register.html",
		    parent: "masterpage2",
		    templateUrl: "app/register/templates/register.html",
		    controller: 'registerCtrl',
		    controllerAs: 'registerCtrlAs',
		    resolve: {
		        lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
		            getSessionSrvc.checkPgSec('outpg', event);
		            return $ocLazyLoad.load([{ name: 'app', files: [registerCtrl, sociallgnCtrl, fblgn, registerSrvc, socialLgnSrvc, selfprofileSrvc] }]);
		        }]
		    }

		})

		.state('register/security', {
		    url: '/register/security.html',
		    parent: "masterpage2",
		    templateUrl: 'app/register/templates/registersec.html',
		    controller: 'registersecCtrl',
		    controllerAs: 'registersecCtrl',
		    resolve: {
		        lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$window', function ($ocLazyLoad, getSessionSrvc, $location, $window, event) {
		            if ($window.localStorage.getItem("memreg") == null) {
		                $location.path('/register.html');
		                //event.preventDefault();
		            } else
		                getSessionSrvc.checkPgSec('outpg', event);

		            return $ocLazyLoad.load([{
		                name: 'app', files: [registersecCtrl, registerSrvc]/*googleRecaptcha,*/
		            }])
		        }]
		    }

		})

        .state('register/Fbsecurity', {
            url: '/register/Fbsecurity.html',
            parent: "masterpage2",
            templateUrl: 'app/register/templates/registersocialsec.html',
            controller: 'registersocialsecCtrl',
            controllerAs: 'registersocialsecCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$window', function ($ocLazyLoad, getSessionSrvc, $location, $window, event) {
                    if ($window.localStorage.getItem("memreg") == null) {
                        $location.path('/register.html');
                        //event.preventDefault();
                    } else
                        getSessionSrvc.checkPgSec('outpg', event);

                    return $ocLazyLoad.load([{ name: 'app', files: [registersocialsecCtrl, socialLgnSrvc] }])/*googleRecaptcha,*/
                }]
            }
        })

        .state('register/security/email', {
            url: '/register/security/email.html',
            parent: "masterpage2",
            templateUrl: 'app/register/templates/registeracteml.html',
            controller: 'registersecCtrl',
            controllerAs: 'registersecCtrl',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [registersecCtrl, registerSrvc] }]);
                }]
            }
        })

        .state('register/security/fb', {
            url: '/register/security/fb.html',
            templateUrl: 'app/register/templates/fblgn.html'
        })

        .state('register/security/fb/email', {
            url: '/register/security/fb/email.html',
            parent: "masterpage2",
            templateUrl: 'app/register/templates/registerfbeml.html',
            controller: 'registerfbemlCtrl',
            controllerAs: 'registerfbemlCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [registerfbemlCtrl, socialLgnSrvc] }]);
                }]
            }
        })

        .state('register/security/details', {
            url: '/register/security/details.html',
            parent: "masterpage2",
            templateUrl: 'app/register/templates/registerdtls.html',
            controller: 'registerdtlsCtrl',
            controllerAs: 'registerdtlsCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$http', function ($ocLazyLoad, getSessionSrvc, $location, $http, event) {
                    var urlmId = $location.absUrl().split('?')[1];
                    if (!urlmId) {
                        $location.path('/register.html');
                        //event.preventDefault();
                    }
                    else
                        getSessionSrvc.checkPgSec('outpg', event);

                    return $ocLazyLoad.load([{ name: 'app', files: [registerdtlsCtrl, signinCtrl, signinSrvc, registerSrvc, socialLgnSrvc, countryIntlSrv, blurIt] }])
                }]
            }
        })

           .state('register/emailsend', {
               url: '/register/emailsend.html',
               parent: "masterpage2",
               templateUrl: 'app/register/templates/registersendeml.html',
               controller: 'registersendemlCtrl',
               controllerAs: 'registersendemlCtrlAs',
               resolve: {
                   lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                     //  getSessionSrvc.checkPgSec('outpg', event);
                       return $ocLazyLoad.load([{ name: 'app', files: [registersendemlCtrl, registerSrvc] }]);
                   }]
               }
           })

        //.state('register-mem-promotion', {
        //    url: '/register-mem-promotion.html',
        //    parent: "masterpage",
        //    templateUrl: 'app/register/templates/reg-membership-promotional.html'
        //})

        .state('reg-membership', {
            url: '/reg-membership.html',
            parent: "masterpage",
            templateUrl: 'app/register/templates/reg-membership.html'
        })

        .state('signin', {
            url: "/signin.html",
            parent: "masterpage2",
            templateUrl: 'app/signin/templates/signin.html',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [signinCtrl, signinDirts, signinSrvc, fblgn, socialLgnSrvc, sociallgnCtrl, selfprofileSrvc] }]);
                }]
            }
        })
          //.state("registerd/social/user", {
          //    url: "/register/social/registered.html",
          //    templateUrl: "app/signin/templates/registeredsocial.html",
          //    controller: 'registersocialemlCtrl',
          //    controllerAs: 'registersocialemlCtrlAs',
          //    resolve: {
          //        lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [registersocialemlCtrl] }]); }]
          //    }
          //})
        .state('signout', {
            url: '/signout.html',
            parent: "masterpage2",
            templateUrl: 'app/signin/templates/signout.html',
            controller: 'signinCtrl',
            controllerAs: 'signinCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [signinCtrl, signinDirts, fblgn, socialLgnSrvc, sociallgnCtrl, signinSrvc, selfprofileSrvc] }]);
                }]
            }
        })

         .state('signouthide', {
             url: '/signouthide.html',
             parent: "masterpage2",
             templateUrl: 'app/signin/templates/signouthide.html',
             controller: 'signinCtrl',
             controllerAs: 'signinCtrlAs',
             resolve: {
                 lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                     getSessionSrvc.checkPgSec('outpg', event);
                     return $ocLazyLoad.load([{ name: 'app', files: [signinCtrl, signinDirts, fblgn, socialLgnSrvc, sociallgnCtrl, signinSrvc, selfprofileSrvc] }]);
                 }]
             }
         })

        .state('signinpwdreset', {
            url: '/signinpwdreset.html',
            parent: "masterpage2",
            templateUrl: 'app/signin/templates/signinpwdreset.html',
            controller: 'signinCtrl',
            controllerAs: 'signinCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [signinCtrl, signinDirts, signinSrvc, socialLgnSrvc] }]);
                }]
            }
        })

        .state('profilehide', {
            url: '/profilehide.html',
            parent: "masterpage",
            templateUrl: 'app/signin/templates/profilehide.html',
            controller: 'signinCtrl',
            controllerAs: 'signinCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$window', function ($ocLazyLoad, getSessionSrvc, $location, $window, event) {
                    if (!($window.sessionStorage.getItem("8B3414FB"))) {
                        $location.path('/');
                    }
                    return $ocLazyLoad.load([{ name: 'app', files: [signinCtrl, signinSrvc, socialLgnSrvc] }])
                }]
            }
        })

        //.state('forgotpwd', {
        //    url: '/forgotpwd.html',
        //    parent: "masterpage2",
        //    templateUrl: 'app/signin/templates/forgotpwd.html',
        //    controller: 'forgotpwdCtrl',
        //    controllerAs: 'forgotpwdCtrlAs',
        //    resolve: {
        //        lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
        //            getSessionSrvc.checkPgSec('outpg', event);
        //            return $ocLazyLoad.load([{ name: 'app', files: [forgotpwdSrvc, forgotpwdCtrl] }]);
        //        }]/*, googleRecaptcha*/
        //    }
        //})

        //.state('forgotpwdsec', {
        //    url: '/forgotpwdsec.html',
        //    parent: "masterpage2",
        //    templateUrl: 'app/signin/templates/forgotpwdsec.html',
        //    controller: 'forgotpwdCtrl',
        //    controllerAs: 'forgotpwdCtrlAs',
        //    resolve: {
        //        lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$window', function ($ocLazyLoad, getSessionSrvc, $location, $window, event) {
        //            if ($window.localStorage.getItem("A5D7FPD45") == null) {
        //                $location.path('/forgotpwd.html');
        //                //event.preventDefault();
        //            } else
        //                getSessionSrvc.checkPgSec('outpg', event);

        //            return $ocLazyLoad.load([{
        //                name: 'app', files: [forgotpwdSrvc, forgotpwdCtrl]
        //            }])
        //        }]
        //    }
        //})

        //.state('forgotpwdreset', {
        //    url: '/forgotpwdreset.html',
        //    parent: "masterpage2",
        //    templateUrl: 'app/signin/templates/forgotpwdreset.html',
        //    controller: 'forgotpwdCtrl',
        //    controllerAs: 'forgotpwdCtrlAs',

        //    resolve: {
        //        lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$rootScope', '$http', function ($ocLazyLoad, getSessionSrvc, $location, $rootScope, $http, event) {
        //            var url = $location.absUrl().split('?')[1];
        //            if (url == "" || url == null || url == undefined) {
        //                $location.path('/sign.html');
        //                //event.preventDefault();
        //            }
        //            else {
        //                $http.get(getApiDomainUrl() + "/api/registersignin/fprsndemlchk/" + url)
        //                  .then(function (response) {
        //                      if (response.data != true) {
        //                          $rootScope.frgtpwdLnkExp = false;
        //                          $rootScope.frgtpwdLnkExpOops = true;
        //                      }
        //                      else {
        //                          $rootScope.frgtpwdLnkExp = true;
        //                          $rootScope.frgtpwdLnkExpOops = false;
        //                      }
        //                  });
        //            }

        //            return $ocLazyLoad.load([{
        //                name: 'app', files: [forgotpwdSrvc, forgotpwdCtrl]
        //            }])
        //        }]
        //    }
        //})

        //.state('forgotpwdreseteml', {
        //    url: '/forgotpwdreseteml.html',
        //    parent: "masterpage2",
        //    templateUrl: 'app/signin/templates/forgotpwdreseteml.html',
        //    controller: 'forgotpwdCtrl',
        //    controllerAs: 'forgotpwdCtrlAs',

        //    resolve: {
        //        lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$window', function ($ocLazyLoad, getSessionSrvc, $location, $window, event) {
        //            if ($window.localStorage.getItem("A5D7FPD45") == null) {
        //                $location.path('/forgotpwd.html');
        //                //event.preventDefault();
        //            } else
        //                getSessionSrvc.checkPgSec('outpg', event);

        //            return $ocLazyLoad.load([{
        //                name: 'app', files: [forgotpwdSrvc, forgotpwdCtrl]
        //            }])
        //        }]
        //    }
        //})

          .state('forgotpwd', {
              url: '/forgotpwd.html',
              templateUrl: 'app/signin/templates/forgotpwd/forgotpwd.html',
              controller: 'forgotcpwdCtrl',
              controllerAs: 'forgotpwdCtrlAs',
              resolve: {
                  lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                      getSessionSrvc.checkPgSec('outpg', event);
                      return $ocLazyLoad.load([{ name: 'app', files: [forgotpwdSrvc, forgotcpwdCtrl] }]);
                  }]/*, googleRecaptcha*/
              }
          })

        .state('forgotpwdreset', {
            url: '/forgotpwdreset.html',
            templateUrl: 'app/signin/templates/forgotpwd/forgotpwdreset.html',
            controller: 'forgotcpwdCtrl',
            controllerAs: 'forgotpwdCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$rootScope', '$http', function ($ocLazyLoad, getSessionSrvc, $location, $rootScope, $http, event) {
                    var url = $location.absUrl().split('?')[1];
                    if (url == "" || url == null || url == undefined) {
                        $location.path('/sign.html');
                        //event.preventDefault();
                    }
                    else {
                        $http.get(getApiDomainUrl() + "/api/registersignin/fprsndemlchk/" + url)
                          .then(function (response) {
                              if (response.data != true) {
                                  $rootScope.frgtpwdLnkExp = false;
                                  $rootScope.frgtpwdLnkExpOops = true;
                              }
                              else {
                                  $rootScope.frgtpwdLnkExp = true;
                                  $rootScope.frgtpwdLnkExpOops = false;
                              }
                          });
                    }

                    return $ocLazyLoad.load([{
                        name: 'app', files: [forgotpwdSrvc, forgotcpwdCtrl]
                    }])
                }]
            }
        })

        .state('forgotpwdreseteml', {
            url: '/forgotpwdreseteml.html',
            templateUrl: 'app/signin/templates/forgotpwd/forgotpwdreseteml.html',
            controller: 'forgotcpwdCtrl',
            controllerAs: 'forgotpwdCtrlAs',

            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$window', function ($ocLazyLoad, getSessionSrvc, $location, $window, event) {
                    if ($window.localStorage.getItem("A5D7FPD45") == null) {
                        $location.path('/forgotpwd.html');
                        //event.preventDefault();
                    } else
                        getSessionSrvc.checkPgSec('outpg', event);

                    return $ocLazyLoad.load([{
                        name: 'app', files: [forgotpwdSrvc, forgotcpwdCtrl]
                    }])
                }]
            }
        })

        //help start
        .state('contactus', {
            url: '/contactus.html',
            parent: "masterpage",
            templateUrl: '/app/help/templates/contactus.html',
            controller: 'contactusCtrl',
            controllerAs: 'contactusCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [contactusCtrl, contactusSrvc] }]); }]/*, googleRecaptcha*/
            }
        })
        //help start

        //aboutus start
        .state("aboutus", {
            url: '/aboutus.html',
            parent: "masterpage",
            templateUrl: "/app/aboutus/templates/abtus.html",
            controller: "abtusCtrl",
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [abtusCtrl, slicksliderCss, slicksliderJS] }]); }]
            }
        })
        //idp2018
        .state("idp2018", {
            url: '/idp2018.html',
            parent: "masterpage",
            templateUrl: "/app/events/templates/idp2018.html",
            controller: "eventsCtrl",
            //controller: "eventsCtrlAs",
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [eventsCtrl] }]); }]
            }
        })

        //team start
        .state("ourteam", {
            url: '/ourteam.html',
            parent: "masterpage",
            templateUrl: "/app/team/templates/ourteam.html",
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [wowminJS, slicksliderCss, slicksliderJS] }]); }]
            }
        })      

   		.state("membership", {
   		    url: '/membership.html',
   		    parent: "masterpage",
   		    templateUrl: "/app/membership/templates/membership.html",
   		    controller: "membershipCtrl",
   		    controllerAs: "membershipCtrlAs",
   		    resolve: {
   		        lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [membershipCtrl, membershipSrvc] }]); }]
   		    }
   		})

        //.state("gp", {
        //    url: '/gp.html',
        //    parent: "masterpage",
        //    templateUrl: "/app/payments/templates/gp.html",
        //})

   		.state("dating-tips", {
   		    url: '/dating-tips.html?secId',
   		    parent: "masterpage",
   		    templateUrl: "/app/datingTips/templates/dtiplst.html",
   		    controller: "dtiplstCtrl",
   		    controllerAs: "dtiplstCtrlAs",
   		    reloadOnSearch: false,
   		    resolve: {
   		        lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [dtiplstCtrl, dtipSrvc, dtipdataSrvc, infinitescroll, addThis, pchtabSrpt] }]); }]
   		    }
   		    //SOCIAL SHARE TEST FOR LOCAL - START
   		}).state("testss", {
   		    url: '/testss.html',
   		    templateUrl: "/app/datingTips/templates/testsocialdatingtip.html",
   		    controller: "dtiplstCtrl",
   		    controllerAs: "dtiplstCtrlAs",
   		    resolve: {
   		        lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [dtiplstCtrl, dtipSrvc, dtipdataSrvc, infinitescroll, addThis, pchtabSrpt] }]); }]
   		    }
   		    //SOCIAL SHARE TEST FOR LOCAL - END
   		})

        .state("dating-tip", {
            url: '/dating-tip/:gpn',
            parent: "masterpage",
            templateUrl: "/app/datingTips/templates/dtip.html",
            controller: "dtipCtrl",
            controllerAs: "dtipCtrlAs",
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{ name: 'app', files: [dtipCtrl, dtipSrvc, dtipdataSrvc, addThis, dtipcmtSrvc, infinitescroll, signinDirts, signinCtrl, signinSrvc, socialLgnSrvc, sociallgnCtrl, fblgn, selfprofileSrvc] }]);
                }]
            }

        })

        .state("dating-tip-srch", {
            url: '/dating-tip-srch.html',
            parent: "masterpage",
            templateUrl: "/app/datingTips/templates/dtipsrch.html",
            controller: "dtipsrchCtrl",
            controllerAs: "dtipsrchCtrlAs",
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [dtipsrchCtrl, dtipSrvc, dtipdataSrvc, infinitescroll, addThis] }]); }]
            }
        })
        //datingTips end

        //policies start
        .state("privacy-policy", {
            url: '/privacy-policy.html',
            parent: "masterpage",
            templateUrl: "/app/policies/templates/pp.html",
            controller: 'ppCtrl',
            controllerAs: 'ppCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{ name: 'app', files: [ppCtrl, ppSrvc] }]);
                }]
            }
        })

        .state("privacy-policy-pop", {
            url: '/privacy-policy-pop.html',
            parent: "masterpage",
            templateUrl: "/app/policies/templates/ppPop.html",
            controller: 'ppCtrl',
            controllerAs: 'ppCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', '$window', function ($ocLazyLoad, $window) {
                    if (!$window.sessionStorage.getItem("8B3414FB"))
                        $window.location.href = "/signin.html";
                    return $ocLazyLoad.load([{ name: 'app', files: [ppCtrl, ppSrvc] }]);
                }]
            }
        })

        .state('terms-conditions', {
            url: '/terms-conditions.html',
            parent: "masterpage",
            templateUrl: '/app/policies/templates/tc.html',
            controller: 'tcCtrl',
            controllerAs: 'tcCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{ name: 'app', files: [tcCtrl, tcSrvc] }]);
                }]
            }
        })

        .state('terms-conditionspop', {
            url: '/terms-conditionspop.html',
            parent: "masterpage",
            templateUrl: '/app/policies/templates/tcPop.html',
            controller: 'tcCtrl',
            controllerAs: 'tcCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', '$window', function ($ocLazyLoad, $window) {
                    if (!$window.sessionStorage.getItem("8B3414FB"))
                        $window.location.href = "/signin.html";
                    return $ocLazyLoad.load([{ name: 'app', files: [tcCtrl, tcSrvc] }]);
                }]
            }
        })

        .state('optoutfr', {
            url: '/optoutfr.html',
            templateUrl: '/app/policies/templates/optoutfr.html',
            controller: 'ppCtrl',
            controllerAs: 'ppCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{ name: 'app', files: [ppCtrl, ppSrvc] }]);
                }]
            }
        })
        .state('optoutfrt', {
            url: '/optoutfrt.html',
            templateUrl: '/app/policies/templates/optoutfrt.html',
        })

        .state('optoutadv', {
            url: '/optoutadv.html',
            templateUrl: '/app/policies/templates/optoutadv.html',
            controller: 'ppCtrl',
            controllerAs: 'ppCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{ name: 'app', files: [ppCtrl, ppSrvc] }]);
                }]
            }
        })
        .state('optoutadvt', {
            url: '/optoutadvt.html',
            templateUrl: '/app/policies/templates/optoutadvt.html',
        })

        .state('dashboard', {
            url: '/dashboard.html',
            parent: "masterpage",
            templateUrl: 'app/dashboard/templates/dashboard.html',
            controller: 'dashboardCtrl',
            controllerAs: 'dashboardCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$cookieStore', '$location', function ($ocLazyLoad, getSessionSrvc, $cookieStore, $location, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    var urlLink = $location.absUrl().split('?')[1];
                    if (urlLink) {
                        if (urlLink == "fav") $cookieStore.put("P_dbTb", "tb2");
                        else if (urlLink == "mm") $cookieStore.put("P_dbTb", "tb3");
                        else if (urlLink == "rvm") $cookieStore.put("P_dbTb", "tb4");
                        else if (urlLink == "flrtby") $cookieStore.put("P_dbTb", "tb5");
                        else if (urlLink == "flrt") $cookieStore.put("P_dbTb", "tb5");
                        else if (urlLink == "pv") $cookieStore.put("P_dbTb", "tb6");
                    }
                    return $ocLazyLoad.load([{ name: 'app', files: [signinCtrl, dashboardCtrl, dashboardSrvc, pchtabSrpt, selfprofileFltr, othersprofileSrvc, advsrchCtrl, srchSrvc, dashboardFact, countryIntlSrv, infinitescroll, membershipSrvc] }]);
                }]
            }
        })

        .state('profile', {
            url: '/profile.html',
            parent: "masterpage",
            templateUrl: 'app/profile/self/templates/selfprofile.html',
            controller: 'selfprofileCtrl',
            controllerAs: 'selfprofileCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [imgOrient, swiperJS, selfprofileSrpt, selfprofileCtrl, selfprofileSrvc, countryIntlSrv, slicksliderCss, slicksliderJS, socialLgnSrvc, sociallgnCtrl, socialPhotosCtrl, socialphotosSrvc, prflphotodataSrvc, glryphotosDirts, selfmatchprefCtrl, selfmatchprefSrvc, objMinSldr, JqrySldr, selfprofileFltr, rangeSldr, sliderDrctve, imgCrop, dashboardFact, fblgn, blurIt, resizeIt]
                    }]);
                }]
            }
        })

        .state('match', {
            url: '/match/:memberId',
            parent: "masterpage",
            templateUrl: 'app/profile/others/templates/mtProfile.html',
            controller: 'othersprofileCtrl',
            controllerAs: 'othersprofileCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$window', '$stateParams', function ($ocLazyLoad, getSessionSrvc, $window, $stateParams, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    var urlmId = $stateParams.memberId;
                    if (!getSessionSrvc.pcd(urlmId)) { // if the member is coming from link then redirect to his/her profile
                        $window.location.href = "match/" + getSessionSrvc.pce(urlmId);
                    }
                    return $ocLazyLoad.load([{
                        name: 'app', files: [swiperJS, othersprofileCtrl, othersprofileSrvc, selfprofileSrpt, selfprofileCtrl, matchAnalysis, selfprofileSrvc, selfprofileFltr, selfmatchprefSrvc, srchSrvc, dashboardFact]
                    }]);
                }]
            }
        })


    //profile end


    //account start
    .state('account', {
        url: '/account.html?tb',
        parent: "masterpage",
        controller: "accountCtrl",
        controllerAs: "accountCtrlAs",
        templateUrl: '/app/account/templates/account.html',
        reloadOnSearch: false,
        params : { 'tb':'account'},
        resolve: {
            lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                getSessionSrvc.checkPgSec('inpg', event);
                return $ocLazyLoad.load([{
                    name: 'app', files: [accountCtrl, accountSrvc, membershipCtrl, membershipSrvc, countryIntlSrv, pchtabSrpt]
                }]);
            }]
        }
    })

    .state('accountdel', {
        url: '/accountdel.html',
        parent: "masterpage",
        controller: "accountdeleteCtrl",
        controllerAs: "accountdeleteCtrlAs",
        templateUrl: '/app/account/templates/accountdelete.html',
        resolve: {
            lazy: ['$ocLazyLoad', 'getSessionSrvc', '$window', '$location', function ($ocLazyLoad, getSessionSrvc, $window, $location) {
                var urlLink = $location.absUrl().split('?')[1];
                if (!urlLink) {
                    $location.path('/dashboard.html');
                }
                getSessionSrvc.checkPgSec('inpg', event);
                return $ocLazyLoad.load([{
                    name: 'app', files: [accountdeleteCtrl, accountdeleteSrvc]
                }]);
            }]
        }
    })

    .state('changegender', {
            url: '/trns/cg.html',
            parent: "masterpage",
            controller: "changeGenderCtrl",
            controllerAs: "changeGenderCtrlAs",
            templateUrl: '/app/account/templates/changeGender.html',
            resolve: {
                lazy: ['$ocLazyLoad', '$location', function ($ocLazyLoad, $location) {
                    var urlLink = $location.absUrl().split('?')[1];
                    if (!urlLink) {
                        $location.path('/');
                    }
                    return $ocLazyLoad.load([{
                        name: 'app', files: [changeGenderCtrl, changeGenderSrvc]
                    }]);
                }]
            }
        })

    //account End


    //Search Starts
        .state('advancedsearch', {
            url: '/advancedsearch.html',
            parent: "masterpage",
            templateUrl: '/app/search/templates/advsrch.html',
            controller: 'advsrchCtrl',
            controllerAs: 'advsrchCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [advsrchCtrl, srchSrvc, countryIntlSrv, infinitescroll]
                        //name: 'app', files: [advsrchCtrl, srchSrvc, selfprofileSrvc, othersprofileSrvc, countryIntlSrv, pchtabSrpt, rangeSldr, sliderDrctve, infinitescroll, dashboardFact]
                    }]);
                }]
            }
        })

    .state('basicsearch', {
        url: '/basicsearch.html',
        parent: "masterpage",
        templateUrl: '/app/search/templates/basicsrch.html',
        controller: 'basicsrchCtrl',
        controllerAs: 'basicsrchCtrlAs',
        resolve: {
            lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                getSessionSrvc.checkPgSec('inpg', event);
                return $ocLazyLoad.load([{
                    name: 'app', files: [basicsrchCtrl, srchSrvc, infinitescroll, pchtabSrpt]
                    //name: 'app', files: [basicsrchCtrl, srchSrvc, countryIntlSrv, infinitescroll, dashboardFact, othersprofileSrvc, pchtabSrpt, srchSrvc]
                }]);
            }]
        }
    })
    //Search End

    //Messaging Starts
    .state('msgcenter', {
        url: '/msgcenter.html',
        parent: "masterpage",
        templateUrl: '/app/messages/templates/msgcenter.html',
        controller: 'msgcenterCtrl',
        controllerAs: 'msgcenterCtrlAs',
        resolve: {
            lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                getSessionSrvc.checkPgSec('inpg', event);
                return $ocLazyLoad.load([{
                    name: 'app', files: [msgcenterCtrl, msgcenterSrvc, infinitescroll, swiperJS, othersprofileCtrl, othersprofileSrvc, selfprofileSrpt, selfprofileCtrl, matchAnalysis, selfprofileSrvc, selfprofileFltr, selfmatchprefSrvc, srchSrvc, dashboardFact]
                }]);
            }]
        }
    })

            .state('message', {
                url: '/message.html',
                parent: "masterpage",
                templateUrl: '/app/chat/templates/message.html'
            })
    //Messaging End

    //Notifications starts
    .state('notifications', {
        url: '/notifications.html',
        parent: "masterpage",
        templateUrl: '/app/notifications/templates/notifications.html',
        controller: 'notificationsCtrl',
        controllerAs: 'notificationsCtrlAs',
        resolve: {
            lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                getSessionSrvc.checkPgSec('inpg', event);
                return $ocLazyLoad.load([{
                    name: 'app', files: [notificationsCtrl, infinitescroll, othersprofileSrvc]
                }]);
            }]
        }
    }).state('instagramPhotos', {
        url: '/InPhotos.html',
        parent: "masterpage",
        templateUrl: '/app/social/templates/instagramphotos.html',
        controller: 'instragramPhtsCtrl',
        controllerAs: 'instragramPhtsCtrlAs',
        resolve: {
            lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                getSessionSrvc.checkPgSec('inpg', event);
                return $ocLazyLoad.load([{
                    name: 'app', files: [inphotosCtrl]
                }]);
            }]
        }
    })

.state("fb", {
    url: '/fb.html',
    parent: "masterpage",
    //controller: 'fblgnCtrl',
    //controllerAs: 'fbCtrlAs',
    templateUrl: '/app/social/templates/sociallgn.html',
    resolve: {
        lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
            return $ocLazyLoad.load([{
                name: 'app', files: [fblgnCtrl, sociallgnCtrl, socialLgnSrvc]
            }]);
        }]
    }
})
    //Notifications End

    .state('err404', {
        url: '/err404.html',
        parent: "masterpage",
        templateUrl: '/app/common/templates/errorpopups/404.html',
    })

    .state('err500', {
        url: '/err500.html',
        parent: "masterpage",
        templateUrl: '/app/common/templates/errorpopups/500.html',
    })

.state('payment', {
    url: '/payment.html',
    controller: 'paymentCtrl',
    controllerAs: 'paymentCtrlAs',
    templateUrl: '/app/payments/templates/payment.html',
    resolve: {
        lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
            getSessionSrvc.checkPgSec('inpg', event);
            return $ocLazyLoad.load([{
                name: 'app', files: [paymentCtrl, paymentrSrvc, paymntValidtnSrvc, jQueryCardChk, ppSrvc, tcSrvc, paypalCheckout, paypalHostedFields, braintreeClient, btPaypalCheckout, bt3DSecure]
            }]);
        }]
    }
})

.state('btpaymentsuccess', {
    url: '/pts/bt/:transactionId',
    controller: 'paymentsuccessCtrl',
    controllerAs: 'paymentsuccessCtrlAs',
    templateUrl: '/app/payments/templates/paymentsuccess.html',
    resolve: {
        lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
            getSessionSrvc.checkPgSec('inpg', event);
            return $ocLazyLoad.load([{
                name: 'app', files: [paymentsuccessCtrl, paymentrSrvc]
            }]);
        }]
    }
})
.state('btpaymentfailure', {
    url: '/ptf/bt/:transactionId',
    controller: 'paymentsuccessCtrl',
    controllerAs: 'paymentsuccessCtrlAs',
    templateUrl: '/app/payments/templates/paymentsuccess.html',
    resolve: {
        lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
            getSessionSrvc.checkPgSec('inpg', event);
            return $ocLazyLoad.load([{
                name: 'app', files: [paymentsuccessCtrl, paymentrSrvc]
            }]);
        }]
    }
})

.state('pwpaymentsuccess', {
    url: '/paymentsuccess/pw/:transactionId',
    controller: 'paymentsuccessCtrl',
    controllerAs: 'paymentsuccessCtrlAs',
    templateUrl: '/app/payments/templates/paymentsuccess.html',
    resolve: {
        lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
            getSessionSrvc.checkPgSec('inpg', event);
            return $ocLazyLoad.load([{
                name: 'app', files: [paymentsuccessCtrl, paymentrSrvc]
            }]);
        }]
    }
})

.state('pppaymentsuccess', {
    url: '/pts/pp/:transactionId',
    controller: 'paymentsuccessCtrl',
    controllerAs: 'paymentsuccessCtrlAs',
    templateUrl: '/app/payments/templates/paymentsuccess.html',
    resolve: {
        lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
            getSessionSrvc.checkPgSec('inpg', event);
            return $ocLazyLoad.load([{
                name: 'app', files: [paymentsuccessCtrl, paymentrSrvc]
            }]);
        }]
    }
})
.state('pppaymentfailure', {
    url: '/ptf/pp/:transactionId',
    controller: 'paymentsuccessCtrl',
    controllerAs: 'paymentsuccessCtrlAs',
    templateUrl: '/app/payments/templates/paymentsuccess.html',
    resolve: {
        lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
            getSessionSrvc.checkPgSec('inpg', event);
            return $ocLazyLoad.load([{
                name: 'app', files: [paymentsuccessCtrl, paymentrSrvc]
            }]);
        }]
    }
})
    .state('changecard', {
        url: '/changecard.html',
        parent: "masterpage",
        templateUrl: "/app/payments/templates/changecard.html",
        controller: "changecardCtrl",
        controllerAs: "changecardCtrlAs",
        resolve: {
            lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                getSessionSrvc.checkPgSec('inpg', event);
                return $ocLazyLoad.load([{
                    name: 'app', files: [braintreeClient,getSessionSrvc,paymentrSrvc, paymntValidtnSrvc, changecardCtrl, jQueryCardChk, ppSrvc, tcSrvc]
                }]);
            }]
        }
    })

    .state('freeTrial', {
        url: '/freetrial.html',
        //parent: "masterpage",
        templateUrl: '/app/register/templates/freetrial.html',
        controller: 'freetrialCtrl',
        controllerAs: 'freetrialCtrlAs',
        resolve: {
            lazy: ['$ocLazyLoad', 'getSessionSrvc', '$window', '$location', function ($ocLazyLoad, getSessionSrvc, $window, $location, event) {
                if ($window.localStorage.getItem("P_ftrl") == 1) {
                    getSessionSrvc.checkPgSec('inpg', event);
                } else
                    $location.path('/signin.html');


                return $ocLazyLoad.load([{
                    name: 'app', files: [freetrialCtrl, membershipSrvc, registerSrvc]
                }]);
            }]
        }
    })

     .state('emlunsubscribe', {
         url: '/emlunsubscribe.html',
         parent: "masterpage",
         templateUrl: '/app/common/templates/emlunsubscribe.html',
         controller: 'emlunsubCtrl',
         controllerAs: 'emlunsubCtrlAs',
         resolve: {
             lazy: ['$ocLazyLoad', '$location', function ($ocLazyLoad, $location) {
                 if ($location.absUrl().includes('?m=')) {
                     var url = $location.absUrl().split('?')[1].split('=')[1];
                     if (url != "" || url != null || url != undefined) {
                         return $ocLazyLoad.load([{
                             name: 'app', files: [emlunsubCtrl, accountSrvc]
                         }]);
                     }
                 }
             }]
         }
     })

    .state('memberticket', {
        url: '/ticketsupport.html',
        //parent: "masterpage",
        templateUrl: '/app/support/templates/tktsprt.html',
        controller: 'mbrtcktrplyCtrl',
        controllerAs: 'mbrtcktrplyCtrlAs',
        resolve: {
            lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                return $ocLazyLoad.load([{
                    name: 'app', files: [mbrtcktrplyCtrl, mbrtckreplySrvc]
                }]);
            }]
        }
    })
    .state('memberemlticket', {
        url: '/memberemailticket.html',
        //parent: "masterpage",
        templateUrl: '/app/support/templates/memberemlticketreply.html',
        controller: 'mbremltcktrplyCtrl',
        controllerAs: 'mbremltcktrplyCtrlAs',
        resolve: {
            lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                return $ocLazyLoad.load([{
                    name: 'app', files: [mbremltcktrplyCtrl, mbremltckreplySrvc]
                }]);
            }]
        }
    })
    .state('referfriend', {
        url: '/referfriend.html',
        templateUrl: '/app/referFriend/templates/referfriend.html',
        parent: "masterpage",
        controller: 'referfriendCtrl',
        controllerAs: 'referfriendCtrlAs',
        resolve: {
            lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                return $ocLazyLoad.load([{
                    name: 'app', files: [referfriendCtrl, referFriendSrvc]
                }]);
            }]
        }
    })
});