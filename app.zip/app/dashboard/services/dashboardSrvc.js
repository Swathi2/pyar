﻿//app.service('dashboardSrvc', ['$http', function ($http) {
angular.module("app").service('dashboardSrvc', ['$http', 'getSessionSrvc', function ($http, getSessionSrvc) {

    //Service for getting member Recommended Matches
    this.dashBrdRecMatchesMatches = function (memberId, pgNo, pgSize, sortBy, sorttype, funCallBack) {
        var url = getApiDomainUrl() + "/api/dashboard/recmat/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        GetServiceByURL($http, url, funCallBack);
    }

    //Service for getting member favorites
    this.dashBrdFav = function (memberId, pgNo, pgSize, sortBy, sorttype, funCallBack) {
        var url = getApiDomainUrl() + "/api/dashboard/fav/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        GetServiceByURL($http, url, funCallBack);
    }

    //Service for getting member Mutual Matches
    this.dashBrdMutualMatches = function (memberId, pgNo, pgSize, sortBy, sorttype, funCallBack) {
        var premMember = getSessionSrvc.p_sub(); //1. Basic 2. Premium
        if (premMember == 1)
            var url = getApiDomainUrl() + "/api/dashboard/bmutmat/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        else if (premMember == 2)
            var url = getApiDomainUrl() + "/api/dashboard/mutmat/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        GetServiceByURL($http, url, funCallBack);
    }

    //Service for getting member Reverse Matches
    this.dashBrdReverseMatches = function (memberId, pgNo, pgSize, sortBy, sorttype, funCallBack) {
        var premMember = getSessionSrvc.p_sub(); //1. Basic 2. Premium
        if (premMember == 1)
            var url = getApiDomainUrl() + "/api/dashboard/brevmat/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        else if (premMember == 2)
            var url = getApiDomainUrl() + "/api/dashboard/revmat/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        GetServiceByURL($http, url, funCallBack);
    }

    //Service for getting member Flirts (sent)
    this.dashBrdFlirt = function (memberId, pgNo, pgSize, sortBy, sorttype, funCallBack) {
        var url = getApiDomainUrl() + "/api/dashboard/flirt/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        GetServiceByURL($http, url, funCallBack);
    }

    //Service for getting member Flirts By (received)
    this.dashBrdFlirtBy = function (memberId, pgNo, pgSize, sortBy, sorttype, funCallBack) {
        var url = getApiDomainUrl() + "/api/dashboard/flirtby/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        GetServiceByURL($http, url, funCallBack);
    }

    //Service for getting member Profile views
    this.dashBrdProfileViews = function (memberId, pgNo, pgSize, sortBy, sorttype, funCallBack) {
        var premMember = getSessionSrvc.p_sub(); //1. Basic 2. Premium
        if (premMember == 1)
            var url = getApiDomainUrl() + "/api/dashboard/bpv/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        else if (premMember == 2)
            var url = getApiDomainUrl() + "/api/dashboard/pv/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        GetServiceByURL($http, url, funCallBack);
    }
    //Service to refer a friend for signup
    this.saveReferelEmails = function (mId, email, funCallBack) {
        var data = { 'val': email }
        var url = getApiDomainUrl() + "/api/dashboard/frdref/" + mId;
        PostServiceByURL($http, url, data, funCallBack);
    }
}]);