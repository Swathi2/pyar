﻿angular.module("app").controller('dashboardCtrl', ['getSessionSrvc', 'dashboardSrvc', '$window', '$timeout', '$state', '$scope', 'dashboardFact', '$cookieStore', '$rootScope', 'membershipSrvc', 'cmnSrvc', '$location',
function (getSessionSrvc, dashboardSrvc, $window, $timeout, $state, $scope, dashboardFact, $cookieStore, $rootScope, membershipSrvc, cmnSrvc, $location) {

    tabMenu();
    var vm = this;
    var mId = getSessionSrvc.p_mId();
    var premMember = getSessionSrvc.p_sub();
    var cmnDTO = $cookieStore.get("P_dbTb");
    vm.trialDays = function () { return cmnSrvc.getTrialDays() };
    vm.srtImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.svg";
    vm.NameLimit = 15;
    vm.stateCntryLimit = 20;
    vm.orderByChecked = 1;
    vm.showRbt = true;
    vm.tabValue = 1;
    vm.recmdVal = vm.favVal = vm.flirtsVal = vm.FlirtsByVal = vm.viewsVal = 1; vm.mutVal = vm.revVal = 2;
    vm.isSortCmplt = false;
    vm.rbtList = false;
    vm.memberEnc = function (memId) { return getSessionSrvc.pce(memId); }

    //freid referal
    vm.success = true;
    vm.EmailPlaceholder = "Friend's Email";
    vm.emailKpcls = "bgWht";
    vm.email = "";
    vm.btnval = false;

    function emptyFrndRefrl(placeHolder) { vm.EmailPlaceholder = placeHolder; vm.email = null; vm.emailKpcls = "eror"; vm.btnval = false; }
    function needEmailCheck(email) { return $rootScope.emailRegex.test(email); }

    vm.emailCheck = function () {
        if (vm.email) {
            if (vm.email.length > 75) { emptyFrndRefrl("Must be < 75 characters"); }
            else if (!needEmailCheck(vm.email)) { emptyFrndRefrl("Invalid email address"); }
        }
        else { emptyFrndRefrl("Please enter email address"); }
    }

    //Email change event
    vm.emailChnage = function () {
        vm.emailKpcls = "bgWht";
        vm.btnval = false;

        if (vm.email.length > 75) { emptyFrndRefrl("Must be < 75 characters"); }
        else { if (!needEmailCheck(vm.email)) { vm.btnval = false; } else { vm.btnval = true; } }
    }

    function resetEmailRf() {
        vm.EmailPlaceholder = "Friend's Email";
        vm.emailKpcls = "bgWht";
        vm.email = "";
        vm.btnval = false;
    }

    vm.savingReferals = function () {
        if (vm.email && vm.btnval == true) {
            pcShowLoader("referFrd");
            dashboardSrvc.saveReferelEmails(mId, vm.email, function (response, status) {
                if (status == 200) {
                    if (response == "1" || response == 1) { emptyFrndRefrl("User opted out"); }
                    else if (response == "2" || response == 2) { emptyFrndRefrl("User already registered"); }
                    else if (response == "3" || response == 3) { emptyFrndRefrl("User already invited"); }
                    else if (response == "4" || response == 4) {
                        vm.success = false;
                        resetEmailRf()
                        $timeout(function () {
                            vm.success = true;
                        }, 5000);
                    }
                    else if (response == null || response == "") { emptyFrndRefrl("unable to send invitation"); }
                    hideLoader();
                } else {
                    hideLoader();
                }
            });
        }
    }

    vm.resetRefrfrdTxt = function () {
        vm.refrshare = !vm.refrshare;
        vm.success = true;
        resetEmailRf();
    }

    //referal a frnd end

    //below code is executed when member come from free trail page start
    if ($rootScope.fromFreeTrialPage == true) {
        membershipSrvc.memberPremiumTbl(function (response, status) {
            if (status = 200 && response != null) {
                vm.premiumTbl = response;
                $("#premFeaturesDasboard").modal('show');
            }
        });
        //bind image source for premium features
        vm.bindImgSrc = function (imgPath) {
            return addCdnPath(imgPath);
        }
        $rootScope.fromFreeTrialPage = false;
    }

    //this popup shows when trial period complete start
    var subExpDate = new Date(getSessionSrvc.p_subex());
    var curDate = new Date();
    var trailMembr = getSessionSrvc.p_subtm();
    if (premMember == 1 && trailMembr == 2 && (subExpDate < curDate)) {
        if (cmnSrvc.ftPOPCheck(5)) {
            membershipSrvc.memberPremiumTbl(function (response, status) {
                if (status = 200 && response != null) {
                    vm.premiumTbl = response;
                    getPrmPlans(function (response) {
                        vm.prmSymbl = response.currencySymbol;
                        prmPriceDisplay(response.price.toString())
                        $("#trialMemExpires").modal('show');
                        hideLoader();
                    });
                }
            });
            cmnSrvc.ftPOPUpdate(5);
        }
    };

    function prmPriceDisplay(prmPrice) {
        if (prmPrice.indexOf('.') != -1) {
            var price = prmPrice.split('.');
            vm.prmbPrice = price[0];
            if (parseInt(price[1]) > 0) {
                vm.prmsPrice = price[1];
            } else {
                vm.prmsPrice = "";
            }
        } else {
            vm.prmbPrice = prmPrice;
            vm.prmsPrice = "";
        };
    };

    function getPrmPlans(callback) {
        cmnSrvc.getMSSP(mId, function (response, status) {
            if (status == 200) {
                cmnSrvc.sessionUpdate(response);
                callback(response);
            }
        });
    };

    vm.goPremium = function () {
        $("#trialMemExpires").modal('hide');
        $("#trialMemExpires").on('hidden.bs.modal', function () {
            $state.go("payment");
        });
    }
    vm.sharefb = function () {
        var updatedUrl = 'https://www.pyar.com';
        var title = "Pyar.com";
        updatingSocialSharingUrl("", "dfb", updatedUrl, title);
    }


    //this popup shows when trial period complete start

    //below code is executed when member come from free trail page end


    // when user clicked on view favorites in favorite actions showing the my favorites tab. 1. from search page 2. from other profile page
    if (dashboardFact.getfromSrchPg() == true || dashboardFact.getfromOtherPrfPg() == true || $window.localStorage.getItem('tlcrval') == "true") {
        $timeout(function () { $("#pchtb #tb2").click(); }, 500);
        dashboardFact.setfromSrchPg(false);
        dashboardFact.getfromOtherPrfPg(false);
        $window.localStorage.removeItem('tlcrval');
    }

    // maintaing tab value in cookie    
    if (cmnDTO != null) $timeout(function () { $("#pchtb #" + cmnDTO).click(); }, 100);
    else $timeout(function () { $("#pchtb #tb1").click(); }, 100);

    //opening Match Preference popup in profile page.
    vm.openMpPop = function () { dashboardFact.setmpPop(true); $state.go('profile'); }

    //Navigate to search block
    vm.navToSearch = function () { if (premMember == 1) { $state.go("basicsearch"); } else if (premMember == 2) { $state.go("advancedsearch"); } }

    //hiding all empty divs
    function hideEmptyDivs() { vm.RecmdMatchesDataEmptyDv = vm.myFavDataEmptyDv = vm.MutualMatchesDataEmptyDv = vm.ReverseMatchesDataEmptyDv = vm.FlirtsEmptyDv = vm.ProfileViewDataEmptyDv = false; }

    //default sorting order 
    if ((vm.recmdVal = vm.favVal = vm.flirtsVal = vm.FlirtsByVal = vm.viewsVal) == 1) { vm.sortByValue = false; } else { vm.sortByValue = true; }

    //Order Radio button click event
    vm.orderBy = function (val) {
        if (vm.isSortCmplt == true) {
            vm.isSortCmplt = false;
            hdAllDvs();
            vm.shwScrollDiv = false;
            resetPagerInfo();
            if (!val) { val = 1; }
            //default sort value assigning. doing reverse to pyar%.
            if (val == 1 || val == 2) { vm.sortByValue = false; }
            else if (val == 3 || val == 4 || val == 5) { vm.sortByValue = true; }
            vm.srtImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.svg";

            if (vm.tabValue == 1) { vm.recmdVal = val; dbDataFunc(vm.pgNo, vm.pgSize, false); }
            else if (vm.tabValue == 2) { vm.favVal = val; dbDataFunc(vm.pgNo, vm.pgSize, false); }
            else if (vm.tabValue == 3) { vm.mutVal = val; dbDataFunc(vm.pgNo, vm.pgSize, false); }
            else if (vm.tabValue == 4) { vm.revVal = val; dbDataFunc(vm.pgNo, vm.pgSize, false); }
            else if (vm.tabValue == 5) { vm.FlirtsByVal = val; dbDataFunc(vm.pgNo, vm.pgSize, false); }
            else if (vm.tabValue == 6) { vm.flirtsVal = val; dbDataFunc(vm.pgNo, vm.pgSize, false); }
            else if (vm.tabValue == 7) { vm.viewsVal = val; dbDataFunc(vm.pgNo, vm.pgSize, false); }
        }
    }

    //Clear Orderby click event
    vm.ClearSort = function () {
        var val = vm.tabValue;
        if (val == 1 || val == 2 || val == 5 || val == 6 || val == 7) { vm.orderByChecked = 1; }
        else if (val == 3 || val == 4) { vm.orderByChecked = 2; }
        vm.orderBy();
    }

    //data selction when click on tabs
    function dataSelection(showRbt, tabValue) {
        vm.shwScrollDiv = false;
        vm.showRbt = showRbt;
        vm.tabValue = tabValue;

        //divs showing/Hiding when cliked on tabs
        function tabDisplay(tb1, tb2, tb3, tb4, tb5, tb6, tb7) { vm.tb1 = tb1; vm.tb2 = tb2; vm.tb3 = tb3; vm.tb4 = tb4; vm.tb5 = tb5; vm.tb6 = tb6; vm.tb7 = tb7; }

        //keep holding the selected radio button value in every tab
        function set_dbTb(val) { $cookieStore.put("P_dbTb", val); }

        if (vm.tabValue == 1) { vm.orderByChecked = vm.recmdVal; set_dbTb("tb1"); tabDisplay(true, false, false, false, false, false, false); }
        else if (vm.tabValue == 2) { vm.orderByChecked = vm.favVal; set_dbTb("tb2"); tabDisplay(false, true, false, false, false, false, false); }
        else if (vm.tabValue == 3) { vm.orderByChecked = vm.mutVal; set_dbTb("tb3"); tabDisplay(false, false, true, false, false, false, false); }
        else if (vm.tabValue == 4) { vm.orderByChecked = vm.revVal; set_dbTb("tb4"); tabDisplay(false, false, false, true, false, false, false); }
        else if (vm.tabValue == 5) {
            if ($location.absUrl().split('?')[1] == "flrt") { vm.orderByChecked = vm.flirtsVal; set_dbTb("tb5"); tabDisplay(false, false, false, false, true, false, false); }
            else { vm.orderByChecked = vm.FlirtsByVal; set_dbTb("tb5"); tabDisplay(false, false, false, false, true, false, false); }
        }
        else if (vm.tabValue == 6) { vm.orderByChecked = vm.flirtsVal; set_dbTb("tb5"); tabDisplay(false, false, false, false, false, true, false); }
        else if (vm.tabValue == 7) { vm.orderByChecked = vm.viewsVal; set_dbTb("tb6"); tabDisplay(false, false, false, false, false, false, true); }

        //restting data scrolling values
        resetPagerInfo();
        hdAllDvs();
    }



    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  DISPLAY DATA IN SCROLLING STARTS  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    function hdAllDvs() {
        vm.RecmdMatchesDataEmptyDv = false;
        vm.myFavDataEmptyDv = false;
        vm.MutualMatchesDataEmptyDv = false;
        vm.ReverseMatchesDataEmptyDv = false;
        vm.FlirtsEmptyDv = vm.FlirtsDataDv = vm.FlirtsByDataDv = false;
        vm.ProfileViewDataEmptyDv = false;
        vm.ShowViewMore = false;

        //vm.dbDataDiv = false;
        vm.dbData = [];
        vm.dbData = "";
    }

    //restting data scrolling values
    function resetPagerInfo() {
        vm.pgNo = 1;
        vm.pgSize = 200;
        vm.localPgSize = 40;
        vm.limitToMemTileCnt = 40;
        vm.contentExists = true;
    }
    resetPagerInfo();

    vm.dbData = [];

    vm.tileDataCallBack = function (response, status, fromAutoScroll) {
        if (status == 200 && response.length > 0) {
            if (response.length > 1)
                vm.rbtList = true;
            vm.isSortCmplt = true;
            if (response.length <= vm.localPgSize)
                vm.ShowViewMore = false;
            else {
                if (vm.pgNo == 1) {
                    $timeout(function () {
                        if (vm.dbData.length > 0) {
                            vm.ShowViewMore = true;
                        }
                    }, 500)
                }
                else
                    vm.ShowViewMore = true;
            }
            if (response.length < vm.pgSize)
                vm.contentExists = false;
            else
                vm.contentExists = true;
            if (fromAutoScroll) {
                angular.forEach(response, function (data) {
                    vm.dbData.push(data);
                });
                vm.dbDataDiv = true;
            }
            else {
                vm.dbData = response;
                vm.dbDataDiv = true;
            }
        }
        else if (status == 204 || response.length == 0) {
            vm.contentExists = false;
            vm.ShowViewMore = false;
            vm.rbtList = false;
            vm.dbDataDiv = false;
        }
        hideLoader();

        //displaying empty state divs when no data found.
        if (vm.tabValue == 1) { if (response != 0) { vm.RecmdMatchesDataEmptyDv = false; } else { vm.RecmdMatchesDataEmptyDv = true; } }
        else if (vm.tabValue == 2) { if (response != 0) { vm.myFavDataEmptyDv = false; } else { vm.myFavDataEmptyDv = true; } }
        else if (vm.tabValue == 3) { if (response != 0) { vm.MutualMatchesDataEmptyDv = false; } else { vm.MutualMatchesDataEmptyDv = true; } }
        else if (vm.tabValue == 4) { if (response != 0) { vm.ReverseMatchesDataEmptyDv = false; } else { vm.ReverseMatchesDataEmptyDv = true; } }
        else if (vm.tabValue == 5) {
            if (response != 0) { vm.FlirtsEmptyDv = false; vm.FlirtsDataDv = true; vm.FlirtsByDataDv = true; }
            else { vm.FlirtsEmptyDv = true; vm.FlirtsDataDv = false; vm.FlirtsByDataDv = false; }
        }
        else if (vm.tabValue == 6) {
            if (response != 0) { vm.FlirtsEmptyDv = false; vm.FlirtsDataDv = true; vm.FlirtsByDataDv = false; }
            else { vm.FlirtsEmptyDv = true; vm.FlirtsDataDv = true; vm.FlirtsByDataDv = false; }
        }
        else if (vm.tabValue == 7) { if (response != 0) { vm.ProfileViewDataEmptyDv = false; } else { vm.ProfileViewDataEmptyDv = true; } }
    }

    vm.shwScrollDiv = false;

    $rootScope.$on("CallFavTileData", function (e, tileIndex) { // calling from matchTile 
        if (tileIndex != undefined || tileIndex != "") {
            vm.dbData.splice(tileIndex, 1);
            if (vm.dbData.length <= vm.localPgSize && vm.ShowViewMore == true)
                vm.ShowViewMore = false;
            else if (vm.dbData.length == 1)
                vm.rbtList = false
            else if (vm.dbData.length == 0) {
                vm.pgNo++;
                dbDataFunc(vm.pgNo, vm.pgSize, true);
            }
        }
    });


    vm.viewMore = function () {
        if (vm.contentExists && (vm.dbData.length == (vm.pgNo * vm.pgSize))) {
            vm.shwScrollDiv = true;
            if ((vm.limitToMemTileCnt == (vm.dbData.length))) {
                vm.pgNo++;
                dbDataFunc(vm.pgNo, vm.pgSize, true);
            }
        }
        vm.limitToMemTileCnt += vm.localPgSize;
        if (vm.dbData.length < vm.limitToMemTileCnt)
            vm.ShowViewMore = false;
    }

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  DISPLAY DATA IN SCROLLING END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    //Sortby ASC/DESC
    vm.SortBy = function () {
        vm.sortByValue = vm.sortByValue ? false : true;
        vm.shwScrollDiv = false;
        vm.ShowViewMore = false;
        resetPagerInfo();
        if ($("#SrtImg").attr('src') == "https://pccdn.pyar.com/pcimgs/asndng.svg") { vm.srtImgSrc = "https://pccdn.pyar.com/pcimgs/dsndng.svg"; } else { vm.srtImgSrc = "https://pccdn.pyar.com/pcimgs/asndng.svg"; }
        dbDataFunc(vm.pgNo, vm.pgSize, false);
    }

    function dbDataFunc(pageNo, pgSize, fromAutoScroll) {
        hideEmptyDivs();
        showLoader();
        if (vm.shwScrollDiv == true) { vm.dbDataDiv = true; } else { vm.dbDataDiv = false; }
        if (vm.tabValue == 1) {
            dashboardSrvc.dashBrdRecMatchesMatches(mId, pageNo, pgSize, vm.recmdVal, vm.sortByValue, function (response, status) {
                if (vm.tabValue == 1)
                    vm.tileDataCallBack(response, status, fromAutoScroll);
            });
        }
        else if (vm.tabValue == 2) {
            dashboardSrvc.dashBrdFav(mId, pageNo, pgSize, vm.favVal, vm.sortByValue, function (response, status) {
                if (vm.tabValue == 2)
                    vm.tileDataCallBack(response, status, fromAutoScroll);
            });
        }
        else if (vm.tabValue == 3) {
            dashboardSrvc.dashBrdMutualMatches(mId, pageNo, pgSize, vm.mutVal, vm.sortByValue, function (response, status) {
                if (vm.tabValue == 3)
                    vm.tileDataCallBack(response, status, fromAutoScroll);
            });
        }
        else if (vm.tabValue == 4) {
            dashboardSrvc.dashBrdReverseMatches(mId, pageNo, pgSize, vm.revVal, vm.sortByValue, function (response, status) {
                if (vm.tabValue == 4)
                    vm.tileDataCallBack(response, status, fromAutoScroll);
            });
        }
        else if (vm.tabValue == 5) {
            dashboardSrvc.dashBrdFlirtBy(mId, pageNo, pgSize, vm.FlirtsByVal, vm.sortByValue, function (response, status) {
                if (vm.tabValue == 5)
                    vm.tileDataCallBack(response, status, fromAutoScroll);
            });
        }
        else if (vm.tabValue == 6) {
            dashboardSrvc.dashBrdFlirt(mId, pageNo, pgSize, vm.flirtsVal, vm.sortByValue, function (response, status) {
                if (vm.tabValue == 6)
                    vm.tileDataCallBack(response, status, fromAutoScroll);
            });
        }
        else if (vm.tabValue == 7) {
            dashboardSrvc.dashBrdProfileViews(mId, pageNo, pgSize, vm.viewsVal, vm.sortByValue, function (response, status) {
                if (vm.tabValue == 7)
                    vm.tileDataCallBack(response, status, fromAutoScroll);
            });
        }
        if ($location.absUrl().split('?')[1]) {
            $state.go('dashboard');
        }
    }

    function subCheck() {
        if (premMember == 1) {
            if (vm.tabValue === 1 || vm.tabValue === 2 || vm.tabValue === 5 || vm.tabValue === 6) {
                vm.dvPrem = true; vm.dvBasic = false;
            }
            else { vm.dvPrem = false; vm.dvBasic = true; }
        }
        else if (premMember == 2) { vm.dvPrem = true; vm.dvBasic = false; }

        if (vm.tabValue == 1) { vm.tilepath = "recommendedmatches"; vm.mtPop = ""; }
        else if (vm.tabValue == 2) { vm.tilepath = "myfavorites"; vm.mtPop = ""; }
        else if (vm.tabValue == 3) {
            vm.tilepath = "mutualmatches";
            if (cmnSrvc.isTrialOrPrmExpired()) vm.mtPop = "#matchTileMutMatchModal";
            else vm.mtPop = "#smPP";
        }
        else if (vm.tabValue == 4) {
            vm.tilepath = "reversematches";
            if (cmnSrvc.isTrialOrPrmExpired()) vm.mtPop = "#matchTileRevMatchModal";
            else vm.mtPop = "#smPP";
        }
        else if (vm.tabValue == 5) { vm.tilepath = "flirtsreceived"; vm.mtPop = ""; }
        else if (vm.tabValue == 6) { vm.tilepath = "flirtssent"; vm.mtPop = ""; }
        else if (vm.tabValue == 7) {
            vm.tilepath = "profileviews";
            if (cmnSrvc.isTrialOrPrmExpired()) vm.mtPop = "#matchTileViewsModal";
            else vm.mtPop = "#smPP";
        }
    }

    function dataFunCalling() {
        vm.dbData = [];
        subCheck();
        $timeout(function () { dbDataFunc(vm.pgNo, vm.pgSize, false); }, 500);
    }

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RECOMMONDED MATCHES BLOCK STARTS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    vm.RcmndedMatchesClk = function () {
        vm.isSortCmplt = false;
        vm.rbtList = false;
        hdAllDvs();
        dataSelection(true, 1);
        dataFunCalling();
    }

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RECOMMONDED MATCHES BLOCK END   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY FAVORITES BLOCK STARTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    vm.myFavoritesClk = function () {
        vm.isSortCmplt = false;
        vm.rbtList = false;
        hdAllDvs();
        dataSelection(true, 2);
        dataFunCalling();
    }

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY FAVORITES BLOCK END   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MUTUAL MATCHES BLOCK STRATS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    vm.mutualMatchesClk = function () {
        vm.isSortCmplt = false;
        vm.rbtList = false;
        hdAllDvs();
        dataSelection(false, 3);
        dataFunCalling();
    }

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MUTUAL MATCHES BLOCK END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/


    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  REVERSE MATCHES BLOCK STARTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    vm.reverseMatchesClk = function () {
        vm.isSortCmplt = false;
        vm.rbtList = false;
        hdAllDvs();
        dataSelection(false, 4);
        dataFunCalling();
    }

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  REVERSE MATCHES BLOCK END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  FLIRTS RECEVIED BLOCK STARTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    vm.FlirtsClk = function () {
        vm.isSortCmplt = false;
        vm.rbtList = false;
        hdAllDvs();
        dataSelection(true, 6);
        dataFunCalling();
    }

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  FLIRTS RECEVIED BLOCK END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  FLIRTS SENT BLOCK STARTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    vm.FlirtsByClk = function () {
        vm.isSortCmplt = false;
        vm.rbtList = false;
        hdAllDvs();
        dataSelection(true, 5);

        if ($location.absUrl().split('?')[1] == "flrt") {
            $("#btnFlrtSnt").addClass("active");
            $("#btnFlrtRecv").removeClass("active");
            vm.FlirtsClk();
        }
        else {
            $("#btnFlrtSnt").removeClass("active");
            $("#btnFlrtRecv").addClass("active");
            dataFunCalling();
        }
    }

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  FLIRTS SENT BLOCK END   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PROFILE VIEWS BLOCK STARTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    vm.profileViewClk = function () {
        vm.isSortCmplt = false;
        vm.rbtList = false;
        hdAllDvs();
        dataSelection(true, 7);
        dataFunCalling();
    }

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PROFILE VIEWS BLOCK END   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    //vm.prfPercentageDiv = true;    
    var pmds = $window.localStorage.getItem("pmds");
    var ppds = $window.localStorage.getItem("ppds");
    if (pmds == null) {
        vm.prfPercentageDiv = true;
        vm.PflVal = getSessionSrvc.p_pprntg();
        if (vm.PflVal > 50) { vm.crclClass = "over50"; } else {
            delete vm.crclClass
        }
        if (vm.PflVal == 100) {
            vm.prfPercentageDiv = false;
        }
    }
    else if (pmds == true) {
        vm.prfPercentageDiv = false;
    }
    vm.removePMDS = function () {
        $window.localStorage.setItem("pmds", true);
        vm.prfPercentageDiv = false;
    }

    if (ppds == null) {
        vm.prfMatchDiv = true;
    }
    else if (ppds == true) {
        vm.prfMatchDiv = false;
    }
    vm.removePPDS = function () {
        $window.localStorage.setItem("ppds", true);
        vm.prfMatchDiv = false;
    }
    //used for notification click navigate
    $scope.$on("openTab", function (e, tabId) {
        $timeout(function () { $("#pchtb #" + tabId).click(); }, 100)
    });
}]);
