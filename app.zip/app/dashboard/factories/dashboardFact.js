﻿
angular.module("app").factory('dashboardFact', function () {
    //for opening match-preference popup in profile page
    var mpPop = [];
    function setmpPop(data) { mpPop = data; }
    function getmpPop() { return mpPop; }    
    //End

    //view favorites data setting from advanced Search page & geetting in Dashbaord contoller.
    var fromSrchPg = [];
    function setfromSrchPg(data) { fromSrchPg = data; }
    function getfromSrchPg() { return fromSrchPg; }
    //End

    //view favorites data setting from othersPtofile page & geetting in Dashbaord contoller.
    var fromOtherPrfPg = [];
    function setfromOtherPrfPg(data) { fromOtherPrfPg = data; }
    function getfromOtherPrfPg() { return fromOtherPrfPg; }
    //End

    return {
        setmpPop: setmpPop,
        getmpPop: getmpPop,

        setfromSrchPg: setfromSrchPg,
        getfromSrchPg: getfromSrchPg,

        setfromOtherPrfPg: setfromOtherPrfPg,
        getfromOtherPrfPg: getfromOtherPrfPg,
    }
});



    