﻿angular.module("app").controller('othersprofileCtrl', ['getSessionSrvc', 'othersprofileSrvc', 'selfprofileSrvc', 'selfmatchprefSrvc', '$scope', '$window', '$filter', '$location', '$timeout', '$rootScope', 'cmnSrvc', 'msgSrvc', 'srchSrvc', '$state', 'dashboardFact', 'hbySearchFact',
    function (getSessionSrvc, othersprofileSrvc, selfprofileSrvc, selfmatchprefSrvc, $scope, $window, $filter, $location, $timeout, $rootScope, cmnSrvc, msgSrvc, srchSrvc, $state, dashboardFact, hbySearchFact) {
        var vm = this;
        var rs = $rootScope;
        vm.mId = function () { return getSessionSrvc.p_mId(); }
        vm.fn = function () { return getSessionSrvc.p_fn(); }
        vm.pp = function () { return getSessionSrvc.p_ppic(); }
        vm.ppblr = function () { return getSessionSrvc.p_ppicblr(); }
        vm.gender = function () { return getSessionSrvc.p_gndr(); }
        vm.sId = function () { return getSessionSrvc.p_sub(); } //1. Basic 2. Premium
        vm.cntryId = function () { return getSessionSrvc.p_cntryId(); }
        vm.cntryName = function () { return getSessionSrvc.p_cntry(); }
        vm.units = function () { getSessionSrvc.p_uts(); }
        vm.gndrPref = function () { return getSessionSrvc.p_gndrp(); }
        vm.invBrw = function () { return getSessionSrvc.p_ib(); };
        vm.pyrUnits = pyrUntsTxt(vm.units());
        //pyar units setting end

        vm.getMemberBlockId = function (omId) {
            cmnSrvc.getMemberBlockId(omId, function (response, status) {
                if (status == 200) {
                    if (response == '1')
                        initialiseData(omId);
                    else {
                        vm.dvpgVisble = false;
                        vm.dvErrMsg = true;
                        hideLoader();
                    }
                }
            })
        };

        // Checking user has opened in mobile or Desktop
        if (location.pathname.split("/")[1] == "match") {
            showLoader();
            var omId = getSessionSrvc.pcd(location.pathname.split("/").pop());
            if (omId)
                vm.getMemberBlockId(omId);
            else
                $state.go("dashboard");
        }
        //broadcast event fired
        $rootScope.$on("matchbrdcast", function (e, omId) {
            $("#matchmb").show();
            $("body").css("overflow", "hidden");
            $rootScope.mblenopgeErr = true;
            if (vm.omId != omId) {
                $("#matchldr").show();
                vm.getMemberBlockId(omId);
            }
            else if (!vm.dvpgVisble)
                vm.dvErrMsg = true; // if user gets blocked,showing error not found
        }.bind(this));

        //InitialiseFunc
        function initialiseData(omId) {
            vm.profiledata = [];
            //gallery photo module
            //vm.imageStorage = "https://ngagrpincblobstrdev.blob.core.windows.net";
            vm.imageCDN = "https://pccdn.pyar.com";
            vm.index = "";
            vm.gallerytnPhotos = [];
            vm.imgGallery = [];
            vm.galleryPhotos = [];
            vm.profileResponse = [];
            vm.bannerResponse = [];
            vm.picPosition = 0;
            vm.mpuId = "";
            vm.glryImgSrc = '';
            vm.memberCollection = "";
            vm.omId = omId;
            vm.dvpgVisble = false;
            vm.dvErrMsg = false;
            vm.rptPrfVsbl = true;
            vm.rptBnrVsbl = true;
            vm.SrvcmpuId = "";
            vm.reportTxtPlaceHoder = "Tell us what happened";
            //Service for getting member info
            if (vm.mId() != "" && vm.omId != "") {
                if (vm.mId() == vm.omId)
                    $state.go('profile');
                else {
                    othersprofileSrvc.memberProfileView(vm.mId(), vm.omId, vm.invBrw(), function (response, status) {
                        if (status == 200) {
                            if (response == false) {
                                vm.dvpgVisble = false;
                                vm.dvErrMsg = true;
                                if ($location.path() == "/notifications.html" && $(window).width() <= 767) {
                                    $rootScope.mblenopgeErr = true; // to apply postion fixed for 404 img n text
                                }
                            }
                            else {
                                GetPrfInfoCallBack(response, status);
                                vm.dvErrMsg = false;
                                vm.dvpgVisble = true;
                                $rootScope.mblenopgeErr = true;
                                //send only live notifications when invisible browse is false and last viewd not today
                                if ((vm.sId() == 1 || (vm.sId() == 2 && vm.invBrw() == false)) && isCurrentDate(response.lastViewedOn) == false) {
                                    cmnSrvc.memberHideCheck(vm.omId, vm.mId(), function (response, status) {
                                        if (status == 200 && response == false) {
                                            //send profile view based on basic and premium
                                            var type = 63, fn = "", pp = "", gender = null;
                                            if (vm.profileInfo.sId == 2) {
                                                type = 61;
                                                fn = vm.fn();
                                                pp = vm.pp();
                                                gender = vm.gender();
                                            }
                                            else
                                                pp = vm.ppblr();
                                            //if service available send other wise push to array once service readt it will auto post
                                            if (msgSrvc.conId)
                                                msgSrvc.sendMemberNotifications(vm.omId, fn, pp, gender, type, new Date());
                                            else
                                                $rootScope.ntfnData.push({ "sendType": 1, "tmId": vm.omId, "fn": fn, "pp": pp, "gender": gender, "type": type, "date": new Date() });
                                            ////send profile view push notificatoion
                                            //msgSrvc.sendProfileViewPushNotification(vm.mId(), vm.omId, vm.fn(), vm.pp(), vm.gender(), vm.profileInfo.sId, function (response, status) {
                                            //    if (status == 200 && response == true)
                                            //        console.log("profile fill reminder push notification sent");
                                            //    else
                                            //        console.log("profile fill reminder push notification sent fail - " + response);
                                            //});
                                        }
                                    });
                                }
                            }
                            $("#matchldr").hide();
                            hideLoader();
                        }
                    });
                }
            }
            else {
                vm.dvpgVisble = false;
                vm.dvErrMsg = true;
                return false;
            }
            bindGlryImages(function (profileResponse, bannerResponse, galleryPhotos, gallerytnPhotos) {
                vm.glryAlbumImgs = galleryPhotos;
                vm.imgGallery = gallerytnPhotos;
                if (vm.imgGallery.length == 1) {
                    //vm.setglryHeight = 400;
                    vm.imgGallery[0].picPath = vm.imgGallery[0].picPath.replace("/tnb/", "/");
                } else {
                    vm.setglryWidth = 400;
                };
            });
        }

        //Swiper slider for Personality traits
        $scope.$on('onPtImgLoadFinish', function () {
            if ($(window).width() <= 767) {
                vm.Tswiper = new Swiper('.swiperPt', {
                    slidesPerView: 5, //paginationClickable: true, //centeredSlides: true, //loop: true,
                    //breakpoints: { 1024: { slidesPerView: 5 }, 768: { slidesPerView: 3 }, 640: { slidesPerView: 2 }, 320: { slidesPerView: 2 } }
                    breakpoints: { 1024: { slidesPerView: 5 }, 768: { centeredSlides: true, slidesPerView: 4 }, 640: { centeredSlides: true, slidesPerView: 2 }, 320: { centeredSlides: true, slidesPerView: 2 } }
                });
            }
        });

        //Swiper slider for Trophies
        vm.onTrophyImgLoadFinish = function () {
            if ($(window).width() <= 767) {
                vm.Trphswiper = new Swiper('.swiperTrph', {
                    slidesPerView: 5, //paginationClickable: true, //centeredSlides: true, //loop: true,
                    //breakpoints: { 1024: { slidesPerView: 5 }, 768: { slidesPerView: 3 }, 640: { slidesPerView: 2 }, 320: { slidesPerView: 2 } }
                    breakpoints: { 1024: { slidesPerView: 5 }, 768: { centeredSlides: true, slidesPerView: 4 }, 640: { centeredSlides: true, slidesPerView: 2 }, 320: { centeredSlides: true, slidesPerView: 2 } }
                });
            }
        };

        //dynamic classes for swiper slider
        if ($(window).width() <= 767) {
            vm.prfslder = "swiper-wrapper"; vm.prsnimg = "swiper-slide"; vm.ptextcls = "prsnimg";
        }
        else {
            vm.prfslder = "prfslder"; vm.prsnimg = "prsnimg"; vm.ptextcls = "";
        }

        //page unevenly loading resolve function
        vm.pgVisble = function () {
            $timeout(function () {
                vm.dvpgVisble = true;
            }, 200, true);
        }

        //MatchSummary page load Service 
        vm.MatchSummaryClk = function () {
            $("#othersMatchSummaryModal").modal("show");
            var Ex1 = vm.MpPrefDataExt1;

            //About me Match summary  Data preparing Dynamically starts
            //About data prepaired in AboutMeMSFunc
            var AboutMeMSDataJSON = AboutMeMSFunc(Ex1.ethinicities, Ex1.religions, Ex1.AreaOfWork, Ex1.rsStatus, Ex1.HighestEduc, htInfoDlts(vm.cntryId(), vm.prefData));

            vm.AboutMeMSData = [];
            getJSonActiveData(AboutMeMSDataJSON, vm.AboutMeMSData);
            tblSplit(vm.AboutMeMSData, function (t1, t2) {
                vm.abtMeMSTblL1 = t1;
                vm.abtMeMSTblL2 = t2;
            });
            //About me Match summary Data preparing Dynamically End

            //My Appearence Match summary Data preparing Dynamically Starts
            //My Appearence data prepaired in MyApprnceMSFunc
            vm.height = GetHeightValTxt(vm.prefData.minHeight, Ex1.MinHeight, vm.prefData.maxHeight, Ex1.MaxHeight);
            var MyApprnceMSDataJSON = MyApprnceMSFunc(Ex1.eyeColor, Ex1.hairColor, vm.height, Ex1.build, vm.profileInfo.genderPref)

            vm.MyApprnceMSData = [];
            getJSonActiveData(MyApprnceMSDataJSON, vm.MyApprnceMSData);
            tblSplit(vm.MyApprnceMSData, function (t1, t2) {
                vm.MyApprMSTblL1 = t1;
                vm.MyApprMSTblL2 = t2;
            });
            //My Appearence Match summary Data preparing Dynamically End

            //myLife style Match summary Data preparing Dynamically Starts
            //myLife style data prepaired in LifeStyleMSFunc 
            var chldCount = petsCount = null;
            if (vm.prefData.childrenCnt) { chldCount = vm.prefData.childrenCnt - 1; } else { chldCount = vm.prefData.childrenCnt }
            if (vm.prefData.petsCnt) { petsCount = vm.prefData.petsCnt - 1 } else { petsCount = vm.prefData.petsCnt; }
            if (chldCount == 5 || chldCount == "5") { chldCount = "+5"; }
            if (petsCount == 3 || petsCount == "3") { petsCount = "+3"; }
            var LifeStyleMSDataJSON = LifeStyleMSFunc($filter, Ex1.diet, Ex1.Smoke, Ex1.Drink, Ex1.IdealRelationship, chldCount, Ex1.ChildrenPref, petsCount,
                Ex1.PetsPref, Ex1.lang, Ex1.familyLang, Ex1.Religious, Ex1.Traditional);

            vm.LifeStyleMSData = [];
            getJSonActiveData(LifeStyleMSDataJSON, vm.LifeStyleMSData);
            tblSplit(vm.LifeStyleMSData, function (t1, t2) {
                vm.LifeStyleMSArrTblL1 = t1;
                vm.LifeStyleMSArrTblL2 = t2;
            });
            //myLife style Match summary  Data preparing Dynamically End 

            //updating location in matchsummary pop
            if (vm.prefData.locType) {
                if (vm.prefData.locType == 1) {
                    vm.locRadiusTxtDisplay = vm.locRadiusTxt + " of my location";
                    vm.lacnHd = true;
                }
                else if (vm.prefData.locType == 3) {
                    if (vm.prefData.locationInfo != null)
                        if (vm.cntryName() == vm.prefData.locationInfo["countryName"]) {
                            vm.locRadiusTxtDisplay = vm.locRadiusTxt + " of " + vm.prefData.locationInfo["cityName"] + ", " + vm.prefData.locationInfo["stateName"];
                        }
                        else {
                            vm.locRadiusTxtDisplay = vm.locRadiusTxt + " of " + vm.prefData.locationInfo["cityName"] + ", " + vm.prefData.locationInfo["stateName"] + ", " + vm.prefData.locationInfo["countryName"];
                        }
                    vm.lacnHd = true;
                }
                else {
                    vm.prefData.locType = null;
                    vm.lacnHd = false;
                }
            }
            else {
                vm.lacnHd = false;
            }

            //dynamic classes for location.
            if (vm.minAge) { vm.npd = ""; vm.prfpd = "prfpd"; }
            else { vm.npd = "npd"; vm.prfpd = ""; }
        }

        //Page load services Called starts
        var GetPrfInfoCallBack = function (response, status) {
            showLoader();
            vm.profileInfo = response;
            vm.profilePic = $filter("PrflPicFltr")(vm.profileInfo.profilePic, vm.profileInfo.gender, vm.memberCollection);
            $timeout(function () {
                if (vm.profileInfo.profileBnr != "" && vm.profileInfo.profileBnr != null)
                    vm.bnrImg = vm.imageCDN + vm.profileInfo.profileBnr;
                else
                    vm.bnrImg = "https://pccdn.pyar.com/pcimgs/defBnr.jpg";
            }, 200); //for loading image properly 

            if (vm.profileInfo.isProfilePicUpld == false) {
                vm.rptPrfVsbl = false;
            }
            if (vm.profileInfo.profileBnr == "" && vm.profileInfo.profileBnr == null) {
                vm.rptBnrVsbl = false;
            }

            if (vm.profileInfo.cntryName) {
                if (vm.cntryId() == vm.profileInfo.countryId) { vm.memLocation = vm.profileInfo.cityName + ", " + vm.profileInfo.stateName; }
                else { vm.memLocation = vm.profileInfo.cityName + ", " + vm.profileInfo.stateName + ", " + vm.profileInfo.cntryName; }
            }
            vm.opGender = vm.profileInfo.gender;
            vm.age = calculateAge(vm.profileInfo.dob);

            if (vm.profileInfo.fav == 1) {
                vm.profileFav = vm.fvrtdImg;
            } else {
                vm.profileFav = vm.fvImg;
            }
            if (vm.profileInfo.flirt == 1) {
                vm.profileFlrt = vm.flirtlgtImg;
            } else {
                vm.profileFlrt = vm.flirtImg;
            }

            //vm.myBioData = vm.profileInfo.abtDesc;
            Trophiesresult = (vm.profileInfo.trophies).split('#');
            trophiesLoad(Trophiesresult);

            //for tag line text display
            if (vm.profileInfo.profileBnrStyles) {
                vm.TagLineStyles = vm.profileInfo.profileBnrStyles;
                vm.sliderTagLineUpdate = vm.TagLineStyles.split("$##$")[0];
                vm.TagLineViewTop = (vm.profileInfo.profileBnrStyles.split("$##$")[2]) - 150;
                vm.tgLineFontColorUpdate = (vm.TagLineStyles.split("$##$")[3]);
            }
            selfprofileSrvc.GetPrfInfoExt1(vm.omId, vm.profileInfo, GetPrfInfoExt1CallBack);
            selfprofileSrvc.GetPrfInfoExt2(vm.omId, vm.profileInfo, GetPrfInfoExt2CallBack);

            getPrefData(function (response) {
                vm.prefData = response;
                //service for getting match preference information.
                selfmatchprefSrvc.getMpPrefDataExt1(vm.prefData, GetMpPrefDataExt1CallBack);
                othersprofileSrvc.memberPyarPerc(vm.mId(), vm.omId, function (response, status) {
                    if (status == 200) {
                        vm.pyrPerc = response;
                    }
                });
                vm.minAge = response.minAge;
                vm.maxAge = response.maxAge;

                mpDistanceFuncG(function (response) {
                    // binding distance radius data
                    for (var i = 0; i < response.length; i++) {
                        if (response[i].priority == vm.prefData.locRadius) {
                            var rds = response[i].priority == 6 ? (response[i].radius + "+") : response[i].radius;
                            //vm.locRadiusTxt = "Within " + response[i].radius + " kms";
                            vm.locRadiusTxt = "Within " + rds + " " + vm.pyrUnits;
                            break;
                        }
                    }
                    // binding distance radius data end here
                    bindLcngForDtls();
                });
            });
        }

        // service for getting matchsummary infromation
        var GetMpPrefDataExt1CallBack = function (responseMpPrefDataEx1, status) {
            vm.MpPrefDataExt1 = responseMpPrefDataEx1;

            //Service calling for get height
            //selfprofileSrvc.ddlsMyAppearence(function (response, status) {
            //    for (var i = 0; i < response.height.length; i++) {
            //        if (response.height[i].val == vm.prefData.maxHeight) {
            //            vm.maxHeight = response.height[i].txt;
            //        }
            //    }
            //});
        }

        var GetPrfInfoExt1CallBack = function (responseEx1, status) {
            vm.profileInfoExt1 = responseEx1;
            var Ex1 = vm.profileInfoExt1;

            function lctnInfoDlts() {
                var htInfo = vm.profileInfoExt1.htInfo;
                if (htInfo) {
                    if (vm.cntryName() == htInfo.countryName) { return "Grew up in " + htInfo.cityName + ", " + htInfo.stateName; }
                    else { return "Grew up in " + htInfo.cityName + ", " + htInfo.stateName + ", " + htInfo.countryName; }
                }
            }

            //About me block Data starts
            var AboutMeDataJSON = AboutMeMSFunc(Ex1.ethinicityId, Ex1.religionId, Ex1.awId, Ex1.rsStatus, Ex1.highestEdu, lctnInfoDlts());
            vm.AboutMeData = [];
            getJSonActiveData(AboutMeDataJSON, vm.AboutMeData);
            tblSplit(vm.AboutMeData, function (t1, t2) {
                vm.abtMeTblL1 = t1;
                vm.abtMeTblL2 = t2;
            });
            hideLoader();
            vm.pgVisble();

        }

        var GetPrfInfoExt2CallBack = function (responseEx2, status) {
            vm.profileInfoExt2 = responseEx2;
            var Ex2 = vm.profileInfoExt2;
            //My Appearence Data Starts
            var MyApprnceDataJSON = MyApprnceMSFunc(Ex2.eyeColor, Ex2.hairColor, Ex2.height, Ex2.build, vm.profileInfo.gender)
            vm.MyApprnceData = [];
            getJSonActiveData(MyApprnceDataJSON, vm.MyApprnceData);
            tblSplit(vm.MyApprnceData, function (t1, t2) {
                vm.MyApprTblL1 = t1;
                vm.MyApprTblL2 = t2;
            });
            //My Appearence Data End       

            //My Life Styles Data Starts
            var LifeStyleDataJSON = LifeStyleOPFunc($filter, Ex2.diet, Ex2.smoke, Ex2.drink, Ex2.idealRelationship, Ex2.childrenCnt, Ex2.childrenPref, Ex2.petsCnt, Ex2.petsPref,
                Ex2.lang, Ex2.familyLangs, Ex2.religious, Ex2.traditional);

            vm.LifeStyleData = [];
            getJSonActiveData(LifeStyleDataJSON, vm.LifeStyleData);
            tblSplit(vm.LifeStyleData, function (t1, t2) {
                vm.lfStlTblL1 = t1;
                vm.lfStlTblL2 = t2;
            });
            //My Life Styles Data End
            hideLoader();
        }

        function getPrefData(callBackFun) {
            selfmatchprefSrvc.getMpPrefData(vm.omId, function (response, status) {
                callBackFun(response);
            });
        }

        //bind locking for gender and radius
        function bindLcngForDtls() {
            var gender = vm.profileInfo.genderPref == true ? "he" : "she";
            if (vm.minAge != null && vm.maxAge != null)
                vm.lcngAge = "Ages " + vm.minAge + "-" + vm.maxAge;
            else
                vm.lcngAge = "How old is " + gender + "?";

            if (vm.prefData.locRadius != null)
                vm.lckngRadius = vm.locRadiusTxt;
            else
                vm.lckngRadius = "Where is " + gender + "?";

        }

        //service call to get the prefered distance  
        function mpDistanceFuncG(callBackBasicData) {
            selfmatchprefSrvc.prefRadius(function (response, status) {
                if (status == 200) {
                    vm.locrad = response;
                    callBackBasicData(response);
                }
            });
        }

        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  TROPHIES BLOCK STARTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/
        var Trophiesresult = [];
        function trophiesLoad(Trophiesresult) {
            if (Trophiesresult[0] == 1)
                vm.tropEml = 'https://pccdn.pyar.com/pcimgs/trophies/prf-emlverified-cmplte.jpg';
            else
                vm.tropEml = 'https://pccdn.pyar.com/pcimgs/trophies/empty-mail.jpg';
            if (Trophiesresult[1] == 1)
                vm.tropSoc = 'https://pccdn.pyar.com/pcimgs/trophies/scial-mdia-lnk-cmplte.jpg';
            else
                vm.tropSoc = 'https://pccdn.pyar.com/pcimgs/trophies/empty-scllink.jpg';
            if (Trophiesresult[2] == 1)
                vm.tropPP = 'https://pccdn.pyar.com/pcimgs/trophies/prf-phto-upload-cmplt.jpg';
            else
                vm.tropPP = 'https://pccdn.pyar.com/pcimgs/trophies/empty-prfl.jpg';

            if (Trophiesresult[3] == 1)
                vm.tropMob = 'https://pccdn.pyar.com/pcimgs/trophies/mbile-vrfied-cmplt.jpg';
            else
                vm.tropMob = 'https://pccdn.pyar.com/pcimgs/trophies/empty-mbile.jpg';
            if (Trophiesresult[4] == 1)
                vm.ProfComplete = 'https://pccdn.pyar.com/pcimgs/trophies/Prf-complete.jpg';
            else
                vm.ProfComplete = 'https://pccdn.pyar.com/pcimgs/trophies/empty-prfle-cmp.jpg';
        }
        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( TROPHIES BLOCK END   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/



        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( PHOTO GALLERY BLOCK STARTS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/
        ////gallery photo module
        //vm.imageStorage = "https://ngagrpincblobstrdev.blob.core.windows.net";
        //vm.imageCDN = "https://pccdn.pyar.com";
        //vm.index = "";
        //vm.gallerytnPhotos = [];
        //vm.galleryPhotos = [];
        //vm.profileResponse = [];
        //vm.bannerResponse = [];
        //vm.picPosition = 0;
        //vm.mpuId = "";
        //vm.glryImgSrc = '';
        ////bindGlryImages(function (profileResponse, bannerResponse, galleryPhotos, gallerytnPhotos) {
        ////    vm.glryAlbumImgs = galleryPhotos;
        ////    vm.imgGallery = gallerytnPhotos;
        ////});

        //vm.selectorPopup = function (index, mpuId, dateCreated, photoPath) {
        //    vm.dateCreated = dateCreated;
        //    vm.index = index;
        //    vm.mpuId = mpuId;

        //    showDivs(index, photoPath);
        //    $("#srcAlbumSliderImg").modal("show");

        //}

        $scope.$on('onImgLoadFinishGlry', function (onImgLoadFinishEvent) {
            showDivs(vm.index, "");
        });
        function bindGlryImages(callBackFunc) {
            selfprofileSrvc.getAllImages(vm.omId, function (response, status) {
                if (status == 200) {
                    for (var i = 0; i < response.length; i++) {
                        if (response[i].picType == 1) {
                            vm.galleryPhotos.push({ mpId: response[i].mpId, picPath: vm.imageCDN + response[i].picPath.replace("/tn/", "/"), picCreateDT: response[i].picCreateDT });
                            vm.gallerytnPhotos.push({ mpId: response[i].mpId, picPath: vm.imageCDN + response[i].picPath.replace("/tn/", "/tnb/"), picCreateDT: response[i].picCreateDT, picPosition: (vm.gallerytnPhotos.length + 1) });
                        } else if (response[i].picType == 2) {
                            vm.profileResponse.push({ mpId: response[i].mpId, picPath: vm.imageCDN + response[i].picPath, picCreateDT: response[i].picCreateDT });
                        } else if (response[i].picType == 3) {
                            vm.bannerResponse.push({ mpId: response[i].mpId, picPath: vm.imageCDN + response[i].picPath, picCreateDT: response[i].picCreateDT });
                        }
                    }
                    callBackFunc(vm.profileResponse, vm.bannerResponse, vm.galleryPhotos, vm.gallerytnPhotos);
                }
            });
        }

        vm.imgGalleryClick = function (index, mpuId, dateCreated, picPath, picPosition) {
            vm.dateCreated = dateCreated;
            vm.picPosition = picPosition;
            vm.mpuId = mpuId;
            //showDivs(vm.picPosition, $("#glryImg" + index).attr('src');
            showDivs(vm.picPosition, $("#glryImg" + index).attr('src').replace("/tnb/", "/tn/"));
            $("#srcAlbumSliderImg").modal("show");
        }
        vm.plusDivs = function (n) {
            vm.picPosition = vm.picPosition + n;
            showDivs(vm.picPosition, "");
        }

        //show slide image function
        function showDivs(n, photoPath) {
            var i;
            var slideImgs = $("#dvSlides .mySlides");
            if (slideImgs.length > 1) {
                if (photoPath != "") {
                    for (j = 0; j < slideImgs.length ; j++) {
                        if (photoPath.replace("/tn/", "/") == $(slideImgs[j]).attr('src')) {
                            slideImgs[j].style.display = "inline-block";
                            vm.mpuId = $(slideImgs[j]).attr('data-mpId');
                            vm.dateCreated = $(slideImgs[j]).attr('data-dateCrctd');
                            vm.glryImgSrc = $(slideImgs[j]).attr('src');
                        } else {
                            slideImgs[j].style.display = "none";
                        }
                    }
                }
                else {

                    if (n > slideImgs.length) {
                        vm.picPosition = 1
                    }
                    if (n < 1) {
                        vm.picPosition = slideImgs.length
                    }
                    for (i = 0; i < slideImgs.length; i++) {
                        slideImgs[i].style.display = "none";
                    }
                    if ($(slideImgs[vm.picPosition - 1])) {
                        vm.mpuId = $(slideImgs[vm.picPosition - 1]).attr('data-mpId');
                        vm.dateCreated = $(slideImgs[vm.picPosition - 1]).attr('data-dateCrctd');
                        slideImgs[vm.picPosition - 1].style.display = "inline-block";
                        vm.glryImgSrc = $(slideImgs[vm.picPosition - 1]).attr('src');
                    }
                }
            } else
                vm.glryImgSrc = photoPath;
            changeImageDimentions();
        }
        //show image width height according to image original width height
        function changeImageDimentions() {
            $("#dvSlides img").height("auto").width("auto");
            $("#dvSlides img").css("max-height", "100%");
        }


        //show profile pic on the profile image click
        vm.showProfilePic = function (imgPath) {
            if (vm.profileInfo.isProfilePicUpld == true) {
                $('#imgIndv').removeClass("bnrpic").addClass("prflpic");
                $("#srcIndvImg").modal("show");
                $("#imgIndv").attr("src", imgPath.replace("/tn/", "/tnb/"));
                //vm.shwPrfPhoto = true;
                //vm.shwCvrPhoto = false;
                vm.rptPrfVsbl = true;
                vm.rptBnrVsbl = false;
                vm.imgCreateDT = vm.profileResponse[0].picCreateDT;
            }
        }
        //show banner pic on the banner image click
        vm.showBannerPic = function (imgPath) {
            if (vm.profileInfo.profileBnr) {
                vm.rptBnrVsbl = true;
                vm.rptPrfVsbl = false;
                $('#imgIndv').removeClass("prflpic").addClass("bnrpic");
                $("#srcIndvImg").modal("show");
                $("#imgIndv").attr("src", imgPath);
                //vm.shwPrfPhoto = false;
                //vm.shwCvrPhoto = true;
                vm.rptPrfVsbl = false;
                vm.imgCreateDT = vm.bannerResponse[0].picCreateDT;
            }
        }
        /*******************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( PHOTO GALLERY BLOCK END   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*******************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  other Actions section Starts   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        //vm.curMemTileIndex = 0;
        vm.fvrtdImg = "https://pccdn.pyar.com/pcimgs/actions/fvrtd.svg";
        vm.fvImg = "https://pccdn.pyar.com/pcimgs/actions/fvrt.svg";
        vm.flirtlgtImg = "https://pccdn.pyar.com/pcimgs/actions/flirt-red.svg";
        vm.flirtImg = "https://pccdn.pyar.com/pcimgs/actions/flirt.svg";
        vm.ldrImg = "https://pccdn.pyar.com/pcimgs/acnLdr.svg";


        //FAVORITE MODULE STARTS 
        vm.FavIcnClk = function () {
            if ($("#ImgFav").attr("src") == vm.fvrtdImg) {
                if (cmnSrvc.ftPOPCheck(3) == true) {
                    vm.othersFavoriteModal = "#othersFavoriteModal";
                    vm.FavPop2 = true; vm.FavPop = false;
                    // AddRemoveFavarite();
                } else {
                    vm.othersFavoriteModal = "";
                    vm.FavRemoveClk();
                }
            } else {
                if (cmnSrvc.ftPOPCheck(2) == true) {
                    vm.othersFavoriteModal = "#othersFavoriteModal";
                } else {
                    vm.othersFavoriteModal = "";
                }
                AddfavFunc();
            }
        }
        function AddfavFunc() {
            $("#ImgFav").attr("src", vm.ldrImg);
            othersprofileSrvc.addFavorite(vm.mId(), vm.omId, function (response, status) {
                if (status == 200 && response == true) {
                    vm.FavPop2 = false;
                    vm.FavPop = true;
                    //rs.is_Favorited = 1;
                    if (cmnSrvc.ftPOPCheck(2))
                        cmnSrvc.ftPOPUpdate(2);
                    if (vm.favCarryVal == 1) {          // checking the fav click in a flirt modal
                        $("#othersFavoriteModal").modal("show");
                        vm.favCarryVal = 0;
                    }
                    $("#ImgFav").attr("src", vm.fvrtdImg);
                    if ($(window).width() <= 767) {
                        $rootScope.$broadcast("favUnfavclick", { 'fav': 'yes', 'mId': vm.omId });
                    };
                }
            });
        }

        vm.FavRemoveClk = function () {
            $("#ImgFav").attr("src", vm.ldrImg);
            othersprofileSrvc.removeFavorite(vm.mId(), vm.omId, function (response, status) {
                if (status == 200 && response == true) {
                    vm.FavPop = false;
                    vm.FavPop2 = false;
                    if (cmnSrvc.ftPOPCheck(3))
                        cmnSrvc.ftPOPUpdate(3);
                    $("#ImgFav").attr("src", vm.fvImg);
                    if ($(window).width() <= 767) {
                        $rootScope.$broadcast("favUnfavclick", { 'fav': 'no', 'mId': vm.omId });
                    };
                }
            });
        }
        //FAVORITE MODULE END 


        //FLIRT MODULE START  
        vm.FlirtIcnClk = function () {
            if (vm.sId() == 1) {
                if (cmnSrvc.isTrialOrPrmExpired()) {
                    vm.othersFlirtModal = "#othersFlirtModal";
                    vm.FlrtPop = vm.FlrtPop2 = vm.FlrtPop3 = false;
                    vm.FlrtPop4 = true;
                }
                else
                    showMobileVerificationPop();
            }
            else
                vm.FlirtAddClk();
        }

        //vm.FlrtHvrDv = false;
        //vm.FlirtIcnClk = function () {
        //    if ($("#ImgFltr").attr("src") == vm.flirtlgtImg) {
        //        vm.othersFlirtModal = "";
        //        $("#dvoop").fadeIn();
        //        return false;
        //    } else if (vm.sId() == 1) {
        //        if (cmnSrvc.isTrialOrPrmExpired()) {
        //            vm.othersFlirtModal = "#othersFlirtModal";
        //            vm.FlrtPop = vm.FlrtPop2 = vm.FlrtPop3 = false;
        //            vm.FlrtPop4 = true;
        //        } else {
        //            showMobileVerificationPop();
        //        }
        //        return;
        //    }
        //    else if (cmnSrvc.ftPOPCheck(4) == false) {
        //        //ACTION POPUP CODE
        //        if ($("#ImgFav").attr("src") == vm.fvrtdImg) {
        //            vm.othersFlirtModal = "#othersFlirtModal";
        //            vm.FlrtPop = vm.FlrtPop3 = vm.FlrtPop4 = false;
        //            vm.FlrtPop2 = true;
        //        }
        //        else {
        //            vm.othersFlirtModal = "#othersFlirtModal";
        //            vm.FlrtPop = true;
        //            vm.FlrtPop2 = vm.FlrtPop3 = vm.FlrtPop4 = false;
        //        }
        //    }
        //    else if (cmnSrvc.ftPOPCheck(2) == false) {
        //        if ($("#ImgFav").attr("src") == vm.fvrtdImg) {
        //            vm.othersFlirtModal = "#othersFlirtModal";
        //            vm.FlrtPop = vm.FlrtPop3 = vm.FlrtPop4 = false;
        //            vm.FlrtPop2 = true;
        //        }
        //        else {
        //            vm.othersFlirtModal = "#othersFlirtModal";
        //            vm.FlrtPop = true;
        //            vm.FlrtPop2 = vm.FlrtPop3 = vm.FlrtPop4 = false;
        //        }
        //    }
        //    else {
        //        vm.othersFlirtModal = "#othersFlirtModal";
        //        vm.FlrtPop = true;
        //        vm.FlrtPop2 = vm.FlrtPop3 = vm.FlrtPop4 = false;
        //    }
        //}

        $('body').click(function (evt) {
            if (["flrtoops", "fltrophd", "fltroptxt", "fvbld"].indexOf(evt.target.className.split(" ")[0]) != -1 || evt.target.id == "ImgFltr" || evt.target.id == "btnFlrt") { if ($("#ImgFltr").attr("src") == vm.flirtlgtImg) { $("#dvoop").fadeIn(); } }
            else { $("#dvoop").fadeOut(); }
        });

        //vm.oopDvMover = function () { if ($("#ImgFltr").attr("src") == vm.flirtlgtImg) { $("#dvoop").show(); } }
        //vm.oopDvMLeave = function () { $("#dvoop").hide(); }

        vm.FavAddClk = function () {
            if (cmnSrvc.ftPOPCheck(2) == true) {
                vm.favCarryVal = 1;
            } else {
                vm.favCarryVal = 0;
            }
            AddfavFunc();
        }

        var isFlrtAcnCmltd = true;
        vm.FlirtAddClk = function () {
            $("#ImgFltr").attr("src", vm.ldrImg);
            if (isFlrtAcnCmltd == true) {
                isFlrtAcnCmltd = false;
                othersprofileSrvc.addFlirt(vm.mId(), vm.omId, function (response, status) {
                    isFlrtAcnCmltd = true;
                    if (status == 200 && response == true) {
                        vm.profileInfo.flirt = 1;
                        vm.FlrtPop = vm.FlrtPop2 = vm.FlrtPop3 = false;
                        $("#ImgFltr").attr("src", vm.flirtlgtImg);

                        //send  flirt notification
                        var type = 51;
                        if (msgSrvc.conId)
                            msgSrvc.sendMemberNotifications(vm.omId, vm.fn(), vm.pp(), vm.gender(), type, new Date());
                        else
                            $rootScope.ntfnData.push({ "sendType": 1, "tmId": vm.omId, "fn": vm.fn(), "pp": vm.pp(), "gender": vm.gender(), "type": type, "date": new Date() });
                        ////send flirt push notificatoion
                        //msgSrvc.sendFlirtPushNotification(vm.mId(), vm.omId, vm.fn(), vm.pp(), vm.gender(), function (response, status) {
                        //    if (status == 200 && response == true)
                        //        console.log("flirt push notification sent");
                        //    else
                        //        console.log("flirt push notification sent fail - " + response);
                        //});
                    }
                });
                if ($(window).width() <= 767) {
                    $rootScope.$broadcast("otherprfFlrt", vm.omId);
                };
            }
        }
        //vm.flrtmsgonmsovr = false;
        //FLIRT MODULE START END

        // BLOCK MEMBER START
        vm.BlckPopClk = function () {
            vm.BlckPop = true;
            vm.BlckPop2 = false;
        }

        vm.BlockSubmit = function () {
            vm.BlckPop = false;
            vm.BlckPop2 = true;
            othersprofileSrvc.addBlock(vm.mId(), vm.omId, function (response, status) {
                if (status == 200 && response == true) {
                    vm.BlckPop = false;
                    vm.BlckPop2 = true;
                    msgSrvc.sendMbrBlockNtfn(vm.mId(), vm.fn(), vm.gender(), vm.omId, true);   // calling sndblck notifctn api when a user is blocked
                    $scope.$emit("selfblck", vm.omId, vm.profileInfo.firstName, vm.profileInfo.gender, true);  // listner to show the block message if chatbox opens
                    removeTilesMbl();
                    vm.hideDivMat();
                }
            });
        }

        function removeTilesMbl() {
            if ($(window).width() <= 767) {
                if ($location.path() == '/dashboard.html') {
                    $("#" + getPed(vm.omId)).remove();
                    // if ($('[id^=pyrMem]').length < 20) {
                    rs.$emit("CallFavTileData", rs.tileindex); //caaling viewMore function in dashboardCtrl.
                    //}
                } else {
                    $("#" + vm.omId).remove();
                    // if ($('#blcktile match-tile').length < 20) {
                    rs.$emit("tileBlockSearch", rs.tileindex); //caaling viewMore function in SearchController.
                    // };
                };
            }
        }

        vm.BlockClose = function () {
            if ($(window).width() >= 767) {
                $("#othersBlockModal").modal("hide");
                $timeout(function () {
                    $state.go('dashboard');
                }, 300);
            } else {
                if ($location.path() == '/dashboard.html') {
                    $("#othersBlockModal").modal("hide");
                    $timeout(function () {
                        $state.go('dashboard');
                    }, 300);
                } else {
                    $("#othersBlockModal").modal("hide");
                };
            };
        }
        //BLOCK MEMBER END

        vm.blockPopUpAction = function () {
            if ($(window).width() >= 767) {
                $("#blockOpsuddn").modal("hide");
                $("#blockOpsuddn").on("hidden.bs.modal", function () {
                    $state.go('dashboard');
                });
            } else {
                $("#blockOpsuddn").modal("hide");
                $("#blockOpsuddn").on("hidden.bs.modal", function () {
                    vm.hideDivMat();
                });
            }
        };

        //HIDE MODULE START
        vm.hidemem = function () {
            if (vm.hideType == 1) {
                vm.othersHideModal = "#othersHideModal";
                vm.hidePop = true;
                vm.hidePop2 = false;
            } else {
                vm.hidePop = false;
                vm.hidePop2 = false;
                vm.othersHideModal = "";
                othersprofileSrvc.removeHide(vm.mId(), vm.omId, function (response, status) {
                    if (status == 200 && response == true) {
                        vm.hideUnHideTxt = "Hide";
                        vm.hideType = 1;
                    }
                });
            }
        }

        vm.hideClk = function () {
            vm.hidePop = false;
            vm.hidePop2 = true;
            othersprofileSrvc.addHide(vm.mId(), vm.omId, function (response, status) {
                if (status == 200 && response == true) {
                    vm.hideUnHideTxt = "Unhide";
                    vm.hideType = 2;
                }
            });
        }

        vm.memHideCheck = function () {
            vm.hideUnHideTxt = "";
            $("#tileImg").show();
            srchSrvc.MemberHideCheck(vm.mId(), vm.omId, function (response, status) {
                if (status == 200 && response == true) {
                    $("#tileImg").hide();
                    vm.hideUnHideTxt = "Unhide";
                    vm.hideType = 2;
                } else {
                    $("#tileImg").hide();
                    vm.hideUnHideTxt = "Hide";
                    vm.hideType = 1;
                }
            });
        }
        //HIDE MODULE END

        vm.viewFavorites = function () {
            $("#othersFavoriteModal").modal("hide");
            $("#othersFlirtModal").modal("hide");
            $timeout(function () {
                dashboardFact.setfromOtherPrfPg(true);
                $location.path("/dashboard.html");
            }, 300);
        };

        function rptEmpty(phTxt) {
            vm.GlryPhotoRptTxt = null;
            vm.GlryPhotoRptTxtPlaceHoder = phTxt;
            vm.txtCls = "";

            vm.PrfPicRptTxt = null;
            vm.PrfPicRptTxtPlaceHoder = phTxt;

            vm.reportTxt = null;
            vm.reportTxtPlaceHoder = phTxt;
        }

        //Report textbox blur event
        vm.rptCheck = function () { if (!vm.GlryPhotoRptTxt && !vm.PrfPicRptTxt && !vm.reportTxt) { rptEmpty("Tell us what happened"); } }
        //Report textbox chanage evnt
        vm.rptChnage = function () {
            if ((vm.GlryPhotoRptTxt && vm.GlryPhotoRptTxt.length > 250) || (vm.PrfPicRptTxt && vm.PrfPicRptTxt.length > 250) || (vm.reportTxt && vm.reportTxt.length > 250)) {
                rptEmpty("Please ensure that your Details do not exceed 250 characters"); vm.txtCls = "txtaraPhClr";
            }
            else if (!vm.GlryPhotoRptTxt && !vm.PrfPicRptTxt && !vm.reportTxt) { rptEmpty("Tell us what happened"); }
        }

        vm.ReportPopClk = function () {
            vm.memRptDv = true;
            vm.memRptDvConfirm = vm.memRptDvThankyou = false;
        }

        vm.ReportClk = function () {
            vm.memRptDv = vm.memRptDvThankyou = false;
            vm.memRptDvConfirm = true;

            vm.RptSubmitDsbl = true;
            vm.flrtbtndsble = "flrtbtndsble";
            vm.reportTxt = "";
            vm.txtCls = "";
            vm.reportTxtPlaceHoder = "Tell us what happened";
            // Report Action Start
            vm.reportJson = [{ name: "Spam", value: "1" }, { name: "Inappropriate", value: "2" }, { name: "Abuse/Threat", value: "3" }, { name: "Other", value: "4" }];
        }

        vm.RptRsnClk = function (val) {
            vm.RptRsnVal = val;
            vm.RptSubmitDsbl = false;
            vm.dsblClass = null;
            delete vm.txtCls;
            vm.reportTxtPlaceHoder = "Tell us what happened";
            vm.flrtbtndsble = null;
        }

        vm.RptSubmit = function () {
            if (vm.RptRsnVal == 4 && (vm.reportTxt == "" || vm.reportTxt == null || vm.reportTxt == undefined)) {
                vm.txtCls = "txtaraPhClr";
                vm.reportTxtPlaceHoder = 'Since you selected "Other" as your reason, please give us some details.';
            }
            else {
                //refId: 1- memeberId, 2- PhotoId
                cmnSrvc.memReport(vm.mId(), vm.omId, 1, vm.omId, vm.RptRsnVal, vm.reportTxt, function (response, status) {
                    if (status == 200 && response == true) {
                        vm.memRptDv = vm.memRptDvConfirm = false;
                        vm.memRptDvThankyou = true;
                    }
                });
            }
        }
        // Report Action End

        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  other Actions section End   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        vm.matchSelection = function (val) {
            if (val > 0 && val <= 29) { return "NOT A MATCH"; }
            else if (val >= 30 && val <= 59) { return "GOOD MATCH"; }
            else if (val >= 60 && val <= 79) { return "GREAT MATCH"; }
            else if (val >= 80 && val <= 100) { return "PERFECT MATCH"; }
            else if (val == -1 || val == -2) {
                return "NOT ENOUGH INFO";
            }
        }

        vm.selctPyarPernt = function (val) {
            if (val == -1 || val == -2)
                return "?"
            else return val;
        }

        vm.matchQ = function (val) {
            if (val == -1 || val == -2)
                return "";
            else return "%";
        }

        vm.MatchAnalysisClk = function (val) {
            if (vm.gndrPref() == true) {
                vm.GenderprefImg = "https://pccdn.pyar.com/pcimgs/male-prflephto.jpg";
            } else {
                vm.GenderprefImg = "https://pccdn.pyar.com/pcimgs/female-prflephto.jpg";
            }
            if (val > 0 && val <= 29) {
                $("#MatchAnalysisZeroPyarModal").modal("show");
            }
            else
                if (val == -1 || val == -2) {
                    if (val == -1) {
                        $("#MatchAnalysisEmptyMPModal").modal("show");
                    }
                        //else if (count > 3)
                    else if (val == -2) {
                        $("#MatchAnalysisEmptyPModal").modal("show");
                        vm.eprbtn = false;
                        othersprofileSrvc.profileReminderchk(vm.mId(), vm.omId, function (response, status) {
                            if (response == true) {
                                vm.eprbtn = false;
                            } else {
                                vm.eprbtn = true;
                            }
                        });
                    }
                    //});
                }
                else {
                    $("#MatchAnalysisCompModal").modal("show");
                    vm.profiledata = angular.merge({}, vm.profileInfoExt1, vm.profileInfoExt2, { "age": vm.age }, { "locrad": vm.locrad }, { "countryId": vm.profileInfo.cntryName }, { "cityId": vm.profileInfo.cityName }, { "stateId": vm.profileInfo.stateName });
                    othersprofileSrvc.matchanalysis(vm.mId(), vm.omId, function (response, status) {
                        //macomp(response, vm.profiledata, vm.cntryName(), function (response) {
                        macomp(response, vm.profiledata, vm.cntryName(), vm.pyrUnits, function (response) {
                            vm.hobbies = response[0].hobbiesdata[0];
                            vm.mAnalysis = response[0].madata;
                            vm.ptdata = response[0].ptdata[0];
                            if (vm.ptdata != null) {
                                vm.ptdisplay = true;
                            }
                            else {
                                vm.ptdisplay = false;
                            }
                            if (vm.hobbies != null) {
                                vm.hobbiesdisplay = true;
                            }
                            else {
                                vm.hobbiesdisplay = false;
                            }
                        });
                    });
                }
        }

        var isRmndrSentCmltd = true;
        vm.eprsend = function () {
            if (isRmndrSentCmltd == true) {
                isRmndrSentCmltd = false
                othersprofileSrvc.profileReminderSend(vm.mId(), vm.omId, function (response, status) {
                    isRmndrSentCmltd = true;
                    if (response == true) {
                        vm.eprbtn = false;
                        //send profile fill remainder sent
                        var type = 52;
                        if (msgSrvc.conId)
                            msgSrvc.sendMemberNotifications(vm.omId, vm.fn(), vm.pp(), vm.gender(), type, new Date());
                        else
                            $rootScope.ntfnData.push({ "sendType": 1, "tmId": vm.omId, "fn": vm.fn(), "pp": vm.pp(), "gender": vm.gender(), "type": type, "date": new Date() });

                        ////send profile fill reminder push notificatoion
                        //msgSrvc.sendProfileFillRemindePushNotification(vm.mId(), vm.omId, vm.fn(), vm.pp(), vm.gender(), function (response, status) {
                        //    if (status == 200 && response == true) {
                        //        console.log("profile fill reminder push notification sent");
                        //    }
                        //    else {
                        //        console.log("profile fill reminder push notification sent fail - " + response);
                        //    }
                        //});
                    }
                });
            }
        };

        vm.filloutClk = function () {
            $rootScope.mpFillout = true;
            $("#MatchAnalysisEmptyMPModal").modal("hide");
            $('.modal-backdrop').remove();
            vm.hideDivMat();
            $state.go("profile");
        }


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((  other Gallery Photo Actions section Starts  )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.GlryphotoReport = function () {
            $("#GlryPhotoReportModal").modal("show");

            if (vm.glryImgSrc.indexOf("/tn/") == -1)
                vm.glryImg = vm.glryImgSrc.replace("/gl/", "/gl/tn/");
            else
                vm.glryImg = vm.glryImgSrc;

            vm.GpRptDv = true;
            vm.GpRptDvConfirm = vm.GpRptDvThankyou = false;
            vm.SrvcmpuId = vm.mpuId;
        }

        vm.GlryPhotoRptClick = function () {
            vm.GpRptDv = vm.GpRptDvThankyou = false;
            vm.GpRptDvConfirm = true;

            // Report Action Start
            vm.reportJson = [{ name: "Spam", value: "1" }, { name: "Inappropriate", value: "2" }, { name: "Abuse/Threat", value: "3" }, { name: "Other", value: "4" }];
            vm.GlryPhotoRptBtnDsbl = true;
            vm.dsblClass = "flrtbtndsble";
            vm.GlryPhotoRptTxt = "";
            vm.txtCls = "";
            vm.GlryPhotoRptTxtPlaceHoder = "Tell us what happened";
        }

        vm.GlryPhotoRptRsnClk = function (val) {
            vm.GlryPhtRptRsnVal = val;
            vm.GlryPhotoRptBtnDsbl = false;
            vm.dsblClass = null;
            delete vm.txtCls;
            vm.GlryPhotoRptTxtPlaceHoder = "Tell us what happened";
        }

        vm.GlryPhotoRptSubmit = function () {

            if (vm.GlryPhtRptRsnVal == 4 && (vm.GlryPhotoRptTxt == "" || vm.GlryPhotoRptTxt == null || vm.GlryPhotoRptTxt == undefined)) {
                vm.txtCls = "txtaraPhClr";
                vm.GlryPhotoRptTxtPlaceHoder = 'Since you selected "Other" as your reason, please give us some details.';
            }
            else {
                //refType: 1- reporting on member, 2- reporting on Photo
                cmnSrvc.memReport(vm.mId(), vm.omId, 2, vm.mpuId, vm.GlryPhtRptRsnVal, vm.GlryPhotoRptTxt, function (response, status) {
                    if (status == 200 && response == true) {
                        vm.GpRptDv = vm.GpRptDvConfirm = false;
                        vm.GpRptDvThankyou = true;
                    }
                });
            }
        }
        /*********************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((  other Gallery Photo Actions section End  )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/


        /*********************************************************************************************************************************************************************/
        /*((((((((((((((((((((((((((((((((((((((((((((((((((((  other Cover Photo Actions section Starts  )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/
        vm.PflPicReport = function () {
            //if (vm.shwCvrPhoto == true) {
            //    vm.prfCvrImg = vm.bnrImg;
            //}
            //else if (vm.shwPrfPhoto == true) {

            //}
            vm.prfCvrImg = vm.profilePic;
            $("#ProfilePicReportModal").modal("show");

            //function keeping class attribute when multiple popups opened
            $("#ProfilePicReportModal").modal().on('hidden.bs.modal', function (e) {
                $("body").addClass("modal-open");
            });

            vm.PpRptDv = true;
            vm.PpRptDvConfirm = vm.PpRptDvThankyou = false;
            vm.SrvcmpuId = vm.profileResponse[0].mpId;
        }
        vm.BnrPicReport = function () {
            vm.prfCvrImg = vm.bnrImg;
            $("#ProfilePicReportModal").modal("show");
            $("#ProfilePicReportModal").modal().on('hidden.bs.modal', function (e) {
                $("body").addClass("modal-open");
            });
            vm.PpRptDv = true;
            vm.PpRptDvConfirm = vm.PpRptDvThankyou = false;
            vm.SrvcmpuId = vm.bannerResponse[0].mpId;
        }

        vm.PrfPicReportClick = function () {
            vm.PpRptDv = vm.PpRptDvThankyou = false;
            vm.PpRptDvConfirm = true;

            // Report Action Start
            vm.reportJson = [{ name: "Spam", value: "1" }, { name: "Inappropriate", value: "2" }, { name: "Abuse/Threat", value: "3" }, { name: "Other", value: "4" }];

            vm.PrfPicRptBtnDsbl = true;
            vm.dsblClass = "flrtbtndsble";
            vm.PrfPicRptTxt = "";
            vm.txtCls = "";
            vm.PrfPicRptTxtPlaceHoder = "Tell us what happened";
        }


        vm.PrfPicRptRsnClk = function (val) {
            vm.PrfPicRptRsnVal = val;
            vm.PrfPicRptBtnDsbl = false;
            vm.dsblClass = null;
            delete vm.txtCls;
            vm.PrfPicRptTxtPlaceHoder = "Tell us what happened";
        }


        vm.PrfPicRptSubmit = function () {
            if (vm.PrfPicRptRsnVal == 4 && (vm.PrfPicRptTxt == "" || vm.PrfPicRptTxt == null || vm.PrfPicRptTxt == undefined)) {
                vm.txtCls = "txtaraPhClr";
                vm.PrfPicRptTxtPlaceHoder = 'Since you selected "Other" as your reason, please give us some details.';
            }
            else {

                //if (vm.shwCvrPhoto == true) {
                //    //cover photo selected
                //}
                //else if (vm.shwPrfPhoto == true) {
                //    //Profile photo selected
                //}

                //refType: 1- reporting on member, 2- reporting on Photo
                //vm.mpuId need to get value from gallery photoa
                cmnSrvc.memReport(vm.mId(), vm.omId, 2, vm.SrvcmpuId, vm.PrfPicRptRsnVal, vm.PrfPicRptTxt, function (response, status) {
                    if (status == 200 && response == true) {
                        vm.PpRptDvConfirm = vm.PpRptDv = false;
                        vm.PpRptDvThankyou = true;
                    }
                });
            }
        }
        /*********************************************************************************************************************************************************************/
        /*(((((((((((((((((((((((((((((((((((((((((((((((((((((  other Cover Photo Actions section End  )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
        /*********************************************************************************************************************************************************************/

        vm.goPremium = function () {
            $("#othersFlirtModal").modal("hide");
            $("#othersFlirtModal").on('hidden.bs.modal', function () {
                $state.go("payment")
            })
        }

        vm.gotoSearch = function (getHbs) {
            var hbySearch = {
                "refId": getHbs.refId, "refType": 2, "sugName": getHbs.txt
            };
            hbySearchFact.sethbySearchData(JSON.stringify(hbySearch));
            if (vm.sId() == 1) {
                vm.hideDivMat();
                $state.go("basicsearch");
                //$window.location.href = "/basicsearch.html";
            }
            else if (vm.sId() == 2) {
                vm.hideDivMat();
                $state.go("advancedsearch");
                //$window.location.href = "/advancedsearch.html";
            }
        }

        vm.openCW = function () {
            if ($location.path() != "/msgcenter.html") {
                if ($(window).width() > 991) {
                    $rootScope.$broadcast("openPCW", vm.omId);
                }
                else {
                    $rootScope.ismsgPopFrmop = true;
                    $rootScope.$broadcast("openMPCW", vm.omId, vm.profileInfo.firstName);
                };
            }
            else
                vm.hideDivMat();
        };

        // match header show in mobile on scroll
        $(".dvmc,.othrprofAdj").bind('scroll', function () {
            if ($(window).width() <= 767) {
                if ($(this).scrollTop() > ($("#bnrimgchk").outerHeight() + $("#profimgchk").outerHeight() - $("#iconsLst").outerHeight()))
                    $("#matchHeader").show();
                else
                    $("#matchHeader").hide();
            };
        });
        // Hide the Match Pop up when clicks cancel in mobile
        vm.hideDivMat = function () {
            if ($(window).width() <= 767) {
                $(".dvmc,.othrprofAdj").scrollTop(0);
                $("#matchmb").hide();
                $('body').css('overflow', '');
                $('body').css('position', '');
                vm.dvErrMsg = false;
                $rootScope.mblenopgeErr = false;
                $rootScope.ismsgPopFrmop = false;
            }
        }
        function getPed(memId) { if (memId) { return "pyrMem" + getSessionSrvc.pce(memId); } }

        //if a user is blocked suddenly
        $scope.$on("recBlockNtfnChg", function (e, mId, fn, gender, status) {
            if (status) {
                vm.blockdUser = fn;
                if (location.pathname.split("/")[1] == "match")
                    $("#blockOpsuddn").modal("show");
                else if ($('#matchmb').css('display') == 'block') {
                    $("#blockOpsuddn").modal("show");
                    removeTilesMbl();
                }
                $scope.$digest();
            }
        });

        $scope.$on("recSelfBlockNtfnChg", function (e, tmId, status) {
            if (status && location.pathname.split("/")[1] == "match") {
                vm.BlckPop = false;
                vm.BlckPop2 = true;
                $scope.$digest();
                $("#othersBlockModal").modal("show");
            };
        });
    }]);