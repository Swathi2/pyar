﻿angular.module("app").service('othersprofileSrvc', ['$http', function ($http) {

    //Service for adding favorite
    this.addFavorite = function (memberId, memFavId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/actions/adfav/" + memberId + "/" + memFavId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    //Service for remove favorite
    this.removeFavorite = function (memberId, mFavId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/actions/rmfav/" + memberId + "/" + mFavId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    //Service for add flirt
    this.addFlirt = function (memberId, memFlirtId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/actions/adflrt/" + memberId + "/" + memFlirtId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    //Service for add Block
    this.addBlock = function (memberId, memBlockedId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/actions/adblk/" + memberId + "/" + memBlockedId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }


    //Service for Remove Block
    this.removeBlock = function (memberId, mBlkId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/actions/rmblk/" + memberId + "/" + mBlkId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    //Service for Add Hide
    this.addHide = function (memberId, memHideId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/actions/adhd/" + memberId + "/" + memHideId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    //Service for Remove Hide
    this.removeHide = function (memberId, mHdId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/actions/rmhd/" + memberId + "/" + mHdId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }


    this.memberProfileView = function (viewedBy, memberId, memInvBrsng, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/profile/mpi/" + viewedBy + "/" + memberId + "/" + memInvBrsng;
        GetServiceByURL($http, liveUrl, funCallBack);
    }

    this.memberPyarPerc = function (viewedBy, memberId, funCallBack) {
        var liveUrl = getApiDomainUrl() + "/api/profile/pyrprcnt/" + viewedBy + "/" + memberId;
        GetServiceByURL($http, liveUrl, funCallBack);
    }
    this.matchanalysis = function (viewedBy, memberId, funCallBack) {
        var Url = getApiDomainUrl() + "/api/profile/getma/" + viewedBy + "/" + memberId;
        GetServiceByURL($http, Url, funCallBack);
    }
    this.profileReminderchk = function (memberId, reminderSentTo, funCallBack) {
        var Url = getApiDomainUrl() + "/api/profile/pfrc/" + memberId + "/" + reminderSentTo;
        GetServiceByURL($http, Url, funCallBack);
    }
    this.profileReminderSend = function (memberId, reminderSentTo, funCallBack) {
        var Url = getApiDomainUrl() + "/api/profile/pfrs/" + memberId + "/" + reminderSentTo;
        GetServiceByURL($http, Url, funCallBack);
    }

}]);