// creating about Ranger Slider Version dynamically
function SldrLoad()
{
if ($pcrngsldr === undefined) var $pcrngsldr = { auto: { disabled: false } };
$pcrngsldr.SliderObj = function (settings) {
  Obj.apply(this);
  
  function toNearest(num, x) {
    return (Math.round(num * (1/x)) / (1/x));
  }
  function betterParseFloat(t){return isNaN(parseFloat(t))&&t.length>0?betterParseFloat(t.substr(1)):parseFloat(t)};
  
    // Creating Ranger Properties Settings like dragging, moving, selecting ,clicking .. on slider dynamically
  this._settings = {
    direction: "horizontal",
    min: 0,
    max: 100,
    step: 0.1,
    value: 50,
    fontsize: 18,
    formatter: function(x){
      if((this._settings.step+"").indexOf(".")>-1)
        var digits = (this._settings.step+"").split(".").pop().length;
      else
        var digits = 0;
      v = betterParseFloat(x);
      if(x<0){
        var neg = true;
        x = 0 - x;
      } else {
        var neg = false;
      }
      if(isNaN(x)){
        return "NaN";
      }
      var whole = Math.floor(x);
      var dec = (x - whole);
      dec = Math.round(dec * Math.pow(10, digits));
      dec = dec+"";
      while(dec.length<digits){
        dec = "0" + dec;
      }
      return ((neg)?"-":"")+whole+((digits>0)?"."+dec:"");
    },
    timeout: 2000,
    range: false,
    id: false,
    name: "",
    class: ""
  };
  Object.defineProperty(this, "settings", {
    get: function(){
      this.trigger("getsetting settings", this._settings);
      return this._settings;
    },
    set: function(newSettings){
      this._settings = $.extend(this._settings, settings);
      this.trigger("setsettings settings", this._settings);
      this.refresh();
    }
  });
  Object.defineProperty(this, "value", {
    get: function(){
      this.trigger("getvalue value", this._settings.value);
      return this._settings.value;
    },
    set: function(newVal){
      var self = this;
      this._settings.value = newVal;
      
      this._elements.find(".addui-slider-input").val(this._settings.value);
      if (!this._settings.range) {
        var offset = betterParseFloat(this._settings.value) - this._settings.min;
        var per = (toNearest(offset, this._settings.step) / (this._settings.max - this._settings.min))  * 100;
        if(this._settings.direction == "vertical"){
          this._elements.find(".addui-slider-handle").css("bottom", per+"%");
          this._elements.find(".addui-slider-range").css("height", per+"%");
          this._elements.find(".addui-slider-range").css("bottom", "0%");
        } else {
          this._elements.find(".addui-slider-handle").css("left", per+"%");
          this._elements.find(".addui-slider-range").css("width", per + "%");

        }
        this._elements.find(".addui-slider-value span").html(toFunc(this._settings.formatter).call(this, this._settings.value));
      } else {
        var l = (toNearest(parseFloat(this._settings.value.split(",")[0]), this._settings.step));
        var h = (toNearest(parseFloat(this._settings.value.split(",")[1]), this._settings.step));
        var range = this._settings.max - this._settings.min;
        var offsetL = l - this._settings.min;
        var offsetH = h - this._settings.min;
        var lPer = (offsetL / range) * 100;
        var hPer = (offsetH / range) * 100;
        this._elements.each(function(i,el){
          var $el = $(el);
          if(self._settings.direction == "vertical"){
            $el.find(".addui-slider-handle").eq(0).css("bottom", lPer+"%");
            $el.find(".addui-slider-handle").eq(1).css("bottom", hPer+"%");
            $el.find(".addui-slider-range").css("bottom", lPer+"%").css("height", (hPer-lPer)+"%");
          } else {
            $el.find(".addui-slider-handle").eq(0).css("left", lPer+"%");
            $el.find(".addui-slider-handle").eq(1).css("left", hPer+"%");
            $el.find(".addui-slider-range").css("left", lPer+"%").css("width", (hPer-lPer)+"%");
          }
          $el.find(".addui-slider-handle").eq(0).find(".addui-slider-value span").html(toFunc(self._settings.formatter).call(self, l));
          $el.find(".addui-slider-handle").eq(1).find(".addui-slider-value span").html(toFunc(self._settings.formatter).call(self, h));
        });
      }
    }
  });
    //End Here

 
    // after init of Range here it will be rendered
  this.renderer = function () {
    //  alert("3")
    var self = this;
    var $slider = $("<div  class='addui-slider addui-slider-"+this._settings.direction+((this._settings.range)?" addui-slider-isrange":"")+" "+this._settings.class+"' "+((this._settings.id)?"id='"+this._settings.id+"'":"")+"></div>");
    var $input = $("<input class='addui-slider-input' type='hidden' name='" + this._settings.name + "' value='" + this._settings.value + "' />").appendTo($slider);


    var $track = $("<div class='addui-slider-track dots'></div>").appendTo($slider);
    var $range = $("<div class='addui-slider-range'></div>").appendTo($track);
    

    var foo = parseInt($("#sdlinpt").attr('data-max'));
    //alert($(".rsldr").width());
    //alert(foo);
      var mar = parseInt(($(".rsldr").width() - 50) / (foo));
    for (var x = 0; x <= foo; x++) {

        $($track).append("<span class='dots' style='left:" + x * mar + "px'></span>");
    }
    
    if (!this._settings.range) {
      var $handle = $("<div class='addui-slider-handle'><div class='addui-slider-value'><span style='font-size: "+this._settings.fontsize+"px'></span></div></div>").appendTo($track);
      var activeTimer = null;
      function dragHandler(e) {
          console.log("dragging");
        e.preventDefault();
        if(self._settings.direction == "vertical"){
          if(e.type == "touchmove")
            var y = e.originalEvent.changedTouches[0].pageY;
          else
            var y = e.pageY;
          var sliderY = $slider.offset().top + $slider.height();
          var offsetY = sliderY - y;
          var offsetPer = (offsetY / $slider.height()) * 100;
        } else {
          if(e.type == "touchmove")
            var x = e.originalEvent.changedTouches[0].pageX;
          else
            var x = e.pageX;
          var sliderX = $slider.offset().left;
          var offsetX = x - sliderX;
          var offsetPer = (offsetX / $slider.width()) * 100;
        }
        
        var val = toNearest((offsetPer / 100) * (self._settings.max - self._settings.min), self._settings.step) + self._settings.min;
        val = Math.min(self._settings.max,Math.max(self._settings.min,val));
        self.value = toNearest(val, self._settings.step);
        
      };
      function dragStopHandler(e){
        $(window).off("mousemove touchmove", dragHandler);
        activeTimer = setTimeout(function(){
          $handle.removeClass("addui-slider-handle-active");
        }, self._settings.timeout);
      };
      $handle.on("mousedown touchstart", function(e){
        clearTimeout(activeTimer);
        $handle.addClass("addui-slider-handle-active");
        $(window).on("mousemove touchmove dragmove", dragHandler);
        $(window).one("mouseup touchend", dragStopHandler);
      });
      $slider.on("click", function (e) {
        e.preventDefault();
        
        if(self._settings.direction == "vertical"){
          if(e.type == "touchmove")
            var y = e.originalEvent.changedTouches[0].pageY;
          else
            var y = e.pageY;
          var sliderY = $slider.offset().top + $slider.height();
          var offsetY = sliderY - y;
          var offsetPer = (offsetY / $slider.height()) * 100;
        } else {
          if(e.type == "touchmove")
            var x = e.originalEvent.changedTouches[0].pageX;
          else
            var x = e.pageX;
          var sliderX = $slider.offset().left;
          var offsetX = x - sliderX;
          var offsetPer = (offsetX / $slider.width()) * 100;
        }
        
        var val = toNearest((offsetPer / 100) * (self._settings.max - self._settings.min), self._settings.step) + self._settings.min;
        val = Math.min(self._settings.max, Math.max(self._settings.min, val));
        $("#hdnSldr").val(val);
        clearTimeout(activeTimer);
        $handle.addClass("addui-slider-handle-active");
        activeTimer = setTimeout(function(){
          $handle.removeClass("addui-slider-handle-active");
        }, self._settings.timeout);
        self.value = val;
      });

    }
    $("#hdnSldr").val(self.value);
    return $slider;
      
  };
  
    //End Here
    // Init of Ranger called with the use of Settings 
  this.init = function (settings) {
     // alert("2")
    var self = this;
    this.settings = settings;
    if(!this._settings.range){
      this._settings.value = Math.max(this._settings.min, Math.min(this._settings.max, betterParseFloat(this._settings.value)));
    } else {
      var val = this._settings.value+"";
      if(val.indexOf(",") > -1){ // Already has two values
        var values = val.split(",");
        var v1 = betterParseFloat(values[0]);
        v1 = Math.min(this._settings.max, Math.max(this._settings.min, v1));
        v1 = toNearest(v1, this._settings.step);
        
        var v2 = betterParseFloat(values[1]);
        v2 = Math.min(this._settings.max, Math.max(this._settings.min, v2));
        v2 = toNearest(v2, this._settings.step);
      } else { // Only has one value
        var val = toNearest(Math.max(this._settings.min, Math.min(this._settings.max, betterParseFloat(this._settings.value))), this._settings.step);
        var middle = (this._settings.max - this._settings.min) / 2;
        if(val < middle){
          var v1 = val;
          var v2 = this._settings.max - val;
        } else {
          var v2 = val;
          var v1 = this._settings.min + val;
        }
      }
      if(v1<v2)
        this._settings.value = v1+","+v2;
      else
        this._settings.value = v2+","+v1;
    }
    this.on("render", function(){
      self.value = self._settings.value;
    })
    this.trigger("init", {
      settings: this._settings
    });
  };
  this.init.apply(this, arguments);
};

//End Here

// when page loading it will call first means slider properties settings called
$pcrngsldr.Slider = function (selector, settings) {
    //alert("1")
    //alert(selector.length);
    var o = $(selector).each(function (i, el) {
    var $el = $(el);
    var s = {};
    if($el.attr("name"))
      s.name = $el.attr("name");
    if($el.attr("class"))
      s.class = $el.attr("class");
    if($el.attr("id"))
      s.id = $el.attr("id");
    if($el.attr("value"))
      s.value = $el.attr("value");
    if($el.attr("min"))
      s.min = $el.attr("min");
    if($el.attr("max"))
      s.max = $el.attr("max");
    if($el.attr("step"))
      s.step = $el.attr("step");
    settings = $.extend(s, $el.data(), settings);
    var S = new $pcrngsldr.SliderObj(settings);
    S.render($el, "replace");
    return S;
    });
    
  return (o.length == 0)?null:(o.length==1)?o[0]:o;
};
$.fn.addSlider = function(settings){
  $pcrngsldr.Slider(this, settings);
};
$pcrngsldr.auto.Slider = function(){
  if(!$pcrngsldr.auto.disabled)
    $("[data-addui=slider]").addSlider();
};
$(function(){
  $pcrngsldr.auto.Slider();
});

    //End Here
}





