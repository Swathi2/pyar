﻿/// <reference path="~/scripts/jquery-2.1.1.min.js" />
/// <reference path="~/scripts/slick.min.js" />

//function profileInfo() {
//    $(document).ready(function () {

//        if (window.outerWidth < 765) {
//            setTimeout(function () {
//                $('.prfslder').slick({
//                    dots: false,
//                    infinite: true,
//                    speed: 300,
//                    slidesToShow: 5,
//                    slidesToScroll: 1,
//                    responsive: [
//                      {
//                          breakpoint: 991,
//                          settings: {
//                              slidesToShow: 3,
//                              slidesToScroll: 1
//                          }
//                      },
//                      {
//                          breakpoint: 767,
//                          settings: {
//                              slidesToShow: 1,
//                              slidesToScroll: 1
//                          }
//                      }]
//                });
//            }, 2000);
//        }
//    });
//}


// When member click on matchsummary edit buttons, then showing the matchsummary popup and navigating to appropriate section. 
function popHideShow(mainTab, subTab) {
    $("#matchSummaryModal").modal("hide");
    $('body').css('overflow', '');
    $('body').css('position', '');

    //Time delay from removing style from body class (that will automatically rendered from bootstrap class
    setTimeout(function () {
        $("#matchPrefModal").modal("show");
        if (subTab != "") { subTab = ", " + subTab; }
        $("#matchprefnav " + mainTab + subTab).click();
        $('body').css('overflow', 'hidden');
        $('body').css('position', 'fixed');

    }, 400);

}

function BasicPopOnClick() { popHideShow("#firstprntanc", "#nvanc1"); }
function AboutMePopOnClick() { popHideShow("#Aboutprntanc", "#nvanc3"); }
function PtPopOnClick() { popHideShow("#nvanc9", ""); }
function AppearancePopOnClick() { popHideShow("#Appearanceprntanc", "#nvanc10"); }
function LifestylePopOnClick() { popHideShow("#Lifestyleprntanc", "#nvanc14"); }
function HobbiesPopOnClick() { popHideShow("#nvanc26", ""); }

//This function is using inside JSON Data 
function IsValueExists(status) {
    if (status != "" && status != null && status != undefined && status.length != 0)
        return true
    else
        return false;
}

//This function is slider count values
function IsCountValueExists(status) {
    if ((status != "" && status != null && status != undefined)) {
        status = status.toString();
        if (status) { if ((status.toString().indexOf("+") !== -1)) { status = status.replace(/\+/g, ""); } }
        return true
    } else
        return false;
}

//Function for return grew up location
//function GrewUpFunc(Country, State) {
//    if (Country == "" || Country == null) return "Grew up in " + State;
//    else return "Grew up in " + State + ", " + Country;
//}

//function GetHmCntry(Country, State) {
//    if (Country == "" || Country == null) return State;
//    else return State + ", " + Country;
//}

//Splitting response data into two parts
function tblSplit(data, callBack) {
    var t1 = Math.round(data.length / 2);
    var t2 = (data.length) - t1;
    callBack(t1, t2);
}

//Get JSON Data that Contains status property true only.
function getJSonActiveData(data, pushVal) {
    for (var i = 0; i < data.length; i++) {
        if (data[i].status == true) {
            pushVal.push(data[i]);
        }
    }
}

function getJSonActiveDataText(data, pushVal) {
    if (data != null) {
        for (var i = 0; i < data.length; i++) {
            pushVal.push(" " + data[i].txt);
        }
    }
}


//This functions is using in Match Summary popups both self profile & others profile:  Starts
function AboutMeMSFunc(Ethnicities, Religions, AreaOfWork, RSStatus, HighestEduc, Country) {
    var EthnicitiesArr = []; getJSonActiveDataText(Ethnicities, EthnicitiesArr);
    var ReligionsArr = []; getJSonActiveDataText(Religions, ReligionsArr);
    var RSStatusArr = []; getJSonActiveDataText(RSStatus, RSStatusArr);

    if (typeof (Ethnicities) == "object") { Ethnicities = EthnicitiesArr.join(); }
    if (typeof (Religions) == "object") { Religions = ReligionsArr.join(); }
    if (typeof (RSStatus) == "object") { RSStatus = RSStatusArr.join(); }

    return [{ Id: Ethnicities, Img: "https://pccdn.pyar.com/pcimgs/hme.svg", status: IsValueExists(Ethnicities) },
           { Id: Religions, Img: "https://pccdn.pyar.com/pcimgs/myreligion.svg", status: IsValueExists(Religions) },
           { Id: AreaOfWork, Img: "https://pccdn.pyar.com/pcimgs/myjob.svg", status: IsValueExists(AreaOfWork) },
           { Id: RSStatus, Img: "https://pccdn.pyar.com/pcimgs/myrship.svg", status: IsValueExists(RSStatus) },
           { Id: HighestEduc, Img: "https://pccdn.pyar.com/pcimgs/myedu.svg", status: IsValueExists(HighestEduc) },
           { Id: Country, Img: "https://pccdn.pyar.com/pcimgs/location.svg", status: IsValueExists(Country) }];
}

function MyApprnceMSFunc(EyeColour, HairColour, maxHeight, Build, genderImg) {
    var eyeColourArr = []; getJSonActiveDataText(EyeColour, eyeColourArr);
    var hairColourArr = []; getJSonActiveDataText(HairColour, hairColourArr);
    var buildArr = []; getJSonActiveDataText(Build, buildArr);
    genderImg = genderImg ? "https://pccdn.pyar.com/pcimgs/myHairClrM.svg" : "https://pccdn.pyar.com/pcimgs/myHairClrF.svg";

    if (typeof (EyeColour) == "object") { EyeColour = eyeColourArr.join(); }
    if (typeof (HairColour) == "object") { HairColour = hairColourArr.join(); }
    if (typeof (Build) == "object") { Build = buildArr.join(); }

    return [{ Id: EyeColour, Img: "https://pccdn.pyar.com/pcimgs/myeyeclr.svg", status: IsValueExists(EyeColour) },
           { Id: HairColour, Img: genderImg, status: IsValueExists(HairColour) },
           { Id: maxHeight + " tall", Img: "https://pccdn.pyar.com/pcimgs/myheight.svg", status: IsValueExists(maxHeight) },
           { Id: Build, Img: "https://pccdn.pyar.com/pcimgs/mybuild.svg", status: IsValueExists(Build) }];
}

function LifeStyleMSFunc($filter, Diet, Smoke, Drink, IdealRelationship, ChildrenCount, ChildrenPref, PetsCount, PetsPref, Languages, FamilyLanguages, Religious, Traditional,pgType) {
    var DietArr = []; getJSonActiveDataText(Diet, DietArr);
    var LangArr = []; getJSonActiveDataText(Languages, LangArr);
    var FmlyLangArr = []; getJSonActiveDataText(FamilyLanguages, FmlyLangArr);
    
    if (typeof (Diet) == "object") { Diet = DietArr.join(); }
    if (typeof (Languages) == "object") { Languages = LangArr.join(); }
    if (typeof (FamilyLanguages) == "object") { FamilyLanguages = FmlyLangArr.join(); }

    return [{ Id: Diet, Img: "https://pccdn.pyar.com/pcimgs/mydiet.svg", status: IsValueExists(Diet) },
           { Id: Smoke + " smokes", Img: "https://pccdn.pyar.com/pcimgs/mysmoking.svg", status: IsValueExists(Smoke) },
           { Id: Drink + " drinks", Img: "https://pccdn.pyar.com/pcimgs/mydrink.svg", status: IsValueExists(Drink) },
           { Id: "Wants a " + IdealRelationship + " relationship", Img: "https://pccdn.pyar.com/pcimgs/myrship.svg", status: IsValueExists(IdealRelationship) },
           { Id: $filter('childCountFltr')(ChildrenCount, "MS"), Img: "https://pccdn.pyar.com/pcimgs/mychildren.svg", status: IsCountValueExists(ChildrenCount) },
           { Id: $filter('childPrefFltr')(ChildrenPref, "MS"), Img: "https://pccdn.pyar.com/pcimgs/mychildren.svg", status: IsValueExists(ChildrenPref) },
           { Id: $filter('petCountFltr')(PetsCount, "MS"), Img: "https://pccdn.pyar.com/pcimgs/mypets.svg", status: IsCountValueExists(PetsCount) },
           { Id: $filter('petsPrefFltr')(PetsPref, "MS"), Img: "https://pccdn.pyar.com/pcimgs/mypets.svg", status: IsValueExists(PetsPref) },
           { Id: "Prefers " + Languages, Img: "https://pccdn.pyar.com/pcimgs/mylanguage.svg", status: IsValueExists(Languages) },
           { Id: "Family speaks " + FamilyLanguages, Img: "https://pccdn.pyar.com/pcimgs/mylanguage.svg", status: IsValueExists(FamilyLanguages) },
           { Id: Religious + " religious", Img: "https://pccdn.pyar.com/pcimgs/myreligion.svg", status: IsValueExists(Religious) },
           { Id: Traditional + " traditional", Img: "https://pccdn.pyar.com/pcimgs/myculture.svg", status: IsValueExists(Traditional) }];
}
function LifeStyleOPFunc($filter, Diet, Smoke, Drink, IdealRelationship, ChildrenCount, ChildrenPref, PetsCount, PetsPref, Languages, FamilyLanguages, Religious, Traditional, pgType) {
    var DietArr = []; getJSonActiveDataText(Diet, DietArr);
    var LangArr = []; getJSonActiveDataText(Languages, LangArr);
    var FmlyLangArr = []; getJSonActiveDataText(FamilyLanguages, FmlyLangArr);

    if (typeof (Diet) == "object") { Diet = DietArr.join(); }
    if (typeof (Languages) == "object") { Languages = LangArr.join(); }
    if (typeof (FamilyLanguages) == "object") { FamilyLanguages = FmlyLangArr.join(); }

    return [{ Id: Diet, Img: "https://pccdn.pyar.com/pcimgs/mydiet.svg", status: IsValueExists(Diet) },
           { Id: Smoke + " smoke", Img: "https://pccdn.pyar.com/pcimgs/mysmoking.svg", status: IsValueExists(Smoke) },
           { Id: Drink + " drink", Img: "https://pccdn.pyar.com/pcimgs/mydrink.svg", status: IsValueExists(Drink) },
           { Id: "I want a " + IdealRelationship + " relationship", Img: "https://pccdn.pyar.com/pcimgs/myrship.svg", status: IsValueExists(IdealRelationship) },
           { Id: $filter('childCountFltr')(ChildrenCount, "OP"), Img: "https://pccdn.pyar.com/pcimgs/mychildren.svg", status: IsCountValueExists(ChildrenCount) },
           { Id: $filter('childPrefFltr')(ChildrenPref, "OP"), Img: "https://pccdn.pyar.com/pcimgs/mychildren.svg", status: IsValueExists(ChildrenPref) },
           { Id: $filter('petCountFltr')(PetsCount, "OP"), Img: "https://pccdn.pyar.com/pcimgs/mypets.svg", status: IsCountValueExists(PetsCount) },
           { Id: $filter('petsPrefFltr')(PetsPref, "OP"), Img: "https://pccdn.pyar.com/pcimgs/mypets.svg", status: IsValueExists(PetsPref) },
           { Id: "Prefers " + Languages, Img: "https://pccdn.pyar.com/pcimgs/mylanguage.svg", status: IsValueExists(Languages) },
           { Id: "Family speaks " + FamilyLanguages, Img: "https://pccdn.pyar.com/pcimgs/mylanguage.svg", status: IsValueExists(FamilyLanguages) },
           { Id: Religious + " religious", Img: "https://pccdn.pyar.com/pcimgs/myreligion.svg", status: IsValueExists(Religious) },
           { Id: Traditional + " traditional", Img: "https://pccdn.pyar.com/pcimgs/myculture.svg", status: IsValueExists(Traditional) }];
}
//This functions is using in Match Summary popups both self profile & others profile:  End

//for calculating profile completion
function prfCmpltn(firstName, gender, dob, cityId, ethinicityId, religionId, awId, rsStatus, highestEdu, htCountry, htCity, myBioData,
                eyeColor, hairColor, build, height, diet, smoke, drink, idealRelationship, childrenCnt, childrenPref, petsCnt,
                petsPref, familyLang, langPref, religious, traditional, PersonalityTraits, hobbies) {

    var myVal = 0;
    var paramCount = 0;
    //for get paramters count, passed to this function
    paramCount = prfCmpltn.length;

    function IncVal() { myVal = myVal + 1; }
    function getVal(val) { if (val != "" && val != null && val != undefined && val.length != 0) { IncVal(); } }

    getVal(firstName);
    getVal(gender);
    getVal(dob);
    getVal(cityId);
    getVal(ethinicityId);
    getVal(religionId);
    getVal(awId);
    getVal(rsStatus);
    getVal(highestEdu);
    getVal(htCountry);
    getVal(htCity);
    getVal(eyeColor);
    getVal(hairColor);
    getVal(build);
    getVal(height);
    getVal(diet);
    getVal(smoke);
    getVal(drink);
    getVal(idealRelationship);
    getVal(childrenCnt);
    getVal(childrenPref);
    getVal(petsCnt);
    getVal(petsPref);
    getVal(familyLang);
    getVal(langPref);
    getVal(religious);
    getVal(traditional);
    getVal(myBioData);
    getVal(PersonalityTraits);
    getVal(hobbies);

    var percentage = Math.round(myVal / paramCount * 100);

    return percentage;
}

//function for updating view after calling APIs
function MultiUpdate(Lst, Ids, OldView) {
    var checkedName = [];
    angular.forEach(Lst, function (data) {
        if (Ids.indexOf(data.val) !== -1) {
            checkedName.push(data.txt);
        }
    });
    angular.forEach(checkedName, function (data) {
        OldView.push({ txt: data });
    });
}

//function for binding chekboxes based Ids
function BindCheckBoxIds(StringIds, PushVal) {
    if (StringIds && typeof (StringIds) != "string") {
        StringIds = StringIds.join();
    }
    if (StringIds) {
        angular.forEach(StringIds.split(','), function (data) {
            if (!isNaN(parseInt(data)))
                PushVal.push(parseInt(data));
        });
    }
}

//Function for Get checkbox clicked Ids
function GetClickedIds(Ids, Id) {
    var index = Ids.indexOf(Id);
    if (index == -1)
        Ids.push(Id);
    else
        Ids.splice(index, 1);
}

//function for getting Ids with Names
function GetIdWithName(Lst, Ids, Names, Id) {
    var index = Ids.indexOf(Id);
    if (index == -1) {
        Ids.splice(0, 0, Id);
        for (var i = 0; i < Lst.length; i++) {
            if (Lst[i].val == Id) {
                Names.splice(0, 0, Lst[i].txt);
                break;
            }
        }
    }
    else {
        Ids.splice(index, 1);
        Names.splice(index, 1);
    }
}


function GetHeightValTxt(minId, minTxt, maxId, maxTxt) {
    var val = "";
    if (minId != null && maxId != null)
        val = "between " + minTxt + " and " + maxTxt;
    else if (minId == null && maxId == null)
        val = "";
    else if (minId == null)
        val = "At most " + maxTxt;
    else if (maxId == null)
        val = "At least " + minTxt;
    return val;
}

//function for getting country name & statename
function htInfoDlts(p_cntryId, prefData) {
    if (prefData.htInfo) {
        if (p_cntryId == prefData.htCountry) {
            return "Grew up in " + prefData.htInfo.cityName + ", " + prefData.htInfo.stateName;
        }
        else {
            return "Grew up in " + prefData.htInfo.cityName + ", " + prefData.htInfo.stateName + ", " + prefData.htInfo.countryName;
        }
    }
}
