﻿angular.module("app").controller('selfprofileCtrl', ['getSessionSrvc', 'selfprofileSrvc', 'countryIntlSrv', '$scope', '$rootScope', '$window', '$state', '$anchorScroll', '$filter', '$timeout', '$interval', 'dashboardFact', 'cmnSrvc', 'msgSrvc', '$cookieStore', '$compile', '$location',
function (getSessionSrvc, selfprofileSrvc, countryIntlSrv, $scope, $rootScope, $window, $state, $anchorScroll, $filter, $timeout, $interval, dashboardFact, cmnSrvc, msgSrvc, $cookieStore, $compile, $location) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    var timezone = function () { return getSessionSrvc.p_tz(); };
    var zone = function () { return getTimeZoneById(timezone()); };
    vm.trialDays = function () { return cmnSrvc.getTrialDays() };
    //Firtst Time trophies Popups Loading starts
    var ShowTrophyFTPOP = function () {
        vm.ftPopupCount = 0;
        if (cmnSrvc.ftPOPCheck(1)) {
            if (cmnSrvc.ftPOPCheckTrophy(vm.profileInfo.trophies, 1)) {
                vm.ftPopupCount++;
                vm.dvEmailComp = true;
            }
            if (cmnSrvc.ftPOPCheckTrophy(vm.profileInfo.trophies, 2)) {
                vm.ftPopupCount++;
                vm.dvSocialComp = true;
            }
            if (cmnSrvc.ftPOPCheckTrophy(vm.profileInfo.trophies, 3)) {
                vm.ftPopupCount++;
                vm.dvprofilePicComp = true;
            }
            if (cmnSrvc.ftPOPCheckTrophy(vm.profileInfo.trophies, 4)) {
                vm.ftPopupCount++;
                vm.dvMobileComp = true;
            }
            $("#ftTrophyPop").modal('show');
            cmnSrvc.ftPOPUpdate(1);
        }
    }
    //Firtst Time trophies Popups Loading End Here


    //Swiper slider for Personality traits
    $scope.$on('onPtImgLoadFinish', function () {
        if ($(window).width() <= 767) {
            vm.Tswiper = new Swiper('.swiperPt', {
                slidesPerView: 5, //paginationClickable: true, //centeredSlides: true, //loop: true,
                breakpoints: { 1024: { slidesPerView: 5 }, 768: { centeredSlides: true, slidesPerView: 4 }, 640: { centeredSlides: true, slidesPerView: 2 }, 320: { centeredSlides: true, slidesPerView: 2 } }
            });
        }
    });

    //Swiper slider for Trophies
    vm.onTrophyImgLoadFinish = function () {
        if ($(window).width() <= 767) {
            vm.Trphswiper = new Swiper('.swiperTrph', {
                slidesPerView: 5, //paginationClickable: true, //centeredSlides: true, //loop: true,
                breakpoints: { 1024: { slidesPerView: 5 }, 768: { centeredSlides: true, slidesPerView: 4 }, 640: { centeredSlides: true, slidesPerView: 2 }, 320: { centeredSlides: true, slidesPerView: 2 } }
            });
        }
    };

    if ($(window).width() <= 767) {
        vm.prfslder = "swiper-wrapper";
        vm.prsnimg = "swiper-slide";
        vm.ptextcls = "prsnimg";
    }
    else {
        vm.prfslder = "prfslder";
        vm.prsnimg = "prsnimg";
        vm.ptextcls = "";
    }

    // Getting memberId from session    
    //var mId = getSessionSrvc.p_mId();
    vm.premMember = function () { return getSessionSrvc.p_sub() }; //1. Basic 2. Premium
    vm.memberCollection = getSessionSrvc.p_pgc();

    var brdrBlueCls = 'pfbgbrdr'; // style for blue color boader in edit mode
    vm.multiTxtLimit = 45;

    vm.dvpgVisble = false;
    //page unevenly loading resolve function
    vm.pgVisble = function () {
        $timeout(function () {
            vm.dvpgVisble = true;
            BindInPhtsUsngLclStgData();
        }, 200, true);
    }

    vm.scrollLock = false;
    function getScroll() {
        $(document).on("scroll", function (e) {
            if (vm.scrollLock) {
                var windowScrollTop = $(window).scrollTop();
                if (windowScrollTop < vm.eTop) {
                    $(document).scrollTop(vm.eTop);
                }
                else if (windowScrollTop > vm.eBottom) {
                    $(document).scrollTop(vm.eBottom);
                }
            }
        });
    }

    function scrollDragable(dvEdit) {
        //vm.scrollLock = true;
        //vm.eTop = $("#" + dvEdit).offset().top - 70;
        //$(document).scrollTop(vm.eTop);
        //vm.eHeight = $("#" + dvEdit).height();
        //vm.eBottom = vm.eTop + vm.eHeight;
        //getScroll();

        $timeout(function () {
            vm.scrollLock = true;
            vm.eTop = $("#" + dvEdit).offset().top - 170;
            $(document).scrollTop(vm.eTop);
            vm.eHeight = $("#" + dvEdit).height();
            vm.eBottom = vm.eTop + vm.eHeight;
            getScroll();
        }, 500);
    }

    //List of classes for actving & deactiving clicks when it is beaing in edit mode.
    var dvEdtblCls = ".prfedt, .asdedit, .ntfbtn, .persEDEvnts,#dvGlryPhoto, .hbsEDEvnts, .glrEDEvnts, .trpEDEvnts, .prfmsmry, .abtEDEvnts, .myaprEDEvnts, .lstEDEvnts, .mbrnav, .dvPrflPcEvnts";
    // Disable All click events when we open the div in Edit mode
    function disblAllClikevnts() { $(dvEdtblCls).addClass("not-active"); }
    //Enable All Click Events when the Edit mode div closed
    function EnableAllClickEvents() { $(dvEdtblCls).removeClass("not-active"); }

    //Page load services Called starts
    var GetPrfInfoCallBack = function (response, status) {
        showLoader();
        vm.profileInfo = response;
        if (response.isProfilePicUpld) {
            vm.prflCurPtr = "curptr";
        }
        if (vm.profileInfo.profileBnr)
            vm.bnrCurPtr = "curptr";
        vm.profilePic = updateImgVersion($filter("PrflPicFltr")(vm.profileInfo.profilePic, vm.profileInfo.gender, vm.memberCollection));
        vm.bnrImg = $filter('bannerPicFltr')(vm.profileInfo.profileBnr, vm.memberCollection);
        vm.tagLIneImg = $filter('bannerPicFltr')(vm.profileInfo.profileBnr, vm.memberCollection);
        vm.gndrHirImg = vm.profileInfo.gender ? "https://pccdn.pyar.com/pcimgs/myHairClrM.svg" : "https://pccdn.pyar.com/pcimgs/myHairClrF.svg";
        vm.age = calculateAge(vm.profileInfo.dob);
        vm.myBioData = vm.profileInfo.abtDesc;
        Trophiesresult = (vm.profileInfo.trophies).split('#');
        vm.ptGenderImg = vm.profileInfo.gender ? "https://pccdn.pyar.com/pcimgs/avataremptyM.png" : "https://pccdn.pyar.com/pcimgs/avataremptyF.png";
        trophiesLoad(Trophiesresult);
        ShowTrophyFTPOP();

        //for TagLine data Binding
        vm.tagLine = vm.profileInfo.profileBnrTxt;
        vm.tagLine ? vm.btnAddTagLineTxt = "EDIT TAGLINE" : vm.btnAddTagLineTxt = "ADD TAGLINE";
        if (vm.profileInfo.profileBnrStyles) {
            vm.TagLineStyles = vm.profileInfo.profileBnrStyles;
            vm.sliderTagLine = vm.TagLineStyles.split("$##$")[0];
            vm.sliderTagLineUpdate = vm.TagLineStyles.split("$##$")[0];
            vm.TagLineViewTop = (vm.TagLineStyles.split("$##$")[2]) - 150;
            vm.tgLineFontColorUpdate = (vm.TagLineStyles.split("$##$")[3]);
        }
        vm.memLocation = vm.profileInfo.cityName + ", " + vm.profileInfo.stateName;
        selfprofileSrvc.GetPrfInfoExt1(vm.mId(), vm.profileInfo, GetPrfInfoExt1CallBack);
        selfprofileSrvc.GetPrfInfoExt2(vm.mId(), vm.profileInfo, GetPrfInfoExt2CallBack);
    }

    var GetPrfInfoExt1CallBack = function (responseEx1, status) {
        vm.profileInfoExt1 = responseEx1;
        if (vm.profileInfoExt1.htInfo) {
            if (getSessionSrvc.p_cntry() == vm.profileInfoExt1.htInfo.countryName) {
                vm.grewUpTxt = "Grew up in " + vm.profileInfoExt1.htInfo.cityName + ", " + vm.profileInfoExt1.htInfo.stateName;
            }
            else {
                vm.grewUpTxt = "Grew up in " + vm.profileInfoExt1.htInfo.cityName + ", " + vm.profileInfoExt1.htInfo.stateName + ", " + vm.profileInfoExt1.htInfo.countryName;
            }
        }

        //Getting About Me block Data Starts
        vm.etnctyId = vm.profileInfo.ethinicityId; vm.etnctyIdTxt = vm.profileInfoExt1.ethinicityId;
        vm.rglnId = vm.profileInfo.religionId; vm.rglnIdTxt = vm.profileInfoExt1.religionId;
        vm.aOfWrkId = vm.profileInfo.awId; vm.aOfWrkIdTxt = vm.profileInfoExt1.awId;
        vm.stsId = vm.profileInfo.rsStatus; vm.stsIdTxt = vm.profileInfoExt1.rsStatus;
        vm.dgrId = vm.profileInfo.highestEdu; vm.dgrIdTxt = vm.profileInfoExt1.highestEdu;
        vm.cntryId = vm.profileInfo.htCountry; vm.cntryIdTxt = vm.profileInfoExt1.htCountry;
        hideLoader();
        vm.pgVisble();

        if (!vm.profileInfo.isProfilePicUpld) { // when member is coming from email to add his/her photo, showing popup.
            if ($location.absUrl().split('?')[1] == "addpp") {
                $timeout(function () { vm.addProfilePic(); }, 1000);
            }
        }
        if ($location.absUrl().split('?')[1] == "verifymob") {  // when member is coming from email to verify  his/her mobile number, showing popup.
            $timeout(function () { vm.mobVerifyPopup(); }, 1000);
        }
        if ($location.absUrl().split('?')[1] == "matchpref") {  // when member is coming from email to fill match preference data, showing popup.
            $timeout(function () { $("#btnMPEdit").click() }, 1000);
        }
    }

    var GetPrfInfoExt2CallBack = function (responseEx2, status) {

        vm.profileInfoExt2 = responseEx2;
        var Ex2 = vm.profileInfoExt2;
        vm.chldCntLst = $filter('childCountFltr')(Ex2.childrenCnt, "OP");
        vm.chldPref = $filter('childPrefFltr')(Ex2.childrenPref, "OP");
        vm.ptsCntLst = $filter('petCountFltr')(Ex2.petsCnt, "OP");
        vm.ptsPref = $filter('petsPrefFltr')(Ex2.petsPref, "OP");

        //Getting My appearance block Data Starts
        vm.eyeId = vm.profileInfo.eyeColor; vm.eyeIdTxt = vm.profileInfoExt2.eyeColor;
        vm.hairId = vm.profileInfo.hairColor; vm.hairIdTxt = vm.profileInfoExt2.hairColor;
        vm.bldId = vm.profileInfo.build; vm.bldIdTxt = vm.profileInfoExt2.build;
        vm.htId = vm.profileInfo.height; vm.htIdTxt = vm.profileInfoExt2.height;
        //Getting My appearance block Data End

        //Getting My lifestyle block Data Starts
        vm.ditId = vm.profileInfo.diet; vm.ditIdTxt = vm.profileInfoExt2.diet;
        vm.smkId = vm.profileInfo.smoke; vm.smkIdTxt = vm.profileInfoExt2.smoke;
        vm.drnkId = vm.profileInfo.drink; vm.drnkIdTxt = vm.profileInfoExt2.drink;
        vm.irltnshp = vm.profileInfo.idealRelationship; vm.irltnshpTxt = vm.profileInfoExt2.idealRelationship;
        vm.chldrnCntId = vm.profileInfo.childrenCnt; vm.chldrnCntIdTxt = vm.profileInfoExt2.childrenCnt;
        vm.chldrnPrefId = vm.profileInfo.childrenPref; vm.chldrnPrefIdTxt = vm.profileInfoExt2.childrenPref;
        vm.ptsCntId = vm.profileInfo.petsCnt; vm.ptsCntIdTxt = vm.profileInfoExt2.petsCnt;
        vm.ptsPrefId = vm.profileInfo.petsPref; vm.ptsPrefIdTxt = vm.profileInfoExt2.petsPref;
        vm.rlgsId = vm.profileInfo.religious; vm.rlgsIdTxt = vm.profileInfoExt2.religious;
        vm.trdtnlId = vm.profileInfo.traditional; vm.trdtnlIdTxt = vm.profileInfoExt2.traditional;
        //Getting My lifestyle block Data End

        //Getting multiple Family Langauges Text        
        vm.FamlyLangs = []; getJSonActiveDataText(vm.profileInfoExt2.familyLangs, vm.FamlyLangs);

        //Getting multiple Prefered Langauges Text
        vm.PrefLangs = []; getJSonActiveDataText(vm.profileInfoExt2.lang, vm.PrefLangs);

        //Calling profile complition
        $timeout(function () { getPrfCmpltn(); }, 500);
        hideLoader();

        //opening match-preference popup from dashboard
        if (dashboardFact.getmpPop() == true) {
            $timeout(function () { $("#matchPrefModal").modal("show"); }, 500);
            dashboardFact.setmpPop(false);
        }
    }

    //calling profileInfo service
    selfprofileSrvc.profileInfo(vm.mId(), GetPrfInfoCallBack);

    vm.trphVal = false; //Temporary trophy value
    //function for Get profile Completion Percentage.
    function getPrfCmpltn() {
        var PInfo = vm.profileInfo;
        var hbs = "";
        if (!vm.hbClick) { hbs = PInfo.hobbies; }
        else if (vm.hbClick == 1) { hbs = vm.activehbIds; }
        else if (vm.hbClick == 2) { hbs = vm.hbsLst; }

        var pts = "";
        if (!vm.ptClick) { pts = PInfo.pt; }
        else if (vm.ptClick == 1) { pts = vm.activetrIds }

        var langs = ""; var famlyLangs = "";
        if (!vm.langClick) { langs = PInfo.lang; famlyLangs = PInfo.familyLangs; }
        else if (vm.langClick == 1) { langs = vm.checkedPrefLangIds; famlyLangs = vm.checkedFmlyLangIds; }

        vm.prfPercentage = prfCmpltn(PInfo.firstName, JSON.stringify(PInfo.gender), PInfo.dob, PInfo.cityId, vm.etnctyId, vm.rglnId, vm.aOfWrkId, vm.stsId, vm.dgrId, vm.cntryId,
                    PInfo.htCity, vm.myBioData, vm.eyeId, vm.hairId, vm.bldId, vm.htId, vm.ditId, vm.smkId, vm.drnkId, vm.irltnshp, vm.chldrnCntId, vm.chldrnPrefId, vm.ptsCntId,
                    vm.ptsPrefId, langs, famlyLangs, vm.rlgsId, vm.trdtnlId, pts, hbs);

        //Updating trophy
        trophiesLoad(Trophiesresult);

        //showing this popup when profile percent reached 100% (not showing control loading)
        if (vm.trphVal == true) {
            if (getSessionSrvc.p_pprntg() == 100) { $("#trophyPopProfileE").modal("hide"); }
            else if (vm.prfPercentage == 100) {
                vm.trophyPopProfileEmpty = false;
                vm.trophyPopProfile = true;
                $("#trophyPopProfileE").modal("show");
            }
        }
        else { vm.trphVal = true; }

        //Updating profile % in member login cookie
        getSessionSrvc.u_ssnd("profileCmplnPrcnt", vm.prfPercentage);

    }
    //Page load services Called End    

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  ABOUT ME BLOCK STARTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    vm.abtRmode = true;
    vm.abtAEmode = false;

    vm.abtMeAE = function () {
        disblAllClikevnts();
        vm.abtMeCls = brdrBlueCls; vm.abtRmode = false; vm.abtAEmode = true; vm.LoadAbtMeDdls();
        scrollDragable("dvAbtMeAE1");

        $timeout(function () {
            countryIntlSrv.BindIntelligence();
            if (vm.profileInfo.htCountry != null && vm.profileInfo.htCity != null)
                countryIntlSrv.BindCity('txtPrflCurrLocCity', 'dvPrflCountry', vm.profileInfo.htCountry, vm.profileInfo.htCity);
            vm.cntryId = vm.profileInfo.htCountry;
            vm.htCityId = vm.profileInfo.htCity;
            vm.htStateId = vm.profileInfo.stateId;

        }, 100);
    }
    vm.abtMeCancel = function () {
        vm.scrollLock = false;
        EnableAllClickEvents();
        delete vm.abtMeCls; vm.abtRmode = true; vm.abtAEmode = false;
    }

    vm.LoadAbtMeDdls = function () {
        // about me dropdowns service called
        selfprofileSrvc.StaticDropDownList(function (response, status) {
            vm.ethnicitiesDdl = response.Ethnicity;
            vm.religionsDdl = response.Religion;
            vm.areaofworksDdl = response.AreaOfWork;
            vm.statusDdl = response.Status;
            vm.degreeDdl = response.Degree;
            //vm.countriesDdl = response.Countries;
            //vm.statesDdl = response.States;
            //vm.citiesDdl = response.Cities;
        });

    }

    vm.ethnicityIdFunc = function (Id, txt) { vm.etnctyId = Id; vm.etnctyIdTxt = txt; }
    vm.religionIdFunc = function (Id, txt) { vm.rglnId = Id; vm.rglnIdTxt = txt; }
    vm.areaofworkIdFunc = function (Id, txt) { vm.aOfWrkId = Id; vm.aOfWrkIdTxt = txt; }
    vm.statusIdFunc = function (Id, txt) { vm.stsId = Id; vm.stsIdTxt = txt; }
    vm.degreeIdFunc = function (Id, txt) { vm.dgrId = Id; vm.dgrIdTxt = txt; }
    vm.countryIdFunc = function (Id, txt) { vm.cntryId = Id; vm.cntryIdTxt = txt; vm.htCityId = null; }


    vm.abtMeUpdate = function () {
        vm.scrollLock = false;
        EnableAllClickEvents();
        pcShowLoader("dvAbtMeAE");
        //about me update service called      
        getPrfCmpltn();

        if (!vm.cntryId && !vm.htCityId) { vm.cntryId = vm.htCityId = null; }
        else if (vm.cntryId) {
            if (!vm.htCityId) { hideLoader(); return false; }
            else if (($("#txtPrflCurrLocCity").val() == "Invalid City name")) { hideLoader(); return false; }
        }

        selfprofileSrvc.aboutmeUpdate(vm.mId(), vm.etnctyId, vm.rglnId, vm.aOfWrkId, vm.stsId, vm.dgrId, vm.cntryId, vm.htStateId, vm.htCityId, vm.prfPercentage, function (response, status) {
            if (status == 200 && response == true) {

                vm.profileInfo.ethinicityId = vm.etnctyId;
                vm.profileInfoExt1.ethinicityId = vm.etnctyIdTxt;

                vm.profileInfo.religionId = vm.rglnId;
                vm.profileInfoExt1.religionId = vm.rglnIdTxt;

                vm.profileInfo.awId = vm.aOfWrkId;
                vm.profileInfoExt1.awId = vm.aOfWrkIdTxt;

                vm.profileInfo.rsStatus = vm.stsId;
                vm.profileInfoExt1.rsStatus = vm.stsIdTxt;

                vm.profileInfo.highestEdu = vm.dgrId;
                vm.profileInfoExt1.highestEdu = vm.dgrIdTxt;


                if (vm.profileInfoExt1.htInfo == null) { vm.profileInfoExt1.htInfo = {}; }
                if (vm.cntryId != vm.profileInfo.htCountry) { vm.profileInfoExt1.htInfo.countryName = vm.cntryIdTxt; }

                vm.profileInfo.htCountry = vm.cntryId;
                vm.profileInfo.htCity = vm.htCityId;

                if (!vm.cntryId) { vm.profileInfoExt1.htInfo = null; }
                else {
                    if (getSessionSrvc.p_cntry() == vm.profileInfoExt1.htInfo.countryName)
                        vm.grewUpTxt = "Grew up in " + $("#txtPrflCurrLocCity").val();
                    else
                        vm.grewUpTxt = "Grew up in " + $("#txtPrflCurrLocCity").val() + ", " + vm.profileInfoExt1.htInfo.countryName;
                }
                vm.abtMeCancel();
                hideLoader();
            }
            else {
                $("#ErrAlert").modal("show");
            }
        });
    }
    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  ABOUT ME BLOCK END   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY PERSONALITY BLOCK STARTS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    //vm.myPrsnltyRmode = true;
    vm.myPrsnltyAEmode = false;
    vm.activetrIds = [];

    vm.myPrsnltyAE = function () {
        vm.myPrsnltyAEmode = true;
        selfprofileSrvc.PrsnltyTraitsListG(function (response) {
            if ($("#btnPtEdit").attr("data-mydata") == "N") {
                var result = {};
                var key = 'ptcId';
                for (var i = 0; i < response.length; i++) {
                    if (!result[response[i][key]]) {
                        result[response[i][key]] = [];
                    }
                    result[response[i][key]].push(response[i])
                }
                vm.PrsnltyTraitsList = result;
                $("#btnPtEdit").attr("data-mydata", "Y");
            }
            vm.ptraits = response;
        });

        //Binding Values to checkboxes
        vm.activetrIds = [];
        BindCheckBoxIds(vm.profileInfo.pt, vm.activetrIds);
    }


    vm.prsnltyChkClick = function (ptId, event) {
        GetClickedIds(vm.activetrIds, ptId);
        if (vm.activetrIds.length > 5) {
            GetClickedIds(vm.activetrIds, ptId);
            vm.ptclt = "ptclr";
            $('#dvPTchk').find('input[type=checkbox]:not(:checked)').attr('disabled', true);
            event.preventDefault();
            return false;
        } else {
            vm.ptclt = "";
            $('#dvPTchk').find('input[type=checkbox]:not(:checked)').attr('disabled', false);
        }
    }

    vm.clrForMorednFv = function () {
        vm.ptclt = "";
        $('#dvPTchk').find('input[type=checkbox]:not(:checked)').attr('disabled', false);
        $("#selfPersnlty").modal("hide");
    };

    vm.PrsnltyTrtsIU = function () {
        vm.ptClick = 1;
        getPrfCmpltn();
        if (vm.activetrIds.length <= 5) {
            selfprofileSrvc.PrsnltyTraitsListIU(vm.mId(), vm.activetrIds.join(), vm.prfPercentage, function (response, status) {
                if (status == 200 && response == true) {

                    //Updating view
                    vm.profileInfoExt1.pt = [];
                    vm.activetrIds.forEach(function (val) {
                        var item = {};
                        for (var i = 0; i < vm.ptraits.length; i++) {
                            if (vm.ptraits[i].ptId == val) {
                                item['txt'] = vm.ptraits[i].personalityName;
                                item['img'] = vm.ptraits[i].iconImg;
                            }
                        }
                        vm.profileInfoExt1.pt.push(item);
                    });
                    vm.ptclt = "";
                    $('#dvPTchk').find('input[type=checkbox]:not(:checked)').attr('disabled', false);
                    //updating pt Ids
                    vm.profileInfo.pt = vm.activetrIds.join();
                    vm.ptClick = "";
                }
            });
        }
    }

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY PERSONALITY BLOCK END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY BIO BLOCK STARTS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    vm.myBioAEImg = true;
    vm.hideBioRead = true;

    vm.myBioAE = function () {
        vm.myBioData = vm.profileInfo.abtDesc;
        if (vm.myBioData == null || vm.myBioData == '') {
            vm.myBioPlaceHolder = "How would you describe yourself?";
            delete vm.txtCls;
        }
        else
            vm.myBioPlaceHolder = "";
        disblAllClikevnts();
        vm.bioCls = brdrBlueCls; vm.myBioAEImg = vm.hideBioRead = false; vm.showTxtLenght = vm.biodwn = true;
        scrollDragable("dvMyBioAE1");
    }
    vm.myBioCnl = function () {
        EnableAllClickEvents();
        delete vm.bioCls; vm.myBioAEImg = vm.hideBioRead = true; vm.showTxtLenght = vm.biodwn = false;
        vm.scrollLock = false;
        vm.myBioPlaceHolder = "";
    }

    vm.myBioUpdate = function () {
        vm.scrollLock = false;
        EnableAllClickEvents();
        pcShowLoader("dvMyBioAE");
        getPrfCmpltn();
        // myBio update Service Called        
        if (vm.profileInfo.abtDesc != vm.myBioData) {
            selfprofileSrvc.myBioU(vm.mId(), vm.myBioData, vm.prfPercentage, function (response, status) {
                if (status == 200) { // dont check response true condition because if mybio is empty then this condition failed.
                    vm.profileInfo.abtDesc = vm.myBioData = response;
                    vm.myBioCnl();
                }
                else {
                    $("#ErrAlert").modal("show");
                }
                hideLoader();
            });
        }
        else {
            hideLoader();
            vm.myBioCnl();
        }
    }

    vm.bioChange = function () {
        if (vm.myBioData && vm.myBioData.length > 2000) {
            vm.txtCls = "txtaraPhClr";
            vm.myBioPlaceHolder = "Please ensure that your Bio does not exceed 2000 characters.";
            vm.myBioData = null;
        }
        else {
            delete vm.txtCls;
            vm.myBioPlaceHolder = "How would you describe yourself?";
        }
    }

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY BIO BLOCK END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY TROPHIES BLOCK STARTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    //My Trophies starts 
    vm.trophyPopPPEmpty = false;
    vm.trophyPopPP = false;
    vm.trophyPopMobCode = false;
    vm.trophyPopMob = false;
    vm.codeWrongMsg = false;
    vm.codeID;
    vm.mailSent = true;
    var Trophiesresult = [];

    function trophiesLoad(Trophiesresult) {
        if (Trophiesresult[0] == 1)
            vm.tropEml = 'https://pccdn.pyar.com/pcimgs/trophies/prf-emlverified-cmplte.jpg';
        else
            vm.tropEml = 'https://pccdn.pyar.com/pcimgs/trophies/empty-mail.jpg';
        if (Trophiesresult[1] == 1) {
            vm.tropSoc = 'https://pccdn.pyar.com/pcimgs/trophies/scial-mdia-lnk-cmplte.jpg';
            angular.element(document.querySelector("#imgtropsoc")).removeClass("dvlst");
        }
        else {
            vm.tropSoc = 'https://pccdn.pyar.com/pcimgs/trophies/empty-scllink.jpg';
            angular.element(document.querySelector("#imgtropsoc")).addClass("dvlst");
        }
        if (Trophiesresult[2] == 1) {
            vm.tropPP = 'https://pccdn.pyar.com/pcimgs/trophies/prf-phto-upload-cmplt.jpg';
            angular.element(document.querySelector("#imgtropPP")).removeClass("dvlst");
        }
        else {
            vm.tropPP = 'https://pccdn.pyar.com/pcimgs/trophies/empty-prfl.jpg';
            angular.element(document.querySelector("#imgtropPP")).addClass("dvlst");
        }
        if (Trophiesresult[3] == 1) {
            vm.tropMob = 'https://pccdn.pyar.com/pcimgs/trophies/mbile-vrfied-cmplt.jpg';
            angular.element(document.querySelector("#imgtropMbl")).removeClass("dvlst");
        }
        else {
            vm.tropMob = 'https://pccdn.pyar.com/pcimgs/trophies/empty-mbile.jpg';
            angular.element(document.querySelector("#imgtropMbl")).addClass("dvlst");
        }

        if (vm.prfPercentage == 100) {
            vm.ProfComplete = 'https://pccdn.pyar.com/pcimgs/trophies/Prf-complete.jpg';
            angular.element(document.querySelector("#imgtropComp")).removeClass("dvlst");
            Trophiesresult[4] = 1;
        }
        else {
            vm.ProfComplete = 'https://pccdn.pyar.com/pcimgs/trophies/empty-prfle-cmp.jpg';
            angular.element(document.querySelector("#imgtropComp")).addClass("dvlst");
            Trophiesresult[4] = 0;
        }

    }

    vm.socVerifyPopup = function () {
        if (Trophiesresult[1] == 0)
            $("#trophyPopsocE").modal('show');
    }

    vm.picVerifyPopup = function () {
        if (Trophiesresult[2] == 0) {
            vm.trophyPopPPEmpty = true;
            $("#trophyPopPPE").modal('show');
        }
    }

    vm.mobVerifyPopup = function () {
        vm.phoneNo = "";
        vm.sendCodedsbld = true;
        vm.sendBtnCls = "prmtnbtndsbld";
        if (Trophiesresult[3] == 0) {
            if (vm.trialMem() == 1) vm.mbltrophyText = " Plus, you will unlock your " +vm.trialDays() +" Premium Trial.";
            else vm.mbltrophyText = "";
            vm.vrfphTryPlsHldr = 'Enter mobile number';
            vm.trophyPopMobEnter = true;
            vm.trophyPopMobCode = vm.trophyPopMob = false;
            $("#trophyPopMobE").modal('show');
            selfprofileSrvc.CountryCodeG(vm.profileInfo.countryId, function (response, status) {
                if (response)
                    vm.countrycode = response;
            });

        }
    }
    vm.PComVerifyPopup = function () {
        if (Trophiesresult[4] == 0) {
            vm.trophyPopProfile = false;
            vm.trophyPopProfileEmpty = true;
            $("#trophyPopProfileE").modal('show');
        }
    }

    vm.sendCodedsbld = true;
    vm.vrfphTryPlsHldr = "Enter mobile number";
    vm.sendBtnCls = "prmtnbtndsbld";

    vm.cntryCodeKeyUp = function () {      
        cntryAndNumberVlded();         
    }

        vm.phNoKeyUp = function () {                  
            if (vm.phoneNo) {
                vm.errCls = "";
                vm.vrfphTryPlsHldr = "";
            } else {
                vm.vrfphTryPlsHldr = "Enter Mobile Number";
            }
            cntryAndNumberVlded();        
        }

    // button validation based on country code and phone number
        function cntryAndNumberVlded()
        {
            if (vm.countrycode && vm.phoneNo) {
            if (vm.countrycode == "91" && vm.phoneNo.length == 10) {
                vm.sendCodedsbld = false;
                vm.sendBtnCls = "prmtnbtn curptr";             
            }
            else if (vm.countrycode != "91" && vm.phoneNo.length > 6) {
                vm.sendCodedsbld = false;
                vm.sendBtnCls = "prmtnbtn curptr";
            } else {
                vm.sendCodedsbld = true;
                vm.sendBtnCls = "prmtnbtndsbld";
            }
        } else {
            vm.sendCodedsbld = true;
           vm.sendBtnCls = "prmtnbtndsbld";
    }
}
    
   
    vm.trophyPopMobSendCode = function () {
        pcShowLoader("verifyMble");
        if (vm.mId() && vm.phoneNo && vm.countrycode && vm.countrycode.length <= 3) {          
            selfprofileSrvc.sendOtp(vm.mId(), vm.countrycode, vm.phoneNo, function (response, status) {
                if (status == 200) {
                    if (parseInt(response) == 0) {
                        vm.errCls = "eror";
                        vm.phoneNo = "";
                        vm.vrfphTryPlsHldr = "Number in use";
                        vm.sendCodedsbld = true;
                        vm.sendBtnCls = "prmtnbtndsbld";
                    }
                    else if ((parseInt(response) == -1) || (parseInt(response) == -2)) {
                        vm.errCls = "eror";
                        vm.phoneNo = "";
                        vm.vrfphTryPlsHldr = "Message sending failed";
                        vm.sendCodedsbld = true;
                        vm.sendBtnCls = "prmtnbtndsbld";
                    }
                    else {
                        vm.codeID = response;
                        vm.trophyPopMobEnter = false;
                        vm.trophyPopMobCode = true;
                        vm.codeWrongMsg = false;
                        vm.OtpDigit1 = vm.OtpDigit2 = vm.OtpDigit3 = vm.OtpDigit4 = vm.OtpDigit5 = vm.OtpDigit6 = '';
                        startInterval(vm, $interval);
                    }

                } else {
                    vm.errCls = "eror";
                    vm.phoneNo = "";
                    vm.vrfphTryPlsHldr = "Invalid member info";
                    vm.sendCodedsbld = true;
                    vm.sendBtnCls = "prmtnbtndsbld";
                }
                pcHideLoader();
            });
        }
    }

    function clearMblTrphVrfyTxtEmpty() {
        vm.OtpDigit1 = vm.OtpDigit2 = vm.OtpDigit3 = vm.OtpDigit4 = vm.OtpDigit5 = vm.OtpDigit6 = "";
        vm.OtpDigit1dsbld = vm.OtpDigit2dsbld = vm.OtpDigit3dsbld = vm.OtpDigit4dsbld = vm.OtpDigit5dsbld = vm.OtpDigit6dsbld = false;
    }

    vm.OtpVerify = function () {
        var otpCode = vm.OtpDigit1 + vm.OtpDigit2 + vm.OtpDigit3 + vm.OtpDigit4 + vm.OtpDigit5 + vm.OtpDigit6;
        vm.OtpDigit1dsbld = true; vm.OtpDigit2dsbld = true; vm.OtpDigit3dsbld = true; vm.OtpDigit4dsbld = true; vm.OtpDigit5dsbld = true; vm.OtpDigit6dsbld = true;
        if (otpCode.length == 6) {
            pcShowLoader("resendingOtp");
            selfprofileSrvc.verifyOtp(vm.mId(), vm.codeID, otpCode, function (response, status) {
                pcHideLoader();
                vm.trophyPopMobCode = false;
                if (response) {
                    updateMblVrfySession(response, getSessionSrvc, $rootScope, $window, false);
                    //var sid = "", subDays = "", subStartDay = "", subEndDay = "", trailMember = false, trailType = "";
                    //angular.forEach(response, function (key, value) {
                    //    var values = Object.values(key);
                    //    if (values[0] == "sId")
                    //        sid = values[1];
                    //    else if (values[0] == "subscribeDays")
                    //        subDays = values[1];
                    //    else if (values[0] == "subscribeStrtDT")
                    //        subStartDay = values[1];
                    //    else if (values[0] == "subscribeExprDT")
                    //        subEndDay = values[1];
                    //    else if (values[0] == "trailMember")
                    //        trailMember = values[1];
                    //    else if (values[0] == "trailType")
                    //        trailType = values[1];
                    //});
                    //getSessionSrvc.u_ssnd("sId", sid);
                    //getSessionSrvc.u_ssnd("dateTimeSubscrbSt", subStartDay);
                    //getSessionSrvc.u_ssnd("dateTimeSubscrbExp", subEndDay);
                    //getSessionSrvc.u_ssnd("trailMember", trailMember);

                    vm.trophyPopMob = true;
                    if (vm.trialMem() == 2) vm.prmUnlckTrphy = true; // hide the indictors of mobile trophy verification if user is premium member or expired
                    else vm.prmUnlckTrphy = false;
                    Trophiesresult[3] = 1;
                    trophiesLoad(Trophiesresult);
                }
                else {
                    vm.trophyPopMobCode = true;
                    vm.codeWrongMsg = true;
                    clearMblTrphVrfyTxtEmpty();
                };
            });
        }
    }
    vm.mbleEntPg = function () {
        vm.trophyPopMobCode = false;
        vm.codeWrongMsg = false;
        vm.trophyPopMobEnter = true;
        clearMblTrphVrfyTxtEmpty();
    }
    //otp code enter textboxes keyup events
    vm.OtpDigit1keyup = function () {
        vm.codeWrongMsg = false;
        if (vm.OtpDigit1) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.OtpVerify();
            } else {
                $("#otpDigit2").focus();
            }
        }
    }
    vm.OtpDigit2keyup = function () {
        vm.codeWrongMsg = false;
        if (vm.OtpDigit2) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.OtpVerify();
            } else
                $("#otpDigit3").focus();
        }
    }
    vm.OtpDigit3keyup = function () {
        vm.codeWrongMsg = false;
        if (vm.OtpDigit3) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.OtpVerify();
            } else
                $("#otpDigit4").focus();
        }
    }
    vm.OtpDigit4keyup = function () {
        vm.codeWrongMsg = false;
        if (vm.OtpDigit4) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.OtpVerify();
            } else
                $("#otpDigit5").focus();
        }
    }
    vm.OtpDigit5keyup = function () {
        vm.codeWrongMsg = false;
        if (vm.OtpDigit5) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.OtpVerify();
            } else
                $("#otpDigit6").focus();
        }
    }
    vm.OtpDigit6keyup = function () {
        vm.codeWrongMsg = false;
        if (vm.OtpDigit6) {
            if (vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
                vm.OtpVerify();
                $("#otpDigit6").blur();
            }
            else if (!vm.OtpDigit1)
                $("#otpDigit1").focus();
            else if (!vm.OtpDigit2)
                $("#otpDigit2").focus();
            else if (!vm.OtpDigit3)
                $("#otpDigit3").focus();
            else if (!vm.OtpDigit4)
                $("#otpDigit4").focus();
            else if (!vm.OtpDigit5)
                $("#otpDigit5").focus();
        }
    }

    vm.resendOtp = function () {
        startInterval(vm, $interval);
        vm.trophyPopMobCode = true;
        clearMblTrphVrfyTxtEmpty();
        if (vm.mId() && vm.phoneNo && vm.countrycode && vm.countrycode.length <= 3) {          
            selfprofileSrvc.resendOtp(vm.mId(), vm.countrycode, vm.phoneNo, function (response, status) {
                if (response) {
                    vm.codeID = response;
                    clearMblTrphVrfyTxtEmpty();
                    vm.trophyPopMobCode = true;
                }
            });
        }
    }


    //common close function for all success trophies
    vm.trophyPopClose = function (type) {
        if (type == 'PopSocCls') {
            $("#trophyPopsocE").modal('hide');
            Trophiesresult[1] = 1;
            trophiesLoad(Trophiesresult);
        }
        else if (type == 'PopPPCls') {
            $("#trophyPopPPE").modal('hide');
            //$("#trophyPopPPE").modal('hide');
            Trophiesresult[2] = 1;
            trophiesLoad(Trophiesresult);
        }
        else if (type == 'PopMobCls') {
            $("#trophyPopMobE").modal('hide');
        }
        else if (type == 'PopProfileCls') {
            $("#trophyPopProfileE").modal("hide");
            Trophiesresult[4] = 1;
            trophiesLoad(Trophiesresult);
        }
    }
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY TROPHIES BLOCK END   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY APPEARANCE BLOCK STARTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    vm.myAprnceRmode = true;
    vm.myAprnceAEmode = false;

    vm.myAprnceCancel = function () {
        vm.scrollLock = false;
        EnableAllClickEvents();
        delete vm.myAprnceCls; vm.myAprnceRmode = true; vm.myAprnceAEmode = false;
    }
    vm.myAprnceAE = function () {
        disblAllClikevnts();
        vm.myAprnceCls = brdrBlueCls; vm.myAprnceRmode = false; vm.myAprnceAEmode = true; vm.myAprnceDdls();
        scrollDragable("dvMyAprnceAE");
    }

    vm.myAprnceDdls = function () {
        //My appearance ddls service called starts
        selfprofileSrvc.ddlsMyAppearence(function (response, status) {
            vm.build = response.build;
            vm.height = response.height;
            vm.eyecolor = response.eyecolor;
            vm.haircolor = response.haircolor;
        });
    }

    vm.eyecolorIdFunc = function (val, txt) {
        vm.eyeId = val; vm.eyeIdTxt = txt;
    }
    vm.haircolorIdFunc = function (val, txt) {
        vm.hairId = val; vm.hairIdTxt = txt;
    }
    vm.buildIdFunc = function (val, txt) {
        vm.bldId = val; vm.bldIdTxt = txt;
    }
    vm.heightIdFunc = function (val, txt) {
        vm.htId = val; vm.htIdTxt = txt;
    }

    vm.myAprnceUpdate = function () {
        vm.scrollLock = false;
        EnableAllClickEvents();
        pcShowLoader("dvMyAprnceAE");
        getPrfCmpltn();

        // My appearance update Service Called
        selfprofileSrvc.myAppearenceU(vm.mId(), vm.eyeId, vm.hairId, vm.bldId, vm.htId, vm.prfPercentage, function (response, status) {
            vm.profileInfo.eyeColor = vm.eyeId;
            vm.profileInfoExt2.eyeColor = vm.eyeIdTxt;

            vm.profileInfo.hairColor = vm.hairId;
            vm.profileInfoExt2.hairColor = vm.hairIdTxt;

            vm.profileInfo.build = vm.bldId;
            vm.profileInfoExt2.build = vm.bldIdTxt;

            vm.profileInfo.height = vm.htId;
            vm.profileInfoExt2.height = vm.htIdTxt;

            vm.myAprnceCancel();
            pcHideLoader();
        });
    }

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY APPEARANCE BLOCK END   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY LIFESTYLE BLOCK STARTS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    vm.myLifeStyleRmode = true;
    vm.myLifeStyleAEmode = false;

    vm.myLifeCancel = function () {
        vm.scrollLock = false;
        EnableAllClickEvents();
        delete vm.myLifeStyleCls; vm.myLifeStyleRmode = true; vm.myLifeStyleAEmode = false;
    }
    vm.myLifeStyleAE = function () {
        disblAllClikevnts();
        vm.myLifeStyleCls = brdrBlueCls; vm.myLifeStyleRmode = false; vm.myLifeStyleAEmode = true; vm.myLifeStyleDdls();
        scrollDragable("dvMyLfyStlAE1");
    }

    vm.myLifeStyleDdls = function () {
        //my life style ddls service called
        selfprofileSrvc.ddlsMyLifeStyleDDlData(function (response, status) {
            vm.dietDdl = response.diet;
            vm.smokeDdl = response.smoke;
            vm.drinkDdl = response.drink;
            vm.idealRelationshipDdl = response.IdealRelationShip;
            vm.childrenCntDdl = response.numOfChildren;
            vm.childrenPrefDdl = response.childrenPref;
            vm.petsCntDdl = response.numOfPets;
            vm.petsPrefDdl = response.petPref;
            vm.langPrefDdl = response.language;
            vm.familyLangDdl = response.language;
            vm.religiousDdl = response.Religious;
            vm.traditionalDdl = response.traditional;


            //Binding Values to Languages dropdown
            vm.checkedPrefLangIds = [];
            BindCheckBoxIds(vm.profileInfo.lang, vm.checkedPrefLangIds);

            //Get checked Langauges Text
            vm.checkedPrefLangName = [];
            angular.forEach(vm.langPrefDdl, function (data) {
                if (vm.checkedPrefLangIds.indexOf(data.val) !== -1)
                    vm.checkedPrefLangName.push(" " + data.txt);
            });

            //Binding Values to Family Languages dropdown
            vm.checkedFmlyLangIds = [];
            BindCheckBoxIds(vm.profileInfo.familyLangs, vm.checkedFmlyLangIds);

            //Get checked Familly Langauges Text
            vm.checkedFmlyLangName = [];
            angular.forEach(vm.familyLangDdl, function (data) {
                if (vm.checkedFmlyLangIds.indexOf(data.val) !== -1)
                    vm.checkedFmlyLangName.push(" " + data.txt);
            });
        });
    }


    //Prefered langauges    
    vm.checkedPrefLangIds = [];
    vm.checkedPrefLangName = [];

    //displaying array in html view
    vm.PrefLangIdTostring = function () {
        return vm.checkedPrefLangName.join(", ");
    };

    //for getting selected checkboxes Ids on checkbox click event
    vm.PrefLangIdFuncG = function (langId, event) {

        if (vm.checkedPrefLangIds.length <= 29)
            GetIdWithName(vm.langPrefDdl, vm.checkedPrefLangIds, vm.checkedPrefLangName, langId);
        else if (vm.checkedPrefLangIds.length == 30 && (vm.checkedPrefLangIds.indexOf(langId) != -1))
            GetIdWithName(vm.langPrefDdl, vm.checkedPrefLangIds, vm.checkedPrefLangName, langId);

        if (vm.checkedPrefLangIds.length == 30 && (vm.checkedPrefLangIds.indexOf(langId) == -1)) {
            $('#dvPrefLangLstdopn').find('input[type=checkbox]:not(:checked)').attr('disabled', true);
            event.preventDefault();
            return false;
        }
        else {
            $('#dvPrefLangLstdopn').find('input[type=checkbox]:not(:checked)').attr('disabled', false);
        }
    }

    vm.noPrefLangPref = function () {
        vm.checkedPrefLangIds = [];
        vm.checkedPrefLangName = [];
        vm.PrefLangIdTostring();
    }

    //family Langauges    
    vm.checkedFmlyLangIds = [];
    vm.checkedFmlyLangName = [];

    //displaying array in html view
    vm.FmlyLangIdTostring = function () {
        return vm.checkedFmlyLangName.join(", ");
    };

    //for getting selected checkboxes Ids on checkbox click event
    vm.FmlyLangIdFuncG = function (langId, event) {

        if (vm.checkedFmlyLangIds.length <= 29)
            GetIdWithName(vm.familyLangDdl, vm.checkedFmlyLangIds, vm.checkedFmlyLangName, langId);
        else if (vm.checkedFmlyLangIds.length == 30 && (vm.checkedFmlyLangIds.indexOf(langId) != -1))
            GetIdWithName(vm.familyLangDdl, vm.checkedFmlyLangIds, vm.checkedFmlyLangName, langId);

        if (vm.checkedFmlyLangIds.length == 30 && (vm.checkedFmlyLangIds.indexOf(langId) == -1)) {
            $('#dvFmlyLangLstdopn').find('input[type=checkbox]:not(:checked)').attr('disabled', true);
            event.preventDefault();
            return false;
        }
        else {
            $('#dvFmlyLangLstdopn').find('input[type=checkbox]:not(:checked)').attr('disabled', false);
        }
    }

    vm.noFmlyLangPref = function () {
        vm.checkedFmlyLangIds = [];
        vm.checkedFmlyLangName = [];
        vm.FmlyLangIdTostring();
    }

    vm.dietIdFunc = function (val, txt) {
        vm.ditId = val; vm.ditIdTxt = txt;
    }
    vm.smokeIdFunc = function (val, txt) {
        vm.smkId = val; vm.smkIdTxt = txt;
    }
    vm.drinkIdFunc = function (val, txt) {
        vm.drnkId = val; vm.drnkIdTxt = txt;
    }
    vm.idealRelationshipIdFunc = function (val, txt) {
        vm.irltnshp = val; vm.irltnshpTxt = txt;
    }
    vm.childrenCntIdFunc = function (val, txt) {
        vm.chldrnCntId = val; vm.chldrnCntIdTxt = txt;
    }
    vm.childrenPrefIdFunc = function (val, txt) {
        vm.chldrnPrefId = val; vm.chldrnPrefIdTxt = txt;
    }
    vm.petsCntIdFunc = function (val, txt) {
        vm.ptsCntId = val; vm.ptsCntIdTxt = txt;
    }
    vm.petsPrefIdFunc = function (val, txt) {
        vm.ptsPrefId = val; vm.ptsPrefIdTxt = txt;
    }
    vm.religiousIdFunc = function (val, txt) {
        vm.rlgsId = val; vm.rlgsIdTxt = txt;
    }
    vm.traditionalIdFunc = function (val, txt) {
        vm.trdtnlId = val; vm.trdtnlIdTxt = txt;
    }

    vm.myLifeUpdate = function () {
        vm.scrollLock = false;
        EnableAllClickEvents();
        pcShowLoader("dvMyLfyStlAE");

        vm.langClick = 1;

        getPrfCmpltn();

        // my life style update Service Called
        selfprofileSrvc.myLifeStyleU(vm.mId(), vm.ditId, vm.smkId, vm.drnkId, vm.irltnshp, vm.chldrnCntId, vm.chldrnPrefId, vm.ptsCntId, vm.ptsPrefId, vm.checkedPrefLangIds.join(), vm.checkedFmlyLangIds.join(), vm.rlgsId, vm.trdtnlId, vm.prfPercentage, function (response, status) {
            if (status == 200) {
                vm.profileInfo.diet = vm.ditId;
                vm.profileInfoExt2.diet = vm.ditIdTxt;

                vm.profileInfo.smoke = vm.smkId;
                vm.profileInfoExt2.smoke = vm.smkIdTxt;

                vm.profileInfo.drink = vm.drnkId;
                vm.profileInfoExt2.drink = vm.drnkIdTxt;

                vm.profileInfo.idealRelationship = vm.irltnshp;
                vm.profileInfoExt2.idealRelationship = vm.irltnshpTxt.toLowerCase();

                vm.profileInfo.childrenCnt = vm.chldrnCntId;
                vm.chldCntLst = $filter('childCountFltr')(vm.chldrnCntIdTxt, "OP");
                vm.profileInfoExt2.childrenCnt = vm.chldrnCntIdTxt;

                vm.profileInfo.childrenPref = vm.chldrnPrefId;
                vm.chldPref = $filter('childPrefFltr')(vm.chldrnPrefIdTxt, "OP");
                vm.profileInfoExt2.childrenPref = vm.chldrnPrefIdTxt;

                vm.profileInfo.petsCnt = vm.ptsCntId;
                vm.ptsCntLst = $filter('petCountFltr')(vm.ptsCntIdTxt, "OP");
                vm.profileInfoExt2.petsCnt = vm.ptsCntIdTxt;

                vm.profileInfo.petsPref = vm.ptsPrefId;
                vm.ptsPref = $filter('petsPrefFltr')(vm.ptsPrefIdTxt, "OP");
                vm.profileInfoExt2.petsPref = vm.ptsPrefIdTxt;

                vm.profileInfo.lang = vm.checkedPrefLangIds;
                vm.PrefLangs = vm.PrefLangIdTostring();

                vm.profileInfo.familyLangs = vm.checkedFmlyLangIds;
                vm.FamlyLangs = vm.FmlyLangIdTostring();

                vm.profileInfo.religious = vm.rlgsId;
                vm.profileInfoExt2.religious = vm.rlgsIdTxt;

                vm.profileInfo.traditional = vm.trdtnlId;
                vm.profileInfoExt2.traditional = vm.trdtnlIdTxt;

                vm.langClick = "";
                vm.myLifeCancel();
                hideLoader();
            }
        });
    }

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY LIFESTYLE BLOCK END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY HOBBIES BLOCK STARTS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    vm.activehbIds = [];
    vm.showhbPop = false;
    //default save hooby button in disabled mode
    vm.btnHbyValid = true;
    vm.btnHbyValidCls = "prbtn btndsbldbg";

    vm.hbList = function () {
        vm.showhbPop = true;
        //myHobbies List Services calling started
        selfprofileSrvc.HobbiesList(function (response) {
            if ($("#btnAddHobby").attr("data-mydata") == "N") {
                var result = {
                };
                var key = 'categoryName';
                for (var i = 0; i < response.length; i++) {
                    if (!result[response[i][key]]) {
                        result[response[i][key]] = [];
                    }
                    result[response[i][key]].push(response[i]);
                }
                // finding key length from Json Object
                var keyLength = Object.keys(result).length;
                var totalLength = response.length;
                var lengthByArray = totalLength / keyLength;

                vm.hbTblL1 = Math.round(lengthByArray / 2);
                vm.hbTblL2 = (lengthByArray) - vm.hbTblL1;
                vm.hobbylst = response;
                vm.lstHobbies = result;
                $("#btnAddHobby").attr("data-mydata", "Y");
            }
        });

        //Binding Values to hobbies checkboxes
        vm.activehbIds = [];
        BindCheckBoxIds(vm.profileInfo.hobbies, vm.activehbIds);
        DisableMultiChkBtn("Hobbies");
    }

    vm.hobbyChkClick = function (hbId) {
        GetClickedIds(vm.activehbIds, hbId);
        DisableMultiChkBtn("Hobbies");
    }

    function DisableMultiChkBtn(dsblType) {
        if (dsblType == "Hobbies") {
            if ((vm.profileInfoExt2.hobbies && vm.profileInfoExt2.hobbies.length) || vm.activehbIds.length > 0) {
                vm.btnHbyValid = false;
                vm.btnHbyValidCls = "prbtn";
            } else {
                vm.btnHbyValid = true;
                vm.btnHbyValidCls = "prbtn btndsbldbg";
            }
        }
    }

    vm.saveHobbies = function () {
        if (!angular.equals(vm.profileInfo.hobbies, vm.activehbIds.join())) {
            vm.hbClick = 1;
            getPrfCmpltn();
            selfprofileSrvc.HobbiesInsert(vm.mId(), vm.activehbIds.sort().join(), vm.prfPercentage, function (response, status) {
                if (status == 200 && response == true) {

                    vm.profileInfoExt2.hobbies = [];

                    vm.activehbIds.forEach(function (val) {
                        var item = {
                        };
                        item['refId'] = val;
                        item['txt'] = getHobbyTxt(val);
                        item['status'] = true;
                        vm.profileInfoExt2.hobbies.push(item);
                    });

                    function getHobbyTxt(val) {
                        var hbyTxt = '';
                        vm.hobbylst.forEach(function (data) {
                            if (data.HobbyId == val) {
                                hbyTxt = data.HobbyName;
                            }
                        });
                        return hbyTxt;
                    }
                    //updating hobby Ids
                    vm.profileInfo.hobbies = vm.activehbIds.join();
                    vm.hbClick = "";
                }
            });
        }
    }
    vm.hbsLst = "";
    vm.hbyDel = function (hobbyId) {
        vm.hbClick = 2;
        if (hobbyId) {
            vm.hbsLst = JSON.parse("[" + vm.profileInfo.hobbies + "]");
            var index = vm.hbsLst.indexOf(hobbyId);
            if (index !== -1) {
                vm.hbsLst.splice(index, 1);
            }

            //updating hobbies list
            getPrfCmpltn();
            selfprofileSrvc.HobbiesInsert(vm.mId(), vm.hbsLst.sort().join(), vm.prfPercentage, function (response, status) {
                if (status == 200 && response == true) {
                    for (var i = 0; i < vm.profileInfoExt2.hobbies.length; i++) {
                        if (vm.profileInfoExt2.hobbies[i].refId == hobbyId) {
                            angular.forEach(vm.profileInfoExt2.hobbies, function (data) {
                                if (data.refId == hobbyId) {
                                    var indx = vm.profileInfoExt2.hobbies.indexOf(data);
                                    vm.profileInfoExt2.hobbies.splice(indx, 1);
                                }
                            });
                        }
                    }
                    vm.profileInfo.hobbies = vm.hbsLst.sort().join();
                    vm.hbClick = "";
                }
            });
        }
    }
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY HOBBIES BLOCK END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    vm.trialMem = function () { return getSessionSrvc.p_subtm() };
    function profileRightPnl(callback) {
        cmnSrvc.getMSSP(vm.mId(), function (response, status) {
            if (status == 200) {
                cmnSrvc.sessionUpdate(response);
                callback(response)
            }
        })
    }


    profileRightPnl(function(subplansRes){
        // Members view plan div starts premMember
        if (vm.premMember() == 1) {
            //vm.sbscptnImg = "https://pccdn.pyar.com/pcimgs/pcs/basic.png";
            //vm.sbscptnHdng = "Unlock Premium features!";
            //vm.sbscptnTxt = "Verify your mobile number to unlock the full Pyar experience.";
            //vm.goPrmBtnVsbl = true;
            //vm.sbscptnBtnTxt = "UNLOCK PREMIUM";
            vm.sbscptnImg = "https://pccdn.pyar.com/pcimgs/pcs/basic.png";
            vm.sbscptnHdng = "Don’t Be Basic!";
            vm.sbscptnTxt = "Upgrade to Premium Today! Just " + subplansRes.currencySymbol + "" + subplansRes.price + " per month!";
            vm.goPrmBtnVsbl = true;
            vm.sbscptnBtnTxt = "Go Premium";
            //;
        }
        else if (vm.premMember() == 2) {
            vm.startDate = cmnSrvc.getDate(zone(), subplansRes.dateTimeSubscrbSt, "profile");
            vm.renewDate = cmnSrvc.getDate(zone(), subplansRes.dateTimeSubscrbRenew, "profile");
            var expDate = cmnSrvc.getDate(zone(), subplansRes.dateTimeSubscrbExp, "profile");
            vm.sbscptnImg = "https://pccdn.pyar.com/pcimgs/pcs/premium.png";

            if (vm.trialMem() == 2) {
                vm.sbscptnHdng = "Enjoying your free trial?";
                vm.sbscptnTxt = "Trial Began: " + vm.startDate + "<br>Trial Expires: " + expDate + "";
                vm.goPrmBtnVsbl = true;
                vm.sbscptnBtnTxt = "Go Premium";
            } else {
                vm.sbscptnHdng = "Thank you for being a Premium member!";

                if (subplansRes.recurringPay) {
                    vm.sbscptnTxt = "Premium Began: " + vm.startDate + "<br> Premium Renews: " + vm.renewDate + "";
                    //vm.sbscptnBtnTxt = "";
                } else {
                    vm.sbscptnTxt = "Premium Began: " + vm.startDate + "<br> Premium Expires: " + expDate + "";
                }

                //vm.sbscptnBtnTxt = "Extend Plan";
                // vm.sbscptnTxt = "You can now access all the features on Pyar.";
                //vm.goPrmBtnVsbl = false;
                vm.goPrmBtnVsbl = true;
            };
        }
    })


    vm.premiumClk = function () {
        if (vm.sbscptnBtnTxt == "CANCEL PLAN" || vm.sbscptnBtnTxt == ("" || null || undefined)) {
            $state.go("account", { 'tb': 'mship' });
        } else $state.go("payment");
        //showMobileVerificationPop();
    }
    // Members view plan div End

    vm.btnBackAddTagLine = function () {
        //$("#addingTagLIne").modal('hide');
        //$("#srcAdjustProfilePhotoPopup").modal('show');
        $("#addingTagLIne").modal('hide');
    }

    //city intelligence module
    $scope.$on("countryBind", function (e, txtId, countryId, data) {
        vm.cntryId = data.countryId;
        vm.htStateId = data.stateId;
        vm.htCityId = data.cityId;
    });

    $scope.$on("countryUnBind", function (e, txtId, countryId) {
    });

    $rootScope.$on("bindCountry", function (e, countries) {
        vm.countries = countries;
    });

    vm.setCountry = function (txtId, dvId, countryId) {
        //$("#txtPrflCurrLocCity").prop('disabled', false);
        countryIntlSrv.SetCountry(txtId, dvId, countryId);
    }
    vm.setDefaultCntry = function () {
        $("#txtPrflCurrLocCity").val('');
        $("#txtPrflCurrLocCity").prop('disabled', true);
    }

    countryIntlSrv.initSrvc();
    //city intelligence module

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PROFILE TAGLINE SECTION STARTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    // profile tagLine section 
    vm.GotoTagLine = function () {
        CroppedImageResult(1600, 400, function (imgtnBlog) {
            vm.tagLIneImg = imgtnBlog;
            //$("#srcAdjustProfilePhotoPopup").modal('hide');
            $("#addingTagLIne").modal('show');
            if (!vm.TagLineStyles) {
                $timeout(function () {
                    vm.TagLineMoveTop = document.getElementById("bnrImage").offsetTop + (document.getElementById("bnrImage").offsetHeight / 2);
                }, 300);
            }
            else {
                vm.TagLineMoveTop = vm.TagLineStyles.split("$##$")[2];
                vm.SelectedTagLineFont = vm.TagLineStyles.split("$##$")[1];
                vm.TagLineBackGroundColorClick(vm.SelectedTagLineFont);
                $timeout(function () {
                    if (!vm.txtAreaTotalHeight) {
                        var txt = $('#tagLine');
                        txt.height(1);
                        vm.txtAreaTotalHeight = txt.prop('scrollHeight') - parseInt(txt.css('padding-top')) - parseInt(txt.css('padding-bottom')) + 4;
                    }
                }, 300);
            }
        });
    }

    vm.sliderTagLineUpdate = vm.sliderTagLine;
    //for deafult tagline position
    if (!vm.TagLineStyles) {
        vm.TagLineStyles = "16$##$2$##$280.5$##$#fff";
    }

    vm.TagLineBackGroundColorClick = function (val) {
        vm.SelectedTagLineFont = val;
        if (val == 1) {
            vm.TagLineTextColor = "#000";
            vm.TagLineTextBackGroundColor = "rgba(255,255,255,0.5)";
            vm.TagLineColorImg = 'https://pccdn.pyar.com/pcimgs/tagline/Unselected white text.png';
            vm.TagLineBackGroundImg = 'https://pccdn.pyar.com/pcimgs/tagline/Selected black text.png';
        }
        else if (val == 2) {
            vm.TagLineTextColor = "#fff";
            vm.TagLineTextBackGroundColor = "rgba(0,0,0,0.5)";
            vm.TagLineColorImg = 'https://pccdn.pyar.com/pcimgs/tagline/Selected white text.png';
            vm.TagLineBackGroundImg = 'https://pccdn.pyar.com/pcimgs/tagline/Unselected black text.png';
        }
    }
    //TagLine Saving Service
    vm.TagLineDone = function () {
        if (vm.SelectedTagLineFont == 1) { vm.tgLineFontColor = "#000"; } else if (vm.SelectedTagLineFont == 2) { vm.tgLineFontColor = "#fff"; }
        if (!vm.sliderTagLine) { vm.sliderTagLine = 16 };
        if (!vm.SelectedTagLineFont) { vm.SelectedTagLineFont = 2 };
        if (!vm.tgLineFontColor) { vm.tgLineFontColor = "#fff" };
        if (vm.profileInfo.profileBnrStyles) { var fontSelection = vm.profileInfo.profileBnrStyles.split("$##$")[1]; }
        vm.TagLineStyles = (vm.sliderTagLine + "$##$" + vm.SelectedTagLineFont + "$##$" + Math.round($("#TagLineMove").position().top) + "$##$" + vm.tgLineFontColor);

        if (vm.profileInfo.profileBnrTxt != vm.tagLine || vm.profileInfo.profileBnrStyles != vm.TagLineStyles || fontSelection != vm.SelectedTagLineFont) {
            selfprofileSrvc.AddTagLine(vm.mId(), vm.tagLine, vm.TagLineStyles, function (response, status) {
                if (status == 200 && response == true) {
                    vm.profileInfo.profileBnrTxt = vm.tagLine;
                    vm.sliderTagLineUpdate = vm.sliderTagLine;
                    vm.tgLineFontColorUpdate = vm.tgLineFontColor;
                    vm.profileInfo.profileBnrStyles = vm.TagLineStyles;
                    vm.TagLineViewTop = (vm.TagLineStyles.split("$##$")[2]) - 150;
                    vm.tagLine ? vm.btnAddTagLineTxt = "EDIT TAGLINE" : vm.btnAddTagLineTxt = "ADD TAGLINE";
                }
            });
        }
    }

    vm.sliderTagLineChange = function () {
        var txt = $('#tagLine');
        txt.height(1);
        vm.txtAreaTotalHeight = txt.prop('scrollHeight') - parseInt(txt.css('padding-top')) - parseInt(txt.css('padding-bottom')) + 4;
    }

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PROFILE TAGLINE SECTION END   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/



    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  GALLERY , PROFILE , BANNER PHOTO MODULE   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    /**************************************************************VARIABLE DECALRATION START**************************************************************/
    vm.PhotoIndex = "";
    vm.glryThumbnails = [];
    vm.mpuId = "";
    //UPLDPHOTOTYPE 1 FOR GALLERY PHOTO 2 FOR PROFILE PHOTO 3 FOR BANNER PHOTO
    vm.upldPhotoType = "";
    //MAX AND MIN IMAGE DIMENSIONS
    vm.maxWidth = 1920;
    vm.maxHeight = 1920;
    vm.minWidth = 400;
    vm.minHeight = 400;
    vm.imgwidth = 0;
    vm.imgHeight = 0;
    vm.photoPath = '';
    vm.imageStorage = "https://ngagrpincblobstrdev.blob.core.windows.net";
    vm.imageCDN = "https://pccdn.pyar.com";
    vm.profileResponse = [];
    vm.bannerResponse = [];
    vm.actionType = 1; //1 adding new image 2 for updating the existing image 
    vm.dvPyarpics = false; //for showing pyar photos in  banner pic upload only
    vm.dsbldCrpBtn = true;
    vm.dsbldCrpBtnCls = "";
    var croppie;
    /**************************************************************VARIABLE DECALRATION END **************************************************************/

    /**************************************************************FILE UPLOAD FOR GALLERY,PROFILE AND BANNER IMAGES **************************************************************/
    $("#fupPhtGlry").click(function () {
        $("#fupPhtGlry").val(null);
    });
    $scope.imageUpload = function (event) {
        var files = event.target.files;
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var reader = new FileReader();
            //var upldSuccess = false;
            reader.onload = function (e) {
                $("<img/>").load(function () {
                    vm.imgRealWidth = this.width;
                    vm.imgRealHeight = this.height;
                    $("#errSmlImg").attr("style", "display:none");
                    if ((vm.upldPhotoType != 3) && (vm.imgRealWidth < vm.minWidth || vm.imgRealHeight < vm.minHeight)) {
                        $("#errSmlImg").attr('style', 'display:block;text-align:center;font-size:14px;color:red;color:red;padding-top:15px');
                    }
                    else {
                        $('#cropImg').croppie('destroy');
                        vm.imgHeight = vm.imgRealHeight;
                        vm.imgwidth = vm.imgRealWidth;

                        if (vm.imgRealWidth > vm.imgRealHeight) {
                            if (vm.imgRealWidth > vm.maxWidth) {
                                vm.imgHeight = vm.imgRealHeight * (vm.maxWidth / vm.imgRealWidth);
                                vm.imgwidth = vm.maxWidth;
                            }
                        } else {
                            if (vm.imgRealHeight > vm.maxHeight) {
                                vm.imgwidth = vm.imgRealWidth * (vm.maxHeight / vm.imgRealHeight);
                                vm.imgHeight = vm.maxHeight;
                            }
                        }
                        //if browser type is an ios device the below code get executed
                        if (getBrowserType() == true) {
                            var options = {
                                canvas: true
                            };
                            vm.imgDataExifProp = false;
                            loadImage.parseMetaData(file, function (data) {
                                if (data.exif) {
                                    vm.imgDataExifProp = true;
                                    options.orientation = data.exif.get('Orientation');
                                    loadImage(file, getOrientImageResponse, options);
                                } else {
                                    vm.uploadImageFromLocalPC(e.target.result);
                                }
                            });
                        } else {
                            vm.uploadImageFromLocalPC(e.target.result);
                        }
                    }
                    //reset the file upload control for uploading same file on onchange event 
                    angular.element("input[type='file']").val(null);
                }).attr("src", e.target.result);
            }
            reader.readAsDataURL(file);
        }
    }

    function getBrowserType() {
        var standalone = window.navigator.standalone,
            userAgent = window.navigator.userAgent.toLowerCase(),
            safari = /safari/.test(userAgent),
            ios = /iphone|ipod|ipad/.test(userAgent);
        return ios;
    };

    var getOrientImageResponse = function (img) {
        if (vm.imgDataExifProp == true)
            vm.uploadImageFromLocalPC(img.toDataURL());
    };
    vm.uploadImageFromLocalPC = function (oreintResultImg) {
        vm.photoPath = oreintResultImg;
        //GALLERY PHOTO UPLOAD FROM LOCAL PC
        if (vm.upldPhotoType == 1) {
            vm.phtUplPrcCmt = false;
            $("#ProiflePhtsPopup").modal("hide");
            pcShowLoader("dvGlAddImg" + vm.PhotoIndex);
            var data = new FormData();
            CreateGlryThumbNail(oreintResultImg, vm.imgRealWidth, vm.imgRealHeight, function () {
                resizingImage(oreintResultImg, function (resizeResponse) {
                    base64ToBlobFileConvertion(resizeResponse, vm.imgwidth, vm.imgHeight, function (originalImgBlob) {
                        GetGalleryTnResponse(430, 430, function (img430Img) {
                            GetGalleryTnResponse(200, 200, function (img200Img) {
                                base64ToBlobFileConvertion(img430Img, 430, 430, function (img430Blog) {
                                    base64ToBlobFileConvertion(img200Img, 200, 200, function (img200Blog) {
                                        data.append("originalImgBlob", originalImgBlob);
                                        data.append("img430Blog", img430Blog);
                                        data.append("img200Blog", img200Blog);
                                        GalleryPhotosI(data);
                                    });
                                });
                            });
                        });
                    });
                });
            });
        }
            //PROFILE PHOTO UPLOAD FROM LOCAL PC
        else if (vm.upldPhotoType == 2) {
            CropPBPhoto(oreintResultImg, 250, 250);
        }
            //BANNER PHOTO UPLOAD FROM LOCAL PC
        else if (vm.upldPhotoType == 3) {
            if (vm.imgwidth < 400 || vm.imgHeight < 400) {
                $("#errSmlImg").attr('style', 'display:block;text-align:center;font-size:14px;color:red;color:red;padding-top:15px');
            }
            else if (vm.imgwidth < 820 || vm.imgHeight < 211) {
                $("#srcCvrPhtWrngPopup").modal("show");
            }
            else {
                CropPBPhoto(oreintResultImg, 600, 200);
            }
        }
    }
    /**************************************************************FILE UPLOAD END **************************************************************/

    /************************************************************** IMAGE CROPPER START**************************************************************/
    function CropPBPhoto(imagePath, VP_Width, VP_Height) {
        pcShowPopupLoader();
        $('#cropImg').croppie('destroy');
        if (vm.upldPhotoType == 3) {
            vm.showTagLine = true;
        }
        else
            vm.showTagLine = false;
        $("#ProiflePhtsPopup").modal("show");
        hideMdlById("crpMdl");
        croppie = $('#cropImg').croppie({
            //enableExif: true,
            viewport: {
                width: VP_Width,
                height: VP_Height,
                type: 'square' // or 'circle'
            },
            showZoomer: true,
            customClass: '',
            mouseWheelZoom: true,
            //enableOrientation: true,
            //enableExif:true,
        });

        //$('#dvGlryImgTn').croppie('get');
        croppie.croppie('bind', 'url').then(function () {
            croppie.croppie('setZoom', 0)
        });

        $timeout(function () {
            $('#cropImg').croppie('bind', {
                url: imagePath,
                zoom: 0.1,
                //orientation: 6,
            });
            vm.dsbldCrpBtn = false;
            vm.dsbldCrpBtnCls = "regBtn";
            hideLoader();
        });
        //vm.tagLineImgPath = imagePath;
    }
    function CroppedImageResult(width, height, callBackFun) {
        croppie.croppie('result', {
            type: 'canvas',
            size: { width: width, height: height }
        }).then(function (response) {
            callBackFun(response);
        });
    }
    function createBlurImage(imgSrc, callBackFun) {
        var canvas = document.createElement('canvas');
        canvas.setAttribute('id', "backgroud_div");
        $(canvas).blurIt(imgSrc, 20, function (resonse) {
            callBackFun(resonse);
        });
    }

    //save image after cropping
    vm.saveCroppedImg = function () {
        vm.dsbldCrpBtn = true;
        var imgSrc = "";
        if (vm.actionType == 1) //adding new image 
            imgSrc = vm.srcType == 1 ? vm.photoPath : $rootScope.imgPath; //vm.srcType  1 photo from local pc 2 from social
        else if (vm.actionType == 2) //updating existring image 
        {
            if (vm.upldPhotoType == 2) {
                imgSrc = vm.profileResponse[0].picPath;
            } else if (vm.upldPhotoType == 3) {
                imgSrc = vm.bannerResponse[0].picPath;
            }
        }
        //ADD PROFILE PIC
        if (vm.upldPhotoType == 2) {
            if ($(window).width() < 767)
                showLoader();
            else
                pcShowLoader("dvCrpMdl");
            if (vm.actionType == 1 && vm.srcType == 1) {
                UploadProfileImage(imgSrc);
            } else {
                convertFileToDataURLviaFileReader(imgSrc, function (originalImgResponse) {
                    UploadProfileImage(originalImgResponse);
                });
            }
        }
            //ADD BANNER PIC
        else if (vm.upldPhotoType == 3) {
            if ($(window).width() < 767)
                showLoader();
            else
                pcShowLoader("dvCrpMdl");
            if (vm.actionType == 1 && vm.srcType == 1) {
                UploadCoverImage(imgSrc);
            } else {
                //uploding pyar pic as banner image
                if (vm.srcType == 5)
                    imgSrc = vm.pyrPicUrl;
                convertFileToDataURLviaFileReader(imgSrc, function (originalImgResponse) {
                    UploadCoverImage(originalImgResponse);
                });
            }
        }
            //SWAP PHOTOs
        else if (vm.upldPhotoType == 4) {
            $("<img/>").load(function () {
                //var glImgWidth = this.width;
                //var glImgHeight = this.height;
                var data = new FormData();
                pcShowPopupLoader();
                convertFileToDataURLviaFileReader(vm.glryImgSrc, function (originalImgResponse) {
                    CroppedImageResult(430, 430, function (img430Response) {
                        CroppedImageResult(200, 200, function (img200Response) {
                            CroppedImageResult(100, 100, function (img100Response) {
                                resizingImage(originalImgResponse, function (resizeResponse) {
                                    base64ToBlobFileConvertion(resizeResponse, 430, 430, function (originalImgBlob) {
                                        base64ToBlobFileConvertion(img430Response, 430, 430, function (img430Blog) {
                                            base64ToBlobFileConvertion(img200Response, 200, 200, function (img200Blog) {
                                                base64ToBlobFileConvertion(img100Response, 100, 100, function (img100Blog) {
                                                    createBlurImage((img430Response), function (blurResponseBlob) {
                                                        data.append("originalImgBlob", originalImgBlob);
                                                        data.append("img430Blog", img430Blog);
                                                        data.append("img200Blog", img200Blog);
                                                        data.append("img100Blog", img100Blog);
                                                        data.append("blurResponseBlob", blurResponseBlob);
                                                        pcHideLoader();
                                                        $("#ProiflePhtsPopup").modal('hide');
                                                        pcShowLoader("dvGlryPhoto");
                                                        selfprofileSrvc.swapImages(vm.mId(), vm.mpuId, data, function (response, status) {
                                                            vm.dsbldCrpBtn = false;
                                                            if (status == 200) {
                                                                vm.prflCurPtr = "curptr";
                                                                refreshGlImgImage(vm.mpuId, function () {
                                                                    $scope.$emit("refreshHdrPP", vm.profilePic);
                                                                });
                                                                var upDt = new Date();
                                                                vm.profileResponse.push({ mpId: parseInt(response), picPath: vm.profilePic, picCreateDT: upDt });
                                                                //on swap image send notification
                                                                var type = 53;
                                                                if (msgSrvc.conId)
                                                                    msgSrvc.sendMemberNWNotifications("", getSessionSrvc.p_fn(), getSessionSrvc.p_ppic(), getSessionSrvc.p_gndr(), type, new Date());
                                                                else
                                                                    $rootScope.ntfnData.push({ "sendType": 2, "tmId": "", "fn": getSessionSrvc.p_fn(), "pp": getSessionSrvc.p_ppic(), "gender": getSessionSrvc.p_gndr(), "type": type, "date": new Date() });
                                                                hideLoader();

                                                                ////send Profile Pic upload push notificatoion
                                                                //msgSrvc.sendProfilePicUpldPushNotification(vm.mId(), getSessionSrvc.p_fn(), getSessionSrvc.p_ppic(), getSessionSrvc.p_gndr(), function (response, status) {
                                                                //    if (status == 200 && response == true) {
                                                                //        console.log("Profile photo push notification sent");
                                                                //    }
                                                                //    else {
                                                                //        console.log("Profile push notification sent fail - " + response);
                                                                //    }
                                                                //});

                                                                vm.profileInfo.isProfilePicUpld = true;
                                                            }
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            }).attr("src", vm.glryImgSrc);
        }
    }


    function resizingImage(imgRes, callbackImgResponse) {
        //***********************Below code is not working in IE*******************
        //var arr = imgRes.split(','), mime = arr[0].match(/:(.*?);/)[1],
        //bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
        //  while (n--) {
        // u8arr[n] = bstr.charCodeAt(n);
        //  }
        //  var imgFile = new File([u8arr], { type: mime });
        //***********************Below code is not working in IE*******************
        var dataURL = imgRes;
        var blobBin = atob(dataURL.split(',')[1]);
        var array = [];
        for (var i = 0; i < blobBin.length; i++) {
            array.push(blobBin.charCodeAt(i));
        }
        //var contentType = dataURL.split(',')[0].split(':')[1];
        var imgFile = new Blob([new Uint8Array(array)], { type: 'image/png' });

        canvasResize(imgFile, {
            width: 1920,
            height: 1920,
            crop: false,
            quality: 100,
            callback: function (data, width, height) {
                callbackImgResponse(data)
            }
        });

    }

    function UploadProfileImage(originalImgResponse) {
        var data = new FormData();
        CroppedImageResult(430, 430, function (img430Response) {
            CroppedImageResult(200, 200, function (img200Response) {
                CroppedImageResult(100, 100, function (img100Response) {
                    resizingImage(originalImgResponse, function (resizeResponse) {
                        base64ToBlobFileConvertion(resizeResponse, 430, 430, function (originalImgBlob) {
                            base64ToBlobFileConvertion(img430Response, 430, 430, function (img430Blog) {
                                base64ToBlobFileConvertion(img200Response, 200, 200, function (img200Blog) {
                                    base64ToBlobFileConvertion(img100Response, 100, 100, function (img100Blog) {
                                        createBlurImage((img430Response), function (blurResponseBlob) {
                                            data.append("originalImgBlob", originalImgBlob);
                                            data.append("img430Blog", img430Blog);
                                            data.append("img200Blog", img200Blog);
                                            data.append("img100Blog", img100Blog);
                                            data.append("blurResponseBlob", blurResponseBlob);
                                            hideLoader();
                                            //need to set action type 1 for adding new photo 2 for update existing photo
                                            pcShowLoader("dvPrflPhoto");
                                            $("#ProiflePhtsPopup").modal("hide");
                                            selfprofileSrvc.uploadPrflImages(vm.mId(), vm.actionType, data, function (response, status) {
                                                vm.dsbldCrpBtn = false;
                                                if (status == 200) {
                                                    vm.prflCurPtr = "curptr";
                                                    if (vm.profileInfo.isProfilePicUpld == false) {
                                                        vm.trophyPopPPEmpty = false;
                                                        vm.trophyPopPP = true;
                                                        $("#trophyPopPPE").modal('show');
                                                    }
                                                    vm.profileInfo.isProfilePicUpld = true;
                                                    var profilePic = vm.imageCDN + response.picPath.replace("/tnb/", "/tn/");
                                                    var mpId = null;
                                                    if (response.mpId == 0)
                                                        mpId = vm.profileResponse[0].mpId;
                                                    else
                                                        mpId = response.mpId;
                                                    vm.profileResponse = [];
                                                    vm.profileResponse.push({ mpId: mpId, picPath: profilePic, picCreateDT: response.picCreateDT });
                                                    refreshProfileImage(profilePic);
                                                    $scope.$emit("refreshHdrPP", profilePic);

                                                    //send notification while profile photo upload
                                                    var type = 53;
                                                    if (msgSrvc.conId)
                                                        msgSrvc.sendMemberNWNotifications("", getSessionSrvc.p_fn(), getSessionSrvc.p_ppic(), getSessionSrvc.p_gndr(), type, new Date());
                                                    else
                                                        $rootScope.ntfnData.push({ "sendType": 2, "tmId": "", "fn": getSessionSrvc.p_fn(), "pp": getSessionSrvc.p_ppic(), "gender": getSessionSrvc.p_gndr(), "type": type, "date": new Date() });
                                                    ////send Profile Pic upload push notificatoion
                                                    //msgSrvc.sendProfilePicUpldPushNotification(vm.mId(), getSessionSrvc.p_fn(), getSessionSrvc.p_ppic(), getSessionSrvc.p_gndr(), function (response, status) {
                                                    //    if (status == 200 && response == true) {
                                                    //        console.log("Profile photo push notification sent");
                                                    //    }
                                                    //    else {
                                                    //        console.log("Profile push notification sent fail - " + response);
                                                    //    }
                                                    //});

                                                }
                                                hideLoader();
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    }

    function UploadCoverImage(originalImgResponse) {
        var data = new FormData();
        CroppedImageResult(1600, 400, function (imgtnBlog) {
            resizingImage(originalImgResponse, function (resizeResponse) {
                base64ToBlobFileConvertion(resizeResponse, 1600, 400, function (originalImgBlob) {
                    base64ToBlobFileConvertion(imgtnBlog, 1600, 400, function (imagetnBlog) {
                        data.append("originalImgBlob", originalImgBlob);
                        data.append("imgtnBlog", imagetnBlog);
                        hideLoader();
                        $("#ProiflePhtsPopup").modal('hide');
                        pcShowLoader("dvBnrPhoto");
                        selfprofileSrvc.uploadBannerImages(vm.mId(), vm.actionType, data, function (response, status) {
                            vm.bnrCurPtr = "curptr";
                            vm.dsbldCrpBtn = false;
                            if (status == 200) {
                                vm.profileInfo.profileBnr = response.picPath;
                                var bannerImage = vm.imageCDN + response.picPath.replace("/tnb/", "/tn/");
                                var mpId = null;
                                if (response.mpId == 0)
                                    mpId = vm.bannerResponse[0].mpId;
                                else
                                    mpId = response.mpId;
                                refreshBannerImage(bannerImage);
                                vm.bannerResponse = [];
                                vm.bannerResponse.push({ mpId: mpId, picPath: bannerImage, picCreateDT: response.picCreateDT });
                            }
                            hideLoader();
                        });
                    });
                });
            });
        });
    }
    function refreshProfileImage(imgPath) {
        vm.profilePic = updateImgVersion(imgPath);
    }
    function refreshBannerImage(imgPath) {
        vm.bnrImg = updateImgVersion(imgPath);
        vm.tagLIneImg = updateImgVersion(imgPath);
    }
    function refreshGlImgImage(mupId, callBackFun) {
        vm.profilePic = updateImgVersion(vm.profilePic);

        if (vm.profileInfo.isProfilePicUpld == true) {
            $("#shwimg img").each(function (index) {
                var img = $(this);
                $(img).attr("src", updateImgVersion($(img).attr("src")));
            });

            $("#dvsliderImages img").each(function (index) {
                var img = $(this);
                $(img).attr("src", updateImgVersion($(img).attr("src")));
            });
        } else {
            for (var i = 0; i < vm.glryThumbnails.length; i++) {
                if (vm.glryThumbnails[i].mpId == mupId) {
                    vm.glryThumbnails[i].mpId = 0;
                    vm.glryThumbnails[i].picPath = "";
                    vm.glryThumbnails[i].picCreateDT = "";
                }
            }
            for (var i = 0; i < vm.glryImgs.length; i++) {
                if (vm.glryImgs[i].mpId == mupId) {
                    vm.glryImgs.splice(i, 1);
                }
            }
        }
        callBackFun();
    }
    vm.showCropImg = function () {
        $('#cropImg').croppie('destroy');
        var imgPath = "";
        if (vm.upldPhotoType == 2)
            imgPath = vm.profileResponse[0].picPath.replace("/tn/", "/").replace("/tnb/", "/");
        else if (vm.upldPhotoType == 3)
            imgPath = vm.bannerResponse[0].picPath.replace("/tn/", "/");
        if (imgPath != "") {
            $("<img/>").load(function () {
                vm.imgwidth = this.width;
                vm.imgHeight = this.height;
            }).attr("src", imgPath);

            if (vm.upldPhotoType == 2) {
                CropPBPhoto(imgPath, 200, 200);
            }
            else if (vm.upldPhotoType == 3)
                CropPBPhoto(imgPath, 600, 200);
        }
    }
    function base64ToBlobFileConvertion(imgSrc, imgWidth, imgHeight, callBackFun) {
        var dataURL = imgSrc;
        var blobBin = atob(dataURL.split(',')[1]);
        var array = [];
        for (var i = 0; i < blobBin.length; i++) {
            array.push(blobBin.charCodeAt(i));
        }
        var contentType = dataURL.split(',')[0].split(':')[1];
        var file = new Blob([new Uint8Array(array)], { type: contentType });
        callBackFun(file);
    }
    function convertFileToDataURLviaFileReader(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.onload = function () {
            var reader = new FileReader();
            reader.onloadend = function () {
                callback(reader.result);
            }
            reader.readAsDataURL(xhr.response);
        };
        xhr.open('GET', url);
        xhr.responseType = 'blob';
        xhr.send();
    }
    vm.btnBackCrpPhoto = function () {
        //vm.adjCrpToDtsny 1 for view mode profile 
        //                 2 for banner
        //                 3 for source selector
        //                 4 from photo album selector

        $('#cropImg').croppie('destroy');
        $("#errSmlImg").attr("style", "display:none");
        if (vm.adjCrpToDtsny == 1)
            hideMdlById("PBImgMdl");
        else if (vm.adjCrpToDtsny == 2)
            hideMdlById("srcSlctrMdl");
        else if (vm.adjCrpToDtsny == 3) {
            hideMdlById("AlbumPhtsMdl");
            vm.adjCrpToDtsny = "";
        }
        else if (vm.adjCrpToDtsny == 4)
            vm.imgGalleryClick(vm.GalleryActiveImgInfo[0].index, vm.GalleryActiveImgInfo[0].type, vm.GalleryActiveImgInfo[0].mpuId, vm.GalleryActiveImgInfo[0].dateCreated, "", vm.GalleryActiveImgInfo[0].picPosition);
        $(document.body).css('padding-right', '0px');
    }
    /************************************************************** IMAGE CROPPER END**************************************************************/


    /************************************************************** ADD PHOTO FROM SOCIAL**************************************************************/
    vm.addPhoto = function () {
        //gallery photo module        
        if (vm.upldPhotoType == 1) {
            pcShowLoader("dvGlryPhoto");
            vm.phtUplPrcCmt = false;
            $("#ProiflePhtsPopup").modal("hide");
            var data = new FormData();
            convertFileToDataURLviaFileReader($rootScope.imgPath, function (originalImgResponse) {
                CreateGlryThumbNail(originalImgResponse, $rootScope.realWidth, $rootScope.realHeight, function (img430Img) {
                    resizingImage(originalImgResponse, function (resizeResponse) {
                        base64ToBlobFileConvertion(resizeResponse, $rootScope.realWidth, $rootScope.realWidth, function (originalImgBlob) {
                            GetGalleryTnResponse(430, 430, function (img430Img) {
                                GetGalleryTnResponse(200, 200, function (img200Img) {
                                    base64ToBlobFileConvertion(img430Img, 430, 430, function (img430Blog) {
                                        base64ToBlobFileConvertion(img200Img, 200, 200, function (img200Blog) {
                                            data.append("originalImgBlob", originalImgBlob);
                                            data.append("img430Blog", img430Blog);
                                            data.append("img200Blog", img200Blog);
                                            hideLoader();
                                            GalleryPhotosI(data);
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        }
            //profile photo module
        else if (vm.upldPhotoType == 2) {
            if ($rootScope.imgPath != "" && $rootScope.realWidth >= vm.minWidth && $rootScope.realHeight >= vm.minHeight) {
                vm.crpMdl = true;
                vm.AlbumPhtsMdl = false;
                vm.srcSlctrMdl = false;
                vm.AlbumMdl = false;
                vm.photoPath = $rootScope.imgPath;
                vm.imgwidth = $rootScope.realWidth;
                vm.imgHeight = $rootScope.realHeight;
                CropPBPhoto($rootScope.imgPath, 200, 200);
            } else {
                //need to show small image error msg
            }
        }

            //banner photo module
        else if (vm.upldPhotoType == 3) {
            //show error message for banner img dimentoin not matched
            vm.photoPath = $rootScope.imgPath;
            vm.imgwidth = $rootScope.realWidth;
            vm.imgHeight = $rootScope.realHeight;
            if (($rootScope.realWidth < 820 || $rootScope.realHeight < 211)) {
                $("#srcCvrPhtWrngPopup").modal("show");
            } else {

                vm.crpMdl = true;
                vm.AlbumPhtsMdl = false;
                vm.srcSlctrMdl = false;
                vm.AlbumMdl = false;
                CropPBPhoto($rootScope.imgPath, 600, 200);
            }
        }
    }
    /************************************************************** ADD PHOTO FROM SOCIAL END**************************************************************/


    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PROFILE MODULE START ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    //add profile pic button click
    vm.addProfilePic = function () {
        $("#errSmlImg").attr("style", "display:none");
        $('#trophyPopPPE').modal('hide');
        vm.dvPyarpics = false;
        //1 FOR ADD 2 FOR EDIT
        vm.actionType = 1;
        vm.upldPhotoType = 2;
        $("#ProiflePhtsPopup").modal("show");
        hideMdlById("srcSlctrMdl");
        vm.cropPhotoType = "Profile";
        //used to come back from cropper popup
        vm.adjCrpToDtsny = 2;
        if (vm.profileResponse[0] != undefined && vm.profileResponse[0].picPath != "")
            vm.imgRplcMsg = true;
        else
            vm.imgRplcMsg = false;
    }

    vm.showProfilePic = function () {
        if (vm.profileInfo.isProfilePicUpld == true) {
            $("#imgIndv").attr("src", "");
            //1 FOR ADD 2 FOR EDIT
            vm.actionType = 2;
            vm.upldPhotoType = 2;
            vm.cropPhotoType = "Profile";
            //some times cdn path not updating with new image so i just replaced cdn path with storage path
            $("#imgIndv").attr("src", $("#prflPic").attr("src").replace("/tn/", "/").replace(vm.imageCDN, vm.imageStorage));
            vm.profileDateCreated = vm.profileResponse[0].picCreateDT;
            //$('#imgIndv').removeClass("bnrpic").addClass("prflpic");
            //used to come back from cropper popup
            vm.adjCrpToDtsny = 1;
            $("#ProiflePhtsPopup").modal("show");
            hideMdlById("PBImgMdl");
        }
    }
    vm.deletePBPhoto = function () {
        if (vm.upldPhotoType == 2) {
            pcShowPopupLoader();
            $("#srcprofBnrdeletePopup").modal("hide");
            selfprofileSrvc.ProfilePhotoD(vm.mId(), vm.profileResponse[0].mpId, function (response, status) {
                if (status == 200 && response == true) {
                    vm.prflCurPtr = "";
                    $("#ProiflePhtsPopup").modal('hide');
                    Trophiesresult[2] = 0;
                    trophiesLoad(Trophiesresult);
                    vm.profileInfo.isProfilePicUpld = false;
                    vm.profileResponse = [];
                    refreshProfileImage(vm.profilePic);
                    $scope.$emit("refreshHdrPP", vm.profilePic);
                } else {
                    alert("unable to  deleted profile photo");
                }
                pcHideLoader();
            });
        } else if (vm.upldPhotoType == 3) {
            pcShowPopupLoader();
            $("#srcprofBnrdeletePopup").modal("hide");
            selfprofileSrvc.BannerPhotoD(vm.mId(), vm.bannerResponse[0].mpId, function (response, status) {
                if (status == 200) {
                    vm.profileInfo.profileBnr = "";
                    vm.bnrCurPtr = "";
                    vm.bannerResponse = [];
                    vm.bnrImg = "https://pccdn.pyar.com/pcimgs/defBnr.jpg";
                    vm.tagLIneImg = "https://pccdn.pyar.com/pcimgs/defBnr.jpg";
                } else {
                    alert("unable to  deleted banner photo");
                }
                pcHideLoader();
            });

            $("#ProiflePhtsPopup").modal("hide");
        }
    }

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PROFILE MODULE END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BANNER MODULE START ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    //add banner pic button click
    vm.addBannerPhoto = function () {
        $("#errSmlImg").attr("style", "display:none");
        vm.dvPyarpics = true;
        vm.actionType = 1;
        vm.upldPhotoType = 3;
        //used to come back from cropper popup
        vm.adjCrpToDtsny = 2;
        $("#ProiflePhtsPopup").modal('show');
        hideMdlById("srcSlctrMdl");
        vm.cropPhotoType = "Cover";
        if (vm.bannerResponse[0] != undefined && vm.bannerResponse[0].picPath != "")
            vm.imgRplcMsg = true;
        else
            vm.imgRplcMsg = false;
    }
    vm.showBannerPic = function () {
        if (vm.bannerResponse[0] != undefined && vm.profileInfo.profileBnr != "") {
            $("#imgIndv").attr("src", "");
            vm.actionType = 2;
            vm.upldPhotoType = 3;
            vm.cropPhotoType = "Cover";
            //$('#imgIndv').removeClass("prflpic").addClass("bnrpic");
            $("#imgIndv").attr("src", updateImgVersion(vm.bannerResponse[0].picPath));
            vm.profileDateCreated = vm.bannerResponse[0].picCreateDT;
            //used to come back from cropper popup
            vm.adjCrpToDtsny = 1;
            $("#ProiflePhtsPopup").modal('show');
            hideMdlById("PBImgMdl");
        }
    }

    vm.btnUseAnyway = function () {
        $("#srcCvrPhtWrngPopup").modal("hide");
        if (vm.srcType == 1) {
            CropPBPhoto(vm.photoPath, 600, 200);
        } else {
            vm.photoPath = $rootScope.imgPath;
            vm.imgwidth = $rootScope.realWidth;
            vm.imgHeight = $rootScope.realHeight;
            CropPBPhoto($rootScope.imgPath, 600, 200);
        }
    }
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BANNER MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/


    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SWAPPING MODULE  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    //make gallery image to profile photo
    vm.makeprflPhoto = function () {
        vm.cropPhotoType = "Profile";
        //vm.ptsType = 1;
        $("#srcMakePrfPicWrngPopup").modal("show");
        vm.adjCrpToDtsny = 4;
    }

    vm.CropMkPrflPic = function () {
        $("#srcMakePrfPicWrngPopup").modal("hide");
        //FOR SWAP IMAGE
        vm.upldPhotoType = 4;
        $('#cropImg').croppie('destroy');
        CropPBPhoto(vm.glryImgSrc, 200, 200);
        vm.adjCrpToDtsny = 4;
    }


    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SWAPPING MODULE  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/


    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  GALLERY MODULE START ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    //bind gallery image on page load
    BindAllImages(function (glryThumbnails, originalGalleryPhotos) {
        vm.glryThumbnails = glryThumbnails;
        vm.glryImgs = originalGalleryPhotos;
    });
    vm.phtUplPrcCmt = true;
    //My Photo gallery click on image note:" type 1 for add photo 2 for slide photo"
    vm.imgGalleryClick = function (index, type, mpuId, dateCreated, picPath, picPosition) {
        if (vm.phtUplPrcCmt == true) {
            vm.GalleryActiveImgInfo = [{ "index": index, "type": type, "mpuId": mpuId, "dateCreated": dateCreated, picPosition: picPosition }];
            $("#errSmlImg").attr("style", "display:none");
            vm.upldPhotoType = 1;
            vm.dateCreated = dateCreated;
            vm.PhotoIndex = index;
            vm.mpuId = mpuId;
            $("#ProiflePhtsPopup").modal("show");
            vm.imgRplcMsg = false;
            if (type == 1) {
                vm.dvPyarpics = false;
                hideMdlById("srcSlctrMdl");
                vm.picPosition = index;
            }
            else if (type == 2) {
                vm.picPosition = picPosition;
                showDivs($("#glryImg" + index).attr('src'));
                hideMdlById("phtSliderMdl");
            }
        }
    }

    //bind gallery image insert
    function GalleryPhotosI(data) {
        //$("#dvGlryImgTn").html('');
        if (data != null) {
            var index = vm.PhotoIndex + 1;
            $("#ProiflePhtsPopup").modal("hide");
            //pcShowLoader("dvGlAddImg" + vm.PhotoIndex);
            selfprofileSrvc.uploadGlryImages(vm.mId(), index, data, function (response, status) {
                if (status == 200) {
                    vm.dateCreated = response.picCreateDT;
                    for (var i = 0; i < vm.glryThumbnails.length; i++) {
                        if (vm.glryThumbnails[i].picOrder == index) {
                            vm.glryThumbnails[i].mpId = response.mpId;
                            vm.glryThumbnails[i].picPath = vm.imageCDN + response.picPath;
                            vm.glryThumbnails[i].picOrder = response.picOrder;
                            vm.glryThumbnails[i].picCreateDT = response.picCreateDT;
                            vm.glryThumbnails[i].picPosition = index;
                        }
                    }
                    vm.glryImgs.push({
                        mpId: response.mpId, picPath: vm.imageCDN + response.picPath.replace("/tn/", "/"), picOrder: response.picOrder, picCreateDT: response.picCreateDT
                    });

                    //send notification while gallery photo upload
                    var type = 54;
                    if (msgSrvc.conId)
                        msgSrvc.sendMemberNWNotifications("", getSessionSrvc.p_fn(), getSessionSrvc.p_ppic(), getSessionSrvc.p_gndr(), type, new Date());
                    else
                        $rootScope.ntfnData.push({ "sendType": 2, "tmId": "", "fn": getSessionSrvc.p_fn(), "pp": getSessionSrvc.p_ppic(), "gender": getSessionSrvc.p_gndr(), "type": type, "date": new Date() });

                    ////send Gallery photo upload push notificatoion
                    //msgSrvc.sendGalleryPicUpldPushNotification(vm.mId(), getSessionSrvc.p_fn(), getSessionSrvc.p_ppic(), getSessionSrvc.p_gndr(), function (response, status) {
                    //    if (status == 200 && response == true) {
                    //        console.log("Gallery photo push notification sent");
                    //    }
                    //    else {
                    //        console.log("Gallery photo notification sent fail - " + response);
                    //    }
                    //});

                    $timeout(function () { hideLoader(); vm.phtUplPrcCmt = true; }, 100);
                }
            });
        }
    }

    //delete photo from gallery
    vm.btnDltGlryPhoto = function () {
        pcShowLoader("dvGlryPhoto");
        $("#srcdeletePopup").modal("hide");
        selfprofileSrvc.GalleryPhotoD(vm.mId(), vm.mpuId, function (response, status) {
            if (status == 200 && response == true) {
                for (var i = 0; i < vm.glryThumbnails.length; i++) {
                    if (vm.glryThumbnails[i].mpId == vm.mpuId) {
                        vm.glryThumbnails[i].mpId = 0;
                        vm.glryThumbnails[i].picPath = "";
                        vm.glryThumbnails[i].picCreateDT = "";
                    }
                }
                for (var i = 0; i < vm.glryImgs.length; i++) {
                    if (vm.glryImgs[i].mpId == vm.mpuId) {
                        vm.glryImgs.splice(i, 1);
                    }
                }
                refreshGalleryDiv();
                hideLoader();
            } else {
                alert("unable to delete photo");
                hideLoader();
            }
        });
    }
    function refreshGalleryDiv() {
        if (vm.glryImgs.length > 0) {
            if (vm.picPosition > 1)
                vm.picPosition = vm.picPosition - 1;

            showDivs("");
        } else
            $("#ProiflePhtsPopup").modal("hide");
    }
    //deltete gallery image popup click 
    vm.btnShowDltPopUp = function () {
        $("#srcdeletePopup").modal("show");
    }

    //delete Profile and banner image popup click 
    vm.deletePBconfrmpopup = function () {
        $("#srcprofBnrdeletePopup").modal("show");
    }


    function BindAllImages(callBackFunc) {
        var glryThumbnails = [];
        var glryImgs = [];
        var picPosition = 0;
        showLoader();
        selfprofileSrvc.getAllImages(vm.mId(), function (response, status) {
            if (status == 200) {
                angular.forEach(response, function (data) {
                    //profile photo data
                    if (data.picType == 2) {
                        vm.profileResponse.push({ mpId: data.mpId, picPath: vm.imageCDN + data.picPath, picCreateDT: data.picCreateDT });
                    }
                    else if (data.picType == 3) {
                        vm.bannerResponse.push({ mpId: data.mpId, picPath: vm.imageCDN + data.picPath, picCreateDT: data.picCreateDT });
                    }
                });
                for (var i = 1; i < 9; i++) {
                    var hasVaue = false;
                    for (var j = 0; j < response.length; j++) {
                        if (response[j].picType == 1) {
                            if (i == response[j].picOrder) {
                                var imgCdn = "";
                                var orgImgCdn = "";
                                if (getDateDiffByMins(response[j].picCreateDT) > 90)
                                    orgImgCdn = imgCdn = vm.imageCDN;
                                else
                                    orgImgCdn = imgCdn = vm.imageCDN;

                                picPosition += 1;
                                glryThumbnails.push({
                                    mpId: response[j].mpId, picPath: imgCdn + response[j].picPath, picOrder: response[j].picOrder, picCreateDT: response[j].picCreateDT, picPosition: picPosition
                                });

                                glryImgs.push({
                                    mpId: response[j].mpId, picPath: imgCdn + response[j].picPath.replace("/tn/", "/"), picOrder: response[j].picOrder, picCreateDT: response[j].picCreateDT
                                });
                                hasVaue = true;
                                break;
                            }
                        }
                    }
                    if (!hasVaue)
                        glryThumbnails.push({
                            mpId: 0, picPath: "", picOrder: i, picCreateDT: ''
                        });
                }
                callBackFunc(glryThumbnails, glryImgs);
                hideLoader();
            }
        });
    }
    //return date difference between photo created and now in minutes
    function getDateDiffByMins(date) {
        var today = new Date();
        var imgAddedDay = new Date(date);
        var diffMs = (today - imgAddedDay); // milliseconds between now & Christmas
        var diffDays = Math.floor(diffMs / 86400000); // days
        var diffHrs = Math.floor((diffMs % 86400000) / 3600000); // hours
        var diffMins = Math.round(((diffMs % 86400000) % 3600000) / 60000);
        return diffMins;
    }
    var tnCroppie;
    function CreateGlryThumbNail(imgSrc, imgWidth, imgHeight, callbackFun) {
        $('#crpThmnl').croppie('destroy');
        tnCroppie = $('#crpThmnl').croppie({
            //enableExif: true,
            viewport: {
                width: 200,
                height: 200,
                type: 'square' // or 'circle'
            },
            showZoomer: true,
            //enableOrientation: true,
            customClass: '',
            mouseWheelZoom: true,
        });

        $('#crpThmnl').croppie('bind', 'url').then(function () {
            $('#crpThmnl').croppie('setZoom', 0);
        });

        $('#crpThmnl').croppie('bind', {
            url: imgSrc,
            zoom: 0.1,
        });
        callbackFun();
    }

    function GetGalleryTnResponse(tmbnWidth, tmbnHeight, callbackFun) {
        $timeout(function () {
            $('#crpThmnl').croppie('result', {
                type: 'canvas',
                size: { width: tmbnWidth, height: tmbnHeight }
            }).then(function (response) {
                callbackFun(response);
            });
        }, 1000);
    }
    vm.ShowPyarPhotos = function () {
        $('#cropImg').croppie('destroy');
        $("#ProiflePhtsPopup").modal("show");
        hideMdlById("pyrPhtsMdl");
        vm.bindPyarPhotos();
    }
    vm.PyarPhotos = [];
    vm.bindPyarPhotos = function () {
        if ($("#dvPyarPhotos").attr("data-pyrImg") == "Y") {
            pcShowPopupLoader();
            selfprofileSrvc.getPyarPics(function (response, status) {
                if (status == 200) {
                    angular.forEach(response, function (data) {
                        vm.PyarPhotos.push({ picPath: vm.imageCDN + data.photoPath, picTNPath: vm.imageCDN + data.photoPathTN });
                    });
                    $("#dvPyarPhotos").attr("data-pyrImg", "N");
                }
                pcHideLoader();
            });
        }
    }
    vm.pyrPicUrl = "";
    vm.PyrImgClick = function (index, url) {
        vm.pyrPicUrl = url;
        $("[id^='selectedPyrImg']").removeClass("bxshdw");
        $("#selectedPyrImg" + index).addClass("bxshdw");
        $("#btnPyarPhotoAdd").attr('disabled', false);
        $("#btnPyarPhotoAdd").addClass("regBtn");
    }
    vm.btnBackPyrPhotos = function () {
        $("#errSmlImg").attr("style", "display:none");
        hideMdlById("srcSlctrMdl");
    }
    vm.uploadBannerImage = function () {
        vm.photoPath = vm.pyrPicUrl;
        vm.upldPhotoType = 3;
        vm.actionType = 1;
        //adding pyar pics as banner image
        vm.srcType = 5;
        $("<img/>").load(function () {
            vm.imgwidth = this.width;
            vm.imgHeight = this.height;
            CropPBPhoto(vm.pyrPicUrl, 600, 200);
        }).attr("src", vm.photoPath);
    }
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  GALLERY MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/


    /********************************************************************SLIDER MODULE START***************************************************************/
    vm.picPosition = 0;
    //default slide image after loading  all the images
    $scope.$on('onGalleryImgLoadFinish', function () {
        showDivs("");
    });
    //slider next and prev click
    vm.plusDivs = function (n) {
        vm.picPosition = vm.picPosition + n;
        showDivs("");
    }
    //show slide image function
    function showDivs(photoPath) {
        var i;
        var slideImgs = $("#dvSlides .mySlides");
        if (slideImgs.length > 1) {
            if (photoPath != "") {
                for (j = 0; j < slideImgs.length ; j++) {
                    var arryImage = $(slideImgs[j]).attr('src');
                    if (photoPath.indexOf("?v=") != -1) {
                        var lastIndex = photoPath.indexOf("?");
                        photoPath = photoPath.substring(0, lastIndex);
                    }
                    if (arryImage.indexOf("?v=") != -1) {
                        var lastIndex = arryImage.indexOf("?");
                        arryImage = arryImage.substring(0, lastIndex);
                    }

                    if (photoPath.replace("/tn/", "/") == arryImage) {
                        slideImgs[j].style.display = "inline-block";
                        vm.mpuId = $(slideImgs[j]).attr('data-mpId');
                        vm.dateCreated = $(slideImgs[j]).attr('data-dateCrctd');
                        vm.glryImgSrc = $(slideImgs[j]).attr('src');
                        vm.GalleryActiveImgInfo = [];
                        $('#dvGlryPhoto').find('img').each(function () {
                            if ($(this).attr('src').replace("/tn/", "/") == vm.glryImgSrc) {
                                vm.GalleryActiveImgInfo = [{ "index": $(this).attr('data-picIndex'), "type": 2, "mpuId": vm.mpuId, "dateCreated": vm.dateCreated, picPosition: vm.picPosition }];
                            }
                        });
                    } else
                        slideImgs[j].style.display = "none";
                }
            }
            else {
                if (vm.picPosition > slideImgs.length) {
                    vm.picPosition = 1
                }
                if (vm.picPosition < 1) {
                    vm.picPosition = slideImgs.length
                }
                for (i = 0; i < slideImgs.length; i++) {
                    slideImgs[i].style.display = "none";
                }
                if (vm.glryImgSrc == $(slideImgs[vm.picPosition - 1]).context.src) {
                    if (vm.picPosition > 1)
                        vm.picPosition = vm.picPosition - 1;
                    else
                        vm.picPosition = vm.picPosition + 1;
                }
                if ($(slideImgs[vm.picPosition - 1])) {
                    vm.mpuId = $(slideImgs[vm.picPosition - 1]).attr('data-mpId');
                    vm.dateCreated = $(slideImgs[vm.picPosition - 1]).attr('data-dateCrctd');
                    slideImgs[vm.picPosition - 1].style.display = "inline-block";
                    vm.glryImgSrc = $(slideImgs[vm.picPosition - 1]).attr('src');
                    vm.GalleryActiveImgInfo = [];
                    $('#dvGlryPhoto').find('img').each(function () {
                        if ($(this).attr('src').replace("/tn/", "/") == vm.glryImgSrc) {
                            vm.GalleryActiveImgInfo = [{ "index": $(this).attr('data-picIndex'), "type": 2, "mpuId": vm.mpuId, "dateCreated": vm.dateCreated, picPosition: vm.picPosition }];
                        }
                    });
                }
            }
        } else
            vm.glryImgSrc = photoPath.replace("/tn/", "/").replace("/tnb/", "/");
        changeImageDimentions(vm.glryImgSrc);
    }
    //show image width height according to image original width height
    function changeImageDimentions(imgPath) {
        $("#dvsliderImages img").height("auto").width("auto");
        $("#dvsliderImages img").css("max-height", "100%");
    }
    /********************************************************************SLIDER MODULE END***************************************************************/


    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  GALLERY , PROFILE , BANNER PHOTO MODULE  END HERE )))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/




    //get images from facebook
    vm.btnFBPhotos = function () {
        FB.login(function (response) {
            if (response.authResponse) {
                var access_token = FB.getAuthResponse()['accessToken'];
                vm.accessToken = access_token;
                var client_id = getFBClntId();
                pcShowPopupLoader();
                selfprofileSrvc.getAlbums(client_id, access_token, function (response, status) {
                    var albumsList = [];
                    for (var i = 0; i < response.data.length; i++) {

                        albumsList.push({ albumId: response.data[i].id, albumName: response.data[i].name });
                    }
                    vm.srcType = 2;
                    vm.albums = albumsList;
                    vm.btnNextActive = "prvbtn";
                    vm.srcSlctrMdl = false;
                    vm.AlbumMdl = true;
                    vm.inPhots = false;
                    pcHideLoader();
                });
            }
        }, {
            scope: 'user_photos',
            return_scopes: true
        });
    }

    //click on album name 
    vm.selectAlbum = function (albumId, index) {
        $("[id^='dvAlbum']").removeClass("bxshdw");
        $("#dvAlbum" + index).addClass("bxshdw");
        if (albumId != "" && albumId != undefined && albumId != null) {
            vm.btnNextActive = "prvbtn regBtn";
            vm.albumId = albumId;
            vm.btnValid = true;
        }
    }

    //get photos by album id
    vm.getAlbumPhotos = function () {
        var photUrls = [];
        pcShowPopupLoader();
        selfprofileSrvc.bindPhotos(vm.albumId, vm.accessToken, function (response, status) {
            if (status == 200) {
                //var albumsList = [];
                for (var i = 0; i < response.data.length; i++) {

                    var url = "https://graph.facebook.com/" + response.data[i].id + "/picture?access_token=" + vm.accessToken;
                    photUrls.push({ "imgUrl": url });
                }
                vm.albumPhotos = photUrls;
                vm.AlbumPhtsMdl = true;
                vm.srcSlctrMdl = false;
                vm.AlbumMdl = false;
                pcHideLoader();
            }
        });
    }

    vm.albumImgClick = function (imgPath, index) {
        $("[id^='selectedImg']").removeClass("bxshdw");
        $("#selectedImg" + index).addClass("bxshdw");
        var width = $("#selectedImg" + index).width();
        var height = $("#selectedImg" + index).height();
        loaduploadImage(imgPath, index, function (response) {
            if (response) {
                $("#btnSelectPhoto").attr('disabled', false);
                $("#btnSelectPhoto").addClass("regBtn");
            } else {
                $("#btnSelectPhoto").attr('disabled', true);
                $("#btnSelectPhoto").removeClass("regBtn");
            }
        });
    }
    function loaduploadImage(imgPath, index, calBackFun) {
        $("<img/>").load(function () {
            vm.imgRealWidth = this.width;
            vm.imgRealHeight = this.height;
            if (vm.imgRealWidth < vm.minWidth || vm.imgRealHeight < vm.minHeight) {
                var errorMsgDiv = "<div class='albhvrmaskscl' style='opacity: 1;border-radius: 20px;'><p class='prfHvr' style='line-height: 150px;'>Too small</p></div>";
                $("#selectedImg" + index).parent().append(errorMsgDiv);
                calBackFun(false);
            }
            else {
                calBackFun(true);
                $('#cropImg').croppie('destroy');
                vm.adjCrpToDtsny = 3;
                vm.imgHeight = vm.imgRealHeight;
                vm.imgwidth = vm.imgRealWidth;

                if (vm.imgRealWidth > vm.imgRealHeight) {
                    if (vm.imgRealWidth > vm.maxWidth) {
                        vm.imgHeight = vm.imgRealHeight * (vm.maxWidth / vm.imgRealWidth);
                        vm.imgwidth = vm.maxWidth;
                    }
                } else {
                    if (vm.imgRealHeight > vm.maxHeight) {
                        vm.imgwidth = vm.imgRealWidth * (vm.maxHeight / vm.imgRealHeight);
                        vm.imgHeight = vm.maxHeight;
                    }
                }
                $rootScope.imgPath = imgPath;
                $rootScope.realWidth = vm.imgwidth;
                $rootScope.realHeight = vm.imgHeight;
            }
        }).attr("src", imgPath);
    }

    vm.btnBackAlbum = function () {
        hideMdlById("srcSlctrMdl");
        vm.btnValid = false;
    }
    vm.btnBackAlbumPhotos = function () {
        if (vm.inPhots == true)
            hideMdlById("srcSlctrMdl");
        else {
            hideMdlById("AlbumMdl");
            vm.inPhots = false;
        }
    }

    vm.btnMyPC = function () {
        $("#fupPhtGlry").click();
        vm.srcType = 1;
        vm.adjCrpToDtsny = 2;
    }

    vm.btnINPhotos = function () {
        vm.srcType = 3;
        var clientid = getIGClntId();
        //var localRedirectUri = "http://localhost:49984/InPhotos.html";
        var liveRedirectUri = "https://dev.pyar.com/InPhotos.html";
        var In_Data = { PhotoIndex: vm.PhotoIndex, upldPhotoType: vm.upldPhotoType };
        $window.localStorage.setItem("In_data", JSON.stringify(In_Data));
        document.location.href = "https://api.instagram.com/oauth/authorize/?client_id=" + clientid + "&redirect_uri=" + liveRedirectUri + "&response_type=token";
    }

    function BindInPhtsUsngLclStgData() {
        var In_data = $window.localStorage.getItem("In_data");
        if (In_data) {
            In_data = JSON.parse(In_data);
            if (In_data.upldPhotoType == 1) {
                $("html, body").animate({
                    scrollTop: $(document).height() / 2 + 500
                }, 500);
            }
            vm.PhotoIndex = In_data.PhotoIndex;
            vm.upldPhotoType = In_data.upldPhotoType;
            bindInPhotos(In_data.access_token);
            vm.inPhots = true;
        }
    }
    function bindInPhotos(access_token) {
        if (access_token) {
            var photoUrls = [];
            selfprofileSrvc.bindPhotosIN(access_token, function (response) {
                //var albumsList = [];
                for (var i = 0; i < response.data.length; i++) {
                    var url = response.data[i].images.standard_resolution.url;
                    photoUrls.push({ "imgUrl": url });
                }
                vm.albumPhotos = photoUrls;

                $window.localStorage.removeItem("In_data");
                $timeout(function () {
                    $("#ProiflePhtsPopup").modal("show");
                    hideMdlById("AlbumPhtsMdl");
                    pcHideLoader();
                }, 1000);
            });
        }
    }

    function hideMdlById(mdl) {
        vm.srcSlctrMdl = false;
        vm.AlbumMdl = false;
        vm.AlbumPhtsMdl = false;
        vm.pyrPhtsMdl = false;
        vm.PBImgMdl = false;
        vm.phtSliderMdl = false;
        vm.crpMdl = false;
        if (mdl == "srcSlctrMdl")
            vm.srcSlctrMdl = true;
        else if (mdl == "AlbumMdl")
            vm.AlbumMdl = true;
        else if (mdl == "AlbumPhtsMdl")
            vm.AlbumPhtsMdl = true;
        else if (mdl == "pyrPhtsMdl")
            vm.pyrPhtsMdl = true;
        else if (mdl == "PBImgMdl")
            vm.PBImgMdl = true;
        else if (mdl == "phtSliderMdl")
            vm.phtSliderMdl = true;
        else if (mdl == "crpMdl")
            vm.crpMdl = true;
    }

    //Adding modal-open class for removing padding
    (function () {
        $('body').on('hidden.bs.modal', function () {
            if ($('.modal.in').length > 0) {
                $('body').addClass('modal-open');
            }
        });
        getModalValue();
    }());
    function getModalValue() {
        if ($('.modal.in').length == 0) {
            $('body').addClass('modalTest');
        }
    }

    if ($rootScope.mpFillout && $rootScope.mpFillout == true) {
        $rootScope.mpFillout = null;
        vm.fillOutIntrl = function () {
            $timeout(function () {
                if ($("#btnMPEdit").length > 0) {
                    $("#btnMPEdit").click();
                }
                else
                    vm.fillOutIntrl();
            }, 100);
        }
        vm.fillOutIntrl();
    }

    vm.bindImgSrc = function (imgPath) {
        return addCdnPath(imgPath);
    };
}]);