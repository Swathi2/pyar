﻿angular.module("app").controller('selfmatchprefCtrl', ['getSessionSrvc', 'selfprofileSrvc', 'selfmatchprefSrvc', 'countryIntlSrv', '$scope', '$timeout', '$rootScope','$filter', function (getSessionSrvc, selfprofileSrvc, selfmatchprefSrvc, countryIntlSrv, $scope, $timeout, $rootScope, $filter) {
    var vm = this;
    //=====================================**************************************==================================   
    vm.onFinishMPload = function () {
        selfmatchprefae();
    };

    function selfmatchprefae() {
        $(document).ready(function () {
            //if navigation exists
            if ($("#matchprefnav").length > 0) {
                //make all submenus invisible on load
                $("#matchprefnav .nvanc+.nvdrpdwn").attr('style', 'display:none');
                //make all tabs data invisible on load
                $("#matchprefnavtab div[id^='nvanc']").attr('style', 'display:none');

                //click for the main menu which is having submenu
                $("#matchprefnav .nvanc").on("click", function () {
                    //alert("nvanc");
                    //add active class for clicked one
                    $(this).addClass('active');
                    //remove active class for all (mainmenu which is having submenu) except clicked one
                    $("#matchprefnav .nvanc").not(this).removeClass('active');
                    //slide up all (mainmenu which is having submenu) except clicked one
                    $("#matchprefnav .nvanc").not(this).next().slideUp(500);
                    //slide down active one (mainmenu which is having submenu) - expand
                    $(this).next().slideToggle(500);
                });

                //direct links (tab data link ex:personality traits,hobbies) main menu links click 
                $("#matchprefnav a[data-type='ml']").click(function () {
                    //collapse all submenu
                    $("#matchprefnav .nvanc").next().slideUp(500);
                    //removing active class for all submenu
                    $("#matchprefnav .nvanc").removeClass('active');
                });

                //click for links (tab data links)
                $("#matchprefnav a[id^='nvanc']").click(function () {
                    //getting cliked one id
                    var ancId = $(this).attr('id');
                    activeMatchPrefTab(ancId);
                })

                $("a[data-matchPrefTab^='nvanc']").click(function () {
                    activeMatchPrefTab($(this).attr('data-matchPrefTab'));
                });

                function activeMatchPrefTab(ancId) {
                    //saving the previous tab data before activating the current tab active
                    SaveActiveTabData();
                    //maintaining active tab id in the hidden field
                    $("#hndMPActiveTab").val(ancId);

                    //in next and back buttons the sub menu may not opened for some times, this is the code to make it open.
                    //getting the submenu parent menu
                    var perentMenu = $("#matchprefnav #" + ancId).closest("ul[class='nvdrpdwn']").closest("li").children("a");
                    //checking its existance and it is closed then only we have to open for that checking active class and performing click.
                    if (perentMenu.length > 0 && !perentMenu.hasClass('active'))
                        perentMenu.click();
                    //end here

                    //add active class for clicked one
                    $("#matchprefnav #" + ancId).addClass('active');
                    //removing active class for links (tab data links)
                    $("#matchprefnav a[id^='nvanc']").not("#matchprefnav #" + ancId).removeClass('active');
                    //make all tabs data invisible 
                    $("#matchprefnavtab div[id^='nvanc']").attr('style', 'display:none');
                    //make clicked tab data visible 
                    $("#matchprefnavtab div[id='" + ancId + "dv']").attr('style', 'display:');
                    //for mobile hide the menu after clicking on link
                    if (window.outerWidth < 765) {
                        $("#matchprefnav").hide();
                        //make the toogle ready for open menu (not like cross)
                        $('#matchprefnavtoogle').addClass('collapsed');
                    }
                }

                //macking click the first one (for open the first submenu on load)
                $("#matchprefnav #firstprntanc").click();
                //for showing the first link data visible - raised the click event
                $("#matchprefnav #nvanc1").click();

                //for mobile
                if (window.outerWidth < 765) {
                    //make the navigation invisible on load
                    $("#matchprefnav").hide();
                    //for rotating the toogle
                    $('[data-toggle="offcanvas"]').click(function () {
                        $('#matchprefnavtoogle.navbar-toggle').toggleClass('collapsed');
                    });
                    //toogle clck
                    $('#matchprefnavtoogle.navbar-toggle').click(function () {
                        //if menu is already in invisible state make it visible else make it invisible
                        if ($("#matchprefnav").css("display") == "none") {
                            $("#matchprefnav").show(100);
                            //in iphone 6plus we are getting the data is compressing this will avoid that in else we remove this attr
                            $("#matchprefslider").attr("style", "width:400px;display:table-cell;");
                        }
                        else {
                            $("#matchprefnav").hide(100);
                            $("#matchprefslider").removeAttr("style");
                        }
                    });
                }


            }
        });
    }
    function SaveActiveTabData() {
        var activeTabId = $("#hndMPActiveTab").val();
        if (activeTabId != null && activeTabId != "") {
            if (vm.prefData) {
                //alert("Active Tab Id : " + activeTabId);
                if (activeTabId == "nvanc1") {
                    vm.btnAgeNext();
                } else if (activeTabId == "nvanc2") {
                    vm.btnDstnceNext();
                } else if (activeTabId == "nvanc3") {
                    vm.btnEtnctyNext();
                    vm.btnEtnctyBack();
                } else if (activeTabId == "nvanc4") {
                    vm.btnRlgnNxt();
                    vm.btnRlgnBack();
                } else if (activeTabId == "nvanc5") {
                    vm.btnAwNext();
                    vm.btnAwBack();
                } else if (activeTabId == "nvanc6") {
                    vm.RltnshpNext();
                } else if (activeTabId == "nvanc7") {
                    vm.btnEduNext();
                    vm.btnEduBack();
                } else if (activeTabId == "nvanc8") {
                    vm.btnHtNext();
                } else if (activeTabId == "nvanc9") {
                    vm.btnPrsnltyNext();
                    vm.btnPrsnltyBack();
                } else if (activeTabId == "nvanc10") {
                    vm.btnEyeClrNext();
                    vm.btnEyeClrBack();
                } else if (activeTabId == "nvanc11") {
                    vm.btnHairClrNext();
                    vm.btnHairClrBack();
                } else if (activeTabId == "nvanc12") {
                    vm.btnHghtNext();
                    vm.btnHghtBack();
                } else if (activeTabId == "nvanc13") {
                    vm.btnBldNext();
                } else if (activeTabId == "nvanc14") {
                    vm.btnDietNext();
                    vm.btnDietBack();
                } else if (activeTabId == "nvanc15") {
                    vm.btnSmkNext();
                    vm.btnSmkBack();
                } else if (activeTabId == "nvanc16") {
                    vm.btnDrnkNext();
                } else if (activeTabId == "nvanc17") {                    
                    vm.btnIRltnShpNext();
                } else if (activeTabId == "nvanc18") {                    
                    vm.btnPrfChildCntNext();
                } else if (activeTabId == "nvanc19") {
                    vm.btnPrefChildNext();
                } else if (activeTabId == "nvanc20") {
                    vm.btnPrfPetsCntNext();
                } else if (activeTabId == "nvanc21") {
                    vm.petsPrefNext();
                } else if (activeTabId == "nvanc22") {
                    vm.btnPrefLangNext();
                } else if (activeTabId == "nvanc23") {
                    vm.btnFmlyLangNext();
                    vm.btnFmlyLangBack();
                } else if (activeTabId == "nvanc24") {
                    vm.religiousNext();
                    vm.religiousBack();
                } else if (activeTabId == "nvanc25") {
                    vm.traditionalNext();
                } else if (activeTabId == "nvanc26") {
                    vm.mpHobbiesNxtG();
                }
            }
            vm.closeModalValue = "";
        }
    }
    //=====================================**************************************==================================
    // Getting memberId from session
    var mId = getSessionSrvc.p_mId();
    var genPref = getSessionSrvc.p_gndrp();

    //pyar units setting
    var units = getSessionSrvc.p_uts();
    vm.pyrUnits = pyrUntsTxt(units);
    //pyar units setting end

    vm.MatchSummaryClk = function () {
        //service for getting match preference information.
        getMpPrefDataExt1Data();
        $("#matchSummaryModal").modal("show");
    }

    function getMpPrefDataExt1Data() {
        if ($("#prefCnvtData").attr("data-prefCnvtData") == "Y") {
            selfmatchprefSrvc.getMpPrefDataExt1(vm.prefData, function (response, status) {
                if (response && status == 200) {
                    vm.MpPrefDataExt1 = response;
                    updateMatSumData();
                    $("#prefCnvtData").attr("data-prefCnvtData", "N");
                }
            });
        }
        else {
            updateMatSumData();
        }
    }


    function updateMatSumData() {
        var Ex1 = vm.MpPrefDataExt1;
        //About me Match summary  Data preparing Dynamically starts
        var AboutMeMSDataJSON = AboutMeMSFunc(Ex1.ethinicities, Ex1.religions, Ex1.AreaOfWork, Ex1.rsStatus, Ex1.HighestEduc, htInfoDlts(getSessionSrvc.p_cntryId(), vm.prefData));

        vm.AboutMeMSData = [];
        getJSonActiveData(AboutMeMSDataJSON, vm.AboutMeMSData);
        tblSplit(vm.AboutMeMSData, function (t1, t2) {
            vm.abtMeMSTblL1 = t1;
            vm.abtMeMSTblL2 = t2;
        });
        //About me Match summary Data preparing Dynamically End

        //My Appearence Match summary Data preparing Dynamically Starts
        vm.height = GetHeightValTxt(vm.prefData.minHeight, Ex1.MinHeight, vm.prefData.maxHeight, Ex1.MaxHeight);
        var MyApprnceMSDataJSON = MyApprnceMSFunc(Ex1.eyeColor, Ex1.hairColor, vm.height, Ex1.build, getSessionSrvc.p_gndrp())

        vm.MyApprnceMSData = [];
        getJSonActiveData(MyApprnceMSDataJSON, vm.MyApprnceMSData);
        tblSplit(vm.MyApprnceMSData, function (t1, t2) {
            vm.MyApprMSTblL1 = t1;
            vm.MyApprMSTblL2 = t2;
        });
        //My Appearence Match summary Data preparing Dynamically End
        var chldCount = petsCount = null;
        if (vm.prefData.childrenCnt) { chldCount = vm.prefData.childrenCnt - 1; } else { chldCount = vm.prefData.childrenCnt}        
        if (vm.prefData.petsCnt) { petsCount = vm.prefData.petsCnt - 1 } else { petsCount = vm.prefData.petsCnt; }
        if (chldCount == 5 || chldCount == "5") { chldCount = "+5"; }
        if (petsCount == 3 || petsCount == "3") { petsCount = "+3"; }
        
        //myLife style Match summary Data preparing Dynamically Starts          
        var LifeStyleMSDataJSON = LifeStyleMSFunc($filter, Ex1.diet, Ex1.Smoke, Ex1.Drink, Ex1.IdealRelationship, chldCount, Ex1.ChildrenPref, petsCount, Ex1.PetsPref,
            Ex1.lang, Ex1.familyLang, Ex1.Religious, Ex1.Traditional);

        vm.LifeStyleMSData = [];
        getJSonActiveData(LifeStyleMSDataJSON, vm.LifeStyleMSData);
        tblSplit(vm.LifeStyleMSData, function (t1, t2) {
            vm.LifeStyleMSArrTblL1 = t1;
            vm.LifeStyleMSArrTblL2 = t2;
        });
        //myLife style Match summary  Data preparing Dynamically End

        //updating location in matchsummary pop
        if (vm.prefData.locType) {
            if (vm.prefData.locType == 1) {
                vm.locRadiusTxtDisplay = vm.locRadiusTxt + " of my location";
                vm.lacnHd = true;
            }
            else if (vm.prefData.locType == 3) {
                if (vm.prefData.locationInfo != null)
                    if (getSessionSrvc.p_cntry() == vm.prefData.locationInfo["countryName"]) {
                        vm.locRadiusTxtDisplay = vm.locRadiusTxt + " of " + vm.prefData.locationInfo["cityName"] + ", " + vm.prefData.locationInfo["stateName"];
                    }
                    else {
                        vm.locRadiusTxtDisplay = vm.locRadiusTxt + " of " + vm.prefData.locationInfo["cityName"] + ", " + vm.prefData.locationInfo["stateName"] + ", " + vm.prefData.locationInfo["countryName"];
                    }
                vm.lacnHd = true;
            }
        }
        else {
            vm.lacnHd = false;
        }

        //dynamic classes for location.
        if (vm.minAge) { vm.npd = ""; vm.msmrypd = "msmrypd"; }
        else { vm.npd = "npd"; vm.msmrypd = ""; }
    }

    //Match Preference click event
    vm.MatchPreferenceClk = function () {
        getPrefData(function () {
            vm.locType = vm.prefData.locType;
            if (vm.locType == 1)
                vm.mylocation = false;
            else if (vm.locType == 3)
                vm.mylocation = true;
        });
        $('body').css('overflow', 'hidden');
        $('body').css('position', 'fixed'); 
    }


    //*****************************on page load getting preference data and stored in vm.prefData **************************************

    getPrefData(function () {
        //this func called here why because vm.prefData.locRadius is requeired for this fun
        mpDistanceFuncG(function (response) {
            // binding distance radius data           
            for (var i = 0; i < response.length; i++) {
                if (response[i].priority == vm.prefData.locRadius) {
                    var rds = response[i].priority == 6 ? (response[i].radius + "+") : response[i].radius;
                    vm.locRadiusTxt = "Within " + rds + " " + vm.pyrUnits;
                    vm.locRadsTxt = "Within " + rds + " " + vm.pyrUnits;
                    break;
                }
            }
            // binding distance radius data
            bindLcngForDtls();
            vm.ddlRadius = response;
        });

        vm.locRadius = vm.prefData.locRadius;
        vm.locType = vm.prefData.locType;
        if (vm.locType == 3) {
            vm.countryId = vm.prefData.countryId;
            vm.stateId = vm.prefData.stateId;
            vm.cityId = vm.prefData.cityId;
            vm.mylocation = true;
        }
        vm.minValue = vm.prefData.minHeight;
        vm.maxValue = vm.prefData.maxHeight;
        vm.htCntryId = vm.prefData.htCountry;
        vm.htStateId = vm.prefData.htState;
        vm.htCityId = vm.prefData.htCity;
    });

    //bind locking for gender and radius
    function bindLcngForDtls() {
        var gender = genPref == true ? "he" : "she";
        if (vm.minAge != null && vm.maxAge != null)
            vm.lcngAge = "Ages " + vm.minAge + "-" + vm.maxAge;
        else
            vm.lcngAge = "How old is " + gender + "?";

        if (vm.prefData.locRadius != null)
            vm.lckngRadius = vm.locRadiusTxt;
        else
            vm.lckngRadius = "Where is " + gender + "?";
    }
    //bind locking for gender and radius end here

    function getPrefData(callBackFun) {
        var attr = $("#dvMPData").attr("data-mpData");
        if ($("#dvMPData").attr("data-mpData") == "Y") {
            selfmatchprefSrvc.getMpPrefData(mId, function (response, status) {
                vm.prefData = response;
                vm.minAge = response.minAge;
                vm.maxAge = response.maxAge;
                vm.locRadius = vm.prefData.locRadius;
                vm.locType == vm.prefData.locType;
                vm.countryId = vm.prefData.countryId;
                vm.cityId = vm.prefData.cityId;
                vm.awId = vm.prefData.awId;
                vm.degreeId = vm.prefData.highestEdu;
                vm.htCntryId = vm.prefData.htCountry;
                vm.htStateId = vm.prefData.htState;
                vm.htCityId = vm.prefData.htCity;
                vm.minValue = vm.prefData.minHeight;
                vm.maxValue = vm.prefData.maxHeight;
                vm.smkHbt = vm.prefData.smoke;
                vm.drinkHbt = vm.prefData.drink;
                vm.idealReltshp = vm.prefData.idealRelationship;
                //vm.sliderValueChldrnCnt = vm.prefData.childrenCnt;
                if (vm.prefData.childrenCnt) { vm.sliderValueChldrnCnt = vm.prefData.childrenCnt - 1; } else { vm.sliderValueChldrnCnt = vm.prefData.childrenCnt }
                vm.childPref = vm.prefData.childrenPref;
                //vm.sliderValuePetsCnt = vm.prefData.petsCnt;
                if (vm.prefData.petsCnt) { vm.sliderValuePetsCnt = vm.prefData.petsCnt - 1 } else { vm.sliderValuePetsCnt = vm.prefData.petsCnt }
                vm.petsPrefval = vm.prefData.petsPref;
                vm.religiousval = vm.prefData.religious;
                vm.traditionalval = vm.prefData.traditional;
                vm.lat = vm.prefData.lat;
                vm.long = vm.prefData.long;
                vm.locRadiusDistance = vm.prefData.locRadiusDistance;
                vm.hmCityUnbind = false;

                $timeout(function () {
                    countryIntlSrv.BindIntelligence();
                }, 100);
                $("#dvMPData").attr("data-mpData", "N");
                getMpPrefDataExt1Data();
                callBackFun();
            });
        }
    }

    function mpDistanceFuncG(callBackBasicData) {
        selfmatchprefSrvc.prefRadius(function (response, status) {
            if (status == 200) {
                vm.radiusResponse = response;
                callBackBasicData(response);
            }
        });
    }

    //*****************************on page load getting preference data and stored in vm.prefData end here**************************************

    //based on prefered gender binding the images and his/her
    if (genPref == true) {
        vm.gndrPrefImg = "https://pccdn.pyar.com/pcimgs/hairClrM.png";
        vm.gndrPrefTxt = "he";
        vm.gndrPrefTxt2 = "his";
    }
    else {
        vm.gndrPrefImg = "https://pccdn.pyar.com/pcimgs/hairClrF.png";
        vm.gndrPrefTxt = "she";
        vm.gndrPrefTxt2 = "her";
    }
    //based on prefered gender binding the images and his/her end here

    //based on choosing distance location show and hide dropdowns and age validations

    function prepareRadiusString() {
        vm.locRadius = 1;
        for (var i = 0; i < vm.ddlRadius.length; i++) {
            if (vm.ddlRadius[i].priority == 1) {
                var rds = vm.ddlRadius[i].radius;
                vm.locRadsTxt = "Within " + rds + " " + vm.pyrUnits;
                $("#ampdst").html(vm.locRadsTxt);
                break;
            }
        }
    }
    vm.locationhide = function () {
        vm.mylocation = false;
        vm.locType = 1;
        if (vm.locRadius == null || vm.locRadius == "") {
            prepareRadiusString();
        }
    }
    vm.locationvisible = function () {
        vm.setMyLocDfaultCntry();
        vm.mylocation = true;
        //vm.countryName = "Country";
        vm.locType = 3;
        if (vm.locRadius == null || vm.locRadius == "") {
            prepareRadiusString();
        }
        countryIntlSrv.resetCountry("txtampdstcntryCity", "ampdstcntry");
    }
    vm.setRadius = function (locRadius) {
        vm.locRadius = locRadius;
        if (!vm.locType) {
            vm.locType = 1;
        }
    }
    vm.seDefaulttRadius = function () {
        vm.mylocation = false;
        vm.locType = null;
        vm.locRadius = null;
        vm.countryId = null;
        vm.stateId = null;
        vm.cityId = null;
        vm.lat = null;
        vm.long = null;
        vm.locRadiusDistance = null;
    }
    vm.ageCheck = function () {
        if (vm.minAge || vm.maxAge) {
            vm.minAge = parseInt(vm.minAge);
            vm.maxAge = parseInt(vm.maxAge);

            if (vm.minAge < 18 || vm.minAge > 99)
                vm.minAge = 18;

            if (vm.maxAge > 99 || vm.maxAge < 18)
                vm.maxAge = 99;

            if (vm.minAge > vm.maxAge) {
                var tempVal = vm.minAge;
                vm.minAge = vm.maxAge;
                vm.maxAge = tempVal;
            }
        }
    }
    //based on choosing distance location show and hide dropdowns and age validations end here

    //*****************************Age save data**************************************
    vm.btnAgeNext = function () {
        if ((vm.minAge != vm.prefData.minAge) || (vm.maxAge != vm.prefData.maxAge)) {
            setAge();
            selfmatchprefSrvc.prefAge(vm.minAge, vm.maxAge, function (response, status) {
                if (response == true && status == 200) {
                    vm.prefData.minAge = vm.minAge;
                    vm.prefData.maxAge = vm.maxAge;
                    //Using for updating Age in profile page
                    bindLcngForDtls();
                }
                else {
                    alert("age updation Failed");
                }
            });

        }
        vm.mpDistanceBind();
    }

    function setAge() {
        if ((!vm.minAge && vm.maxAge) || (!vm.maxAge && vm.minAge)) {
            if (!vm.minAge)
                vm.minAge = 18;
            else if (!vm.maxAge)
                vm.maxAge = 99;
        } else if (vm.minAge && vm.maxAge) {
            if (vm.minAge < 18)
                vm.minAge = 18;
            if (vm.maxAge > 99)
                vm.maxAge = 99;
        } else {
            vm.minAge = null;
            vm.maxAge = null;
        }
    }
    //*****************************Age save data end here************************************


    //*****************************Distance save data ************************************
    vm.mpDistanceBind = function () {
        if (vm.prefData.locType == 3) {
            vm.locType = 3;
            vm.mylocation = true;
            if (vm.prefData.countryId != null && vm.prefData.cityId != null)
                countryIntlSrv.BindCity('txtampdstcntryCity', 'ampdstcntry', vm.prefData.countryId, vm.prefData.cityId);
        } else if (vm.prefData.locType == 1) {
            vm.locType = 1;
            vm.mylocation = false;
        }
    }

    vm.btnDstnceNext = function () {
        for (var i = 0; i < vm.ddlRadius.length; i++) {
            if (vm.ddlRadius[i].priority == vm.locRadius) {
                var rds = vm.ddlRadius[i].radius;
                vm.locRadiusDistance = calculateRadius(units, rds);
            }
        }
        if (!((vm.locType == 3) && (!vm.countryId || !vm.cityId))) {
            selfmatchprefSrvc.prefDistance(vm.locRadius, vm.locType, vm.countryId, vm.stateId, vm.cityId, vm.lat, vm.long, vm.locRadiusDistance, function (response, status) {
                if (response == true && status == 200) {
                    if ($("#txtampdstcntryCity").val()) {
                        if (vm.prefData.locationInfo) {
                            vm.prefData.locationInfo["cityName"] = $("#txtampdstcntryCity").val().split(",")[0];
                            vm.prefData.locationInfo["stateName"] = $("#txtampdstcntryCity").val().split(",")[1];
                        }
                        else {
                            vm.prefData.locationInfo = [];
                            vm.prefData.locationInfo["cityName"] = $("#txtampdstcntryCity").val().split(",")[0];
                            vm.prefData.locationInfo["stateName"] = $("#txtampdstcntryCity").val().split(",")[1];
                        }
                    }
                    vm.prefData.locRadius = vm.locRadius;
                    vm.prefData.locType = vm.locType;
                    vm.prefData.countryId = vm.countryId;
                    vm.prefData.cityId = vm.cityId;
                    if (vm.countryId != null && vm.countriesDdl) {
                        for (var i = 0; i < vm.countriesDdl.length; i++) {
                            if (vm.countriesDdl[i].countryId == vm.countryId) {
                                //vm.countryName = vm.countriesDdl[i].countryName;
                                if ($("#txtampdstcntryCity").val()) {
                                    vm.prefData.locationInfo["countryName"] = vm.countriesDdl[i].countryName;
                                }
                            }
                        }
                    }
                    //else
                    //    vm.countryName = "";

                    //This loop is using for updating Radius in profile page & also in match summary popup
                    if (vm.prefData.locRadius != null) {
                        for (var i = 0; i < vm.ddlRadius.length; i++) {
                            if (vm.ddlRadius[i].priority == vm.prefData.locRadius) {
                                var rds = vm.ddlRadius[i].priority == 6 ? (vm.ddlRadius[i].radius + "+") : vm.ddlRadius[i].radius;
                                vm.locRadiusTxt = vm.lckngRadius = vm.locRadsTxt= "Within " + rds + " " + vm.pyrUnits;
                                //vm.locRadsTxt = vm.lckngRadius = "Within " + rds + " " + vm.pyrUnits;
                                break;
                            }
                        }
                    }
                    else {
                        var gender = genPref == true ? "he" : "she";
                        vm.lckngRadius = "Where is " + gender + "?";
                    }

                }
                else {
                    alert("distance updation Failed");
                }
            });
        } else {
            vm.setMyLocDfaultCntry();
            if (vm.prefData.locType == 3 && vm.prefData.countryId && vm.cityId) {
                vm.locType = 3;
                vm.countryId = vm.prefData.countryId;
                vm.cityId = vm.prefData.cityId;
                vm.mylocation = true;
                countryIntlSrv.BindCity("txtampdstcntryCity", "ampdstcntry", vm.prefData.countryId, vm.prefData.cityId);
            } else {
                vm.mylocation = false;
                vm.locType = 1;
                vm.prefData.locType = 1;
                vm.countryId = vm.prefData.countryId;
                vm.cityId = vm.prefData.cityId;
            }
            $("#txtampdstcntryCity").removeClass("eror");
            for (var i = 0; i < vm.radiusResponse.length; i++) {
                if (vm.radiusResponse[i].priority == vm.prefData.locRadius) {
                    var rds = vm.radiusResponse[i].priority == 6 ? (vm.radiusResponse[i].radius + "+") : vm.radiusResponse[i].radius;
                    vm.locRadsTxt = "Within " + rds + " " + vm.pyrUnits;
                    break;
                }
            }
        }
        vm.mpAboutFuncG();
        vm.mpEthnicitiesFuncG();
    }
    //*****************************Distance save data end here************************************



    //*****************************about dropdowns bind**************************************
    vm.mpAboutFuncG = function () {
        if ($("#ancAbout").attr("data-bindData") == "N") {
            selfprofileSrvc.StaticDropDownList(function (response, status) {
                vm.ethnicitiesDdl = response.Ethnicity;
                vm.religionsDdl = response.Religion;
                vm.areaofworksDdl = response.AreaOfWork;
                vm.RSStatusDdl = response.Status;
                vm.degreeDdl = response.Degree;
                vm.countriesDdl = response.Countries;
                $("#ancAbout").attr("data-bindData", "Y");
            });
        }

        if (vm.prefData.htCountry) {
            vm.htCntryId = vm.prefData.htCountry;
        }
    }
    //*****************************about dropdowns bind end here********************************************

    //*****************************Ethnicities insertion,Getting Starts**************************************

    vm.mpEthnicitiesFuncG = function () {
        vm.checkedMpECIds = [];
        //function for binding chekboxes based Ids
        BindCheckBoxIds(vm.prefData.ethinicities, vm.checkedMpECIds);
    }

    vm.btnRlgnBack = function () {
        vm.mpEthnicitiesFuncG();
    }

    vm.ethinyChkClick = function (Id) {
        //Function for Get checkbox clicked Ids
        GetClickedIds(vm.checkedMpECIds, Id);
    }

    vm.btnEtnctyNext = function () {
        var Ids = vm.checkedMpECIds.sort().join();
        if (!angular.equals(vm.prefData.ethinicities, Ids)) {
            selfmatchprefSrvc.EthnicitiesIU(mId, Ids, function (response, status) {
                if (status == 200 && response == true) {
                    var checkedMpEcName = [];
                    angular.forEach(vm.ethnicitiesDdl, function (data) {
                        if (vm.checkedMpECIds.indexOf(parseInt(data.ethnicityId)) !== -1) {
                            checkedMpEcName.push(data.ethnicityName);
                        }
                    });
                    vm.prefData.ethinicities = Ids;

                    vm.MpPrefDataExt1.ethinicities = [];
                    angular.forEach(checkedMpEcName, function (data) {
                        vm.MpPrefDataExt1.ethinicities.push({ txt: data });
                    });
                }
            });
        }
        vm.btnRlgnFuncG();
    }
    vm.btnEtnctyBack = function () {
        vm.mpDistanceBind();
    }

    //*****************************Ethnicities insertion,Getting Starts end here*************************************************


    //*****************************Religion Insertion, Getting data Starts********************************************************

    checkedmpRlgnName = [];
    vm.RlgnIdTostring = function () {
        return checkedmpRlgnName.join(",");
    };

    vm.btnRlgnFuncG = function (isLeft) {
        vm.checkedmpRlgnIds = [];
        checkedmpRlgnName = [];
        BindCheckBoxIds(vm.prefData.religions, vm.checkedmpRlgnIds);

        //for getting religion names
        angular.forEach(vm.religionsDdl, function (data) {
            if (vm.checkedmpRlgnIds.indexOf(data.religionId) !== -1)
                checkedmpRlgnName.push(" " + data.religionName);
        });

        vm.religionSelectd = checkedmpRlgnName.join(",");
        if (isLeft != "leftBtn" && vm.closeModalValue == "") {
            $scope.$digest();
        }

    }

    vm.RlgnIdFuncG = function (rlgnId) {
        var index = vm.checkedmpRlgnIds.indexOf(rlgnId);
        if (index == -1) {
            vm.checkedmpRlgnIds.splice(0, 0, rlgnId);
            for (var i = 0; i < vm.religionsDdl.length; i++) {
                if (vm.religionsDdl[i].religionId == rlgnId) {
                    checkedmpRlgnName.splice(0, 0, " " + vm.religionsDdl[i].religionName);
                    vm.religionSelectd = checkedmpRlgnName.join(",");
                    break;
                }
            }
        }
        else {
            vm.checkedmpRlgnIds.splice(index, 1);
            checkedmpRlgnName.splice(index, 1);
            vm.religionSelectd = checkedmpRlgnName.join(",");
        }
    }


    vm.noRlgnPref = function () {
        vm.checkedmpRlgnIds = [];
        checkedmpRlgnName = [];
        vm.RlgnIdTostring();
        vm.religionSelectd = "";
    }

    //Saving Data
    vm.btnRlgnNxt = function () {
        var Ids = vm.checkedmpRlgnIds.sort().join();
        if (!angular.equals(vm.prefData.religions, Ids)) {
            selfmatchprefSrvc.ReligionsIU(mId, Ids, function (response, status) {
                if (status == 200 && response == true) {
                    var checkedMpRlngName = [];
                    angular.forEach(vm.religionsDdl, function (data) {
                        if (vm.checkedmpRlgnIds.indexOf(data.religionId) !== -1) {
                            checkedMpRlngName.push(data.religionName);
                        }
                    });

                    vm.prefData.religions = Ids;

                    vm.MpPrefDataExt1.religions = [];
                    angular.forEach(checkedMpRlngName, function (data) {
                        vm.MpPrefDataExt1.religions.push({ txt: data });
                    });
                }
            });
        }
    }

    //*****************************Religion Insertion, Getting data End***********************************************************



    //*****************************Area of work insertion data*******************************************************************
    vm.awIdFunc = function (Id) {
        vm.awId = Id;
    }

    vm.btnAwNext = function () {
        if (!angular.equals(vm.prefData.awId, vm.awId)) {
            selfmatchprefSrvc.prefAreaOfWork(vm.awId, function (response, status) {
                if (response == true && status == 200) {
                    vm.prefData.awId = vm.awId;
                    vm.MpPrefDataExt1.AreaOfWork = "";
                    for (var i = 0; i < vm.areaofworksDdl.length; i++) {
                        if (vm.areaofworksDdl[i].awId == vm.prefData.awId) {
                            vm.MpPrefDataExt1.AreaOfWork = vm.areaofworksDdl[i].awName;
                            break;
                        }
                    }
                }
            })
        }
        vm.mpRSStatusFuncG();
    }

    vm.btnAwBack = function () {
        vm.btnRlgnFuncG();
    }
    //*****************************Area of work insertion data end here******************************************************************


    //*****************************Relationship status insertion,Getting Starts**********************************************************
    vm.mpRSStatusFuncG = function () {
        vm.checkedMpRSIds = [];
        BindCheckBoxIds(vm.prefData.rsStatus, vm.checkedMpRSIds);
    }

    vm.rsChkClick = function (Id) {
        GetClickedIds(vm.checkedMpRSIds, Id);
    }

    vm.rltnChecked = function (rltnVal) {
        if (vm.MpPrefDataExt1.rsStatus) {
            return vm.MpPrefDataExt1.rsStatus.some(function (item) {
                return item.txt === rltnVal;
            });
        }

    }
    vm.ethinyChkd = function (ethnVal) {
        if (vm.MpPrefDataExt1.ethinicities)
            return vm.MpPrefDataExt1.ethinicities.some(function (item) {
                return item.txt === ethnVal;
            });
    }
    vm.mpPrsnltyChkd = function (prsnlty) {
        if (vm.MpPrefDataExt1.pt)
            return vm.MpPrefDataExt1.pt.some(function (item) {
                return item.txt === prsnlty;
            });
    }
    vm.eyeChkd = function (eyeChkd) {
        if (vm.MpPrefDataExt1.eyeColor)
            return vm.MpPrefDataExt1.eyeColor.some(function (item) {
                return item.txt === eyeChkd;
            });
    }
    vm.hairChkd = function (hairChkd) {
        if (vm.MpPrefDataExt1.hairColor)
            return vm.MpPrefDataExt1.hairColor.some(function (item) {
                return item.txt === hairChkd;
            });
    }
    vm.buildChkd = function (build) {
        if (vm.MpPrefDataExt1.build)
            return vm.MpPrefDataExt1.build.some(function (item) {
                return item.txt === build;
            });
    }
    vm.dietChkd = function (diet) {
        if (vm.MpPrefDataExt1.diet)
            return vm.MpPrefDataExt1.diet.some(function (item) {
                return item.txt === diet;
            });
    }
    vm.hobbyChkd = function (hobby) {
        if (vm.MpPrefDataExt1.hobbies)
            return vm.MpPrefDataExt1.hobbies.some(function (item) {
                return item.txt.toLowerCase() === hobby.toLowerCase();
            });
    }

    vm.RltnshpNext = function () {
        var Ids = vm.checkedMpRSIds.sort().join();
        if (!angular.equals(vm.prefData.rsStatus, Ids)) {
            selfmatchprefSrvc.RSStatusIU(mId, Ids, function (response, status) {
                if (status = 200 && response == true) {
                    //before updating view, clear data in this object
                    vm.MpPrefDataExt1.rsStatus = [];
                    //Updating view
                    MultiUpdate(vm.RSStatusDdl, vm.checkedMpRSIds, vm.MpPrefDataExt1.rsStatus);
                    //updating checked Ids
                    vm.prefData.rsStatus = Ids;
                }
            });
        }
    }
    //*****************************Relationship status insertion,Getting Starts end here********************

    //*****************************Education  insertion data*************************************************
    vm.degreeIdFunc = function (Id) {
        vm.degreeId = Id;
    }

    vm.btnEduNext = function () {
        if (!angular.equals(vm.prefData.highestEdu, vm.degreeId)) {
            selfmatchprefSrvc.prefEducation(vm.degreeId, function (response, status) {
                if (response == true && status == 200) {
                    vm.prefData.highestEdu = vm.degreeId;
                    vm.MpPrefDataExt1.HighestEduc = "";
                    for (var i = 0; i < vm.degreeDdl.length; i++) {
                        if (vm.degreeDdl[i].val == vm.prefData.highestEdu) {
                            vm.MpPrefDataExt1.HighestEduc = vm.degreeDdl[i].txt;
                            break;
                        }
                    }
                }
            });
        }
        vm.homeTownClick();
    }

    vm.btnEduBack = function () {
        vm.mpRSStatusFuncG();
    }
    //*****************************Education  insertion data end here*************************************************

    //*****************************Hometown  insertion data **********************************************************

    vm.homeTownClick = function () {
        if (vm.prefData.htCountry != null && vm.prefData.htCity != null)
            countryIntlSrv.BindCity('txtamphtwnCity', 'amphtwn', vm.prefData.htCountry, vm.prefData.htCity);
        else
            $("#amphtwn").html('Country');
        vm.htCntryId = vm.prefData.htCountry;
        vm.htStateId = vm.prefData.htState;
        vm.htCityId = vm.prefData.htCity;
    }

    vm.btnHtNext = function () {
        if (vm.hmCityUnbind == false) {
            selfmatchprefSrvc.prefHometown(vm.htCntryId, vm.htStateId, vm.htCityId, function (response, status) {
                if (response == true && status == 200) {
                    if ($("#txtamphtwnCity").val()) {
                        vm.prefData.htInfo = {};
                        vm.prefData.htInfo["cityName"] = $("#txtamphtwnCity").val().split(",")[0];
                        vm.prefData.htInfo["stateName"] = $("#txtamphtwnCity").val().split(",")[1];
                    }
                    if (vm.htCntryId == null) { vm.prefData.htInfo = null; }

                    vm.prefData.htCountry = vm.htCntryId;
                    vm.prefData.htState = vm.htStateId;
                    vm.prefData.htCity = vm.htCityId;
                    for (var i = 0; i < vm.countriesDdl.length; i++) {
                        if (vm.countriesDdl[i].countryId == vm.prefData.htCountry) {
                            vm.MpPrefDataExt1.HTCountry = vm.countriesDdl[i].countryName;
                            if ($("#txtamphtwnCity").val()) {
                                vm.prefData.htInfo["countryName"] = vm.countriesDdl[i].countryName;
                            }
                            break;
                        }
                    }
                }
            });
        } else {
            vm.htCntryId = vm.prefData.htCountry;
            vm.htStateId = vm.prefData.htState;
            vm.htCityId = vm.prefData.htCity;
            vm.sethmLctDfaultCntry();
            $("#txtamphtwnCity").removeClass("eror");
            $("#amphtwn").val("Country");
        }
        vm.mpPersonalityTraitsFuncG();
    }

    //*****************************Hometown  insertion data end here**************************************************


    //*****************************PERSONALITY dropdowns bind and insertion,Getting Starts ***************************

    vm.mpPersonalityTraitsFuncG = function () {
        if ($("#nvanc9dv").attr("data-mpData") == "N") {
            selfprofileSrvc.PrsnltyTraitsListG(function (response) {
                var result = {};
                var key = 'ptcId';
                for (var i = 0; i < response.length; i++) {
                    if (!result[response[i][key]]) {
                        result[response[i][key]] = [];
                    }
                    result[response[i][key]].push(response[i])
                }
                vm.PrsnltyTraitsList = result;
                vm.ptraits = response;
            });
            $("#nvanc9dv").attr("data-mpData", "Y");
        }

        vm.checkedMpPTIds = [];
        BindCheckBoxIds(vm.prefData.pt, vm.checkedMpPTIds);
    }

    vm.mpPrsnltyChkClick = function (Id) {
        GetClickedIds(vm.checkedMpPTIds, Id);
    }

    vm.btnPrsnltyNext = function () {
        var Ids = vm.checkedMpPTIds.sort().join();
        if (!angular.equals(vm.prefData.pt, Ids)) {
            selfmatchprefSrvc.PersonalityTraitsIU(mId, Ids, function (response, status) {

                if (status == 200 && response == true) {
                    vm.MpPrefDataExt1.pt = [];
                    vm.checkedMpPTIds.forEach(function (val) {
                        vm.MpPrefDataExt1.pt.push({ txt: getPtTxt(val) });
                    });

                    function getPtTxt(val) {
                        var ptTxt = '';
                        vm.ptraits.forEach(function (data) {
                            if (data.ptId == val) {
                                ptTxt = data.personalityName;
                            }
                        });
                        return ptTxt;
                    }
                    //updating personality trait Ids
                    vm.prefData.pt = Ids;
                }
            });
        }
        vm.mpAppearanceFuncG();
        vm.mpEyeColourFuncG();
    }

    vm.btnPrsnltyBack = function () {
        vm.homeTownClick();
        if (vm.prefData.htCountry) {
            vm.htCntryId = vm.prefData.htCountry;
        }
    }

    //*****************************PERSONALITY dropdowns bind and insertion,Getting Starts end here**************************************



    //*****************************APPEARANCE dropdowns bind **************************************    
    vm.mpAppearanceFuncG = function () {
        if ($("#ancAppearance").attr("data-bindData") == "N") {
            selfprofileSrvc.ddlsMyAppearence(function (response, status) {
                vm.build = response.build;
                vm.MinHeightddl = response.height;
                vm.MaxHeightddl = response.height;
                // binding distance radius data
                for (var i = 0; i < response.height.length; i++) {
                    if (response.height[i].val == vm.prefData.maxHeight) {
                        vm.maxHeight = response.height[i].txt;
                        vm.maxValue = response.height[i].val;
                    }
                    if (response.height[i].val == vm.prefData.minHeight) {
                        vm.minHeight = response.height[i].txt;
                        vm.minValue = response.height[i].val;
                    }
                }
                // binding distance radius data
                vm.eyecolor = response.eyecolor;
                vm.haircolor = response.haircolor;

                vm.limitMaxVal = vm.MinHeightddl.length - vm.minValue;
                vm.limitMinVal = ((vm.MaxHeightddl.length) - (vm.MaxHeightddl.length - vm.maxValue)) - 1;
                if (vm.limitMinVal == -1) {
                    vm.limitMinVal = vm.MaxHeightddl.length;
                }
                $("#ancAppearance").attr("data-bindData", "Y");
            });
        }
    }
    //*****************************APPEARANCE dropdowns bind end here**************************************


    //*****************************Eye Color insertion And Getting Starts **************************************    

    vm.mpEyeColourFuncG = function () {
        vm.checkedmpEyeClrIds = [];
        BindCheckBoxIds(vm.prefData.eyeColor, vm.checkedmpEyeClrIds);
    }

    vm.eyeChkClick = function (Id) {
        GetClickedIds(vm.checkedmpEyeClrIds, Id);
    };

    vm.btnEyeClrNext = function () {
        if (vm.checkedmpEyeClrIds) {
            var Ids = vm.checkedmpEyeClrIds.sort().join();
            if (!angular.equals(vm.prefData.eyeColor, Ids)) {
                selfmatchprefSrvc.EyeColourIU(mId, Ids, function (response, status) {
                    if (status == 200 && response == true) {
                        vm.MpPrefDataExt1.eyeColor = [];
                        MultiUpdate(vm.eyecolor, vm.checkedmpEyeClrIds, vm.MpPrefDataExt1.eyeColor);
                        vm.prefData.eyeColor = Ids;
                    }
                });
            }
        }
        vm.mpHairColourFuncG();
    }

    vm.btnEyeClrBack = function () {
        vm.mpPersonalityTraitsFuncG();
    }

    //*****************************Eye Color insertion And Getting Starts end here**************************************    


    //*****************************Hair Color insertion And Getting Starts **************************************        
    vm.mpHairColourFuncG = function () {
        vm.checkedmpHcIds = [];
        BindCheckBoxIds(vm.prefData.hairColor, vm.checkedmpHcIds);
    }
    vm.btnHghtBack = function () {
        vm.mpHairColourFuncG();
    }

    vm.hairChkClick = function (Id) {
        GetClickedIds(vm.checkedmpHcIds, Id);
    }

    vm.btnHairClrNext = function () {
        if (vm.checkedmpHcIds) {
            var Ids = vm.checkedmpHcIds.sort().join();
            if (!angular.equals(vm.prefData.hairColor, Ids)) {
                selfmatchprefSrvc.HairColourIU(mId, Ids, function (response, status) {
                    if (status == 200 && response == true) {
                        vm.MpPrefDataExt1.hairColor = [];
                        MultiUpdate(vm.haircolor, vm.checkedmpHcIds, vm.MpPrefDataExt1.hairColor);
                        vm.prefData.hairColor = Ids;
                    }
                });
            }
        }
    }

    vm.btnHairClrBack = function () {
        vm.mpEyeColourFuncG();
    }

    //*****************************Hair Color insertion And Getting Starts end here*************************


    //*****************************Height insertion data****************************************************

    //minmum Height
    vm.setMinHeight = function (minHeight, txt) {
        vm.minValue = minHeight;

        if (vm.limitMaxVal == 0 && vm.limitMinVal == 0) {
            vm.limitMaxVal = vm.MaxHeightddl.length;
            vm.limitMinVal = vm.MinHeightddl.length;
        }

        if (vm.limitMaxVal == 0 || vm.limitMaxVal == undefined) { vm.limitMaxVal = vm.MinHeightddl.length; }
        else {
            vm.limitMaxVal = vm.MinHeightddl.length - minHeight;
        }

        for (var i = 0; i < vm.MinHeightddl.length; i++) {
            if (minHeight == vm.MinHeightddl[i].val) {
                vm.minHeight = vm.MinHeightddl[i].txt;
            }
        }
    }

    //maximum Height
    vm.setMaxHeight = function (maxHeight, txt) {
        vm.maxValue = maxHeight;
        if (vm.limitMaxVal == 0 && vm.limitMinVal == 0) {
            vm.limitMaxVal = vm.MaxHeightddl.length;
            vm.limitMinVal = vm.MinHeightddl.length;
        }

        if (vm.limitMinVal == 0 || vm.limitMinVal == undefined) { vm.limitMinVal = vm.MaxHeightddl.length; }
        else {
            vm.limitMinVal = (vm.MaxHeightddl.length) - (vm.MaxHeightddl.length - maxHeight) - 1;
        }
        if (vm.limitMinVal == -1) {
            vm.limitMinVal = vm.MaxHeightddl.length;
        }

        for (var i = 0; i < vm.MaxHeightddl.length; i++) {
            if (maxHeight == vm.MaxHeightddl[i].val) {
                vm.maxHeight = vm.MaxHeightddl[i].txt;
            }
        }
    }

    vm.btnHghtNext = function () {
        selfmatchprefSrvc.prefHeight(vm.minValue, vm.maxValue, function (response, status) {
            if (status == 200) {
                vm.prefData.minHeight = vm.minValue;
                vm.prefData.maxHeight = vm.maxValue;

                for (var i = 0; i < vm.MaxHeightddl.length; i++) {
                    if (vm.MaxHeightddl[i].val == vm.minValue) {
                        vm.MpPrefDataExt1.MinHeight = vm.MaxHeightddl[i].txt;
                    }
                    if (vm.MaxHeightddl[i].val == vm.maxValue) {
                        vm.MpPrefDataExt1.MaxHeight = vm.MaxHeightddl[i].txt;
                    }
                }
            }
        });

        vm.mpBuildFuncG();
    }
    //*****************************Height insertion data end here********************************************


    //*****************************Build insertion And Getting Starts ***************************************              

    vm.mpBuildFuncG = function () {
        vm.checkedmpBldIds = [];
        BindCheckBoxIds(vm.prefData.build, vm.checkedmpBldIds);
    }

    vm.buildChkClick = function (Id) {
        GetClickedIds(vm.checkedmpBldIds, Id);
    }

    vm.btnBldNext = function () {
        var Ids = vm.checkedmpBldIds.sort().join();
        if (!angular.equals(vm.prefData.build, Ids)) {
            selfmatchprefSrvc.BuildIU(mId, Ids, function (response, status) {
                if (status == 200 && response == true) {
                    vm.MpPrefDataExt1.build = [];
                    MultiUpdate(vm.build, vm.checkedmpBldIds, vm.MpPrefDataExt1.build);
                    vm.prefData.build = Ids;
                }
            });
        }
        vm.mpLifeStylesFuncG();
        vm.mpDietFuncG();
    }

    //*****************************Build insertion And Getting Starts end here**************************************               



    //*****************************LifeStyles bind dropdowns Getting Starts of some sub modules**************************************               

    function mpLifeStylesDataFuncG() {
        if ($("#ancLifeStyle").attr("data-bindData") == "N") {
            selfprofileSrvc.ddlsMyLifeStyleDDlData(function (response, status) {
                vm.dietDdl = response.diet;
                vm.smokeDdl = response.smoke;
                vm.drinkDdl = response.drink;
                vm.idealRelationshipDdl = response.IdealRelationShip;
                vm.childCntDdl = response.numOfChildren;
                vm.childrenPrefDdl = response.childrenPref;
                vm.petsCntDdl = response.numOfPets;                
                vm.petsPrefDdl = response.petPref;
                vm.langPrefDdl = response.language;
                vm.familyLangDdl = response.language;
                vm.religiousDdl = response.Religious;
                vm.traditionalDdl = response.traditional;
                if (vm.religiousDdl) {
                    for (var i = 0; i < vm.religiousDdl.length; i++) {
                        if (vm.religiousDdl[i].val == vm.prefData.religious) {
                            vm.ReligiousText = vm.religiousDdl[i].txt;
                            break;
                        }
                    }
                }
                $("#ancLifeStyle").attr("data-bindData", "Y");
            });
        }
    }

    vm.mpLifeStylesFuncG = function () {
        mpLifeStylesDataFuncG();

        //setting child & Pet count values
        if (vm.prefData.childrenCnt == null) { vm.resetChldCnt(); }
        else {
            if (vm.prefData.childrenCnt) { vm.sliderValueChldrnCnt = vm.prefData.childrenCnt - 1; } else { vm.sliderValueChldrnCnt = vm.prefData.childrenCnt }
        }
        if (vm.prefData.petsCnt) { vm.sliderValuePetsCnt = vm.prefData.petsCnt - 1 } else { vm.sliderValuePetsCnt = vm.prefData.petsCnt }
        if (!vm.prefData.petsCnt)
            vm.isChkPetsrnCnt = true;
    }

    //*****************************LifeStyles bind dropdowns end here************************************** 

    //*****************************Diet binding starts and save data************************************** 

    vm.mpDietFuncG = function () {
        vm.checkedmpDtIds = [];
        BindCheckBoxIds(vm.prefData.diet, vm.checkedmpDtIds);
    }

    vm.dietChkClick = function (Id) {
        GetClickedIds(vm.checkedmpDtIds, Id);
    }

    vm.btnDietNext = function () {
        var Ids = vm.checkedmpDtIds.sort().join();
        if (!angular.equals(vm.prefData.diet, Ids)) {
            selfmatchprefSrvc.DietIU(mId, Ids, function (response, status) {
                if (status == 200 && response == true) {
                    vm.MpPrefDataExt1.diet = [];
                    MultiUpdate(vm.dietDdl, vm.checkedmpDtIds, vm.MpPrefDataExt1.diet);
                    vm.prefData.diet = Ids;
                }
            });
        }
    }

    vm.btnDietBack = function () {
        vm.mpBuildFuncG();
        vm.mpAppearanceFuncG();
    }

    //*****************************Diet binding starts and save data end here************************************** 


    //*****************************Smoking save data***************************************************************
    vm.setSmkHbt = function (smkHbt) {
        vm.smkHbt = smkHbt;
    }
    vm.btnSmkNext = function () {
        if (!angular.equals(vm.prefData.smoke, vm.smkHbt)) {
            selfmatchprefSrvc.prefSmoking(vm.smkHbt, function (response, status) {
                if (status == 200 && response == true) {
                    vm.prefData.smoke = vm.smkHbt;
                    vm.MpPrefDataExt1.Smoke = "";
                    for (var i = 0; i < vm.smokeDdl.length; i++) {
                        if (vm.smokeDdl[i].val == vm.prefData.smoke) {
                            vm.MpPrefDataExt1.Smoke = vm.smokeDdl[i].txt;
                            break;
                        }
                    }
                }
            });
        }
    }

    vm.btnSmkBack = function () {
        vm.btnSmkNext();
        vm.mpDietFuncG();
    }
    //*****************************Smoking save data end here******************************************************



    //*****************************Drinking save data **************************************************************
    vm.drinkhabit = function (drinkHbt) {
        vm.drinkHbt = drinkHbt;
    }
    vm.btnDrnkNext = function () {
        if (!angular.equals(vm.prefData.drink, vm.drinkHbt)) {
            selfmatchprefSrvc.prefDrinking(vm.drinkHbt, function (response, status) {
                if (status == 200 && response == true) {
                    vm.prefData.drink = vm.drinkHbt;
                    vm.MpPrefDataExt1.Drink = "";
                    for (var i = 0; i < vm.drinkDdl.length; i++) {
                        if (vm.drinkDdl[i].val == vm.prefData.drink) {
                            vm.MpPrefDataExt1.Drink = vm.drinkDdl[i].txt;
                            break;
                        }
                    }
                }
            });
        }
    }

    //*****************************Drinking save data end here******************************************************



    //*****************************Ideal relationship save data ******************************************************
    vm.setIdealReltshp = function (idealReltshp) {
        vm.idealReltshp = idealReltshp;
    }

    vm.btnIRltnShpNext = function () {
        if (!angular.equals(vm.prefData.idealRelationship, vm.idealReltshp)) {
            selfmatchprefSrvc.prefRelationship(vm.idealReltshp, function (response, status) {
                if (status == 200 && response == true) {
                    vm.prefData.idealRelationship = vm.idealReltshp;
                    vm.MpPrefDataExt1.IdealRelationship = "";
                    for (var i = 0; i < vm.idealRelationshipDdl.length; i++) {
                        if (vm.idealRelationshipDdl[i].val == vm.prefData.idealRelationship) {
                            vm.MpPrefDataExt1.IdealRelationship = vm.idealRelationshipDdl[i].txt;
                            break;
                        }
                    }
                }
            });
        }
    }
    //*****************************Ideal relationship save data end here******************************************************


    //*****************************Number of children save data **************************************************************

    //CHILDREN SLIDER MODULE    
    var ticksChldrnCnt = [0, 1, 2, 3, 4, 5];

    vm.sliderTicksChldrnCnt = function () {
        return ticksChldrnCnt;
    }
    vm.myFormatterChldrnCnt = function (value) {        
        return value;
    }
    vm.resetChldCnt = function () {
        vm.isChkChldrnCnt = true;
        vm.sliderValueChldrnCnt = null;
    }
    vm.sldrChlClk = function () {
        vm.isChkChldrnCnt = false;
        if (vm.sliderValueChldrnCnt == null)
            vm.sliderValueChldrnCnt = 0;
    }
    //CHILDREN SLIDER MODULE END


    vm.btnPrfChildCntNext = function () {        
        var sldrVal = null;
        if (vm.sliderValueChldrnCnt == 5 || vm.sliderValueChldrnCnt == "5")
            sldrVal = 6;
        else {
            for (var i = 0; i < vm.childCntDdl.length; i++) {
                if (vm.sliderValueChldrnCnt == vm.childCntDdl[i].txt) {
                    sldrVal = vm.childCntDdl[i].val;
                    break;
                }
            }
        }

        if (!angular.equals(vm.prefData.childrenCnt, sldrVal)) {
            selfmatchprefSrvc.prefChildrenCnt(sldrVal, function (response, status) {                
                if (status == 200 && response == true) {                    
                    vm.prefData.childrenCnt = sldrVal;                    
                }
            });
        }
    }
    //*****************************Number of children save data end here******************************************************


    //*****************************Child preference save data **************************************************************
    vm.setChildPref = function (childPref) {
        vm.childPref = childPref;
    }

    vm.btnPrefChildNext = function () {
        if (!angular.equals(vm.prefData.childrenPref, vm.childPref)) {
            selfmatchprefSrvc.prefChildren(vm.childPref, function (response, status) {
                if (status == 200 && response == true) {
                    vm.prefData.childrenPref = vm.childPref;
                    vm.MpPrefDataExt1.ChildrenPref = "";
                    for (var i = 0; i < vm.childrenPrefDdl.length; i++) {
                        if (vm.childrenPrefDdl[i].val == vm.prefData.childrenPref) {
                            vm.MpPrefDataExt1.ChildrenPref = vm.childrenPrefDdl[i].txt;
                            break;
                        }
                    }
                }
            });
        }
    }

    //*****************************Child preference save data end here******************************************************



    //*****************************Number of pets save data **************************************************************

    //PETS SLIDER MODULE    
    var ticksPetsCnt = [0, 1, 2, 3];
    vm.sliderTicksPetsCnt = function () {
        return ticksPetsCnt;
    }
    vm.myFormatterPetsCnt = function (value) {
        return value;
    }
    vm.resetPetsCnt = function () {
        vm.sliderValuePetsCnt = null;
        vm.isChkPetsrnCnt = true;
    }
    vm.sldrPetsCnt = function () {
        vm.isChkPetsrnCnt = false;
        if (vm.sliderValuePetsCnt == null)
            vm.sliderValuePetsCnt = 0;
    }
    //PETS SLIDER MODULE END

    vm.btnPrfPetsCntNext = function (val) {
        var sldrVal = null;
        if (vm.sliderValuePetsCnt == 3 || vm.sliderValuePetsCnt == "3")
            sldrVal = 4;
        else {
            for (var i = 0; i < vm.petsCntDdl.length; i++) {
                if (vm.sliderValuePetsCnt == vm.petsCntDdl[i].txt) {
                    sldrVal = vm.petsCntDdl[i].val;
                    break;
                }
            }
        }        
        if (!angular.equals(vm.prefData.petsCnt, sldrVal)) {
            selfmatchprefSrvc.prefPets(sldrVal, function (response, status) {
                if (status == 200 && response == true) {
                    vm.prefData.petsCnt = sldrVal;
                }
            });
        }
    }
    //*****************************Number of pets save data end here******************************************************


    //*****************************Pet preference save data **************************************************************
    vm.petsPrefId = function (val) {
        vm.petsPrefval = val;
    }

    vm.petsPrefNext = function () {
        if (!angular.equals(vm.prefData.petsPref, vm.petsPrefval)) {
            selfmatchprefSrvc.prefPetPref(vm.petsPrefval, function (response, status) {
                if (status == 200 && response == true) {
                    vm.prefData.petsPref = vm.petsPrefval;
                    vm.MpPrefDataExt1.PetsPref = "";
                    for (var i = 0; i < vm.petsPrefDdl.length; i++) {
                        if (vm.petsPrefDdl[i].val == vm.prefData.petsPref) {
                            vm.MpPrefDataExt1.PetsPref = vm.petsPrefDdl[i].txt;
                            break;
                        }
                    }
                }
            });
        }
        vm.btnPrefLangFuncG();
    }

    //*****************************Pet preference save data end here******************************************************





    //*****************************Prefered language save data end here******************************************************


    //Prefered langauges    
    vm.checkedmpPrefLangIds = [];
    checkedmpPrefLangName = [];

    //displaying array in html view
    vm.PrefLangIdTostring = function () {
        return checkedmpPrefLangName.join(", ");
    };

    vm.btnPrefLangFuncG = function (isLeft) {
        vm.checkedmpPrefLangIds = [];
        checkedmpPrefLangName = [];

        BindCheckBoxIds(vm.prefData.lang, vm.checkedmpPrefLangIds);

        //Get checked Langauges Text        
        angular.forEach(vm.langPrefDdl, function (data) {
            if (vm.checkedmpPrefLangIds.indexOf(data.val) !== -1)
                checkedmpPrefLangName.push(" " + data.txt);
        });
        vm.preferedLang = checkedmpPrefLangName.join(", ");
        if (isLeft != "leftBtn" && vm.closeModalValue == "") {
            $scope.$digest();
        }

    }

    vm.PrefLangClick = function (langId) {
        GetIdWithName(vm.langPrefDdl, vm.checkedmpPrefLangIds, checkedmpPrefLangName, langId);
        vm.preferedLang = checkedmpPrefLangName.join(", ");
    }

    vm.noPrefLangPref = function () {
        vm.checkedmpPrefLangIds = [];
        checkedmpPrefLangName = [];
        vm.PrefLangIdTostring();
        vm.preferedLang = "";
    }


    vm.btnPrefLangNext = function () {
        var Ids = vm.checkedmpPrefLangIds.sort().join();
        if (!angular.equals(vm.prefData.lang, Ids)) {
            selfmatchprefSrvc.LanguagesIU(mId, Ids, function (response, status) {
                if (status == 200 && response == true) {
                    vm.MpPrefDataExt1.lang = [];
                    MultiUpdate(vm.langPrefDdl, vm.checkedmpPrefLangIds, vm.MpPrefDataExt1.lang);
                    vm.prefData.lang = Ids;
                }
            });
        }
        vm.btnFmlyLangFuncG();
    }

    //*****************************Prefered language save data end here******************************************************


    //*****************************Family language save data******************************************************

    //family Langauges    
    vm.checkedmpFmlyLangIds = [];
    checkedmpFmlyLangName = [];


    //displaying array in html view
    vm.FmlyLangIdTostring = function () {
        return checkedmpFmlyLangName.join(", ");
    };

    vm.btnFmlyLangFuncG = function (isLeft) {
        vm.checkedmpFmlyLangIds = [];
        checkedmpFmlyLangName = [];
        //Binding Values to Family checkboxes
        BindCheckBoxIds(vm.prefData.familyLang, vm.checkedmpFmlyLangIds);

        //Get checked Familly Langauges Text
        angular.forEach(vm.familyLangDdl, function (data) {
            if (vm.checkedmpFmlyLangIds.indexOf(data.val) !== -1)
                checkedmpFmlyLangName.push(" " + data.txt);
        });

        vm.languageSelectd = checkedmpFmlyLangName.join(", ");
        if (isLeft != "leftBtn" && vm.closeModalValue == "") {
            $scope.$digest();
        }
    }

    //for getting selected checkboxes Ids on checkbox click event
    vm.FmlyLangClick = function (langId) {
        GetIdWithName(vm.familyLangDdl, vm.checkedmpFmlyLangIds, checkedmpFmlyLangName, langId);
        vm.languageSelectd = checkedmpFmlyLangName.join(", ");
    }

    vm.noFmlyLangPref = function () {
        vm.checkedmpFmlyLangIds = [];
        checkedmpFmlyLangName = [];
        vm.FmlyLangIdTostring();
        vm.languageSelectd = "";
    }

    vm.btnFmlyLangNext = function () {
        var Ids = vm.checkedmpFmlyLangIds.sort().join();
        if (!angular.equals(vm.prefData.familyLang, Ids)) {
            selfmatchprefSrvc.FamLanguagesIU(mId, Ids, function (response, status) {
                if (status == 200 && response == true) {
                    vm.MpPrefDataExt1.familyLang = [];
                    MultiUpdate(vm.familyLangDdl, vm.checkedmpFmlyLangIds, vm.MpPrefDataExt1.familyLang);
                    vm.prefData.familyLang = Ids;
                }
            });
        }
    }

    vm.btnFmlyLangBack = function () {
        vm.btnPrefLangFuncG('leftBtn');
    }

    //*****************************Family language save data end here******************************************************


    //*****************************Religious habits save data **************************************************************
    vm.religiousId = function (val) {
        vm.religiousval = val;
    }
    vm.religiousNext = function () {
        if (!angular.equals(vm.prefData.religious, vm.religiousval)) {
            selfmatchprefSrvc.prefReligious(vm.religiousval, function (response, status) {
                if (status == 200 && response == true) {
                    vm.prefData.religious = vm.religiousval;
                    vm.MpPrefDataExt1.Religious = "";
                    for (var i = 0; i < vm.religiousDdl.length; i++) {
                        if (vm.religiousDdl[i].val == vm.prefData.religious) {
                            //vm.ReligiousText = vm.religiousDdl[i].txt;                            
                            vm.MpPrefDataExt1.Religious = vm.religiousDdl[i].txt;
                            break;
                        }
                    }
                }
            });
        }
    }

    vm.religiousBack = function () {
        vm.btnFmlyLangFuncG();
    }
    //*****************************Religious habits save data end here******************************************************


    //*****************************Cultural habits save data ******************************************************
    vm.traditionalId = function (val) {
        vm.traditionalval = val;
    }

    vm.traditionalNext = function () {
        if (!angular.equals(vm.prefData.traditional, vm.traditionalval)) {
            selfmatchprefSrvc.prefCultural(vm.traditionalval, function (response, status) {
                if (status == 200 && response == true) {
                    vm.prefData.traditional = vm.traditionalval;
                    vm.MpPrefDataExt1.Traditional = "";
                    for (var i = 0; i < vm.traditionalDdl.length; i++) {
                        if (vm.traditionalDdl[i].val == vm.prefData.traditional) {
                            vm.MpPrefDataExt1.Traditional = vm.traditionalDdl[i].txt;
                            break;
                        }
                    }
                }
            });
        }

        vm.mpHobbieFuncG();
    }

    //*****************************Cultural habits save data end here******************************************************

    //*****************************HOBBIES bind dropdowns,starts and save data******************************************************

    function mpHobbieDataFuncG(callback) {
        selfprofileSrvc.HobbiesList(function (response) {
            if ($("#nvanc26").attr("data-mpData") == "N") {
                var result = {
                };
                var key = 'categoryName';
                for (var i = 0; i < response.length; i++) {
                    if (!result[response[i][key]]) {
                        result[response[i][key]] = [];
                    }
                    result[response[i][key]].push(response[i]);
                }
                // finding key length from Json Object
                var keyLength = Object.keys(result).length;
                var totalLength = response.length;
                var lengthByArray = totalLength / keyLength;

                vm.hbTblL1 = Math.round(lengthByArray / 2);
                vm.hbTblL2 = (lengthByArray) - vm.hbTblL1;

                vm.lstHobbies = result;
                vm.hobbiesList = response;
                callback();
                $("#nvanc26").attr("data-mpData", "Y");
            }
        });
    }

    vm.mpHobbieFuncG = function () {
        mpHobbieDataFuncG(function () {
            vm.checkedmphbIds = [];
            BindCheckBoxIds(vm.prefData.hobbies, vm.checkedmphbIds);
        });
    }

    vm.hobbyChkClick = function (Id) {
        GetClickedIds(vm.checkedmphbIds, Id);
    }

    vm.mpHobbiesNxtG = function () {
        if (vm.checkedmphbIds) {
            var Ids = vm.checkedmphbIds.sort().join();
            if (!angular.equals(vm.prefData.hobbies, Ids)) {
                selfmatchprefSrvc.HobbiesIU(mId, Ids, function (response, status) {
                    if (status == 200 && response == true) {
                        vm.MpPrefDataExt1.hobbies = [];
                        vm.checkedmphbIds.forEach(function (val) {
                            vm.MpPrefDataExt1.hobbies.push({ txt: getHobbyTxt(val) });
                        });

                        function getHobbyTxt(val) {
                            var hbyTxt = '';
                            vm.hobbiesList.forEach(function (data) {
                                if (data.HobbyId == val) {
                                    hbyTxt = data.HobbyName;
                                }
                            });
                            return hbyTxt;
                        }
                        vm.prefData.hobbies = Ids;
                    }
                });
            }
        }
        $('body').css('overflow', '');
        $('body').css('position', '');
    }

    //*****************************HOBBIES bind dropdowns,starts and save data end here******************************************************



    //city intelligence module
    $scope.$on("countryBind", function (e, txtId, countryId, data) {
        if (txtId == "txtampdstcntryCity") {
            vm.locType = 3;
            vm.countryId = data.countryId;
            vm.stateId = data.stateId;
            vm.cityId = data.cityId;
            vm.lat = data.lat;
            vm.long = data.long;

        } else if (txtId == "txtamphtwnCity") {
            //vm.hmPopUp = false;
            vm.hmCityUnbind = false;
            vm.htCntryId = data.countryId;
            vm.htStateId = data.stateId;
            vm.htCityId = data.cityId;
        }
    });

    $scope.$on("countryUnBind", function (e, txtId, countryId) {
        console.log("unbind : " + txtId + "  --  " + countryId);
        if (txtId == "txtampdstcntryCity") {
            vm.countryId = null;
            vm.stateId = null;
            vm.cityId = null;
        } else if (txtId == "txtamphtwnCity") {
            vm.htCntryId = null;
            vm.htStateId = null;
            vm.htCityId = null;
            vm.hmCityUnbind = true;
        }
    });

    $rootScope.$on("bindCountry", function (e, countries) {
        vm.countries = countries;
    });

    vm.setCountry = function (txtId, dvId, countryId) {
        //$("#txtamphtwnCity").prop('disabled', false);
        //$("#txtampdstcntryCity").prop('disabled', false);
        countryIntlSrv.SetCountry(txtId, dvId, countryId);
    }
    vm.sethmLctDfaultCntry = function () {
        $("#txtamphtwnCity").val('');
        $("#txtamphtwnCity").prop('disabled', true);
        //vm.hmPopUp = false;
        vm.htCntryId = null;
        vm.htStateId = null;
        vm.htCityId = null;
    }
    vm.setMyLocDfaultCntry = function () {
        $("#txtampdstcntryCity").val('');
        $("#txtampdstcntryCity").prop('disabled', true);
        vm.countryId = null;
        vm.cityId = null;
    }
    countryIntlSrv.initSrvc();

    vm.mpModalHide = function () {
        vm.closeModalValue = "leftBtn"
        SaveActiveTabData();
        $("#matchPrefModal").modal('hide');
        $('body').css('overflow', '');
        $('body').css('position', ''); 
    }
}]);

