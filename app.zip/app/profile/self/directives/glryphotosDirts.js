﻿angular.module("app").directive('glryPhotosSlider', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            scope.slideIndex = 1;
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit(attr.glryPhotosSlider);
                });
            }
        }
    }
});