﻿var app = angular.module("app");

//filter for changing text to pets count
app.filter("petCountFltr", function () {
    return function (ptsCnt, type) {
        if (type == "MS") {
            if (ptsCnt == 0 || ptsCnt == null || ptsCnt == "") return "Has no pets";
            else if (ptsCnt == 1) return "Has " + ptsCnt + " pet";
            else return "Has " + ptsCnt + " pets";
        }
        else if (type == "OP") {
            if (ptsCnt == 0 || ptsCnt == null || ptsCnt == "") return "I have no pets";
            else if (ptsCnt == 1) return "I have " + ptsCnt + " pet";
            else return "I have " + ptsCnt + " pets";
        }
    }
});

//filter changing text to pets preference
app.filter("petsPrefFltr", function () {
    return function (ptspref, type) {
        if (type == "MS") {
            if (ptspref == "Yes") return "Wants pets";
            else if (ptspref == "No") return "Doesn’t want pets";
            else if (ptspref == "Unsure") return "May want pets";
        }
        else if (type == "OP") {
            if (ptspref == "Yes") return "I want pets";
            else if (ptspref == "No") return "I don't want pets";
            else if (ptspref == "Unsure") return "I may want pets";
        }
    }
});

//filter for changing text to children count
app.filter("childCountFltr", function () {
    return function (chldCnt, type) {
        if (type == "MS") {
            if (chldCnt == 0 || chldCnt == null || chldCnt == "") return "Has no children";
            else if (chldCnt == 1) return "Has " + chldCnt + " child";
            else return "Has " + chldCnt + " children";
        }
        else if (type == "OP") {
            if (chldCnt == 0 || chldCnt == null || chldCnt == "") return "I have no children";
            else if (chldCnt == 1) return "I have " + chldCnt + " child";
            else return "I have " + chldCnt + " children";
        }
    }
});

//filter for changing text to children preference
app.filter("childPrefFltr", function () {
    return function (chldPref, type) {
        if (type == "MS") {
            if (chldPref == "Yes") return "Wants children";
            else if (chldPref == "No") return "Doesn’t want children";
            else if (chldPref == "Unsure") return "May want children";
        }
        else if (type == "OP") {
            if (chldPref == "Yes") return "I want children";
            else if (chldPref == "No") return "I don't want children";
            else if (chldPref == "Unsure") return "I may want children";
        }
    }
});

//filter for changing profile pic based on gender
//app.filter("PrflPicFltr", function () {
//    return function (pic, gndr,storageCollection) {
//        if (pic == null || pic == "") {
//            if (gndr == true) return gndr = "https://pccdn.pyar.com/pcimgs/profilePicM.jpg";
//            else return gndr = "https://pccdn.pyar.com/pcimgs/profilePicF.jpg";
//        }
//        else
//            return gndr = "https://pccdn.pyar.com" + pic.replace("/tnb/", "/tn/");
//    }
//});


//showing default banner image, if the member not select any banner image
app.filter("bannerPicFltr", function () {
    return function (bnr, storageCollection) {
        if (bnr == null || bnr == "")
            return "https://pccdn.pyar.com/pcimgs/defBnr.jpg";
        else
            return "https://pccdn.pyar.com" + bnr;
    }
});

//get member location
//app.filter("memLocFltr", function () {
//    return function (countryId, stateId) {
//        if (countryId == null || countryId == "" || countryId == undefined)
//            return stateId;
//        else
//            return stateId + ", " + countryId;
//    }
//});
