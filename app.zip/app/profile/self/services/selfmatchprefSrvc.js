﻿angular.module("app").service('selfmatchprefSrvc', ['$http', 'getSessionSrvc', function ($http, getSessionSrvc) {
    var mId = getSessionSrvc.p_mId();
    // About Me Service Starts
    // About Me View Dropdowns 
    //this.aboutMe = function (funCallBack) {
    //    var url = getApiDomainUrl() + "/api/profile/AboutMeData";
    //    GetServiceByURL($http, url, funCallBack);
    //}

    //My appearence service for ddls Starts
    //this.myAppearance = function (funCallBack) {
    //    var url = getApiDomainUrl() + "/api/profile/MyAppearanceDDlData";
    //    GetServiceByURL($http, url, funCallBack);
    //}

    //My life style service for ddls Starts
    //this.myLifeStyle = function (funCallBack) {
    //    var url = getApiDomainUrl() + "/api/profile/MyLifeStyleDDlData";
    //    GetServiceByURL($http, url, funCallBack);
    //}

    var updateMpData = { memberId: mId, minAge: "", maxAge: "", locRadius: "", locType: "", countryId: "", stateId: "", cityId: "", latitude: "", longitute: "", locRadiusDistance: "", awId: "", highestEdu: "", htCountry: "", htState: "", htCity: "", minHeight: "", maxHeight: "", smoke: "", drink: "", idealRelationship: "", childrenCnt: "", childrenPref: "", petsCnt: "", petsPref: "", religious: "", traditional: "" }

    this.prefAge = function (minAge, maxAge, funCallBack) {
        updateMpData.minAge = minAge;
        updateMpData.maxAge = maxAge;
        var url = getApiDomainUrl() + "/api/matchpref/age";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefDistance = function (locRadius, locType, countryId, stateId, cityId, latitude, longitute, locRadiusDistance, funCallBack) {
        updateMpData.locRadius = locRadius;
        updateMpData.locType = locType;
        updateMpData.countryId = countryId;
        updateMpData.stateId = stateId;
        updateMpData.cityId = cityId;
        updateMpData.latitude = latitude;
        updateMpData.longitute = longitute;
        updateMpData.locRadiusDistance = locRadiusDistance;
        var url = getApiDomainUrl() + "/api/matchpref/distance";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefAreaOfWork = function (awId, funCallBack) {
        updateMpData.awId = awId;
        var url = getApiDomainUrl() + "/api/matchpref/areaofwork";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefEducation = function (highestEdu, funCallBack) {
        updateMpData.highestEdu = highestEdu;
        var url = getApiDomainUrl() + "/api/matchpref/education";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefHometown = function (htCountry, htState, htCity, funCallBack) {
        updateMpData.htCountry = htCountry;
        updateMpData.htState = htState;
        updateMpData.htCity = htCity;
        var url = getApiDomainUrl() + "/api/matchpref/hometown";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefHeight = function (minHeight, maxHeight, funCallBack) {
        updateMpData.minHeight = minHeight;
        updateMpData.maxHeight = maxHeight;
        var url = getApiDomainUrl() + "/api/matchpref/heights";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefSmoking = function (smoke, funCallBack) {
        updateMpData.smoke = smoke;
        var url = getApiDomainUrl() + "/api/matchpref/smoking";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefDrinking = function (drink, funCallBack) {
        updateMpData.drink = drink;
        var url = getApiDomainUrl() + "/api/matchpref/drinking";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefRelationship = function (idealRelationship, funCallBack) {
        updateMpData.idealRelationship = idealRelationship;
        var url = getApiDomainUrl() + "/api/matchpref/relationship";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefChildrenCnt = function (childrenCnt, funCallBack) {
        updateMpData.childrenCnt = childrenCnt;
        var url = getApiDomainUrl() + "/api/matchpref/children";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefChildren = function (childrenPref, funCallBack) {
        updateMpData.childrenPref = childrenPref;
        var url = getApiDomainUrl() + "/api/matchpref/childpref";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefPets = function (petsCnt, funCallBack) {
        updateMpData.petsCnt = petsCnt;
        var url = getApiDomainUrl() + "/api/matchpref/pets";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefPetPref = function (petsPref, funCallBack) {
        updateMpData.petsPref = petsPref;
        var url = getApiDomainUrl() + "/api/matchpref/petpref";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefReligious = function (religious, funCallBack) {
        updateMpData.religious = religious;
        var url = getApiDomainUrl() + "/api/matchpref/religious";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefCultural = function (traditional, funCallBack) {
        updateMpData.traditional = traditional;
        var url = getApiDomainUrl() + "/api/matchpref/cultural";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    }

    this.prefRadius = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/utils/radius/";
        GetServiceByURL($http, url, funCallBack);
    }

    this.getMpPrefData = function (memId, funCallBack) {
        var url = getApiDomainUrl() + "/api/matchpref/memberpref/" + memId;
        GetServiceByURL($http, url, funCallBack);
    }

    this.EthnicitiesIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = getApiDomainUrl() + "/api/matchpref/ethncty";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);

        } else
            alert("Incorrect Id's Formation");
    }

    this.ReligionsIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = getApiDomainUrl() + "/api/matchpref/rlgns";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);

        } else
            alert("Incorrect Id's Formation");
    }

    this.RSStatusIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = getApiDomainUrl() + "/api/matchpref/rssts";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }

    this.PersonalityTraitsIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = getApiDomainUrl() + "/api/matchpref/pts";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }

    this.EyeColourIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = getApiDomainUrl() + "/api/matchpref/eyeclr";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }

    this.HairColourIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = getApiDomainUrl() + "/api/matchpref/hrclr";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }

    this.BuildIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = getApiDomainUrl() + "/api/matchpref/blds";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }

    this.DietIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = getApiDomainUrl() + "/api/matchpref/dts";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }

    this.LanguagesIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = getApiDomainUrl() + "/api/matchpref/langs";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }

    this.FamLanguagesIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = getApiDomainUrl() + "/api/matchpref/fmlylangs";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }

    this.HobbiesIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = getApiDomainUrl() + "/api/matchpref/hobbies";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }

    // Match summary getMpPrefDataExt1
    this.getMpPrefDataExt1 = function (prefData, funCallBack) {

        var data = {
            countryId: prefData.countryId,
            stateId: prefData.stateId,
            cityId: prefData.cityId,
            awId: prefData.awId,
            highestEdu: prefData.highestEdu,
            htCountry: prefData.htCountry,
            htState: prefData.htState,
            htCity: prefData.htCity,
            smoke: prefData.smoke,
            drink: prefData.drink,
            idealRelationship: prefData.idealRelationship,
            childrenPref: prefData.childrenPref,
            petsPref: prefData.petsPref,
            religious: prefData.religious,
            traditional: prefData.traditional,
            rsStatus: prefData.rsStatus,
            eyeColor: prefData.eyeColor,
            hairColor: prefData.hairColor,
            build: prefData.build,
            diet: prefData.diet,
            ethinicities: prefData.ethinicities,
            religions: prefData.religions,
            lang: prefData.lang,
            familyLang: prefData.familyLang,
            hobbies: prefData.hobbies,
            pt: prefData.pt,
            MinHeight: prefData.minHeight,
            MaxHeight: prefData.maxHeight
        }

        var url = getApiDomainUrl() + "/api/matchpref/matchprefinfo";
        PostServiceByURL($http, url, data, funCallBack);
    }
}]);