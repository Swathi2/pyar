﻿angular.module("app").service('selfprofileSrvc', ['$http', function ($http) {

    //Getting basic profile info starts
    this.profileInfo = function (memberId, funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/GetProfileInfo/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    }

    this.GetPrfInfoExt1 = function (memberId, profileInfo, funCallBack) {
        if (profileInfo.pt == null) { profileInfo.pt = ""; }
        var data = {
            countryId: profileInfo.countryId,
            stateId: profileInfo.stateId,
            cityId: profileInfo.cityId,
            ethinicityId: profileInfo.ethinicityId,
            rsStatus: profileInfo.rsStatus,
            religionId: profileInfo.religionId,
            highestEdu: profileInfo.highestEdu,
            awId: profileInfo.awId,
            htCountry: profileInfo.htCountry,
            htState: profileInfo.htState,
            htCity: profileInfo.htCity,
            pt: profileInfo.pt
        }

        var url = getApiDomainUrl() + "/api/profile/GetProfileInfoExt1/" + memberId;
        PostServiceByURL($http, url, data, funCallBack);
    }

    this.GetPrfInfoExt2 = function (memberId, profileInfo, funCallBack) {
        if (profileInfo.lang == null) { profileInfo.lang = ""; }
        if (profileInfo.hobbies == null) { profileInfo.hobbies = ""; }
        if (profileInfo.familyLangs == null) { profileInfo.familyLangs = ""; }

        var data = {
            eyeColor: profileInfo.eyeColor,
            height: profileInfo.height,
            hairColor: profileInfo.hairColor,
            build: profileInfo.build,
            diet: profileInfo.diet,
            smoke: profileInfo.smoke,
            drink: profileInfo.drink,
            idealRelationship: profileInfo.idealRelationship,
            childrenCnt: profileInfo.childrenCnt,
            childrenPref: profileInfo.childrenPref,
            petsCnt: profileInfo.petsCnt,
            petsPref: profileInfo.petsPref,
            lang: profileInfo.lang,
            familyLangs: profileInfo.familyLangs,
            religious: profileInfo.religious,
            traditional: profileInfo.traditional,
            hobbies: profileInfo.hobbies
        }


        var url = getApiDomainUrl() + "/api/profile/GetProfileInfoExt2/" + memberId;
        PostServiceByURL($http, url, data, funCallBack);
    }

    // About Me Services Starts
    // About Me View Dropdowns 
    this.StaticDropDownList = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/AboutMeData";
        GetServiceByURL($http, url, funCallBack);
    }

    //About Me Search Info
    //this.aboutmeSearch = function (countryId, funCallBack) {
    //    var url = getApiDomainUrl() + "/api/profile/searchdata/" + countryId;
    //    GetServiceByURL($http, url, funCallBack);

    //}

    // about me update service
    this.aboutmeUpdate = function (memberId, ethinicityId, religionId, awId, rsStatus, highestEdu, htCountry, htState, htCity, profileCmplnPrcnt, funCallBack) {
        var data = {
            memberId: memberId, ethinicityId: ethinicityId, religionId: religionId, awId: awId,
            rsStatus: rsStatus, highestEdu: highestEdu, htCountry: htCountry, htState: htState, htCity: htCity, profileCmplnPrcnt: profileCmplnPrcnt
        }
        var url = getApiDomainUrl() + "/api/profile/AboutMeU";
        PostServiceByURL($http, url, data, funCallBack);
    }
    //About Me services End


    //Personality Traits Services Starts
    //Getting Personality Traits
    this.PrsnltyTraitsListG = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/Personalitytraits";
        GetServiceByURL($http, url, funCallBack);
    }

    this.PrsnltyTraitsListIU = function (memberId, multiVal, profileCmplnPrcnt, funCallBack) {
        //checking comma based multi val is in correct format or not
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: profileCmplnPrcnt }
            var url = getApiDomainUrl() + "/api/profile/MyPTU";
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }

    //PersonalitytraitsServices End


    //my bio services Starts
    //My Bio update service
    this.myBioU = function (memberId, bio, profileCmplnPrcnt, funCallBack) {
        var data = { memberId: memberId, bio: bio, profileCmplnPrcnt: profileCmplnPrcnt }
        var url = getApiDomainUrl() + "/api/profile/MyBioU";
        PostServiceByURL($http, url, data, funCallBack);
    }
    // my bio services End    


    //My trophies Services starts
    //My Trophies starts(Tatish)
    this.CountryCodeG = function (countryId, funCallBack) {
        var url = getApiDomainUrl() + "/api/utils/countrycode/" + countryId;
        GetServiceByURL($http, url, funCallBack);
    }

    this.socTrophy = function (memberId, funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/v2/soctroph/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    }

    this.sendOtp = function (memberId, countryCode, mobileNo, funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/v2/sndtphvc";
        var data = { memberId: memberId, countryCode: countryCode, mobileNo: mobileNo };
        PostServiceByURL($http, url, data, funCallBack);
    }

    this.resendOtp = function (memberId, countryCode, mobileNo, funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/v2/resndtphvc";
        var data = { memberId: memberId, countryCode: countryCode, mobileNo: mobileNo };
        PostServiceByURL($http, url, data, funCallBack);
    }

    this.verifyOtp = function (memberId, codeId, code, funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/v2_1/chktphvc/" + memberId + "/" + codeId + "/" + code;
        GetServiceByURL($http, url, funCallBack);
    }
    //My trophies Services End


    //My appearance services starts
    //My appearence service for ddls Starts
    this.ddlsMyAppearence = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/MyAppearanceDDlData";
        GetServiceByURL($http, url, funCallBack);
    }

    //My appearence update service Starts
    this.myAppearenceU = function (memberId, eyeColor, hairColor, build, height,profileCmplnPrcnt, funCallBack) {
        var data = { memberId: memberId, eyeColor: eyeColor, hairColor: hairColor, build: build, height: height, profileCmplnPrcnt: profileCmplnPrcnt }
        var url = getApiDomainUrl() + "/api/profile/MyAppearanceU";
        PostServiceByURL($http, url, data, funCallBack);
    }
    //My appearance services End

    // My LifeStyle Services starts
    //My life style service for ddls service
    this.ddlsMyLifeStyleDDlData = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/profile/MyLifeStyleDDlData";
        GetServiceByURL($http, url, funCallBack);
    }

    //My MyLifeStyle update service Starts
    this.myLifeStyleU = function (memberId, diet, smoke, drink, idealRelationship, childrenCnt, childrenPref, petsCnt, petsPref, lang, familyLangs, religious, traditional, profileCmplnPrcnt, funCallBack) {
        //checking comma based multi val is in correct format or not
        if (commaSeperatedNumbStrCheck(lang) && commaSeperatedNumbStrCheck(familyLangs)) {
            var data = {
                memberId: memberId,
                diet: diet,
                smoke: smoke,
                drink: drink,
                idealRelationship: idealRelationship,
                childrenCnt: childrenCnt,
                childrenPref: childrenPref,
                petsCnt: petsCnt,
                petsPref: petsPref,
                lang: lang,
                familyLangs: familyLangs,
                religious: religious,
                traditional: traditional,
                profileCmplnPrcnt: profileCmplnPrcnt
            }
            var url = getApiDomainUrl() + "/api/profile/MyLifeStyleU";
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }
    //My LifeStyles Services End


    //My hobbies Services Starts
    //Hobbies List service
    this.HobbiesList = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/utils/hobbies";
        GetServiceByURL($http, url, funCallBack);
    }


    this.HobbiesInsert = function (memberId, multiVal, profileCmplnPrcnt, funCallBack) {
        //checking comma based multi val is in correct format or not       
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: profileCmplnPrcnt }
            var url = getApiDomainUrl() + "/api/profile/MyHobbiesU";
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    }

    this.AddTagLine = function (memberId, tagLine, tagLineStyles, funCallBack) {
        var data = { memberId: memberId, tagLine: tagLine, tagLineStyles: tagLineStyles };
        var url = getApiDomainUrl() + "/api/profile/tgln";
        PostServiceByURL($http, url, data, funCallBack);
    }



    //*********************************************************image uploading ************************************************************************************************

    this.getAllImages = function (memberId, funCallBack) {
        var url = getApiDomainUrl() + "/api/mbrphotos/getallimgs/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    }
    //upload gallery image
    this.uploadGlryImages = function (memberId,picOrder, formData, funCallBack) {
        var request = {
            method: 'POST',
            url: getApiDomainUrl() + "/api/mbrphotos/galleryI/" + memberId + "/" + picOrder,
            data: formData,
            headers: {
                'Content-Type': undefined
            }
        };
        $http(request).success(function (response, status) { funCallBack(response, status);}).error(function () { });
    }
    //upload profile image
    this.uploadPrflImages = function (memberId, actionType, formData, funCallBack) {
        var request = {
            method: 'POST',
            url: getApiDomainUrl() + "/api/mbrphotos/prfImgIU/" + memberId + "/" + actionType,
            data: formData,
            headers: {
                'Content-Type': undefined
            }
        };
        $http(request).success(function (response, status) { funCallBack(response, status); }).error(function () { });
    }
    //upload banner image
    this.uploadBannerImages = function (memberId, actionType, formData, funCallBack) {
        var request = {
            method: 'POST',
            url: getApiDomainUrl() + "/api/mbrphotos/bnrImgIU/" + memberId + "/" + actionType,
            data: formData,
            headers: {
                'Content-Type': undefined
            }
        };
        $http(request).success(function (response, status) { funCallBack(response, status);}).error(function () { });
    }
    //swap image
    this.swapImages = function (memberId, gmpuId, formData, funCallBack) {
        var request = {
            method: 'POST',
            url: getApiDomainUrl() + "/api/mbrphotos/swapimg/" + memberId + "/" + gmpuId,
            data: formData,
            headers: {
                'Content-Type': undefined
            }
        };
        $http(request).success(function (response, status) { funCallBack(response, status);}).error(function () { });
    }

    //delete banner photo
    this.BannerPhotoD = function (memberId, mupId, funCallBack) {
        var data = {};
        var url = getApiDomainUrl() + "/api/mbrphotos/bnrimgd/" + memberId + "/" + mupId;
        PostServiceByURL($http, url, data, funCallBack);
    }
    //delete gallery photo
    this.GalleryPhotoD = function (memberId, mupId, funCallBack) {
        var data = {};
        var url = getApiDomainUrl() + "/api/mbrphotos/glimgd/" + memberId + "/" + mupId;
        PostServiceByURL($http, url, data, funCallBack);

    }
    //delete profile photo
    this.ProfilePhotoD = function (memberId, mupId, funCallBack) {
        var data = {};
        var url = getApiDomainUrl() + "/api/mbrphotos/prflimgd/" + memberId + "/" + mupId;
        PostServiceByURL($http, url, data, funCallBack);
    }
    //get gallery pics
    this.getPyarPics = function (funCallBack) {
        var url = getApiDomainUrl() + "/api/mbrphotos/getpyrpcs";
        GetServiceByURL($http, url, funCallBack);
    }
    //*********************************************************image uploading  end***********************************************************************************

    this.getAlbums = function (client_id, accessToken, funCallBack) {
        $http({
            method: "GET",
            url: "https://graph.facebook.com/me/albums?access_token=" + accessToken + "&client_id=" + client_id,
            data: { access_token: accessToken },
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            funCallBack(response, status);
        }).error(function (error, status) {
            errStatuChk(status);
        });
    }

    this.bindPhotos = function (albumId, accessToken, funCallBack) {

        $http({
            method: "GET",
            url: "https://graph.facebook.com/" + albumId + "/photos?access_token=" + accessToken,
            data: { access_token: accessToken },
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            funCallBack(response, status);
        }).error(function (error, status) {
            errStatuChk(status);
        });
    }


    this.bindPhotosIN = function (accessToken, funCallBack) {
        $.ajax({
            url: 'https://api.instagram.com/v1/users/self/media/recent',
            dataType: 'jsonp',
            type: 'GET',
            data: { access_token: accessToken, count: 100 },
            success: function (data) {
                funCallBack(data);
            },
            error: function (data) {
               
            }
        });
    }

}]);