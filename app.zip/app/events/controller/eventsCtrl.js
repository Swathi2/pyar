﻿angular.module('app').controller('eventsCtrl', function ($scope,$compile) {

    //Gallery images showing in popup
    var imgGallryindex = 0;
    function PopulateGallryPics() {
        var listItems = $(".idpglry li");
        var total = $('.idpglry li').length + 1;
        listItems.each(function (idx, li) {
            var img = $('img',this).prop("src");
            $compile($(li).attr('ng-click', 'PopupGlryImg(' + (idx + 1) + ',"'+ img+ '")'))($scope);
        });
    };
    PopulateGallryPics();

    $scope.PopupGlryImg = function(imgindx, img) {
        imgGallryindex += imgindx
        var html = '';
        var img = '<img src="' + img + '" />';
        html += img;
        html += '<div class="idparwbtn" data-index="' + (imgGallryindex) + '">';
        html += '<a class="controls next"></a>';
        html += '<a class="controls previous"></a>';
        html += '</div>';

        $('#idpglrpup').modal();
        $('#idpglrpup').on('shown.bs.modal', function () {
            $('#idpglrpup .idpglp').html(html);
        })
        $('#idpglrpup').on('hidden.bs.modal', function () {
            $('#idpglrpup .idpglp').html('');
            imgGallryindex = 0;
        });
    }

    $(document).on('click', 'a.controls', function () {
        var glryIndx = parseInt($(".idparwbtn").attr('data-index'));
        var total = $('.idpglry li').length;
        var src = "";
        if ($(this).hasClass('previous')) {
            imgGallryindex = glryIndx - 1;
            if (imgGallryindex == 0) imgGallryindex = total;
            src = $('.idpglry li:nth-child(' + imgGallryindex + ') img').attr('src');
            $(".idparwbtn").attr('data-index', imgGallryindex);
        } else {
            if (total == imgGallryindex) glryIndx = 0;
            imgGallryindex = glryIndx + 1;
            src = $('.idpglry li:nth-child(' + imgGallryindex + ') img').attr('src');
            $(".idparwbtn").attr('data-index', imgGallryindex);
        }
        $('.idpglp img').attr('src', src);
    })
});