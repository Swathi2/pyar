﻿angular.module("app").controller('forgotpwdCtrl', ['forgotpwdSrvc', 'getSessionSrvc', '$scope', '$rootScope', '$window', '$rootScope', '$location', '$interval', function (forgotpwdSrvc, getSessionSrvc, $scope, $rootScope, $window, $rootScope, $location, $interval) {
    var vm = this;
    //#region for checking email and date of birth
    vm.emailValid = false;
    vm.dobValid = false;
    vm.err = false;
    vm.errEmailMsg = "";
    vm.errMsg = "";
    vm.errdobMsg = "";
    vm.errnewpwd = "";
    vm.errorcnfmpwd = "";
    vm.newPwdValid = false;
    vm.cnfmPwdValid = false;
    vm.emailRegexs = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    vm.email = "";
    vm.resendEmailVal = true;
     vm.vrfyOtp = true;
    vm.emailClear = function () {
        if (vm.email)
            vm.email = vm.email.toLowerCase();
        if (!vm.email) {
            vm.emailValid = false;
            vm.errEmailMsg = "Invalid email"
        }
        else if (!vm.emailValid)
            vm.errEmailMsg = "Invalid email";
    };

    vm.emailCheck = function (email) {
        vm.errEmailMsg = "";
        if (!vm.email) {
            vm.emailValid = false;
            vm.errEmailMsg = "Invalid email";
        }
        else {
            var emlReg = new RegExp(vm.emailRegexs);
            if (emlReg.test(vm.email))
                vm.emailValid = true;             
            else
                vm.emailValid = false;
        }
        if (vm.email.length > 75) {
            vm.errEmailMsg = "Must be < 75 characters";
            vm.emailValid = false;
            vm.email = "";
        }
    };

    vm.dobCheck = function (val) {
        vm.err = false;
        if (val && vm.dobChange(val) >= 18) {
            vm.dobValid = true;
            vm.dob = getDate(val);
        }
        else {
            vm.dobValid = false;
            vm.errdobMsg = "Please enter valid Date of Birth";
        }
    };

    vm.dobChange = function (val) {
        var today = new Date();
        var dateOfBirth = new Date(val);
        var age = today.getFullYear() - dateOfBirth.getFullYear();
        var m = today.getMonth() - dateOfBirth.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < dateOfBirth.getDate()))
            age--;
        return age;
    };

    //Dynamic binding for the date picker(restricting ages from 18 to 130 years)
    var today = new Date();
    var maxAge = 18;
    var minAge = 130;
    vm.maxAge = new Date(today.getFullYear() - maxAge, today.getMonth(), today.getDate());
    vm.minAge = new Date(today.getFullYear() - minAge, today.getMonth(), today.getDate());
    vm.dateOfBirth = "";

    vm.frgtPwdStep1 = function () {
        if ($scope.frmFrgtPwd.$valid) {
            showLoader();
            forgotpwdSrvc.forgotPwd(vm.email, vm.dob, function (response, status) {
                hideLoader();
                if (status == 200) {
                    if (response == "2" || response == "1") {
                        vm.err = true;
                        vm.errFgtPwddobMsg = "Incorrect Birthday or Email";
                    }
                    else {
                        var ssnSec = { "memberId": response.MemberId, "secQns": response.SecQuestion };
                        $window.localStorage.setItem("ssnSec", getSessionSrvc.pce(JSON.stringify(ssnSec)));
                        $window.location.href = "/forgotpwdsec.html";
                    }
                }
            });
        }
    };
    //#endregion

    //#region  used for validating security question
    vm.secAnsValid = false;
    var lgnSsn = $window.localStorage.getItem("ssnSec");
    if (lgnSsn != null && lgnSsn.length != 0) {
        var ssnSecObj = JSON.parse(getSessionSrvc.pcd(lgnSsn));
        vm.SecQuestion = ssnSecObj.secQns;
        vm.mId = ssnSecObj.memberId;
    }

    vm.AnswerCheck = function () {
        if (vm.answer && vm.answer.length > 75) {
            vm.secAnsValid = false;
            vm.errSecAns = 'Must be <76 characters'
        }
    };

    vm.SecAnsKeyUp = function () {
        if (vm.answer) {
            vm.secAnsValid = true;
            vm.errSecAns = "";
        }
    };

    vm.frgtPwdStep2 = function () {
        if ($scope.frmFrgtPwd.$valid) {
            showLoader();
            forgotpwdSrvc.resetPwd(vm.mId, vm.answer, function (response, status) {
                hideLoader();
                if (status == 200) {
                    if (response == false)
                        vm.errSecAns = "email sending failed";
                    else if (response == "1") {
                        vm.errMsg2 = true;
                        vm.answer = "";
                        vm.secAnsValid = false;
                        vm.errSecAns = "Sorry, that’s incorrect. Please try again or contact Customer Service.";
                    }
                    else if (response.hasOwnProperty("memberId") && response.hasOwnProperty("otpId")) {
                        var memfpw = { "memberId": response.memberId, "otpId": response.otpId };
                        $window.localStorage.setItem("memfpw", getSessionSrvc.pce(JSON.stringify(memfpw)));
                        $window.location.href = "/forgotpwdreseteml.html";
                    }
                }
            });
        }
    };
    //#endregion

    //#region Verifity OTP and Resend OTP 
    vm.otpValid = false;

    vm.frgtOTPKeyPress = function (texboxIndex, event) {
        if (event.keyCode == 13)
            vm.frgtPwdStep3(texboxIndex, event);
    };

    vm.frgtPwdStep3 = function (texboxIndex, event) {       
            var keyCode = event.keyCode;
            if ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105) || keyCode == 13) {
                vm.otpErrMsg = "";
                vm.otpVerify();
                //focus next elements
                texboxIndex++;
                $('input[tabindex=' + (texboxIndex) + ']').focus();
            }        
    };

    vm.otpVerify = function () {
        if (vm.vrfyOtp == true && vm.otpCode1 && vm.otpCode2 && vm.otpCode3 && vm.otpCode4) {
            vm.vrfyOtp = false;
            var otpCode = vm.otpCode1 + vm.otpCode2 + vm.otpCode3 + vm.otpCode4;
            var memfpw = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("memfpw")));
            if (memfpw.memberId && otpCode && memfpw.otpId) {
                showLoader();
                forgotpwdSrvc.otpVerify(memfpw.memberId, memfpw.otpId, otpCode, function (response, status) {
                    hideLoader();
                    if (status == 200) {
                        vm.vrfyOtp = true;
                        if (response == "1")// invalid
                        {
                            vm.otpValid = true;
                            vm.otpErrMsg = "Invalid Code";
                            vm.otpCode1 = vm.otpCode2 = vm.otpCode3 = vm.otpCode4 = "";
                            $("#otpCode1").focus();
                        }
                        else if (response == "2")//otp expired
                        {
                            vm.otpValid = true;
                            vm.otpErrMsg = "This code expired. Please fill in the code within 24 hours.";
                            vm.otpCode1 = vm.otpCode2 = vm.otpCode3 = vm.otpCode4 = "";
                            $("#otpCode1").focus();
                        }
                        else if (response == "3")//wrong otp
                        {
                            vm.otpValid = true;
                            vm.otpErrMsg = "That’s incorrect. Please try again.";
                            vm.otpCode1 = vm.otpCode2 = vm.otpCode3 = vm.otpCode4 = "";
                            $("#otpCode1").focus();
                        }
                        else { //otp verfied success
                            var memfpw = { "memberId": response };
                            $window.localStorage.setItem("memfpw", getSessionSrvc.pce(JSON.stringify(memfpw)));
                            $window.location.href = "/forgotpwdreset.html";
                        }
                    }
                });
            }
        }
    };
    vm.resendOTP = function () {
        var memfpw = $window.localStorage.getItem("memfpw");
        if (memfpw) {
            var memberId = JSON.parse(getSessionSrvc.pcd(memfpw)).memberId;
            vm.otpValid = false;
            vm.otpErrMsg = "";
            showLoader();
            //wait 30 sec after first click on resend email
            startInterval(vm, $interval);
            forgotpwdSrvc.resedOTP(memberId, function (response, status) {
                hideLoader()
                if (status == 200) {
                    if (response == "1") {
                        vm.otpValid = true;
                        vm.otpErrMsg = "unable to process request";
                    }
                    else if (response == "2") {
                        vm.otpValid = true;
                        vm.otpErrMsg = "email sending failed";
                    }
                    else {
                        var memfpw = { "memberId": response.memberId, "otpId": response.otpId };
                        $window.localStorage.setItem("memfpw", getSessionSrvc.pce(JSON.stringify(memfpw)));
                        vm.otpCode1 = vm.otpCode2 = vm.otpCode3 = vm.otpCode4 = "";
                        $("#otpCode1").focus();
                    }
                }
            });
        }
    };
    //#endregion
    /*New Password Function start for password change*/
    vm.newPassword = "";
    vm.newPwdFunc = function (newPassword) {
        var pwdReg = new RegExp("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,16}$");
        if (!pwdReg.test(vm.newPassword)) {
            vm.errnewpwd = "Please follow password guidelines";
            vm.newPassword == "";
        }
        else
            vm.errnewpwd = "";
        $("#pwdgl").css("display", "none");
    };

    vm.newPwdClearFunc = function (newPassword, confirmPassword) {
        if (vm.newPassword == '')
            vm.newPwdValid = false;
        else {
            if (vm.newPassword && vm.newPassword.length > 16) {              
                vm.errnewpwd = "Must be < 16 characters";
                vm.newPwdValid = false;
                vm.newPassword = "";
                return;
            }
            var pwdReg = new RegExp("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,16}$");
            if (!pwdReg.test(vm.newPassword || vm.newPassword == undefined)) {
                vm.newPwdValid = false;
                vm.errnewpwd = "";
            }
            else if (confirmPassword == newPassword) {
                vm.errnewpwd = "";
                vm.newPwdValid = true;
                vm.cnfmPwdValid = true;
            }
            else {
                vm.errnewpwd = "";
                vm.newPwdValid = false;
            }
        }
    };
    /*New Password Function End*/

    /*Confirm Password Function Start*/
    vm.cnfPwdCheck = function (newPassword, confirmPassword) {
        var vm = this;
        if (vm.newPassword == undefined || vm.newPassword == "")
            vm.errorcnfmpwd = "";
        else if (vm.newPassword != vm.confirmPassword)
            vm.errorcnfmpwd = "Password does not match";
        else
            vm.errorcnfmpwd = "";
    };

    vm.cnfPwdCheckkeypress = function (newPassword, confirmPassword) {
        if (vm.confirmPassword && vm.confirmPassword.length > 16) {
            vm.errorcnfmpwd = "Must be < 16 characters";
            vm.cnfmPwdValid = false;
            vm.confirmPassword = "";
            return;
        }
        if (vm.confirmPassword == undefined) {
            vm.cnfmPwdValid = false;
            vm.errorcnfmpwd = "";
        }
        else if (vm.newPassword != vm.confirmPassword)
            vm.cnfmPwdValid = false;
        else {
            vm.cnfmPwdValid = true;
            vm.errorcnfmpwd = "";
            vm.newPwdClearFunc(newPassword, confirmPassword);
        }
    };

    // on new password focus showing passwored guidelines div
    vm.pwdGuidLines = function () {
        $("#pwdgl").css("display", "").css("position", "relative");
    };

    //Resetting Password
    vm.frgtPwdStep4 = function () {
        if ($scope.frmFrgtPwd.$valid) {
            var memfpw = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("memfpw")));
            if (memfpw && memfpw.memberId) {
                showLoader();
                forgotpwdSrvc.changePwd(memfpw.memberId, vm.newPassword, function (response, status) {
                    hideLoader();
                    if (status == 200) {
                        if (response == "1") {
                            vm.errnewpwd = "Invalid id";
                            vm.newPwdValid = false;
                        }
                        else if (response == "2") {
                            vm.errnewpwd = "previous password can't be used"
                            vm.newPwdValid = false;
                        }
                        else if (response == "3") {
                            $window.localStorage.setItem("pgType", 2);
                            $window.location.href = "/";
                        }
                    }
                    else {
                        alert("Password resetting failed...!");
                    }
                });
            }
        }
    };
    //#endregion
}]);