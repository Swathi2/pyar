﻿angular.module("app").controller('signinCtrl', ['signinSrvc', 'getSessionSrvc', 'abndnSrvc', '$scope', '$window', '$rootScope', '$http', '$state', function (signinSrvc, getSessionSrvc, abndnSrvc, $scope, $window, $rootScope, $http, $state) {
    var vm = this;
    vm.emailRegexs = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    vm.pwdRegexs = '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,16}$';

    //#region used for signin
    vm.email = "";
    vm.password = "";
    vm.emlValid = false;
    vm.pwdValid = false;
    vm.signInValid = false;
    vm.newPwdValid = false;
    vm.cnfmPwdValid = false;

    //Profile Hide pop showing on profilehide.html Page_Load
    if ($("#profileHidePopup").length > 0)
        $("#profileHidePopup").modal("show");

    vm.errorEmailMsg = "";
    vm.errorPwdMsg = "";
    vm.errorNewPwdMsgCnfm = "";
    vm.errMsg = "";
    vm.errorNewPwdMsg = "";

    vm.emailCheck = function () {
        vm.errorEmailMsg = "";
        if (!vm.email) {
            vm.emlValid = false;
            vm.errorEmailMsg = "Invalid email";
        }
        else {          
            if (vm.emailRegexs.test(vm.email)) 
                vm.emlValid = true;                                      
            else 
                vm.emlValid = false;
        }
        if (vm.email.length > 75) {
            vm.errorEmailMsg = "Must be < 75 characters";
            vm.emlValid = false;
            vm.email = "";
        }
    };

    vm.emailClear = function () {
        if (vm.email)
            vm.email = vm.email.toLowerCase();
        if (!vm.email) {
            vm.emlValid = false;
            vm.errorEmailMsg = "Invalid email";
            vm.email = "";
        }
        else if (!vm.emlValid)
            vm.errorEmailMsg = "Invalid email";
    };
    vm.pwdTest = function (password) {
        var pwdReg = new RegExp(vm.pwdRegexs);
        return pwdReg.test(password);
    };
    vm.pwdCheck = function () {
        vm.errorPwdMsg = "";
        if (!vm.password) {
            vm.pwdValid = false;
            vm.errorPwdMsg = "Invalid password";
        }
        else {
            vm.errorPwdMsg = "";
            if (vm.password && vm.password.length >= 8 && vm.password.length <= 16)
                vm.pwdValid = true;
            else
                vm.pwdValid = false;
            if (vm.password && vm.password.length > 16) {
                vm.password = null;
                vm.pwdValid = false;
                vm.errorPwdMsg = "Must be < 16 characters";
            }
        }
    };
        

    vm.PwdClear = function () {   
        if (!vm.password) {
            vm.pwdValid = false;
            vm.errorPwdMsg = "Invalid password";
        }      
    };

    vm.showErrorMsg = function (errType, message) {
        if (errType == 1) {
            vm.emlValid = false;
            vm.errorEmailMsg = message;
        }
        else if (errType == 2) {
            vm.pwdValid = false;
            vm.errorPwdMsg = message;
        }
        else if (errType == 3) {
            vm.signInValid = false;
            vm.errMsg = message;
        }
        if(errType==2)
            vm.password = null;
        else {
            vm.email = null;
            vm.password = null;
        }
    };

    vm.navigate = function (url, response) {
        $('.modal-backdrop').remove();
        $window.sessionStorage.setItem("8B3414FB", response.id);
        $state.go(url);
    };

    vm.rspStaus = function (id, response) {
        if (response.refId != undefined) {
            return response.refId.indexOf(id) > -1;
        }
    };

    vm.SignIn = function () {
        if (vm.email && vm.password) {
            showLoader();
            signinSrvc.signInMember_New(vm.email, vm.password, function (response, status) {
                if (status == 200) {
                    $window.localStorage.removeItem("memreg");
                    if (vm.rspStaus(10, response) == true) { alert("server error"); }
                    else if (vm.rspStaus(6, response) == true) { vm.showErrorMsg(1, 'Please sign in with your social network'); }
                    else if (vm.rspStaus(7, response) == true) { vm.showErrorMsg(1, 'Please sign in with your social network'); }
                    else if (vm.rspStaus(9, response) == true) { vm.showErrorMsg(1, 'Unregistered email, try social login'); }
                    else if (vm.rspStaus(5, response) == true) { vm.showErrorMsg(2, 'Incorrect password'); }
                    else if (vm.rspStaus(8, response) == true) { vm.showErrorMsg(3, "Your account has been suspended. Please contact our helpdesk for further information"); }
                    else if (vm.rspStaus(3, response) == true) { vm.navigate("profilehide", response); }
                    else if (vm.rspStaus(1, response) == true) { vm.navigate("privacy-policy-pop", response); }
                    else if (vm.rspStaus(2, response) == true) { vm.navigate("terms-conditionspop", response); }
                    else if (vm.rspStaus(4, response) == true) { vm.navigate("signinpwdrotation", response); }
                    else if (getSessionSrvc.validateSessionInfo(response)) {
                        $window.sessionStorage.removeItem("8B3414FB");
                        getSessionSrvc.setLoginData(response);
                        $state.go('dashboard');
                    }
                }
                  hideLoader();
            });
        }
        else
            vm.showErrorMsg(3, "Please fill all fileds!");
    };

    vm.regClk = function () {
        showLoader();
        $state.go("register");
    };
    //#endregion

    //#region used for password rotation
    vm.newpassword = "";
    vm.pwdErr = false;
    vm.pwdErrMsg = "";
    vm.confirmPassword = "";
    vm.currentpassword = "";
    vm.cpwdErr = false;
    vm.cpwdErrMsg = "";
    vm.crtpwdErr = false;
    vm.pwdmatchErr = false;
    vm.pwdmatchErrMsg = "";
    vm.crtpwdErrMsg = "";
    //password textbox focus event for showing guidlines
    vm.pwdGuidLines = function () {
        $("#pwdgl").css("display", "").css("position", "relative");
    };
    vm.pwdChange = function () {
        vm.pwdErr = false;
        vm.pwdmatchErr = false;
        vm.pwdVal = vm.pwdTest(vm.newpassword);
        if (!vm.pwdVal)
            vm.newpasswordval = undefined;
        else
            vm.newpasswordval = vm.newpassword;
        if (vm.newpassword && vm.newpassword.length > 16) {
            vm.newpassword = "";
            vm.pwdErr = true;
            vm.pwdErrMsg = "Must be < 16 characters";
        }
    };

    vm.CnfPwdChange = function () {
        vm.cpwdErr = false;        
        if (vm.confirmPassword && vm.confirmPassword.length > 16) {
            vm.confirmPassword = "";
            vm.cpwdErr = true;
            vm.cpwdErrMsg = "Must be < 16 characters";
        }
    };

    vm.prPwdCheck = function () {
        if (vm.newpassword == "") {
            vm.pwdErr = true;
            vm.pwdmatchErr = false;
            vm.pwdErrMsg = 'Please Enter Password';
        }
        else if (vm.newpasswordval == undefined) { //if regular expression falild it will return undefind
            vm.pwdErr = true;
            vm.pwdmatchErr = false;
            vm.cpwdErr = false;
            vm.pwdErrMsg = 'Please follow password guidelines';
            vm.newpassword = "";
        }
        else if (vm.currentpassword == vm.newpassword) {
            vm.pwdErr = false;
            vm.pwdmatchErr = true;
            vm.pwdmatchErrMsg = 'Previous password can’t be used';
            vm.newpassword = "";
        }
        else if (vm.confirmPassword == undefined || vm.newpassword != vm.confirmPassword) {
            vm.cpwdErr = true;
            vm.cpwdErrMsg = 'Password does not match';
        }
        else if (vm.newpassword != "" && vm.newpasswordval != undefined) {
            vm.pwdErr = false;
            vm.cpwdErr = false;
        }
        else
            vm.pwdmatchErr = false;
        $("#pwdgl").css("display", "none");
    };

    vm.cnfPwdCheck = function () {
        if (vm.newpassword)
        if (vm.confirmPassword == undefined || vm.newpassword != vm.confirmPassword) {
            vm.cpwdErr = true;
            vm.cpwdErrMsg = 'Password does not match';
        }
        else
            vm.cpwdErr = false;
    };

    vm.crtpwdChange = function () {
        vm.crtpwdErr = false;
        if (vm.currentpassword && vm.currentpassword.length > 16) {
            vm.currentpassword = "";
            vm.crtpwdErr = true;
            vm.crtpwdErrMsg = "Must be < 16 characters";
        }
    };

    vm.crtpwdCheck = function () {
        if (vm.currentpassword == "") {
            vm.crtpwdErr = true;
            vm.crtpwdErrMsg = 'Please Enter valid Password';
        }
    };

    vm.frgtPwd = function () {
        showLoader();
        $state.go('forgotpwd');
    };

    vm.pwdRotationNext = function () {
        var memId = $window.sessionStorage.getItem("8B3414FB");
        if ($scope.formRotation.$valid) {
            showLoader();
            if (memId != "" && memId != undefined) {
                signinSrvc.pwdrotation(memId, vm.currentpassword, vm.newpassword, function (response, status) {
                    hideLoader();
                    if (status == 200) {
                        if (vm.rspStaus(10, response) == true) { alert("server error"); }
                        else if (vm.rspStaus(3, response) == true) { vm.navigate("profilehide", response); }
                        else if (vm.rspStaus(1, response) == true) { vm.navigate("privacy-policy-pop", response); }
                        else if (vm.rspStaus(2, response) == true) { vm.navigate("terms-conditionspop", response); }
                        else if (response == false) {
                            vm.crtpwdErr = true;
                            vm.crtpwdErrMsg = "Sorry we are unable to process, please try again later";
                        }
                        //if response true also it will go inside if we not add 3 equils
                        else if (response == 3) {
                            vm.pwdErrMsg = "Previous password can’t be used";
                            vm.pwdErr = true;
                            vm.newpassword = "";
                            vm.confirmPassword = "";
                        }
                        else if (response == 2) {
                            vm.crtpwdErr = true;
                            vm.crtpwdErrMsg = "Incorrect Password";
                            vm.currentpassword = "";
                        }
                        else if (response == true) {
                            $window.sessionStorage.removeItem("8B3414FB");
                            $state.go('signin');
                        }
                    }
                });
            }
        }
        else
            alert("Please fill all fileds!");
    };
    //#endregion 

    //#region used for profile un-hide
    vm.pflhdCnfrm = function () {
        $('body').removeClass().removeAttr('style');//Remove back drop opacity 
        $('.modal-backdrop').remove();
        var ids = $window.sessionStorage.getItem("8B3414FB");
        if (ids != "") {
            showLoader();
            signinSrvc.removepflhd(ids, function (response, status) {
                if (status == 200) {
                    if (vm.rspStaus(10, response) == true) { alert("server error"); }
                    else if (vm.rspStaus(1, response) == true) { vm.navigate("privacy-policy-pop", response); }
                    else if (vm.rspStaus(2, response) == true) { vm.navigate("terms-conditionspop", response); }
                    else if (vm.rspStaus(4, response) == true) { vm.navigate("signinpwdrotation", response); }
                    else if (getSessionSrvc.validateSessionInfo(response)) {
                        $window.sessionStorage.removeItem("DtpsNtP");
                        $window.sessionStorage.removeItem("8B3414FB");
                        getSessionSrvc.setLoginData(response);
                        $state.go('dashboard');
                    }
                }
            });
        }
    };

    vm.pflhdCancel = function () {
        $window.sessionStorage.removeItem("8B3414FB");
        $('.modal-backdrop').remove();
        $state.go("signin");
    };
    //#endregion
}]);