﻿app.service('forgotpwdSrvc', ['$http', '$window', function ($http, $window) {
    //Service for forgot password
    this.forgotPwd = function (email, dob, funCallBack) {
        var data = { email: email, dob: dob }
        var url = "https://pcapi.pyar.com/api/registersignin/fpemlval";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //Service for Reset Password
    this.resetPwd = function (memberId, secanswer, funCallBack) {
        var data = { memberId: memberId, secanswer: secanswer }
        var url = "https://pcapi.pyar.com/api/registersignin/fpsecaval";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //Service for resendOTP
    this.resedOTP = function (memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/registersignin/rsndresetpwdotp/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Service for Check OTP valid or not
    this.otpVerify = function (memberId, otpId, otpCode, funCallBack) {
        var data = { memberId: memberId, otpId: otpId, otpCode: otpCode };
        var url = "https://pcapi.pyar.com/api/registersignin/frgtpwdotpvrfy";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //Service for Change Password
    this.changePwd = function (memberId, newpassword, funCallBack) {
        var data = { memberId: memberId, newpassword: newpassword }
        var url = "https://pcapi.pyar.com/api/registersignin/fprstpwd ";
        PostServiceByURL($http, url, data, funCallBack);
    };
}]);