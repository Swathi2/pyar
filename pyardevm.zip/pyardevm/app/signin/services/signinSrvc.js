﻿app.service('signinSrvc', ['$http', '$window', function ($http, $window) {
    //for signin
    this.signInMember_New = function (email, pwd, funCallBack) {
        var data = { email: email, pwd: pwd, }
        var url = "https://pcapi.pyar.com/api/registersignin/signin_New";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //Service for Password Rotation after 90days
    this.pwdrotation = function (memberId, currentpassword, newpassword, funCallBack) {
        var data = { memberId: memberId, currentpassword: currentpassword, newpassword: newpassword }
        var url = "https://pcapi.pyar.com/api/registersignin/cgpd";
        PostServiceByURL($http, url, data, funCallBack);
    };

    // for remove profile hide
    this.removepflhd = function (ids, funCallBack) {
        var data = { ids: ids }
        var url = "https://pcapi.pyar.com/api/registersignin/rmprflhd/" + ids;
        PostServiceByURL($http, url, data, funCallBack);
    }
}]);