﻿angular.module("app").controller('newMessageCtrl', ['getSessionSrvc', 'msgSrvc', '$scope', '$rootScope', '$timeout', function (getSessionSrvc, msgSrvc, $scope, $rootScope, $timeout) {
    var vm = this;
    vm.showNM = false;
    vm.noResults = false;
    vm.txtNWSrch = "";
    vm.mId = function () { return getSessionSrvc.p_mId(); }
    vm.saveSrchRslt = [];
    vm.nwSrchRslt = [];
    vm.imgCDN = "https://pccdn.pyar.com/";
    vm.ppm = "https://pccdn.pyar.com/pcmbr/defaults/profilemtns.jpg";
    vm.ppf = "https://pccdn.pyar.com/pcmbr/defaults/profileftns.jpg";

    $scope.$on("openNM", function (e) {
        vm.showNM = true;
        vm.noResults = false;
        vm.txtNWSrch = "";
        vm.saveSrchRslt = [];
        vm.nwSrchRslt = [];
        $timeout(function () { $("#txtNWSrch").focus(); }, 100);
        $("body").css("overflow", "hidden");
    });

    vm.hideNM = function () {
        $rootScope.$broadcast("closeNM");
        vm.showNM = false;
        $("body").css("overflow", "");
    };

    vm.srchNWM = function () {
        try {
            if (vm.txtNWSrch.length > 2) {
                if (vm.txtNWSrch.length == 3 && !vm.checkSaveResults(vm.txtNWSrch)) {
                    showLoader();
                    var keyword = vm.txtNWSrch;
                    msgSrvc.getMNWSrch(vm.mId(), vm.txtNWSrch, function (response, status) {
                        hideLoader();
                        if (status == 200) {
                            if (response && response.length > 0)
                                vm.saveSrchResponse(keyword, response);
                            vm.showSrchResults(keyword);
                        }
                        else {
                            console.log("msgSrvc.getMNWSrch  --  " + e.message);
                        }
                    });
                }
                else
                    vm.showSrchResults(vm.txtNWSrch);
            }
            else if (vm.txtNWSrch.length > 3)
                vm.showSrchResults(vm.txtNWSrch);
            else {
                vm.showHideSrchRslt();
            }
        } catch (e) {
            console.log("vm.srchNWM  --  " + e.message);
        }
    };

    vm.showSrchResults = function (keyword) {
        try {
            vm.nwSrchRslt = [];
            var srchRslt = vm.getSaveResults(keyword);
            for (var i = 0; i < srchRslt.length; i++) {
                if (srchRslt[i].fn.toLowerCase().indexOf(keyword.toLowerCase()) == 0)
                    vm.nwSrchRslt.push(srchRslt[i]);
            }
            vm.showHideSrchRslt();
        } catch (e) {
            console.log("vm.showSrchResults  --  " + e.message);
        }
    };

    vm.checkSaveResults = function (keyword) {
        try {
            var rsltExist = false;
            for (var i = 0; i < vm.saveSrchRslt.length; i++) {
                if (vm.saveSrchRslt[i].keyword == keyword) {
                    rsltExist = true;
                    break
                }
            }
            return rsltExist;
        } catch (e) {
            console.log("vm.checkSaveResults  --  " + e.message);
        }
    };

    vm.getSaveResults = function (keyword) {
        try {
            var response = [];
            for (var i = 0; i < vm.saveSrchRslt.length; i++) {
                if (keyword.toLowerCase().indexOf(vm.saveSrchRslt[i].keyword.toLowerCase())==0) {
                    response = vm.saveSrchRslt[i].response;
                    break;
                }
            }
            return response;
        } catch (e) {
            console.log("vm.getSaveResults  --  " + e.message);
        }
    };

    vm.saveSrchResponse = function (keyword, response) {
        try {
            var keyNotExist = true;
            for (var i = 0; i < vm.saveSrchRslt.length; i++) {
                if (vm.saveSrchRslt[i].keyword == keyword) {
                    vm.saveSrchRslt[i].response = response;
                    keyNotExist = false;
                    break;
                }
            }
            if (keyNotExist)
                vm.saveSrchRslt.push({ "keyword": keyword, "response": response });
        } catch (e) {
            console.log("vm.saveSrchResponse  --  " + e.message);
        }
    };

    vm.showHideSrchRslt = function () {
        try {
            if (vm.txtNWSrch.length > 2) {
                if (vm.nwSrchRslt.length > 0)
                    vm.noResults = false;
                else
                    vm.noResults = true;
            }
            else {
                vm.noResults = false;
                vm.nwSrchRslt = [];
            }
        } catch (e) {
            console.log("vm.showHideSrchRslt  --  " + e.message);
        }
    };

    vm.openMmeberChat = function (mbr) {
        try {
            vm.showNM = false;
            $rootScope.$broadcast("openMMC", mbr.tmId, mbr.fn, "NM");
        } catch (e) {
            console.log("vm.openMmeberChat  --  " + e.message);
        }
    };

    vm.getPP = function (imgPath, gender) {
        if (imgPath) return vm.imgCDN + imgPath.replace("/p/tnb/", "/p/tns/");
        else if (gender == true) return vm.ppm;
        else return vm.ppf;
    };
}]);