﻿angular.module("app").controller('msgcenterCtrl', ['getSessionSrvc', 'msgSrvc', '$scope', '$rootScope', '$filter', '$timeout', function (getSessionSrvc, msgSrvc, $scope, $rootScope, $filter, $timeout) {
    var vm = this;
    vm.sId = function () { return getSessionSrvc.p_sub(); }
    vm.mId = function () { return getSessionSrvc.p_mId(); }
    vm.tz = function () { return getSessionSrvc.p_tz(); };
    setFooterIcon("msgc");
    vm.mrc = [];
    vm.macList = [];
    vm.mcs = null;
    vm.aprOnline = false;
    vm.bdyCls = "margin-top:125px;";
    vm.imgCDN = "https://pccdn.pyar.com/";
    vm.ppm = "https://pccdn.pyar.com/pcmbr/defaults/profilemtns.jpg";
    vm.ppf = "https://pccdn.pyar.com/pcmbr/defaults/profileftns.jpg";
    vm.ShowDvOnline = false;
    vm.rmcStopScroll = false;
    vm.pasted = false;
    vm.editMode = false;
    vm.basicSearch = 'Search';
    vm.srchStr = "";
    vm.saveSrchRslt = [];
    vm.pgNo = 1;
    vm.pgSize = 10;
    vm.mrcBusy = false;
    vm.enableDelbutton = false;
    vm.selectedRMC = [];
    vm.zone = function () { return getTimeZoneById(vm.tz()); };
    vm.mmCnt = 0;
    vm.searchOn = false;
    vm.rmcSrchRslt = [];
    vm.internetAvail = $rootScope.online;
    vm.actMbrsSwiper = null;
    vm.mmc = false;
    vm.mmcScrollTo = 0;

    /**********************************************************
                      msg service listeners start
    **********************************************************/
    $scope.$on("msgSrvcReady", function (e) {
        try {
            vm.loadPgData();
        } catch (e) {
            console.log("msgSrvcReady listener  --  " + e.message);
        }
    });

    $scope.$on("receiveMsg", function (e, tmId, fn, msg, tmpp, convrnId, dt, sender) {
        try {
            if (!sender) {
                vm.incrMsgCount(tmId);
                vm.updateRecentMsg(tmId, msg, dt, true);
                $scope.$digest();
            }
        } catch (e) {
            console.log("receiveMsg listener  --  " + e.message);
        }
    });

    $scope.$on("onlineStatusChg", function (e, mId, statusType, status) {
        try {
            //for recent msg contacts
            for (var i = 0; i < vm.mrc.length; i++) {
                if (vm.mrc[i].tmId == mId) {
                    if (statusType == 1)
                        vm.mrc[i].online = status;
                    else if (statusType == 2)
                        vm.mrc[i].offline = status;
                    $scope.$digest();
                    break;
                }
            }
            //for active now contacts
            for (var i = 0; i < vm.macList.length; i++) {
                if (vm.macList[i].tmId == mId) {
                    if (statusType == 1)
                        vm.macList[i].online = status;
                    else if (statusType == 2)
                        vm.macList[i].offline = status;
                    $scope.$digest();
                    break;
                }
            }
            //for check active count and manage heights
            vm.manageHeights();
        } catch (e) {
            console.log("onlineStatusChg listener  --  " + e.message);
        }
    });

    $scope.$on("selfOnlineStatusChg", function (e, mId, statusType, status) {
        try {
            if (vm.mId() == mId && statusType == 2) {
                vm.mcs.offline = status;
                vm.aprOnline = !vm.mcs.offline
                $scope.$digest();
            }
        } catch (e) {
            console.log("selfOnlineStatusChg listener  --  " + e.message);
        }
    });
    /**********************************************************
                      msg service listeners end
    **********************************************************/

    /**********************************************************
                      msg service functions start
    **********************************************************/
    vm.getMMCount = function () {
        try {
            msgSrvc.getMessagesCount(vm.mId(), function (response, status) {
                if (status == 200) {
                    vm.mmCnt = response.tmIds;
                    $rootScope.$broadcast("setMsgReadCount", response.tmIds);
                }
            });
        } catch (e) {
            console.log("vm.getMMCount  --  " + e.message);
        }
    };

    vm.getMAC = function () {
        try {
            msgSrvc.getMAC(vm.mId(), function (response, status) {
                if (status == 200 && response)
                    vm.macList = response;
            });
        } catch (e) {
            console.log("vm.getMAC  --  " + e.message);
        }
    };

    vm.getMCS = function () {
        try {
            msgSrvc.getChatSettings(vm.mId(), function (response, status) {
                if (status == 200) {
                    vm.mcs = response;
                    vm.aprOnline = !vm.mcs.offline;
                }
            });
        } catch (e) {
            console.log("vm.getMCS  --  " + e.message);
        }
    };

    vm.updateMCS = function (type, status) {
        try {
            msgSrvc.updateMemberChatSettings(vm.mId(), type, status, function (response, respSstatus) {
                if (respSstatus == 200) {
                    if (type == 1) {
                        vm.mcs.offline = status;
                        msgSrvc.updateMemberOnlineStatus(2, status);
                    }
                }
            });
        } catch (e) {
            console.log("vm.updateMCS  --  " + e.message);
        }
    };

    vm.getRMC = function () {
        try {
            if (vm.rmcStopScroll) return;
            vm.mrcBusy = true;
            $("#dvrmcLdr").show();
            msgSrvc.getMemberRecentMsgContacts(vm.mId(), vm.pgNo, vm.pgSize, function (response, status) {
                vm.mrcBusy = false;
                hideLoader();
                $("#dvrmcLdr").hide();
                if (status == 200) {
                    //check stop scroll for get next items
                    if (response.length < vm.pgSize)
                        vm.rmcStopScroll = true;

                    //add chat contacts
                    for (var i = 0; i < response.length; i++) {
                        var nrExist = true;
                        for (var j = 0; j < vm.mrc.length; j++) {
                            if (response[i].tmId == vm.mrc[j].tmId) {
                                nrExist = false;
                                break;
                            }
                        }
                        if (nrExist)
                            vm.mrc.push(response[i]);
                    }

                    //check empty state
                    if (vm.mrc.length == 0)
                        vm.noMsgs = true;
                    else
                        vm.noMsgs = false;
                    vm.pgNo++;
                }
            });
        } catch (e) {
            console.log("vm.getRMC  --  " + e.message);
        }
    };

    vm.addMRC = function (fmId, tmId) {
        try {
            msgSrvc.getMemberConvrnHead(fmId, tmId, function (response, status) {
                if (status == 200 && response) {
                    var nrExist = true;
                    for (var i = 0; i < vm.mrc.length; i++) {
                        if (vm.mrc[i].tmId == tmId) {
                            nrExist = false;
                            break;
                        }
                    }
                    if (nrExist) {
                        vm.mrc.push(response);
                        //check after add if empty state is there then change to non empty state
                        if (vm.noMsgs == true && vm.mrc.count > 0)
                            vm.noMsgs = false;
                    }
                }
            });
        } catch (e) {
            console.log("vm.addMRC  --  " + e.message);
        }
    };
    /**********************************************************
                        msg service functions end
    **********************************************************/

    /**********************************************************
                        self listeners start
    **********************************************************/
    $scope.$on("offline", function (e) {
        try {
            vm.internetAvail = $rootScope.online;
        } catch (e) {
            console.log("offline listener  --  " + e.message);
        }
    });

    $scope.$on("online", function (e) {
        try {
            vm.internetAvail = $rootScope.online;
        } catch (e) {
            console.log("online listener  --  " + e.message);
        }
    });

    $scope.$on("updateSentMsg", function (e, tmId, msg, msgDT) {
        try {
            vm.updateRecentMsg(tmId, msg, msgDT, false);
        } catch (e) {
            console.log("updateLastMsg listener  --  " + e.message);
        }
    });

    $scope.$on("chgMsgReadCount", function (e, tmIds, status) {
        try {
            for (var i = 0; i < tmIds.length; i++) {
                if (status)
                    vm.incrMsgCount(tmIds[i]);
                else
                    vm.decrMsgCount(tmIds[i]);
                for (var j = 0; j < vm.mrc.length; j++) {
                    if (vm.mrc[j].tmId == tmIds[i]) {
                        vm.mrc[j].urExist = status;
                        break;
                    }
                }
            }
        } catch (e) {
            console.log("chgMsgReadCount listener  --  " + e.message);
        }
    });

    $scope.$on("actMbrSwiper", function (e) {
        try {
            vm.updateAMSwiper();
        } catch (e) {
            console.log("actMbrSwiper listener  --  " + e.message);
        }
    });

    $scope.$on("closeMMC", function (e, refPgType) {
        if (refPgType == "MC" || refPgType == "NM") {
            vm.mmc = false;
            $timeout(function () { window.scrollTo(0, vm.mmcScrollTo); }, 0);
        }
    });

    $scope.$on("closeNM", function (e) {
        vm.mmc = false;
        $timeout(function () { window.scrollTo(0, vm.mmcScrollTo); }, 0);
    });
    /**********************************************************
                        selft listeners end
    **********************************************************/

    /**********************************************************
            msg center helper functions start
    **********************************************************/
    //used to open appear offline and online div
    vm.onlineDvShow = function () {
        try {
            vm.ShowDvOnline = !vm.ShowDvOnline;
            vm.manageHeights();
        } catch (e) {
            console.log("vm.onlineDvShow  --  " + e.message);
        }
    };

    //update recent msg to user
    vm.updateRecentMsg = function (tmId, msg, msgDT, urExist) {
        try {
            var nrExist = true;
            for (var i = 0; i < vm.mrc.length; i++) {
                if (vm.mrc[i].tmId == tmId) {
                    nrExist = false;
                    vm.mrc[i].msg = msg;
                    vm.mrc[i].msgDT = msgDT;
                    vm.mrc[i].urExist = urExist;
                    break;
                }
            }
            if (nrExist)
                vm.addMRC(vm.mId(), tmId);
        } catch (e) {
            console.log("vm.updateRecentMsg  --  " + e.message);
        }
    };

    //update actie member swiper on status change
    vm.updateAMSwiper = function () {
        try {
            vm.actMbrsSwiper = new Swiper('.mbractSwiper', {
                slidesPerView: 5,
                paginationClickable: true
            });
            vm.manageHeights();
        } catch (e) {
            console.log("vm.updateAMSwiper  --  " + e.message);
        }
    };

    vm.manageHeights = function () {
        if (vm.searchOn == false) {
            var maCnt = vm.getActCount();
            if (vm.ShowDvOnline && maCnt > 0)
                vm.bdyCls = "margin-top:272px;";
            else if (!vm.ShowDvOnline && maCnt > 0)
                vm.bdyCls = "margin-top:245px;";
            else if (vm.ShowDvOnline && maCnt == 0)
                vm.bdyCls = "margin-top:162px;";
            else
                vm.bdyCls = "margin-top:127px;";
        }
        else
            vm.bdyCls = "margin-top:100px;";
    };

    //edit messages mode
    vm.setEditMode = function () {
        try {
            $("#pcFtr").hide();
            $(".nvtgle").hide();
            if (vm.ShowDvOnline)
                vm.onlineDvShow();

            vm.editMode = true;
        } catch (e) {
            console.log("vm.setEditMode  --  " + e.message);
        }
    };

    // messages edit mode exit
    vm.cancelEditMode = function () {
        try {
            $("#pcFtr").show();
            $(".nvtgle").show();
            vm.editMode = false;
            for (var i = 0; i < vm.mrc.length; i++) {
                if (vm.mrc[i].checked == true) {
                    vm.mrc[i].checked = false;
                }
            }
        } catch (e) {
            console.log("vm.cancelEditMode  --  " + e.message);
        }
    };

    //edit message if msg where selected for read/delete
    vm.chkChgRMC = function (mbr, checked) {
        try {
            if (checked)
                vm.selectedRMC.push({ "tmId": mbr.tmId, "urExist": mbr.urExist, "convrnId": mbr.convrnId });
            else {
                for (var i = 0; i < vm.selectedRMC.length; i++) {
                    if (vm.selectedRMC[i].tmId == mbr.tmId) {
                        vm.selectedRMC.splice(i, 1);
                        break;
                    }
                }
            }
        } catch (e) {
            console.log("vm.chkChgRMC  --  " + e.message);
        }
    };

    // to mark as unread message
    vm.markUnRead = function () {
        try {
            var tmIds = [];
            //checking the read msg contacts from selected list
            for (var i = 0; i < vm.selectedRMC.length; i++) {
                if (vm.selectedRMC[i].urExist == false)
                    tmIds.push(vm.selectedRMC[i].tmId);
            }
            if (tmIds.length > 0) {
                showLoader();
                msgSrvc.updateMsgConvHdMarkAsReadMulti(vm.mId(), tmIds, true, function (response, status) {
                    hideLoader();
                    if (status == 200 && response) {
                        for (var i = 0; i < tmIds.length; i++) {
                            for (var j = 0; j < vm.mrc.length; j++) {
                                if (tmIds[i] == vm.mrc[j].tmId) {
                                    vm.mrc[j].urExist = true;   //making read msg as unread
                                    break;
                                }
                            }
                            vm.incrMsgCount(tmIds[i]);
                        }
                        //for footer message number change
                        $rootScope.$broadcast("chgMsgReadCount", tmIds, true);
                        //empty the selectd list
                        vm.selectedRMC = [];
                        vm.cancelEditMode();
                    }
                });
            }
            else
                vm.cancelEditMode();
        } catch (e) {
            console.log("vm.markUnRead  --  " + e.message);
        }
    };

    //confirm delete popup
    vm.delConfirm = function () {
        try {
            $("#dvDelPopup").modal('show');
        } catch (e) {
            console.log("vm.deletePopup  --  " + e.message);
        }
    };

    //to delete message
    vm.deleteMsg = function () {
        try {
            var tmIds = [];
            var converIds = [];
            for (var i = 0; i < vm.selectedRMC.length; i++) {
                tmIds.push(vm.selectedRMC[i].tmId);
                converIds.push(vm.selectedRMC[i].convrnId);
            }
            if (tmIds.length > 0) {
                showLoader();
                msgSrvc.updateMsgConvHdDMulti(vm.mId(), tmIds, converIds, function (response, status) {
                    hideLoader();
                    if (status == 200 && response) {
                        for (var i = 0; i < tmIds.length; i++) {
                            for (var j = 0; j < vm.mrc.length; j++) {
                                if (tmIds[i] == vm.mrc[j].tmId) {
                                    vm.mrc.splice(j, 1);
                                    break;
                                }
                            }
                            vm.decrMsgCount(tmIds[i]);
                        }
                        //for footer message number change
                        $rootScope.$broadcast("chgMsgReadCount", tmIds, false);
                        //empty the selected list
                        vm.selectedRMC = [];
                        vm.cancelEditMode();

                        //after delete check empty state
                        if (vm.mrc.length == 0) {
                            if (vm.rmcStopScroll == false)
                                vm.getRMC();
                            else {
                                vm.noMsgs = true;
                                vm.manageHeights();
                            }
                        }
                    }
                });
            }
        } catch (e) {
            console.log("vm.deleteMsg  --  " + e.message);
        }
    };

    // open private chat
    vm.openMmeberChat = function (mbr) {
        try {
            vm.mmcScrollTo = $(window).scrollTop();
            vm.mmc = true;
            $rootScope.$broadcast("openMMC", mbr.tmId, mbr.fn,"MC");
            vm.cancelSrch();
        } catch (e) {
            console.log("vm.opneMmeberChat  --  " + e.message);
        }
    };

    //active now member click event
    vm.openActMbrChat = function (mbr) {
        try {
            if (!vm.editMode) {
                vm.mmc = true;
                $rootScope.$broadcast("openMMC", mbr.tmId, mbr.fn, "MC");
            }
        } catch (e) {
            console.log("vm.openActMbrChat  --  " + e.message);
        }
    };

    //open new message 
    vm.openNM = function () {
        try {
            if (vm.sId() == 1)
                $rootScope.$broadcast("showPremiumPopup", "NM");
            else {
                vm.mmcScrollTo = $(window).scrollTop();
                vm.mmc = false;
                $rootScope.$broadcast("openNM");
            }
        }
        catch (e) {
            console.log("vm.messaging  --  " + e.message);
        }
    };

    vm.getDateOrTime = function (dt) {
        try {
            var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), dt);
            if (dtObj.date)
                return dtObj.date;
            else if (dtObj.time)
                return dtObj.time;
            else
                return "";
        } catch (e) {
            console.log("vm.getDateOrTime  --  " + e.message);
        }
    };

    vm.getPP = function (imgPath, gender) {
        if (imgPath) return vm.imgCDN + imgPath.replace("/p/tnb/", "/p/tns/");
        else if (gender == true) return vm.ppm;
        else return vm.ppf;
    };

    vm.incrMsgCount = function (mId) {
        try {
            var notExist = true;
            if (vm.mmCnt && vm.mmCnt.length > 0) {
                for (var i = 0; i < vm.mmCnt.length; i++) {
                    if (vm.mmCnt[i] == mId) {
                        notExist = false;
                    }
                }
            }
            if (notExist)
                vm.mmCnt.push(mId);
        } catch (e) {
            console.log("vm.incrMsgCount  --  " + e.message);
        }
    };

    vm.decrMsgCount = function (mId) {
        try {
            if (vm.mmCnt && vm.mmCnt.length > 0) {
                for (var i = 0; i < vm.mmCnt.length; i++) {
                    if (vm.mmCnt[i] == mId) {
                        vm.mmCnt.splice(i, 1);
                        break;
                    }
                }
            }
        } catch (e) {
            console.log("vm.decrMsgCount  --  " + e.message);
        }
    };

    vm.getActCount = function () {
        var maCnt = 0;
        for (var i = 0; i < vm.macList.length; i++) {
            if (vm.macList[i].online == true && vm.macList[i].offline == false)
                maCnt++;
        }
        return maCnt;
    };
    /**********************************************************
            msg center helper functions start
    **********************************************************/

    /**********************************************************
                member message contact search start
    **********************************************************/
    vm.openRMCSrch = function () {
        try {
            if (vm.srchStr == "") {
                vm.searchOn = true;
                vm.rmcSrchRslt = [];
                vm.noResults = false;
                vm.ShowDvOnline = false;
                vm.manageHeights();
            }
        } catch (e) {
            console.log("vm.openRMCSrch  --  " + e.message);
        }
    };

    vm.rmcSrchChg = function () {
        try {
            //check srch lengh and show error msg
            if (vm.pasted == true && vm.srchStr.length > 100) {
                vm.srchStr = "";
                vm.basicSearch = "Must be <100 character";
                vm.lenErr = true;
                vm.pasted = false;
                return;
            }
            else
                vm.lenErr = false;

            if (vm.srchStr.length > 2) {
                if (vm.srchStr.length == 3 && !vm.checkSaveResults(vm.srchStr)) {
                    showLoader();
                    var keyword = vm.srchStr;
                    msgSrvc.GetMemberRecentMessageHeadsSrch(vm.mId(), vm.srchStr, function (response, status) {
                        hideLoader();
                        if (status == 200) {
                            if (response && response.length > 0)
                                vm.saveSrchResponse(keyword, response);
                            vm.showSrchResults(keyword);
                        }
                    });
                }
                else
                    vm.showSrchResults(vm.srchStr);
            }
            else if (vm.srchStr.length > 3)
                vm.showSrchResults(vm.srchStr);
            else
                vm.showHideSrchRslt();
        } catch (e) {
            console.log("vm.rmcSrchChg  --  " + e.message);
        }
    };

    vm.showSrchResults = function (keyword) {
        try {
            vm.rmcSrchRslt = [];
            var srchRslt = vm.getSaveResults(keyword);
            for (var i = 0; i < srchRslt.length; i++) {
                if (srchRslt[i].fn.toLowerCase().indexOf(keyword.toLowerCase()) == 0)
                    vm.rmcSrchRslt.push(srchRslt[i]);
            }
            vm.showHideSrchRslt();
        } catch (e) {
            console.log("vm.showSrchResults  --  " + e.message);
        }
    };

    vm.checkSaveResults = function (keyword) {
        try {
            var rsltExist = false;
            for (var i = 0; i < vm.saveSrchRslt.length; i++) {
                if (vm.saveSrchRslt[i].keyword == keyword) {
                    rsltExist = true;
                    break
                }
            }
            return rsltExist;
        } catch (e) {
            console.log("vm.checkSaveResults  --  " + e.message);
        }
    };

    vm.getSaveResults = function (keyword) {
        try {
            var response = [];
            for (var i = 0; i < vm.saveSrchRslt.length; i++) {
                if (keyword.toLowerCase().indexOf(vm.saveSrchRslt[i].keyword.toLowerCase()) == 0) {
                    response = vm.saveSrchRslt[i].response;
                    break;
                }
            }
            return response;
        } catch (e) {
            console.log("vm.getSaveResults  --  " + e.message);
        }
    };

    vm.saveSrchResponse = function (keyword, response) {
        try {
            var keyNotExist = true;
            for (var i = 0; i < vm.saveSrchRslt.length; i++) {
                if (vm.saveSrchRslt[i].keyword == keyword) {
                    vm.saveSrchRslt[i].response = response;
                    keyNotExist = false;
                    break;
                }
            }
            if (keyNotExist)
                vm.saveSrchRslt.push({ "keyword": keyword, "response": response });
        } catch (e) {
            console.log("vm.saveSrchResponse  --  " + e.message);
        }
    };

    vm.showHideSrchRslt = function () {
        try {
            if (vm.srchStr.length > 2) {
                if (vm.rmcSrchRslt.length > 0)
                    vm.noResults = false;
                else
                    vm.noResults = true;
            }
            else {
                vm.noResults = false;
                vm.rmcSrchRslt = [];
            }
        } catch (e) {
            console.log("vm.showHideSrchRslt  --  " + e.message);
        }
    };

    vm.fetchSrchResults = function (dat) {
        try {
            vm.noSrchResults = false;
            vm.basicSearch = 'Search';
            vm.lenErr = false;
            if (dat.length >= 1)
                vm.searchOn = true;

            if (dat.length == 0)
                vm.noSrchResults = true;

            //sending data to backend api after validating
            if (dat.length >= 3 && dat.length < 4) {
                msgSrvc.getMNWSrch(vm.mId(), dat, function (response, status) {
                    vm.rmcSrchRslt = response;
                    if (vm.rmcSrchRslt.length == 0) {
                        vm.noSrchResults = true;
                    }
                    hideLoader();
                });
            }
            vm.filteredNames = $filter('filter')(vm.rmcSrchRslt, { 'fn': dat });
        } catch (e) {
            console.log("vm.fetchSrchResults  --  " + e.message);
        }
    };

    vm.clear = function () {
        try {
            vm.rmcSrchRslt = [];
            vm.noResults = false;
            vm.srchStr = "";
            vm.basicSearch = 'Search';
            vm.lenErr = false;
            vm.srchStr = "";

        } catch (e) {
            console.log("vm.clear  --  " + e.message);
        }
    };

    vm.cancelSrch = function () {
        try {
            vm.searchOn = false;
            vm.basicSearch = 'search';
            vm.lenErr = false;
            vm.srchStr = "";
            vm.manageHeights();
        } catch (e) {
            console.log("vm.cancelSrch  --  " + e.message);
        }
    };

    /**********************************************************
                member message contact search end
    **********************************************************/

    /**********************************************************
                        Page Load events start
    **********************************************************/
    vm.loadPgData = function () {
        try {
            if (msgSrvc.apiHost) {
                vm.getMAC();
                vm.getMCS();
                vm.getMMCount();
                vm.getRMC();
            }
        } catch (e) {
            console.log("vm.loadPgData  --  " + e.message);
        }
    };

    vm.loadPgData();
    /**********************************************************
                        Page Load events end
    **********************************************************/
}]);