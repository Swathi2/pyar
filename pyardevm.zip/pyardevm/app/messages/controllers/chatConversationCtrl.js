﻿angular.module("app").controller('chatConversationCtrl', ['$scope', 'getSessionSrvc', '$rootScope', 'msgSrvc', '$filter', '$timeout', function ($scope, getSessionSrvc, $rootScope, msgSrvc, $filter, $timeout) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.sId = function () { return getSessionSrvc.p_sub(); };
    vm.fn = function () { return getSessionSrvc.p_fn() };
    vm.pp = function () { return getSessionSrvc.p_ppic() };
    vm.tz = function () { return getSessionSrvc.p_tz(); };
    vm.imgCDN = "https://pccdn.pyar.com/";
    vm.ppm = "https://pccdn.pyar.com/pcmbr/defaults/profilemtns.jpg";
    vm.ppf = "https://pccdn.pyar.com/pcmbr/defaults/profileftns.jpg";
    vm.scrollTo = 0;
    vm.pgNo = 1;
    vm.pgSize = 15;
    vm.gmmBusy = false;
    vm.stopScroll = true;
    vm.zone = function () { return getTimeZoneById(vm.tz()); };
    vm.typingStatus = false;
    vm.mch = [];
    vm.offlineMsgs = [];
    vm.prvHeight = 0;
    vm.txtSndMsg = "";
    vm.txtPaste = false;
    vm.txtFocus = false;
    vm.lastSeen = false;
    vm.sendTyping = false;
    // 1 - bind msg on selected member
    // 2 - bind previous msg on on scroll
    // 3 - bind sent msg 
    // 4 - bind receive msg
    vm.msgBindType = "";
    vm.showMC = false;
    vm.tmId = "";
    vm.tmfn = "";
    vm.tmpp = "";
    vm.online = "";
    vm.offline = "";
    vm.convrnId = "";
    vm.seenDT = "";
    vm.urExist = null;
    vm.urExistProcess = false;
    vm.isBD = null;
    vm.gender = null;
    /**********************************************************
                    Seof listeners start
    **********************************************************/
    $scope.$on("openMMC", function (e, tmId, fn, refPgType) {
        try {
            vm.refPgType = refPgType;
            if (tmId) {
                //empty the object befor settting 
                vm.showMC = true;
                $("#dvldr").show();
                vm.resetVariables();
                vm.tmId = tmId;
                vm.tmfn = fn;
                vm.checkConvrnHd();
                vm.msgBindType = "1";
                $("body").css("overflow", "hidden");
            }
        } catch (e) {
            console.log("openMMC listener  --  " + e.message);
        }
    });

    $scope.$on("mchBindCmplt", function (e) {
        try {
            if (vm.msgBindType == "2")// on scroll top load previous messages
                $("#dvmch").animate({ scrollTop: ($("#dvmch").prop("scrollHeight") - (vm.prvHeight - 5)) }, 0);
        } catch (e) {
            console.log("mchBindCmplt  listener  --  " + e.message);
        }
    });

    $scope.$on("mchBindCmpltFirst", function (e) {
        try {
            if (vm.msgBindType == "1") {// page load
                $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 0);
                $timeout(function () { vm.checkReadAndisBD(vm.mch); }, 100);
            }
            else if (vm.msgBindType == "3")// sent msg
                $timeout(function () { $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 1000) }, 50);
            else if (vm.msgBindType == "4" && vm.isScrollBottom())// receive msg
            {
                $timeout(function () {
                    $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 500);
                    vm.checkMRS(vm.mId(), vm.tmId);
                }, 50);
            }
        } catch (e) {
            console.log("mchBindCmpltFirst  listener  --  " + e.message);
        }
    });

    $scope.$on("online", function (e) {
        try {
            if (vm.tmId)
                vm.sendOfflineMsgs();
        } catch (e) {
            console.log("online listener  --  " + e.message);
        }
    });
    /**********************************************************
                    Self listeners end
    **********************************************************/

    /**********************************************************
                    msg service listeners start
    **********************************************************/
    $scope.$on("msgSrvcReady", function (e) {
        try {
            if (vm.tmId)
                vm.sendOfflineMsgs();
        } catch (e) {
            console.log("msgSrvcReady listener  --  " + e.message);
        }
    });

    $scope.$on("receiveMsg", function (e, mId, fn, msg, tmpp, convernId, datetime, sender) {
        try {
            if (vm.tmId == mId) {
                vm.msgBindType = "4";
                if (sender)
                    vm.mch.push({ "fmId": vm.mId(), "tmId": vm.tmId, "convrnId": convernId, "msg": msg, "dtCreated": datetime });
                else {
                    vm.mch.push({ "fmId": vm.tmId, "tmId": vm.mId(), "convrnId": convernId, "msg": msg, "dtCreated": datetime });
                    vm.urExist = true;
                }
                vm.lastSeen = false;
                vm.typingStatus = false;
                $scope.$digest();
            }
        } catch (e) {
            console.log("receiveMsg listener  --  " + e.message);
        }
    });

    $scope.$on("recTypeReq", function (e, mId) {
        try {
            if (vm.tmId == mId) {
                vm.typingStatus = true;
                $timeout(function () { vm.typingStatus = false; }, 4000);
                $scope.$digest();
            }
        } catch (e) {
            console.log("recTypeReq listener  --  " + e.message);
        }
    });

    $scope.$on("recSeenStatus", function (e, mId, seenDT) {
        try {
            if (vm.tmId == mId) {
                if (vm.mch.length > 0 && vm.mch[vm.mch.length - 1].fmId == vm.mId()) {
                    var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), seenDT);
                    if (dtObj.date)
                        vm.lastSeenTxt = "Seen " + dtObj.date + " at " + dtObj.time;
                    else
                        vm.lastSeenTxt = "Seen at " + dtObj.time;
                    vm.lastSeen = true;
                    if (vm.isScrollBottom())
                        $timeout(function () { $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 1000) }, 10);
                    $scope.$digest();
                }
            }
        } catch (e) {
            console.log("recSeenStatus listener  --  " + e.message);
        }
    });

    $scope.$on("onlineStatusChg", function (e, mId, statusType, status) {
        try {
            if (vm.tmId == mId) {
                if (statusType == 1)
                    vm.online = status;
                else if (statusType == 2)
                    vm.offline = status;
                $scope.$digest();
            }
        } catch (e) {
            console.log("onlineStatusChg listener  --  " + e.message);
        }
    });
    /**********************************************************
                    msg service listeners end
    **********************************************************/

    /**********************************************************
                    msg service functions start
    **********************************************************/
    vm.getMCH = function (funCallBack) {
        try {
            if (vm.tmId) {
                msgSrvc.getMemberConvrnHead(vm.mId(), vm.tmId, funCallBack);
            }
        } catch (e) {
            console.log("vm.getMCH  --  " + e.message);
        }
    };

    vm.getMbrInfoById = function (mId, funCallBack) {
        try {
            if (mId) {
                msgSrvc.getmemberInfoById(mId, funCallBack);
            }
        } catch (e) {
            console.log("vm.getMbrInfoById  --  " + e.message);
        }
    };

    vm.getMM = function () {
        try {
            if (vm.tmId) {
                if (vm.stopScroll || vm.gmmBusy) return;
                vm.prvHeight = $("#dvmch").prop("scrollHeight");
                $("#dvldr").show();
                vm.gmmBusy = true;
                msgSrvc.getMemberMessages(vm.convrnId, vm.mId(), vm.tmId, vm.pgNo, vm.pgSize, function (response, status) {
                    $("#dvldr").hide();
                    vm.gmmBusy = false;
                    if (status == 200) {
                        if (response && response.length > 0) {
                            if (response.length < vm.pgSize)
                                vm.stopScroll = true;
                            for (var i = 0; i < response.length; i++)
                                vm.mch.unshift(response[i]);
                        }
                        else
                            vm.stopScroll = true;
                        vm.pgNo++;
                    }
                });
            }
        } catch (e) {
            console.log("vm.getMM  --  " + e.message);
        }
    };

    vm.sendMsg = function () {
        try {
            if (vm.sId() == 2) {
                if (vm.txtSndMsg) {
                    if ($rootScope.online) {
                        msgSrvc.sendMsg(vm.tmId, vm.fn(), vm.pp(), vm.convrnId, vm.txtSndMsg);
                        vm.checkMCHdBD(vm.tmId);
                        vm.lastSeen = false;
                        $rootScope.$broadcast("updateSentMsg", vm.tmId, vm.txtSndMsg, moment.utc(new Date()).format());
                    }
                    else {
                        vm.offlineMsgs.push({ "tmId": vm.tmId, "fn": vm.fn(), "pp": vm.pp(), "convrnId": vm.convrnId, "msg": vm.txtSndMsg });
                        vm.disableInput = true;
                    }
                    vm.lastSeen = false;
                    vm.msgBindType = "3";
                    vm.mch.push({ "fmId": vm.mId(), "tmId": vm.tmId, "convrnId": vm.convrnId, "msg": vm.txtSndMsg, "dtCreated": moment.utc(new Date()).format() });
                    vm.txtSndMsg = "";
                }
            }
            else
                $rootScope.$broadcast("showPremiumPopup", "RM");
        } catch (e) {
            console.log("vm.sendMsg  --  " + e.message);
        }
    };

    vm.sendOfflineMsgs = function () {
        try {
            if ($rootScope.online && msgSrvc.conId) {
                while (vm.offlineMsgs.length > 0) {
                    msgSrvc.sendMsg(vm.offlineMsgs[0].tmId, vm.offlineMsgs[0].fn, vm.offlineMsgs[0].pp, vm.offlineMsgs[0].convrnId, vm.offlineMsgs[0].msg);
                    $rootScope.$broadcast("updateSentMsg", vm.offlineMsgs[0].tmId, vm.offlineMsgs[0].msg, moment.utc(new Date()).format());
                    vm.checkMCHdBD(vm.tmId);
                    vm.offlineMsgs.splice(0, 1);
                    vm.disableInput = false;
                }
            }
        } catch (e) {
            console.log("vm.sendOfflineMsgs  --  " + e.message);
        }
    };

    vm.sendTypeReq = function () {
        try {
            if (vm.tmId && vm.txtSndMsg && !vm.sendTyping) {
                vm.sendTyping = true;
                msgSrvc.sendTypeRequest(vm.tmId);
                $timeout(function () { vm.sendTyping = false; }, 5000);
            }
        } catch (e) {
            console.log("vm.sendTypeReq  --  " + e.message);
        }
    };
    /**********************************************************
                    msg service functions start
    **********************************************************/

    /**********************************************************
                    chat convrn helper functions start
    **********************************************************/
    vm.getPP = function (mId, gender) {
        if (mId == vm.tmId)
            return vm.imgCDN + vm.tmpp.replace("/p/tnb/", "/p/tns/");
        else if (mId == vm.mId())
            return vm.imgCDN + vm.pp().replace("/p/tnb/", "/p/tns/");
        else if (gender == true) return vm.ppm;
        else return vm.ppf;
    };

    vm.resetVariables = function () {
        try {
            vm.pgNo = 1;
            vm.stopScroll = false;
            vm.gmmBusy = false;
            vm.lastSeen = false;
            vm.mch = [];
            vm.txtSndMsg = "";
            vm.lenErr = false;
            //to member data
            vm.tmId = "";
            vm.tmfn = "";
            vm.tmpp = "";
            vm.online = "";
            vm.offline = "";
            vm.convrnId = "";
            vm.seenDT = "";
            vm.urExist = null;
            vm.isBD = null;
            vm.gender = null;
            vm.sendTyping = false;
        } catch (e) {
            console.log("vm.resetVariables  --  " + e.message);
        }
    };

    vm.setMbrData = function (tmId, fn, pp, online, offline, convrnId, seenDT, urExist, urExistProcess, isBD, gender) {
        try {
            vm.tmId = tmId;
            vm.tmfn = fn;
            vm.tmpp = pp;
            vm.online = online;
            vm.offline = offline;
            vm.convrnId = convrnId;
            vm.seenDT = seenDT;
            vm.urExist = urExist;
            vm.urExistProcess = urExistProcess;
            vm.isBD = isBD;
            vm.gender = gender;
        } catch (e) {
            console.log("vm.setMbrData  --  " + e.message);
        }
    };

    vm.checkConvrnHd = function () {
        try {
            if (vm.tmId) {
                vm.getMCH(function (response, status) {
                    if (status == 200) {
                        if (response && response != null) {
                            vm.setMbrData(response.tmId, response.fn, response.pp, response.online, response.offline, response.convrnId, response.seenDT, response.urExist, false, response.isBD, response.gender);
                            vm.getMM();
                        }
                        else
                            vm.checkMbrInfo();
                    }
                });
            }
        } catch (e) {
            console.log("vm.checkConvrnHd  --  " + e.message);
        }
    };

    vm.checkMbrInfo = function () {
        try {
            if (vm.tmId) {
                vm.getMbrInfoById(vm.tmId, function (response, status) {
                    if (status == 200) {
                        if (response && response != "invalid mId") {
                            vm.setMbrData(response.mId, response.fn, response.pp, response.online, response.offline, "", "", true, false, true, true);
                            vm.getMM();
                        }
                        else
                            alert("member not found");
                    };
                });
            }
        } catch (e) {
            console.log("vm.checkMbrInfo  --  " + e.message);
        }
    };

    vm.hideMC = function () {
        try {
            $rootScope.$broadcast("closeMMC", vm.refPgType);
            vm.resetVariables();
            $("body").css("overflow", "");
            vm.showMC = false;
        } catch (e) {
            console.log("vm.hideMC  --  " + e.message);
        }
    }

    vm.txtSndMsgFocus = function (e) {
        try {
            if (vm.sId() == 2) {
                vm.ensureVisible(e.currentTarget);
                vm.txtFocus = true;
                if (vm.isScrollBottom())
                    $timeout(function () { $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 0); }, 0);
                //$timeout(function () { $('body').animate({ scrollTop: $('#dvmch').position().top }, 'slow'); }, 0);
            }
            else {
                $("#txtSndMsg").blur();
                $rootScope.$broadcast("showPremiumPopup", "RM");
            }
        } catch (e) {
            console.log("vm.txtSndMsgFocus  --  " + e.message);
        }
    };

    vm.ensureVisible = function (e) {
        $timeout(function () { vm.scrolling(e, 0); }, 300);
    };

    vm.scrolling = function (e, c) {
            e.scrollIntoView();
            if (c < 5) $timeout(function () { vm.scrolling(e, c + 1) }, 300);
    };

    vm.txtSndMsgChg = function () {
        try {
            if (vm.txtPaste && vm.txtSndMsg.length > 1000)
                vm.lenErr = true;
            else
                vm.lenErr = false;

            if (vm.txtSndMsg.length > 1000)
                vm.txtSndMsg = vm.txtSndMsg.substring(0, 1000);
            vm.sendTypeReq();
        } catch (e) {
            console.log("vm.txtSndMsgChg  --  " + e.message);
        }
    };

    vm.txtSndMsgkeyPress = function (event) {
        try {
            if (vm.tmId && event.keyCode == 13 && vm.txtSndMsg.length > 0)
                vm.sendMsg();
        } catch (e) {
            console.log("vm.txtSndMsgkeyPress  --  " + e.message);
        }
    };
    /**********************************************************
                    chat convrn helper functions end
    **********************************************************/

    /**********************************************************
                member chat histroy functions start
    **********************************************************/
    $("#dvmch").scroll(function (e) {
        try {
            if (vm.isScrollTop()) {
                vm.msgBindType = "2";
                vm.getMM();
            }
            else if (vm.isScrollBottom())
                vm.checkMRS(vm.mId(), vm.tmId);
        } catch (e) {
            console.log("dvmch scroll  --  " + e.message);
        }
    });

    vm.checkReadAndisBD = function () {
        try {
            //append last seen when last msg ins login member msg
            var showSeen = false;
            if (vm.mch && vm.mch.length > 0)
                showSeen = $filter("orderBy")(vm.mch, "-dtCreated")[0].fmId == vm.mId() ? true : false;
            if (showSeen && vm.seenDT) {
                var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), vm.seenDT);
                if (dtObj.date)
                    vm.lastSeenTxt = "Seen " + dtObj.date + " at " + dtObj.time;
                else
                    vm.lastSeenTxt = "Seen at " + dtObj.time;
                vm.lastSeen = true;
                $("#dvmch").animate({ scrollTop: $("#dvmch").prop("scrollHeight") }, 1000);
            }
            else
                vm.lastSeen = false;

            //if unread exist true update to read
            if (vm.urExist)
                vm.checkMRS();
            //if conversion are not bidirectional check and update 
            if (!vm.isBD)
                vm.findMBD();
        } catch (e) {
            console.log("vm.checkReadAndisBD  --  " + e.message);
        }
    };

    vm.checkMRS = function () {
        try {
            if (vm.urExist && vm.urExistProcess == false && vm.isScrollBottom())
                vm.updateMRS();
        } catch (e) {
            console.log("vm.checkMRS --  " + e.message);
        }
    };

    vm.updateMRS = function () {
        try {
            vm.urExistProcess = true;
            msgSrvc.updateMsgReadStatus(vm.mId(), vm.tmId, function (response, status) {
                if (status = 200 && response) {
                    vm.urExist = false;
                    vm.urExistProcess = false;
                    //check and decrese the count for unread msgs
                    $rootScope.$broadcast("chgMsgReadCount", [vm.tmId], false);
                }
                else {
                    console.log("unable to update read status  --  " + response);
                }
            });
        } catch (e) {
            console.log("vm.updateMRS --  " + e.message);
        }
    };

    vm.findMBD = function () {
        try {
            if (vm.isBD == false && vm.mch && vm.mch.length > 0) {
                var fmCnt = 0, tmCnt = 0;
                for (var i = 0; i < vm.mch.length; i++) {
                    if (vm.mch[i].fmId == vm.mId())
                        fmCnt++;
                    else
                        tmCnt++;
                }
                //check who to replay for set isBD
                if (vm.mch.length == tmCnt)
                    vm.isBDType = "1";//update in sending msg
                else if (vm.mch.length == fmCnt)
                    vm.isBDType = "2";//update will happen when other member send msg
                else if (fmCnt > 0 && tmCnt > 0) {
                    vm.updateMCHdBD();
                }
            }
        } catch (e) {
            console.log("vm.findMBD --  " + e.message);
        }
    };

    vm.checkMCHdBD = function () {
        try {
            if (vm.isBD == false && vm.isBDType == "1") {
                vm.updateMCHdBD(vm.mId(), vm.tmId);
            }
        } catch (e) {
            console.log("vm.checkMCHdBD  --  " + e.message);
        }
    };

    vm.updateMCHdBD = function () {
        try {
            msgSrvc.updateMsgConvHdBiDirectional(vm.mId(), vm.tmId, function (response, status) {
                if (status == 200 && response == "true") {
                    vm.isBD = true;
                    vm.isBDType = "3";
                    //broadcast for isbdupdate
                    $rootScope.$broadcast("chgIsBD", vm.tmId);
                }
            });
        } catch (e) {
            console.log("vm.updateMCHdBD --  " + e.message);
        }
    };
    /**********************************************************
                member chat histroy functions end
    **********************************************************/

    /**********************************************************
                    member helper function end
    **********************************************************/
    vm.isScrollTop = function () {
        try {
            if ($("#ulmch li").length > 0 && $("#dvmch").length > 0 && $("#dvmch").scrollTop() == 0)
                return true;
            else
                return false;
        } catch (e) {
            console.log("vm.isScrollTop  --  " + e.message);
        }
    };

    vm.isScrollBottom = function () {
        try {
            var $this = $("#dvmch");
            if ($("#ulmch li").length > 0 && $this.length > 0) {
                var scrollTop = $this.scrollTop() + $this.innerHeight() + $("#ulmch li:last-child").height() + 50;
                if (scrollTop >= $this[0].scrollHeight)
                    return true;
                else
                    return false;
            }
            else
                return true;
        } catch (e) {
            console.log("vm.isScrollBottom  --  " + e.message);
        }
    };

    vm.getDateOrTime = function (dt) {
        try {
            var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), dt);
            if (dtObj.date)
                return dtObj.date;
            else if (dtObj.time)
                return dtObj.time;
            else
                return "";
        } catch (e) {
            console.log("vm.getDateOrTime  --  " + e.message);
        }
    };

    vm.isDatesSame = function (fromDt, toDt) {
        try {
            if (fromDt && toDt) {
                fromDt = new Date(fromDt);
                toDt = new Date(toDt);
                return fromDt.getMonth() == toDt.getMonth() && fromDt.getDate() == toDt.getDate() && fromDt.getFullYear() == toDt.getFullYear();
            }
            else
                return null;
        } catch (e) {
            console.log("vm.compareDate  --  " + e.message);
        }
    };

    vm.getDate = function (dt) {
        try {
            return msgSrvc.getDate(vm.zone(), dt);
        } catch (e) {
            console.log("vm.getDate  --  " + e.message);
        }
    };

    vm.getTime = function (dt) {
        try {
            return msgSrvc.getTime(vm.zone(), dt);
        } catch (e) {
            console.log("vm.getTime  --  " + e.message);
        }
    };
    /**********************************************************
                    member helper function end
    **********************************************************/

    vm.gotoProfile = function () {
        if (vm.tmId) {
            if (vm.refPgType == "Match")
                vm.hideMC();
            else {
                vm.scrollTo = $("#dvmch").scrollTop();
                vm.showMC = false;
                $rootScope.$broadcast("openMatch", getSessionSrvc.pce(vm.tmId), "MMC");
            }
        }
    };

    $scope.$on("closeMatch", function (e, refPgType) {
        if (refPgType == "MMC") {
            vm.showMC = true;
            $("#dvmch").animate({ scrollTop: vm.scrollTo }, 0);
        }
    });
}]);