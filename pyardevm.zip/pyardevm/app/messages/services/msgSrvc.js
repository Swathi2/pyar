﻿/**********************************************************
                    Services start
**********************************************************/
angular.module("app").service('msgSrvc', ['$http', '$rootScope', '$timeout', '$cookieStore', function ($http, $rootScope, $timeout, $cookieStore) {
    var vm = this;
    /**********************************************************
                        Variabl Declaration
    **********************************************************/
    vm.mId = function () { return vm.g_ssnd("mId") };
    vm.sId = function () { return vm.g_ssnd("sId") };
    vm.mrc = null;
    vm.addClientMethods = true;
    vm.recTimeOut = null;
    vm.apiHost = "";
    vm.conId = null;
    vm.server = null;
    vm.chatHubProxy = null;
    /**********************************************************
                        Variabl Declaration End
    **********************************************************/

    /**********************************************************
                            Chat Http Services Start
     **********************************************************/
    vm.getServerURL = function (funCallBack) {
        try {
            var url = "https://pcapi.pyar.com/api/msg/mscurl";
            GetServiceByURL($http, url, funCallBack);
        } catch (e) {
            console.log("vm.getServerURL  --  " + e.message);
        }
    };

    vm.updateMemberChatLogintData = function (mId, mrc, sId, scId, conId, status, funCallBack) {
        try {
            if (vm.apiHost) {
                var data = { "mId": mId, "mrc": mrc, "sId": sId, "scId": scId, "conId": conId, "status": status };
                var url = vm.apiHost + "/api/msg/umcld";
                PostServiceByURL($http, url, data, funCallBack);
            }
        } catch (e) {
            console.log("vm.updateMemberChatLogintData  --  " + e.message);
        }
    };

    vm.getMAC = function (mId, funCallBack) {
        try {
            if (vm.apiHost) {
                var url = vm.apiHost + "/api/msg/gmac/" + mId;
                GetServiceByURL($http, url, funCallBack);
            }
        } catch (e) {
            console.log("vm.getMAC  --  " + e.message);
        }
    };

    vm.getMemberConvrnHead = function (fmId, tmId, funCallBack) {
        try {
            if (vm.apiHost) {
                var data = { "fmId": fmId, "tmId": tmId };
                var url = vm.apiHost + "/api/msg/gmch";
                PostServiceByURL($http, url, data, funCallBack);
            }
        } catch (e) {
            console.log("vm.getMemberConvrnHead  --  " + e.message);
        }
    };

    vm.getMNWSrch = function (mId, fName, funcallBack) {
        try {
            if (vm.apiHost) {
                var data = { "mId": mId, "fn": fName };
                var url = vm.apiHost + "/api/msg/mnwsrch";
                PostServiceByURL($http, url, data, funcallBack);
            }
        } catch (e) {
            console.log("vm.getMNWSrch  --  " + e.message);
        }
    };

    vm.getChatSettings = function (mId, funCallBack) {
        try {
            if (vm.apiHost) {
                var url = vm.apiHost + "/api/msg/gmcs/" + mId;
                GetServiceByURL($http, url, funCallBack);
            }
        } catch (e) {
            console.log("vm.getChatSettings  --  " + e.message);
        }
    };

    vm.getmemberInfoById = function (mId, funCallBack) {
        try {
            if (vm.apiHost) {
                var url = vm.apiHost + "/api/msg/gmiById/" + mId;
                GetServiceByURL($http, url, funCallBack);
            }
        } catch (e) {
            console.log("vm.getmemberInfoById  --  " + e.message);
        }
    };

    vm.updateMemberChatSettings = function (mId, settingsType, status, funCallBack) {
        try {
            if (vm.apiHost) {
                var data = { "mId": mId, "settingsType": settingsType, "status": status };
                var url = vm.apiHost + "/api/msg/umcs";
                PostServiceByURL($http, url, data, funCallBack);
            }
        } catch (e) {
            console.log("vm.updateMemberChatSettings  --  " + e.message);
        }
    };

    vm.getMemberRecentMsgContacts = function (mId, pgNo, pgSize, funCallBack) {
        try {
            if (vm.apiHost) {
                var data = { "mId": mId, "pgNo": pgNo, "pgSize": pgSize };
                var url = vm.apiHost + "/api/msg/gmrmc";
                PostServiceByURL($http, url, data, funCallBack);
            }
        } catch (e) {
            console.log("vm.getMemberRecentMsgContacts  --  " + e.message);
        }
    };

    vm.GetMemberRecentMessageHeadsSrch = function (mId, fn, funCallBack) {
        try {
            if (vm.apiHost) {
                var data = { "mId": mId, "fn": fn };
                var url = vm.apiHost + "/api/msg/grmhs";
                PostServiceByURL($http, url, data, funCallBack);
            }
        } catch (e) {
            console.log("vm.GetMemberRecentMessageHeadsSrch  --  " + e.message);
        }
    };

    vm.getMemberMessages = function (convrnId, fmId, tmId, pgNo, pgSize, funCallBack) {
        try {
            if (vm.apiHost) {
                var data = { "convrnId": convrnId, "fmId": fmId, "tmId": tmId, "pgNo": pgNo, "pgSize": pgSize };
                var url = vm.apiHost + "/api/msg/gmm";
                PostServiceByURL($http, url, data, funCallBack);
            }
        } catch (e) {
            console.log("vm.getMemberMessages  --  " + e.message);
        }
    };

    vm.getMessagesCount = function (fmId, funCallBack) {
        try {
            if (vm.apiHost) {
                var url = vm.apiHost + "/api/msg/gmmc/" + fmId;
                GetServiceByURL($http, url, funCallBack);
            }
        } catch (e) {
            console.log("vm.getMessagesCount  --  " + e.message);
        }
    };

    vm.updateMsgConvHdBiDirectional = function (fmId, tmId, funCallBack) {
        try {
            if (vm.apiHost) {
                var data = { "fmId": fmId, "tmId": tmId };
                var url = vm.apiHost + "/api/msg/mchbd";
                PostServiceByURL($http, url, data, funCallBack);
            }
        } catch (e) {
            console.log("vm.updateMsgConvHdBiDirectional  --  " + e.message);
        }
    };

    vm.updateMsgReadStatus = function (fmId, tmId, funCallBack) {
        try {
            if (vm.apiHost) {
                var data = { "fmId": fmId, "tmId": tmId };
                var url = vm.apiHost + "/api/msg/mchureu";
                PostServiceByURL($http, url, data, funCallBack);
            }
        } catch (e) {
            console.log("vm.updateMsgReadStatus  --  " + e.message);
        }
    };

    vm.updateMsgConvHdMarkAsReadMulti = function (fmId, tmIds, unReadExist, funCallBack) {
        try {
            if (vm.apiHost) {
                var data = { "fmId": fmId, "tmIds": tmIds, "unReadExist": unReadExist };
                var url = vm.apiHost + "/api/msg/mchrs";
                PostServiceByURL($http, url, data, funCallBack);
            }
        } catch (e) {
            console.log("vm.updateMsgConvHdMarkAsReadMulti  --  " + e.message);
        }
    };

    vm.updateMsgConvHdMarkAsSeen = function (fmId, tmId, funCallBack) {
        try {
            if (vm.apiHost) {
                var data = { "fmId": fmId, "tmId": tmId };
                var url = vm.apiHost + "/api/msg/mchms";
                PostServiceByURL($http, url, data, funCallBack);
            }
        } catch (e) {
            console.log("vm.updateMsgConvHdMarkAsSeen  --  " + e.message);
        }
    };

    vm.updateMsgConvHdDMulti = function (fmId, tmIds, convrnIds, funCallBack) {
        try {
            if (vm.apiHost) {
                var data = { "fmId": fmId, "tmIds": tmIds, "convrnIds": convrnIds };
                var url = vm.apiHost + "/api/msg/mchdm";
                PostServiceByURL($http, url, data, funCallBack);
            }
        } catch (e) {
            console.log("vm.updateMsgConvHdDMulti  --  " + e.message);
        }
    };

    vm.updateMbrNtfnView = function (mId, actType, funCallBack) {
        try {
            if (vm.apiHost) {
                var url = vm.apiHost + "/api/ntfn/umnv/" + mId + "/" + actType;
                GetServiceByURL($http, url, funCallBack);
            }
        } catch (e) {
            console.log("vm.updateMbrNtfnView  --  " + e.message);
        }
    };

    /**********************************************************
                        Chat Http Services End
     **********************************************************/

    /**********************************************************
                        SignalrR client method start
    **********************************************************/
    vm.connectServer = function (mrc) {
        try {
            if (vm.mId() && !vm.conId) {
                vm.getServerURL(function (response, status) {
                    if (status == 200) {
                        vm.server = response;
                        $.connection.hub.url = response.ServerUrl;
                        vm.apiHost = vm.getAPIHost(vm.server.ServerUrl);
                        vm.connectSignalR(mrc);
                    }
                    else {
                        console.log("unable to connet server");
                    }
                });
            }
        } catch (e) {
            console.log("vm.connectServer  --  " + e.message);
        }
    };

    vm.disconnectServer = function () {
        try {
            if (vm.chatHubProxy) {
                $.connection.hub.stop();
                vm.conId = "";
            }
        } catch (e) {
            console.log("vm.disconnectServer  --  " + e.message);
        }
    };

    vm.connectSignalR = function (mrc) {
        try {
            vm.chatHubProxy = $.connection.chathub;
            if (vm.addClientMethods) {
                vm.addClientMethods = false;
                vm.registerClientMethods();
                vm.regConectionEvents();
            }
            $.connection.hub.logging = true;
            if (!vm.conId) {
                $.connection.hub.start()
                    .done(function () {
                        $timeout.cancel(vm.recTimeOut);
                        vm.conId = $.connection.hub.id;
                        $rootScope.$broadcast("msgSrvcReady");
                        vm.updateMCLD(mrc, true);
                    });
            }
        } catch (e) {
            console.log("vm.connectSignalR  --  " + e.message);
        }
    };

    vm.registerClientMethods = function () {
        try {
            vm.chatHubProxy.client.receiveMsg = function (mId, fn, msg, tmpp, convernId, datetime, sender) {
                $rootScope.$broadcast("receiveMsg", mId, fn, msg, tmpp, convernId, datetime, sender);
            };
            
            vm.chatHubProxy.client.receiveTypingRequest = function (mId) {
                $rootScope.$broadcast("recTypeReq", mId);
            };

            vm.chatHubProxy.client.recSeenStatus = function (mId, seenDT) {
                $rootScope.$broadcast("recSeenStatus", mId, seenDT);
            };

            vm.chatHubProxy.client.updateStatusText = function (mId, statusText) {
                $rootScope.$broadcast("statuTextChg", mId, statusText);
            };

            vm.chatHubProxy.client.updateOnlieStatus = function (mId, statusType, status) {
                $rootScope.$broadcast("onlineStatusChg", mId, statusType, status);
            };

            vm.chatHubProxy.client.updateSelfOnlieStatus = function (mId, statusType, status) {
                $rootScope.$broadcast("selfOnlineStatusChg", mId, statusType, status);
            };

            vm.chatHubProxy.client.receiveNotifications = function (tmId, firstname, profilepic, gender, type, dtCreated) {
                $rootScope.$broadcast("receiveNotifications", tmId, firstname, profilepic, gender, type, dtCreated);
            };

            vm.chatHubProxy.client.displayMsg = function (msg) {
                alert(msg);
            };
        } catch (e) {
            console.log("vm.registerClientMethods  --  " + e.message);
        }
    };

    vm.regConectionEvents = function () {
        try {
            $.connection.hub.reconnecting(function () {
                try {
                    vm.conId = "";
                } catch (e) {
                    console.log("$.connection.hub.reconnecting  --  " + e.message);
                }
            });

            $.connection.hub.reconnected(function () {
                try {
                    vm.conId = $.connection.hub.id;
                    $rootScope.$broadcast("msgSrvcReady");
                } catch (e) {
                    console.log("$.connection.hub.reconnected  --  " + e.message);
                }
            });

            $.connection.hub.disconnected(function () {
                try {
                    vm.conId = "";
                    if ($.connection.hub.lastError) {
                        vm.reconnectServer(vm.mrc ? false : true);
                        console.log("error disconnected : " + $.connection.hub.lastError.message);
                    }
                } catch (e) {
                    console.log("$.connection.hub.disconnected  --  " + e.message);
                }
            });
        } catch (e) {
            console.log("regConectionEvents  --  " + e.message);
        }
    };

    vm.reconnectServer = function (mrc) {
        try {
            vm.recTimeOut = $timeout(function () { vm.connectServer(mrc); }, 10000);
        } catch (e) {
            console.log("vm.reconnectServer  --  " + e.message);
        }
    };

    $rootScope.$on("online", function (e) {
        vm.reconnectServer(false);
    });
    /**********************************************************
                            SignalrR client method end
    **********************************************************/

    /**********************************************************
                        Chat Service functions
    **********************************************************/
    vm.updateMCLD = function (mrc, status) {
        try {
            vm.updateMemberChatLogintData(vm.mId(), mrc, vm.sId(), vm.server.scId, vm.conId, status, function (response, status) {
                //type - 1(online/offline),2(appear offline/appear online)
                vm.updateMemberOnlineStatus(1, true);
                if (status == 200) {
                    //member recent contacts for chat window
                    if (mrc) {
                        vm.mrc = response;
                        $rootScope.$broadcast("mrc", response, status);
                    }
                }
                else
                    console.log("unable to update member login data");
            });
        } catch (e) {
            console.log("vm.updateMCLD  --  " + e.message);
        }
    };

    vm.updateMemberOnlineStatus = function (type, status) {
        try {
            if (vm.mId() && type)
                vm.chatHubProxy.server.updateMemberOnlineStatus(vm.mId(), type, status);
        } catch (e) {
            console.log("vm.updateMemberOnlineStatus  --  " + e.message);
        }
    };

    vm.updateMST = function (mst) {
        try {
            if (mst) {
                vm.chatHubProxy.server.updateStatusText(vm.mId(), mst);
            }
        } catch (e) {
            console.log("vm.updateMST  --  " + e.message);
        }
    };

    vm.sendMsg = function (tmId, tmfn, tmpp, convrnId, msg) {
        try {
            var msm = { "fmId": vm.mId(), "tmfn": tmfn, "tmId": tmId, "tmpp": tmpp, "convrnId": convrnId, "msg": msg };
            vm.chatHubProxy.server.sendMsg(msm);
        } catch (e) {
            console.log("vm.sendMsg  --  " + e.message);
        }
    };

    vm.sendTypeRequest = function (tmId) {
        try {
            if (tmId)
                vm.chatHubProxy.server.sendTypingRequest(vm.mId(), tmId);
        } catch (e) {
            console.log("vm.sendTypeRequest  --  " + e.message);
        }
    };

    vm.sendMemberNotifications = function (tmId, fn, pp, gender, type, date) {
        try {
            var ntfcn = { "fmId": vm.mId(), "tmId": tmId, "fn": fn, "ppic": pp, "gender": gender, "type": type, "dtCreated": date };
            vm.chatHubProxy.server.sendMemberNotifications(ntfcn);
        } catch (e) {
            console.log("vm.sendNotifications  --  " + e.message);
        }
    };

    vm.sendMemberNWNotifications = function (tmId, fn, pp, gender, type, date) {
        try {
            var ntfcn = { "fmId": vm.mId(), "tmId": tmId, "fn": fn, "ppic": pp, "gender": gender, "type": type, "dtCreated": date };
            vm.chatHubProxy.server.sendMemberNWNotifications(ntfcn);
        } catch (e) {
            console.log("vm.sendNotifications  --  " + e.message);
        }
    };

    /**********************************************************
                        Chat Service functions end
    **********************************************************/

    /**********************************************************
                        Helper functions
    **********************************************************/
    //session login detials
    vm.g_ssnd = function (key) {
        try {
            var ck = $cookieStore.get("p_sfg");
            if (ck != null && ck.length != 0)
                return JSON.parse(vm.pcd((ck)))[key];
            else
                return "";
        } catch (e) {
            console.log("vm.g_ssnd  --  " + e.message);
        }
    };

    //This Service return Encrypted Text format
    vm.pce = function (et) {
        try {
            if (et != null && et != undefined && et != "" && et.length != 0) {
                var encrypted = CryptoJS.AES.encrypt(et, $rootScope.base64Key, { iv: $rootScope.iv });
                var enc = encrypted.ciphertext.toString(CryptoJS.enc.Base64);
                var val = enc.replace(/\+/g, "PPPP1").replace(/\//g, "YYYY4").replace(/\=/g, "RRRR3");
                if (val)
                    return val;
                else
                    return null;
            }
            else
                return null;
        } catch (e) {
            console.log("vm.pce  --  " + e.message);
        }
    };

    //This Service return Decrypted Text format
    vm.pcd = function (dt) {
        try {
            if (dt) {
                dt = dt.replace(/PPPP1/g, "+").replace(/YYYY4/g, "/").replace(/RRRR3/g, "=");
                var decrypted = CryptoJS.AES.decrypt(CryptoJS.lib.CipherParams.create({ ciphertext: CryptoJS.enc.Base64.parse(dt) }), $rootScope.base64Key, { iv: $rootScope.iv });
                var val = decrypted.toString(CryptoJS.enc.Utf8);
                if (val)
                    return val;
                else
                    return null;
            }
            else
                return null;
        } catch (e) {
            console.log("vm.pcd  --  " + e.message);
        }
    };

    //get api host
    vm.getAPIHost = function (url) {
        try {
            var link = document.createElement("a");
            link.setAttribute("href", url);
            return link.protocol + "//" + link.host;
        } catch (e) {
            console.log("vm.getAPIHost  --  " + e.message);
        }
    };

    //return date difference between photo created and now in minutes
    vm.getDateDiffByMins = function (date) {
        try {
            var today = new Date();
            var imgAddedDay = new Date(date);
            var diffMs = (today - imgAddedDay); // milliseconds between now & Christmas
            var diffDays = Math.floor(diffMs / 86400000); // days
            return diffDays;
        } catch (e) {
            console.log("vm.getDateDiffByMins  --  " + e.message);
        }
    };

    // return object of date and time 
    //if given date is same date return only time other wise return date and time
    vm.getDateTimeBasedOnZone = function (zone, utcDT) {
        try {
            var dtObj = { date: "", time: "" };
            if (zone && utcDT) {
                var today = moment.utc(new Date()).format("YYYY-MM-DD");
                var dt = moment.utc(utcDT).format("YYYY-MM-DD");
                if (zone.length > 0) {
                    //if zone not null, change dates to particular time zones.
                    vm.toDay = moment.tz(today, zone).format("YYYY-MM-DD");
                    vm.givenDay = moment.tz(moment.utc(utcDT), zone).format('YYYY-MM-DD');
                    if (moment(vm.toDay).isSame(vm.givenDay)) {  //Check date is same as today date if yes, display TIME || Else - Month day,Year
                        dtObj.time = moment.tz(moment.utc(utcDT), zone).format('LT');
                    }
                    else {
                        dtObj.date = moment.tz(moment.utc(utcDT), zone).format('MMMM D, YYYY');
                        dtObj.time = moment.tz(moment.utc(utcDT), zone).format('LT');
                    }
                }
                else {
                    if (moment(today).isSame(dt))
                        dtObj.time = dt.format('LT');
                    else {
                        dtObj.date = dt.format('MMMM D, YYYY');
                        dtObj.time = dt.format('LT');
                    }
                }
            }
            return dtObj;
        } catch (e) {
            console.log("getDateTimeBasedOnZone  --  " + e.message);
        }
    };

    vm.getDate = function (zone, utcDT) {
        try {
            if (zone && utcDT) {
                if (zone.length > 0)
                    return moment.tz(moment.utc(utcDT), zone).format('MMMM D, YYYY');
                else
                    return moment.utc(utcDT).format("MMMM D, YYYY");
            }
            else
                return moment.tz(moment.utc(new Date()), zone).format('MMMM D, YYYY');
        } catch (e) {
            console.log("vm.getDate  --  " + e.message);
        }
    };

    vm.getTime = function (zone, utcDT) {
        try {
            if (zone && utcDT) {
                if (zone.length > 0)
                    return moment.tz(moment.utc(utcDT), zone).format('LT');
                else
                    return moment.utc(utcDT).format("LT");
            }
            else
                return moment.tz(moment.utc(new Date()), zone).format('LT');

        } catch (e) {
            console.log("vm.getTime  --  " + e.message);
        }
    };
    /**********************************************************
                       Helper functions end
   **********************************************************/
}]);

angular.module("app").service('notificationSrvc', ['$http', function ($http) {
    this.getNotifications = function (mId, sId, pgNo, pgSize, fromDt, toDt, funCallBack) {
        var data = { "mId": mId, "sId": sId, "pgNo": pgNo, "pgSize": pgSize, "fromDt": fromDt, "toDt": toDt };
        var url = "https://pcapi.pyar.com/api/notification/ntfction";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //Service for Add Hide
    this.addHide = function (memberId, memHideId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/adhd/" + memberId + "/" + memHideId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Service for Remove Hide
    this.removeHide = function (memberId, mHdId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/rmhd/" + memberId + "/" + mHdId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Service for Member Hide check
    this.memberHideCheck = function (memberId, memHideId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/hdchk/" + memberId + "/" + memHideId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.getNMTypes = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/notification/nmTypes";
        GetServiceByURL($http, url, funCallBack);
    };
}]);
/**********************************************************
                    services end
**********************************************************/

/**********************************************************
                    Filters start
**********************************************************/
// returns data which has notify Type 51/52/53/54 
app.filter('nonSysNotify', function ($filter) {
    return function (items, option) {
        if (option) {
            var filtered = [];
            var nSysAlrtTyp = [51, 52, 53, 54, 61, 62, 63];
            angular.forEach(items, function (item) {
                if (nSysAlrtTyp.indexOf(item.notifyType) != -1)
                    filtered.push(item);
            });
            return filtered;
        }
        else
            return items;
    };
});

app.filter('notifyMsg', function ($sce) {
    return function (msg, fname, gender, Lgn, pvCnt) {
        if (msg) {
            if (fname)
                msg = msg.replace("##FNAME##", fname);
            else
                msg = msg.replace("##FNAME##", "");
            if (gender == true)
                msg = msg.replace("##GENSERSALTN##", "his");
            else if (gender == false)
                msg = msg.replace("##GENSERSALTN##", "her");
            if (Lgn)
                msg = msg.replace("##LGNNAME##", Lgn);
            else
                msg = msg.replace("##LGNNAME##", "");
            if (pvCnt && pvCnt > 0)
                msg = msg.replace("##PVCNT##", pvCnt)
            else
                msg = msg.replace("##PVCNT##", "");
        }
        return $sce.trustAsHtml(msg);
    };
});
/**********************************************************
                    Filters end
**********************************************************/

/**********************************************************
        SignalR server side script functions start
**********************************************************/
//<script src="/scripts/signalr.js"></script>
/*!
 * ASP.NET SignalR JavaScript Library v2.2.2
 * http://signalr.net/
 *
 * Copyright (c) .NET Foundation. All rights reserved.
 * Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.
 *
 */

/// <reference path="..\..\SignalR.Client.JS\Scripts\jquery-1.6.4.js" />
/// <reference path="jquery.signalR.js" />
(function ($, window, undefined) {
    /// <param name="$" type="jQuery" />
    "use strict";

    if (typeof ($.signalR) !== "function") {
        throw new Error("SignalR: SignalR is not loaded. Please ensure jquery.signalR-x.js is referenced before ~/signalr/js.");
    }

    var signalR = $.signalR;

    function makeProxyCallback(hub, callback) {
        return function () {
            // Call the client hub method
            callback.apply(hub, $.makeArray(arguments));
        };
    }

    function registerHubProxies(instance, shouldSubscribe) {
        var key, hub, memberKey, memberValue, subscriptionMethod;

        for (key in instance) {
            if (instance.hasOwnProperty(key)) {
                hub = instance[key];

                if (!(hub.hubName)) {
                    // Not a client hub
                    continue;
                }

                if (shouldSubscribe) {
                    // We want to subscribe to the hub events
                    subscriptionMethod = hub.on;
                } else {
                    // We want to unsubscribe from the hub events
                    subscriptionMethod = hub.off;
                }

                // Loop through all members on the hub and find client hub functions to subscribe/unsubscribe
                for (memberKey in hub.client) {
                    if (hub.client.hasOwnProperty(memberKey)) {
                        memberValue = hub.client[memberKey];

                        if (!$.isFunction(memberValue)) {
                            // Not a client hub function
                            continue;
                        }

                        subscriptionMethod.call(hub, memberKey, makeProxyCallback(hub, memberValue));
                    }
                }
            }
        }
    }

    $.hubConnection.prototype.createHubProxies = function () {
        var proxies = {};
        this.starting(function () {
            // Register the hub proxies as subscribed
            // (instance, shouldSubscribe)
            registerHubProxies(proxies, true);

            this._registerSubscribedHubs();
        }).disconnected(function () {
            // Unsubscribe all hub proxies when we "disconnect".  This is to ensure that we do not re-add functional call backs.
            // (instance, shouldSubscribe)
            registerHubProxies(proxies, false);
        });

        proxies['chathub'] = this.createHubProxy('chathub');
        proxies['chathub'].client = {};
        proxies['chathub'].server = {
            sendMemberNotifications: function (ntfcn) {
                return proxies['chathub'].invoke.apply(proxies['chathub'], $.merge(["sendMemberNotifications"], $.makeArray(arguments)));
            },

            sendMemberNWNotifications: function (ntfcn) {
                return proxies['chathub'].invoke.apply(proxies['chathub'], $.merge(["sendMemberNWNotifications"], $.makeArray(arguments)));
            },

            sendMsg: function (msm) {
                return proxies['chathub'].invoke.apply(proxies['chathub'], $.merge(["sendMsg"], $.makeArray(arguments)));
            },

            sendSeenStatus: function (fmId, tmId, seenDT) {
                return proxies['chathub'].invoke.apply(proxies['chathub'], $.merge(["sendSeenStatus"], $.makeArray(arguments)));
            },

            sendTypingRequest: function (fmId, tmId) {
                return proxies['chathub'].invoke.apply(proxies['chathub'], $.merge(["sendTypingRequest"], $.makeArray(arguments)));
            },

            updateMemberOnlineStatus: function (mId, statusType, status) {
                return proxies['chathub'].invoke.apply(proxies['chathub'], $.merge(["updateMemberOnlineStatus"], $.makeArray(arguments)));
            },

            updateStatusText: function (mId, statusText) {
                return proxies['chathub'].invoke.apply(proxies['chathub'], $.merge(["updateStatusText"], $.makeArray(arguments)));
            }
        };

        return proxies;
    };

    signalR.hub = $.hubConnection("/signalr", { useDefaultPath: false });
    $.extend(signalR, signalR.hub.createHubProxies());

}(window.jQuery, window));
/**********************************************************
        SignalR server side script functions end
**********************************************************/

/**********************************************************
            moment js start
            referece file ==> moment.min.js
**********************************************************/
//<script src="/scripts/moment.min.js"></script>
//! moment.js
//! version : 2.18.2
//! authors : Tim Wood, Iskren Chernev, Moment.js contributors
//! license : MIT
//! momentjs.com
!function(a,b){"object"==typeof exports&&"undefined"!=typeof module?module.exports=b():"function"==typeof define&&define.amd?define(b):a.moment=b()}(this,function(){"use strict";function a(){return rd.apply(null,arguments)}function b(a){return a instanceof Array||"[object Array]"===Object.prototype.toString.call(a)}function c(a){return null!=a&&"[object Object]"===Object.prototype.toString.call(a)}function d(a){var b;for(b in a)return!1;return!0}function e(a){return void 0===a}function f(a){return"number"==typeof a||"[object Number]"===Object.prototype.toString.call(a)}function g(a){return a instanceof Date||"[object Date]"===Object.prototype.toString.call(a)}function h(a,b){var c,d=[];for(c=0;c<a.length;++c)d.push(b(a[c],c));return d}function i(a,b){return Object.prototype.hasOwnProperty.call(a,b)}function j(a,b){for(var c in b)i(b,c)&&(a[c]=b[c]);return i(b,"toString")&&(a.toString=b.toString),i(b,"valueOf")&&(a.valueOf=b.valueOf),a}function k(a,b,c,d){return rb(a,b,c,d,!0).utc()}function l(){return{empty:!1,unusedTokens:[],unusedInput:[],overflow:-2,charsLeftOver:0,nullInput:!1,invalidMonth:null,invalidFormat:!1,userInvalidated:!1,iso:!1,parsedDateParts:[],meridiem:null,rfc2822:!1,weekdayMismatch:!1}}function m(a){return null==a._pf&&(a._pf=l()),a._pf}function n(a){if(null==a._isValid){var b=m(a),c=sd.call(b.parsedDateParts,function(a){return null!=a}),d=!isNaN(a._d.getTime())&&b.overflow<0&&!b.empty&&!b.invalidMonth&&!b.invalidWeekday&&!b.nullInput&&!b.invalidFormat&&!b.userInvalidated&&(!b.meridiem||b.meridiem&&c);if(a._strict&&(d=d&&0===b.charsLeftOver&&0===b.unusedTokens.length&&void 0===b.bigHour),null!=Object.isFrozen&&Object.isFrozen(a))return d;a._isValid=d}return a._isValid}function o(a){var b=k(NaN);return null!=a?j(m(b),a):m(b).userInvalidated=!0,b}function p(a,b){var c,d,f;if(e(b._isAMomentObject)||(a._isAMomentObject=b._isAMomentObject),e(b._i)||(a._i=b._i),e(b._f)||(a._f=b._f),e(b._l)||(a._l=b._l),e(b._strict)||(a._strict=b._strict),e(b._tzm)||(a._tzm=b._tzm),e(b._isUTC)||(a._isUTC=b._isUTC),e(b._offset)||(a._offset=b._offset),e(b._pf)||(a._pf=m(b)),e(b._locale)||(a._locale=b._locale),td.length>0)for(c=0;c<td.length;c++)d=td[c],f=b[d],e(f)||(a[d]=f);return a}function q(b){p(this,b),this._d=new Date(null!=b._d?b._d.getTime():NaN),this.isValid()||(this._d=new Date(NaN)),!1===ud&&(ud=!0,a.updateOffset(this),ud=!1)}function r(a){return a instanceof q||null!=a&&null!=a._isAMomentObject}function s(a){return a<0?Math.ceil(a)||0:Math.floor(a)}function t(a){var b=+a,c=0;return 0!==b&&isFinite(b)&&(c=s(b)),c}function u(a,b,c){var d,e=Math.min(a.length,b.length),f=Math.abs(a.length-b.length),g=0;for(d=0;d<e;d++)(c&&a[d]!==b[d]||!c&&t(a[d])!==t(b[d]))&&g++;return g+f}function v(b){!1===a.suppressDeprecationWarnings&&"undefined"!=typeof console&&console.warn&&console.warn("Deprecation warning: "+b)}function w(b,c){var d=!0;return j(function(){if(null!=a.deprecationHandler&&a.deprecationHandler(null,b),d){for(var e,f=[],g=0;g<arguments.length;g++){if(e="","object"==typeof arguments[g]){e+="\n["+g+"] ";for(var h in arguments[0])e+=h+": "+arguments[0][h]+", ";e=e.slice(0,-2)}else e=arguments[g];f.push(e)}v(b+"\nArguments: "+Array.prototype.slice.call(f).join("")+"\n"+(new Error).stack),d=!1}return c.apply(this,arguments)},c)}function x(b,c){null!=a.deprecationHandler&&a.deprecationHandler(b,c),vd[b]||(v(c),vd[b]=!0)}function y(a){return a instanceof Function||"[object Function]"===Object.prototype.toString.call(a)}function z(a){var b,c;for(c in a)b=a[c],y(b)?this[c]=b:this["_"+c]=b;this._config=a,this._dayOfMonthOrdinalParseLenient=new RegExp((this._dayOfMonthOrdinalParse.source||this._ordinalParse.source)+"|"+/\d{1,2}/.source)}function A(a,b){var d,e=j({},a);for(d in b)i(b,d)&&(c(a[d])&&c(b[d])?(e[d]={},j(e[d],a[d]),j(e[d],b[d])):null!=b[d]?e[d]=b[d]:delete e[d]);for(d in a)i(a,d)&&!i(b,d)&&c(a[d])&&(e[d]=j({},e[d]));return e}function B(a){null!=a&&this.set(a)}function C(a,b,c){var d=this._calendar[a]||this._calendar.sameElse;return y(d)?d.call(b,c):d}function D(a){var b=this._longDateFormat[a],c=this._longDateFormat[a.toUpperCase()];return b||!c?b:(this._longDateFormat[a]=c.replace(/MMMM|MM|DD|dddd/g,function(a){return a.slice(1)}),this._longDateFormat[a])}function E(){return this._invalidDate}function F(a){return this._ordinal.replace("%d",a)}function G(a,b,c,d){var e=this._relativeTime[c];return y(e)?e(a,b,c,d):e.replace(/%d/i,a)}function H(a,b){var c=this._relativeTime[a>0?"future":"past"];return y(c)?c(b):c.replace(/%s/i,b)}function I(a,b){var c=a.toLowerCase();Bd[c]=Bd[c+"s"]=Bd[b]=a}function J(a){return"string"==typeof a?Bd[a]||Bd[a.toLowerCase()]:void 0}function K(a){var b,c,d={};for(c in a)i(a,c)&&(b=J(c))&&(d[b]=a[c]);return d}function L(a,b){Cd[a]=b}function M(a){var b=[];for(var c in a)b.push({unit:c,priority:Cd[c]});return b.sort(function(a,b){return a.priority-b.priority}),b}function N(b,c){return function(d){return null!=d?(P(this,b,d),a.updateOffset(this,c),this):O(this,b)}}function O(a,b){return a.isValid()?a._d["get"+(a._isUTC?"UTC":"")+b]():NaN}function P(a,b,c){a.isValid()&&a._d["set"+(a._isUTC?"UTC":"")+b](c)}function Q(a){return a=J(a),y(this[a])?this[a]():this}function R(a,b){if("object"==typeof a){a=K(a);for(var c=M(a),d=0;d<c.length;d++)this[c[d].unit](a[c[d].unit])}else if(a=J(a),y(this[a]))return this[a](b);return this}function S(a,b,c){var d=""+Math.abs(a),e=b-d.length;return(a>=0?c?"+":"":"-")+Math.pow(10,Math.max(0,e)).toString().substr(1)+d}function T(a,b,c,d){var e=d;"string"==typeof d&&(e=function(){return this[d]()}),a&&(Gd[a]=e),b&&(Gd[b[0]]=function(){return S(e.apply(this,arguments),b[1],b[2])}),c&&(Gd[c]=function(){return this.localeData().ordinal(e.apply(this,arguments),a)})}function U(a){return a.match(/\[[\s\S]/)?a.replace(/^\[|\]$/g,""):a.replace(/\\/g,"")}function V(a){var b,c,d=a.match(Dd);for(b=0,c=d.length;b<c;b++)Gd[d[b]]?d[b]=Gd[d[b]]:d[b]=U(d[b]);return function(b){var e,f="";for(e=0;e<c;e++)f+=y(d[e])?d[e].call(b,a):d[e];return f}}function W(a,b){return a.isValid()?(b=X(b,a.localeData()),Fd[b]=Fd[b]||V(b),Fd[b](a)):a.localeData().invalidDate()}function X(a,b){function c(a){return b.longDateFormat(a)||a}var d=5;for(Ed.lastIndex=0;d>=0&&Ed.test(a);)a=a.replace(Ed,c),Ed.lastIndex=0,d-=1;return a}function Y(a,b,c){Ld[a]=y(b)?b:function(a,d){return a&&c?c:b}}function Z(a,b){return i(Ld,a)?Ld[a](b._strict,b._locale):new RegExp($(a))}function $(a){return _(a.replace("\\","").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g,function(a,b,c,d,e){return b||c||d||e}))}function _(a){return a.replace(/[-\/\\^$*+?.()|[\]{}]/g,"\\$&")}function aa(a,b){var c,d=b;for("string"==typeof a&&(a=[a]),f(b)&&(d=function(a,c){c[b]=t(a)}),c=0;c<a.length;c++)Md[a[c]]=d}function ba(a,b){aa(a,function(a,c,d,e){d._w=d._w||{},b(a,d._w,d,e)})}function ca(a,b,c){null!=b&&i(Md,a)&&Md[a](b,c._a,c,a)}function da(a,b){return new Date(Date.UTC(a,b+1,0)).getUTCDate()}function ea(a,c){return a?b(this._months)?this._months[a.month()]:this._months[(this._months.isFormat||Wd).test(c)?"format":"standalone"][a.month()]:b(this._months)?this._months:this._months.standalone}function fa(a,c){return a?b(this._monthsShort)?this._monthsShort[a.month()]:this._monthsShort[Wd.test(c)?"format":"standalone"][a.month()]:b(this._monthsShort)?this._monthsShort:this._monthsShort.standalone}function ga(a,b,c){var d,e,f,g=a.toLocaleLowerCase();if(!this._monthsParse)for(this._monthsParse=[],this._longMonthsParse=[],this._shortMonthsParse=[],d=0;d<12;++d)f=k([2e3,d]),this._shortMonthsParse[d]=this.monthsShort(f,"").toLocaleLowerCase(),this._longMonthsParse[d]=this.months(f,"").toLocaleLowerCase();return c?"MMM"===b?(e=xd.call(this._shortMonthsParse,g),-1!==e?e:null):(e=xd.call(this._longMonthsParse,g),-1!==e?e:null):"MMM"===b?-1!==(e=xd.call(this._shortMonthsParse,g))?e:(e=xd.call(this._longMonthsParse,g),-1!==e?e:null):-1!==(e=xd.call(this._longMonthsParse,g))?e:(e=xd.call(this._shortMonthsParse,g),-1!==e?e:null)}function ha(a,b,c){var d,e,f;if(this._monthsParseExact)return ga.call(this,a,b,c);for(this._monthsParse||(this._monthsParse=[],this._longMonthsParse=[],this._shortMonthsParse=[]),d=0;d<12;d++){if(e=k([2e3,d]),c&&!this._longMonthsParse[d]&&(this._longMonthsParse[d]=new RegExp("^"+this.months(e,"").replace(".","")+"$","i"),this._shortMonthsParse[d]=new RegExp("^"+this.monthsShort(e,"").replace(".","")+"$","i")),c||this._monthsParse[d]||(f="^"+this.months(e,"")+"|^"+this.monthsShort(e,""),this._monthsParse[d]=new RegExp(f.replace(".",""),"i")),c&&"MMMM"===b&&this._longMonthsParse[d].test(a))return d;if(c&&"MMM"===b&&this._shortMonthsParse[d].test(a))return d;if(!c&&this._monthsParse[d].test(a))return d}}function ia(a,b){var c;if(!a.isValid())return a;if("string"==typeof b)if(/^\d+$/.test(b))b=t(b);else if(b=a.localeData().monthsParse(b),!f(b))return a;return c=Math.min(a.date(),da(a.year(),b)),a._d["set"+(a._isUTC?"UTC":"")+"Month"](b,c),a}function ja(b){return null!=b?(ia(this,b),a.updateOffset(this,!0),this):O(this,"Month")}function ka(){return da(this.year(),this.month())}function la(a){return this._monthsParseExact?(i(this,"_monthsRegex")||na.call(this),a?this._monthsShortStrictRegex:this._monthsShortRegex):(i(this,"_monthsShortRegex")||(this._monthsShortRegex=Zd),this._monthsShortStrictRegex&&a?this._monthsShortStrictRegex:this._monthsShortRegex)}function ma(a){return this._monthsParseExact?(i(this,"_monthsRegex")||na.call(this),a?this._monthsStrictRegex:this._monthsRegex):(i(this,"_monthsRegex")||(this._monthsRegex=$d),this._monthsStrictRegex&&a?this._monthsStrictRegex:this._monthsRegex)}function na(){function a(a,b){return b.length-a.length}var b,c,d=[],e=[],f=[];for(b=0;b<12;b++)c=k([2e3,b]),d.push(this.monthsShort(c,"")),e.push(this.months(c,"")),f.push(this.months(c,"")),f.push(this.monthsShort(c,""));for(d.sort(a),e.sort(a),f.sort(a),b=0;b<12;b++)d[b]=_(d[b]),e[b]=_(e[b]);for(b=0;b<24;b++)f[b]=_(f[b]);this._monthsRegex=new RegExp("^("+f.join("|")+")","i"),this._monthsShortRegex=this._monthsRegex,this._monthsStrictRegex=new RegExp("^("+e.join("|")+")","i"),this._monthsShortStrictRegex=new RegExp("^("+d.join("|")+")","i")}function oa(a){return pa(a)?366:365}function pa(a){return a%4==0&&a%100!=0||a%400==0}function qa(){return pa(this.year())}function ra(a,b,c,d,e,f,g){var h=new Date(a,b,c,d,e,f,g);return a<100&&a>=0&&isFinite(h.getFullYear())&&h.setFullYear(a),h}function sa(a){var b=new Date(Date.UTC.apply(null,arguments));return a<100&&a>=0&&isFinite(b.getUTCFullYear())&&b.setUTCFullYear(a),b}function ta(a,b,c){var d=7+b-c;return-(7+sa(a,0,d).getUTCDay()-b)%7+d-1}function ua(a,b,c,d,e){var f,g,h=(7+c-d)%7,i=ta(a,d,e),j=1+7*(b-1)+h+i;return j<=0?(f=a-1,g=oa(f)+j):j>oa(a)?(f=a+1,g=j-oa(a)):(f=a,g=j),{year:f,dayOfYear:g}}function va(a,b,c){var d,e,f=ta(a.year(),b,c),g=Math.floor((a.dayOfYear()-f-1)/7)+1;return g<1?(e=a.year()-1,d=g+wa(e,b,c)):g>wa(a.year(),b,c)?(d=g-wa(a.year(),b,c),e=a.year()+1):(e=a.year(),d=g),{week:d,year:e}}function wa(a,b,c){var d=ta(a,b,c),e=ta(a+1,b,c);return(oa(a)-d+e)/7}function xa(a){return va(a,this._week.dow,this._week.doy).week}function ya(){return this._week.dow}function za(){return this._week.doy}function Aa(a){var b=this.localeData().week(this);return null==a?b:this.add(7*(a-b),"d")}function Ba(a){var b=va(this,1,4).week;return null==a?b:this.add(7*(a-b),"d")}function Ca(a,b){return"string"!=typeof a?a:isNaN(a)?(a=b.weekdaysParse(a),"number"==typeof a?a:null):parseInt(a,10)}function Da(a,b){return"string"==typeof a?b.weekdaysParse(a)%7||7:isNaN(a)?null:a}function Ea(a,c){return a?b(this._weekdays)?this._weekdays[a.day()]:this._weekdays[this._weekdays.isFormat.test(c)?"format":"standalone"][a.day()]:b(this._weekdays)?this._weekdays:this._weekdays.standalone}function Fa(a){return a?this._weekdaysShort[a.day()]:this._weekdaysShort}function Ga(a){return a?this._weekdaysMin[a.day()]:this._weekdaysMin}function Ha(a,b,c){var d,e,f,g=a.toLocaleLowerCase();if(!this._weekdaysParse)for(this._weekdaysParse=[],this._shortWeekdaysParse=[],this._minWeekdaysParse=[],d=0;d<7;++d)f=k([2e3,1]).day(d),this._minWeekdaysParse[d]=this.weekdaysMin(f,"").toLocaleLowerCase(),this._shortWeekdaysParse[d]=this.weekdaysShort(f,"").toLocaleLowerCase(),this._weekdaysParse[d]=this.weekdays(f,"").toLocaleLowerCase();return c?"dddd"===b?(e=xd.call(this._weekdaysParse,g),-1!==e?e:null):"ddd"===b?(e=xd.call(this._shortWeekdaysParse,g),-1!==e?e:null):(e=xd.call(this._minWeekdaysParse,g),-1!==e?e:null):"dddd"===b?-1!==(e=xd.call(this._weekdaysParse,g))?e:-1!==(e=xd.call(this._shortWeekdaysParse,g))?e:(e=xd.call(this._minWeekdaysParse,g),-1!==e?e:null):"ddd"===b?-1!==(e=xd.call(this._shortWeekdaysParse,g))?e:-1!==(e=xd.call(this._weekdaysParse,g))?e:(e=xd.call(this._minWeekdaysParse,g),-1!==e?e:null):-1!==(e=xd.call(this._minWeekdaysParse,g))?e:-1!==(e=xd.call(this._weekdaysParse,g))?e:(e=xd.call(this._shortWeekdaysParse,g),-1!==e?e:null)}function Ia(a,b,c){var d,e,f;if(this._weekdaysParseExact)return Ha.call(this,a,b,c);for(this._weekdaysParse||(this._weekdaysParse=[],this._minWeekdaysParse=[],this._shortWeekdaysParse=[],this._fullWeekdaysParse=[]),d=0;d<7;d++){if(e=k([2e3,1]).day(d),c&&!this._fullWeekdaysParse[d]&&(this._fullWeekdaysParse[d]=new RegExp("^"+this.weekdays(e,"").replace(".",".?")+"$","i"),this._shortWeekdaysParse[d]=new RegExp("^"+this.weekdaysShort(e,"").replace(".",".?")+"$","i"),this._minWeekdaysParse[d]=new RegExp("^"+this.weekdaysMin(e,"").replace(".",".?")+"$","i")),this._weekdaysParse[d]||(f="^"+this.weekdays(e,"")+"|^"+this.weekdaysShort(e,"")+"|^"+this.weekdaysMin(e,""),this._weekdaysParse[d]=new RegExp(f.replace(".",""),"i")),c&&"dddd"===b&&this._fullWeekdaysParse[d].test(a))return d;if(c&&"ddd"===b&&this._shortWeekdaysParse[d].test(a))return d;if(c&&"dd"===b&&this._minWeekdaysParse[d].test(a))return d;if(!c&&this._weekdaysParse[d].test(a))return d}}function Ja(a){if(!this.isValid())return null!=a?this:NaN;var b=this._isUTC?this._d.getUTCDay():this._d.getDay();return null!=a?(a=Ca(a,this.localeData()),this.add(a-b,"d")):b}function Ka(a){if(!this.isValid())return null!=a?this:NaN;var b=(this.day()+7-this.localeData()._week.dow)%7;return null==a?b:this.add(a-b,"d")}function La(a){if(!this.isValid())return null!=a?this:NaN;if(null!=a){var b=Da(a,this.localeData());return this.day(this.day()%7?b:b-7)}return this.day()||7}function Ma(a){return this._weekdaysParseExact?(i(this,"_weekdaysRegex")||Pa.call(this),a?this._weekdaysStrictRegex:this._weekdaysRegex):(i(this,"_weekdaysRegex")||(this._weekdaysRegex=ee),this._weekdaysStrictRegex&&a?this._weekdaysStrictRegex:this._weekdaysRegex)}function Na(a){return this._weekdaysParseExact?(i(this,"_weekdaysRegex")||Pa.call(this),a?this._weekdaysShortStrictRegex:this._weekdaysShortRegex):(i(this,"_weekdaysShortRegex")||(this._weekdaysShortRegex=fe),this._weekdaysShortStrictRegex&&a?this._weekdaysShortStrictRegex:this._weekdaysShortRegex)}function Oa(a){return this._weekdaysParseExact?(i(this,"_weekdaysRegex")||Pa.call(this),a?this._weekdaysMinStrictRegex:this._weekdaysMinRegex):(i(this,"_weekdaysMinRegex")||(this._weekdaysMinRegex=ge),this._weekdaysMinStrictRegex&&a?this._weekdaysMinStrictRegex:this._weekdaysMinRegex)}function Pa(){function a(a,b){return b.length-a.length}var b,c,d,e,f,g=[],h=[],i=[],j=[];for(b=0;b<7;b++)c=k([2e3,1]).day(b),d=this.weekdaysMin(c,""),e=this.weekdaysShort(c,""),f=this.weekdays(c,""),g.push(d),h.push(e),i.push(f),j.push(d),j.push(e),j.push(f);for(g.sort(a),h.sort(a),i.sort(a),j.sort(a),b=0;b<7;b++)h[b]=_(h[b]),i[b]=_(i[b]),j[b]=_(j[b]);this._weekdaysRegex=new RegExp("^("+j.join("|")+")","i"),this._weekdaysShortRegex=this._weekdaysRegex,this._weekdaysMinRegex=this._weekdaysRegex,this._weekdaysStrictRegex=new RegExp("^("+i.join("|")+")","i"),this._weekdaysShortStrictRegex=new RegExp("^("+h.join("|")+")","i"),this._weekdaysMinStrictRegex=new RegExp("^("+g.join("|")+")","i")}function Qa(){return this.hours()%12||12}function Ra(){return this.hours()||24}function Sa(a,b){T(a,0,0,function(){return this.localeData().meridiem(this.hours(),this.minutes(),b)})}function Ta(a,b){return b._meridiemParse}function Ua(a){return"p"===(a+"").toLowerCase().charAt(0)}function Va(a,b,c){return a>11?c?"pm":"PM":c?"am":"AM"}function Wa(a){return a?a.toLowerCase().replace("_","-"):a}function Xa(a){for(var b,c,d,e,f=0;f<a.length;){for(e=Wa(a[f]).split("-"),b=e.length,c=Wa(a[f+1]),c=c?c.split("-"):null;b>0;){if(d=Ya(e.slice(0,b).join("-")))return d;if(c&&c.length>=b&&u(e,c,!0)>=b-1)break;b--}f++}return null}function Ya(a){var b=null;if(!ke[a]&&"undefined"!=typeof module&&module&&module.exports)try{b=he._abbr,require("./locale/"+a),Za(b)}catch(a){}return ke[a]}function Za(a,b){var c;return a&&(c=e(b)?ab(a):$a(a,b))&&(he=c),he._abbr}function $a(a,b){if(null!==b){var c=je;if(b.abbr=a,null!=ke[a])x("defineLocaleOverride","use moment.updateLocale(localeName, config) to change an existing locale. moment.defineLocale(localeName, config) should only be used for creating a new locale See http://momentjs.com/guides/#/warnings/define-locale/ for more info."),c=ke[a]._config;else if(null!=b.parentLocale){if(null==ke[b.parentLocale])return le[b.parentLocale]||(le[b.parentLocale]=[]),le[b.parentLocale].push({name:a,config:b}),null;c=ke[b.parentLocale]._config}return ke[a]=new B(A(c,b)),le[a]&&le[a].forEach(function(a){$a(a.name,a.config)}),Za(a),ke[a]}return delete ke[a],null}function _a(a,b){if(null!=b){var c,d=je;null!=ke[a]&&(d=ke[a]._config),b=A(d,b),c=new B(b),c.parentLocale=ke[a],ke[a]=c,Za(a)}else null!=ke[a]&&(null!=ke[a].parentLocale?ke[a]=ke[a].parentLocale:null!=ke[a]&&delete ke[a]);return ke[a]}function ab(a){var c;if(a&&a._locale&&a._locale._abbr&&(a=a._locale._abbr),!a)return he;if(!b(a)){if(c=Ya(a))return c;a=[a]}return Xa(a)}function bb(){return wd(ke)}function cb(a){var b,c=a._a;return c&&-2===m(a).overflow&&(b=c[Od]<0||c[Od]>11?Od:c[Pd]<1||c[Pd]>da(c[Nd],c[Od])?Pd:c[Qd]<0||c[Qd]>24||24===c[Qd]&&(0!==c[Rd]||0!==c[Sd]||0!==c[Td])?Qd:c[Rd]<0||c[Rd]>59?Rd:c[Sd]<0||c[Sd]>59?Sd:c[Td]<0||c[Td]>999?Td:-1,m(a)._overflowDayOfYear&&(b<Nd||b>Pd)&&(b=Pd),m(a)._overflowWeeks&&-1===b&&(b=Ud),m(a)._overflowWeekday&&-1===b&&(b=Vd),m(a).overflow=b),a}function db(a){var b,c,d,e,f,g,h=a._i,i=me.exec(h)||ne.exec(h);if(i){for(m(a).iso=!0,b=0,c=pe.length;b<c;b++)if(pe[b][1].exec(i[1])){e=pe[b][0],d=!1!==pe[b][2];break}if(null==e)return void(a._isValid=!1);if(i[3]){for(b=0,c=qe.length;b<c;b++)if(qe[b][1].exec(i[3])){f=(i[2]||" ")+qe[b][0];break}if(null==f)return void(a._isValid=!1)}if(!d&&null!=f)return void(a._isValid=!1);if(i[4]){if(!oe.exec(i[4]))return void(a._isValid=!1);g="Z"}a._f=e+(f||"")+(g||""),kb(a)}else a._isValid=!1}function eb(a){var b,c,d,e,f,g,h,i,j={" GMT":" +0000"," EDT":" -0400"," EST":" -0500"," CDT":" -0500"," CST":" -0600"," MDT":" -0600"," MST":" -0700"," PDT":" -0700"," PST":" -0800"},k="YXWVUTSRQPONZABCDEFGHIKLM";if(b=a._i.replace(/\([^\)]*\)|[\n\t]/g," ").replace(/(\s\s+)/g," ").replace(/^\s|\s$/g,""),c=se.exec(b)){if(d=c[1]?"ddd"+(5===c[1].length?", ":" "):"",e="D MMM "+(c[2].length>10?"YYYY ":"YY "),f="HH:mm"+(c[4]?":ss":""),c[1]){var l=new Date(c[2]),n=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][l.getDay()];if(c[1].substr(0,3)!==n)return m(a).weekdayMismatch=!0,void(a._isValid=!1)}switch(c[5].length){case 2:0===i?h=" +0000":(i=k.indexOf(c[5][1].toUpperCase())-12,h=(i<0?" -":" +")+(""+i).replace(/^-?/,"0").match(/..$/)[0]+"00");break;case 4:h=j[c[5]];break;default:h=j[" GMT"]}c[5]=h,a._i=c.splice(1).join(""),g=" ZZ",a._f=d+e+f+g,kb(a),m(a).rfc2822=!0}else a._isValid=!1}function fb(b){var c=re.exec(b._i);if(null!==c)return void(b._d=new Date(+c[1]));db(b),!1===b._isValid&&(delete b._isValid,eb(b),!1===b._isValid&&(delete b._isValid,a.createFromInputFallback(b)))}function gb(a,b,c){return null!=a?a:null!=b?b:c}function hb(b){var c=new Date(a.now());return b._useUTC?[c.getUTCFullYear(),c.getUTCMonth(),c.getUTCDate()]:[c.getFullYear(),c.getMonth(),c.getDate()]}function ib(a){var b,c,d,e,f=[];if(!a._d){for(d=hb(a),a._w&&null==a._a[Pd]&&null==a._a[Od]&&jb(a),null!=a._dayOfYear&&(e=gb(a._a[Nd],d[Nd]),(a._dayOfYear>oa(e)||0===a._dayOfYear)&&(m(a)._overflowDayOfYear=!0),c=sa(e,0,a._dayOfYear),a._a[Od]=c.getUTCMonth(),a._a[Pd]=c.getUTCDate()),b=0;b<3&&null==a._a[b];++b)a._a[b]=f[b]=d[b];for(;b<7;b++)a._a[b]=f[b]=null==a._a[b]?2===b?1:0:a._a[b];24===a._a[Qd]&&0===a._a[Rd]&&0===a._a[Sd]&&0===a._a[Td]&&(a._nextDay=!0,a._a[Qd]=0),a._d=(a._useUTC?sa:ra).apply(null,f),null!=a._tzm&&a._d.setUTCMinutes(a._d.getUTCMinutes()-a._tzm),a._nextDay&&(a._a[Qd]=24)}}function jb(a){var b,c,d,e,f,g,h,i;if(b=a._w,null!=b.GG||null!=b.W||null!=b.E)f=1,g=4,c=gb(b.GG,a._a[Nd],va(sb(),1,4).year),d=gb(b.W,1),((e=gb(b.E,1))<1||e>7)&&(i=!0);else{f=a._locale._week.dow,g=a._locale._week.doy;var j=va(sb(),f,g);c=gb(b.gg,a._a[Nd],j.year),d=gb(b.w,j.week),null!=b.d?((e=b.d)<0||e>6)&&(i=!0):null!=b.e?(e=b.e+f,(b.e<0||b.e>6)&&(i=!0)):e=f}d<1||d>wa(c,f,g)?m(a)._overflowWeeks=!0:null!=i?m(a)._overflowWeekday=!0:(h=ua(c,d,e,f,g),a._a[Nd]=h.year,a._dayOfYear=h.dayOfYear)}function kb(b){if(b._f===a.ISO_8601)return void db(b);if(b._f===a.RFC_2822)return void eb(b);b._a=[],m(b).empty=!0;var c,d,e,f,g,h=""+b._i,i=h.length,j=0;for(e=X(b._f,b._locale).match(Dd)||[],c=0;c<e.length;c++)f=e[c],d=(h.match(Z(f,b))||[])[0],d&&(g=h.substr(0,h.indexOf(d)),g.length>0&&m(b).unusedInput.push(g),h=h.slice(h.indexOf(d)+d.length),j+=d.length),Gd[f]?(d?m(b).empty=!1:m(b).unusedTokens.push(f),ca(f,d,b)):b._strict&&!d&&m(b).unusedTokens.push(f);m(b).charsLeftOver=i-j,h.length>0&&m(b).unusedInput.push(h),b._a[Qd]<=12&&!0===m(b).bigHour&&b._a[Qd]>0&&(m(b).bigHour=void 0),m(b).parsedDateParts=b._a.slice(0),m(b).meridiem=b._meridiem,b._a[Qd]=lb(b._locale,b._a[Qd],b._meridiem),ib(b),cb(b)}function lb(a,b,c){var d;return null==c?b:null!=a.meridiemHour?a.meridiemHour(b,c):null!=a.isPM?(d=a.isPM(c),d&&b<12&&(b+=12),d||12!==b||(b=0),b):b}function mb(a){var b,c,d,e,f;if(0===a._f.length)return m(a).invalidFormat=!0,void(a._d=new Date(NaN));for(e=0;e<a._f.length;e++)f=0,b=p({},a),null!=a._useUTC&&(b._useUTC=a._useUTC),b._f=a._f[e],kb(b),n(b)&&(f+=m(b).charsLeftOver,f+=10*m(b).unusedTokens.length,m(b).score=f,(null==d||f<d)&&(d=f,c=b));j(a,c||b)}function nb(a){if(!a._d){var b=K(a._i);a._a=h([b.year,b.month,b.day||b.date,b.hour,b.minute,b.second,b.millisecond],function(a){return a&&parseInt(a,10)}),ib(a)}}function ob(a){var b=new q(cb(pb(a)));return b._nextDay&&(b.add(1,"d"),b._nextDay=void 0),b}function pb(a){var c=a._i,d=a._f;return a._locale=a._locale||ab(a._l),null===c||void 0===d&&""===c?o({nullInput:!0}):("string"==typeof c&&(a._i=c=a._locale.preparse(c)),r(c)?new q(cb(c)):(g(c)?a._d=c:b(d)?mb(a):d?kb(a):qb(a),n(a)||(a._d=null),a))}function qb(d){var i=d._i;e(i)?d._d=new Date(a.now()):g(i)?d._d=new Date(i.valueOf()):"string"==typeof i?fb(d):b(i)?(d._a=h(i.slice(0),function(a){return parseInt(a,10)}),ib(d)):c(i)?nb(d):f(i)?d._d=new Date(i):a.createFromInputFallback(d)}function rb(a,e,f,g,h){var i={};return!0!==f&&!1!==f||(g=f,f=void 0),(c(a)&&d(a)||b(a)&&0===a.length)&&(a=void 0),i._isAMomentObject=!0,i._useUTC=i._isUTC=h,i._l=f,i._i=a,i._f=e,i._strict=g,ob(i)}function sb(a,b,c,d){return rb(a,b,c,d,!1)}function tb(a,c){var d,e;if(1===c.length&&b(c[0])&&(c=c[0]),!c.length)return sb();for(d=c[0],e=1;e<c.length;++e)c[e].isValid()&&!c[e][a](d)||(d=c[e]);return d}function ub(){return tb("isBefore",[].slice.call(arguments,0))}function vb(){return tb("isAfter",[].slice.call(arguments,0))}function wb(a){for(var b in a)if(-1===we.indexOf(b)||null!=a[b]&&isNaN(a[b]))return!1;for(var c=!1,d=0;d<we.length;++d)if(a[we[d]]){if(c)return!1;parseFloat(a[we[d]])!==t(a[we[d]])&&(c=!0)}return!0}function xb(){return this._isValid}function yb(){return Rb(NaN)}function zb(a){var b=K(a),c=b.year||0,d=b.quarter||0,e=b.month||0,f=b.week||0,g=b.day||0,h=b.hour||0,i=b.minute||0,j=b.second||0,k=b.millisecond||0;this._isValid=wb(b),this._milliseconds=+k+1e3*j+6e4*i+1e3*h*60*60,this._days=+g+7*f,this._months=+e+3*d+12*c,this._data={},this._locale=ab(),this._bubble()}function Ab(a){return a instanceof zb}function Bb(a){return a<0?-1*Math.round(-1*a):Math.round(a)}function Cb(a,b){T(a,0,0,function(){var a=this.utcOffset(),c="+";return a<0&&(a=-a,c="-"),c+S(~~(a/60),2)+b+S(~~a%60,2)})}function Db(a,b){var c=(b||"").match(a);if(null===c)return null;var d=c[c.length-1]||[],e=(d+"").match(xe)||["-",0,0],f=60*e[1]+t(e[2]);return 0===f?0:"+"===e[0]?f:-f}function Eb(b,c){var d,e;return c._isUTC?(d=c.clone(),e=(r(b)||g(b)?b.valueOf():sb(b).valueOf())-d.valueOf(),d._d.setTime(d._d.valueOf()+e),a.updateOffset(d,!1),d):sb(b).local()}function Fb(a){return 15*-Math.round(a._d.getTimezoneOffset()/15)}function Gb(b,c,d){var e,f=this._offset||0;if(!this.isValid())return null!=b?this:NaN;if(null!=b){if("string"==typeof b){if(null===(b=Db(Jd,b)))return this}else Math.abs(b)<16&&!d&&(b*=60);return!this._isUTC&&c&&(e=Fb(this)),this._offset=b,this._isUTC=!0,null!=e&&this.add(e,"m"),f!==b&&(!c||this._changeInProgress?Wb(this,Rb(b-f,"m"),1,!1):this._changeInProgress||(this._changeInProgress=!0,a.updateOffset(this,!0),this._changeInProgress=null)),this}return this._isUTC?f:Fb(this)}function Hb(a,b){return null!=a?("string"!=typeof a&&(a=-a),this.utcOffset(a,b),this):-this.utcOffset()}function Ib(a){return this.utcOffset(0,a)}function Jb(a){return this._isUTC&&(this.utcOffset(0,a),this._isUTC=!1,a&&this.subtract(Fb(this),"m")),this}function Kb(){if(null!=this._tzm)this.utcOffset(this._tzm,!1,!0);else if("string"==typeof this._i){var a=Db(Id,this._i);null!=a?this.utcOffset(a):this.utcOffset(0,!0)}return this}function Lb(a){return!!this.isValid()&&(a=a?sb(a).utcOffset():0,(this.utcOffset()-a)%60==0)}function Mb(){return this.utcOffset()>this.clone().month(0).utcOffset()||this.utcOffset()>this.clone().month(5).utcOffset()}function Nb(){if(!e(this._isDSTShifted))return this._isDSTShifted;var a={};if(p(a,this),a=pb(a),a._a){var b=a._isUTC?k(a._a):sb(a._a);this._isDSTShifted=this.isValid()&&u(a._a,b.toArray())>0}else this._isDSTShifted=!1;return this._isDSTShifted}function Ob(){return!!this.isValid()&&!this._isUTC}function Pb(){return!!this.isValid()&&this._isUTC}function Qb(){return!!this.isValid()&&(this._isUTC&&0===this._offset)}function Rb(a,b){var c,d,e,g=a,h=null;return Ab(a)?g={ms:a._milliseconds,d:a._days,M:a._months}:f(a)?(g={},b?g[b]=a:g.milliseconds=a):(h=ye.exec(a))?(c="-"===h[1]?-1:1,g={y:0,d:t(h[Pd])*c,h:t(h[Qd])*c,m:t(h[Rd])*c,s:t(h[Sd])*c,ms:t(Bb(1e3*h[Td]))*c}):(h=ze.exec(a))?(c="-"===h[1]?-1:1,g={y:Sb(h[2],c),M:Sb(h[3],c),w:Sb(h[4],c),d:Sb(h[5],c),h:Sb(h[6],c),m:Sb(h[7],c),s:Sb(h[8],c)}):null==g?g={}:"object"==typeof g&&("from"in g||"to"in g)&&(e=Ub(sb(g.from),sb(g.to)),g={},g.ms=e.milliseconds,g.M=e.months),d=new zb(g),Ab(a)&&i(a,"_locale")&&(d._locale=a._locale),d}function Sb(a,b){var c=a&&parseFloat(a.replace(",","."));return(isNaN(c)?0:c)*b}function Tb(a,b){var c={milliseconds:0,months:0};return c.months=b.month()-a.month()+12*(b.year()-a.year()),a.clone().add(c.months,"M").isAfter(b)&&--c.months,c.milliseconds=+b-+a.clone().add(c.months,"M"),c}function Ub(a,b){var c;return a.isValid()&&b.isValid()?(b=Eb(b,a),a.isBefore(b)?c=Tb(a,b):(c=Tb(b,a),c.milliseconds=-c.milliseconds,c.months=-c.months),c):{milliseconds:0,months:0}}function Vb(a,b){return function(c,d){var e,f;return null===d||isNaN(+d)||(x(b,"moment()."+b+"(period, number) is deprecated. Please use moment()."+b+"(number, period). See http://momentjs.com/guides/#/warnings/add-inverted-param/ for more info."),f=c,c=d,d=f),c="string"==typeof c?+c:c,e=Rb(c,d),Wb(this,e,a),this}}function Wb(b,c,d,e){var f=c._milliseconds,g=Bb(c._days),h=Bb(c._months);b.isValid()&&(e=null==e||e,f&&b._d.setTime(b._d.valueOf()+f*d),g&&P(b,"Date",O(b,"Date")+g*d),h&&ia(b,O(b,"Month")+h*d),e&&a.updateOffset(b,g||h))}function Xb(a,b){var c=a.diff(b,"days",!0);return c<-6?"sameElse":c<-1?"lastWeek":c<0?"lastDay":c<1?"sameDay":c<2?"nextDay":c<7?"nextWeek":"sameElse"}function Yb(b,c){var d=b||sb(),e=Eb(d,this).startOf("day"),f=a.calendarFormat(this,e)||"sameElse",g=c&&(y(c[f])?c[f].call(this,d):c[f]);return this.format(g||this.localeData().calendar(f,this,sb(d)))}function Zb(){return new q(this)}function $b(a,b){var c=r(a)?a:sb(a);return!(!this.isValid()||!c.isValid())&&(b=J(e(b)?"millisecond":b),"millisecond"===b?this.valueOf()>c.valueOf():c.valueOf()<this.clone().startOf(b).valueOf())}function _b(a,b){var c=r(a)?a:sb(a);return!(!this.isValid()||!c.isValid())&&(b=J(e(b)?"millisecond":b),"millisecond"===b?this.valueOf()<c.valueOf():this.clone().endOf(b).valueOf()<c.valueOf())}function ac(a,b,c,d){return d=d||"()",("("===d[0]?this.isAfter(a,c):!this.isBefore(a,c))&&(")"===d[1]?this.isBefore(b,c):!this.isAfter(b,c))}function bc(a,b){var c,d=r(a)?a:sb(a);return!(!this.isValid()||!d.isValid())&&(b=J(b||"millisecond"),"millisecond"===b?this.valueOf()===d.valueOf():(c=d.valueOf(),this.clone().startOf(b).valueOf()<=c&&c<=this.clone().endOf(b).valueOf()))}function cc(a,b){return this.isSame(a,b)||this.isAfter(a,b)}function dc(a,b){return this.isSame(a,b)||this.isBefore(a,b)}function ec(a,b,c){var d,e,f,g;return this.isValid()?(d=Eb(a,this),d.isValid()?(e=6e4*(d.utcOffset()-this.utcOffset()),b=J(b),"year"===b||"month"===b||"quarter"===b?(g=fc(this,d),"quarter"===b?g/=3:"year"===b&&(g/=12)):(f=this-d,g="second"===b?f/1e3:"minute"===b?f/6e4:"hour"===b?f/36e5:"day"===b?(f-e)/864e5:"week"===b?(f-e)/6048e5:f),c?g:s(g)):NaN):NaN}function fc(a,b){var c,d,e=12*(b.year()-a.year())+(b.month()-a.month()),f=a.clone().add(e,"months");return b-f<0?(c=a.clone().add(e-1,"months"),d=(b-f)/(f-c)):(c=a.clone().add(e+1,"months"),d=(b-f)/(c-f)),-(e+d)||0}function gc(){return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")}function hc(){if(!this.isValid())return null;var a=this.clone().utc();return a.year()<0||a.year()>9999?W(a,"YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]"):y(Date.prototype.toISOString)?this.toDate().toISOString():W(a,"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]")}function ic(){if(!this.isValid())return"moment.invalid(/* "+this._i+" */)";var a="moment",b="";this.isLocal()||(a=0===this.utcOffset()?"moment.utc":"moment.parseZone",b="Z");var c="["+a+'("]',d=0<=this.year()&&this.year()<=9999?"YYYY":"YYYYYY",e=b+'[")]';return this.format(c+d+"-MM-DD[T]HH:mm:ss.SSS"+e)}function jc(b){b||(b=this.isUtc()?a.defaultFormatUtc:a.defaultFormat);var c=W(this,b);return this.localeData().postformat(c)}function kc(a,b){return this.isValid()&&(r(a)&&a.isValid()||sb(a).isValid())?Rb({to:this,from:a}).locale(this.locale()).humanize(!b):this.localeData().invalidDate()}function lc(a){return this.from(sb(),a)}function mc(a,b){return this.isValid()&&(r(a)&&a.isValid()||sb(a).isValid())?Rb({from:this,to:a}).locale(this.locale()).humanize(!b):this.localeData().invalidDate()}function nc(a){return this.to(sb(),a)}function oc(a){var b;return void 0===a?this._locale._abbr:(b=ab(a),null!=b&&(this._locale=b),this)}function pc(){return this._locale}function qc(a){switch(a=J(a)){case"year":this.month(0);case"quarter":case"month":this.date(1);case"week":case"isoWeek":case"day":case"date":this.hours(0);case"hour":this.minutes(0);case"minute":this.seconds(0);case"second":this.milliseconds(0)}return"week"===a&&this.weekday(0),"isoWeek"===a&&this.isoWeekday(1),"quarter"===a&&this.month(3*Math.floor(this.month()/3)),this}function rc(a){return void 0===(a=J(a))||"millisecond"===a?this:("date"===a&&(a="day"),this.startOf(a).add(1,"isoWeek"===a?"week":a).subtract(1,"ms"))}function sc(){return this._d.valueOf()-6e4*(this._offset||0)}function tc(){return Math.floor(this.valueOf()/1e3)}function uc(){return new Date(this.valueOf())}function vc(){var a=this;return[a.year(),a.month(),a.date(),a.hour(),a.minute(),a.second(),a.millisecond()]}function wc(){var a=this;return{years:a.year(),months:a.month(),date:a.date(),hours:a.hours(),minutes:a.minutes(),seconds:a.seconds(),milliseconds:a.milliseconds()}}function xc(){return this.isValid()?this.toISOString():null}function yc(){return n(this)}function zc(){return j({},m(this))}function Ac(){return m(this).overflow}function Bc(){
    return { input: this._i, format: this._f, locale: this._locale, isUTC: this._isUTC, strict: this._strict } } function Cc(a, b) { T(0, [a, a.length], 0, b) } function Dc(a) { return Hc.call(this, a, this.week(), this.weekday(), this.localeData()._week.dow, this.localeData()._week.doy) } function Ec(a) { return Hc.call(this, a, this.isoWeek(), this.isoWeekday(), 1, 4) } function Fc() { return wa(this.year(), 1, 4) } function Gc() { var a = this.localeData()._week; return wa(this.year(), a.dow, a.doy) } function Hc(a, b, c, d, e) { var f; return null == a ? va(this, d, e).year : (f = wa(a, d, e), b > f && (b = f), Ic.call(this, a, b, c, d, e)) } function Ic(a, b, c, d, e) { var f = ua(a, b, c, d, e), g = sa(f.year, 0, f.dayOfYear); return this.year(g.getUTCFullYear()), this.month(g.getUTCMonth()), this.date(g.getUTCDate()), this } function Jc(a) { return null == a ? Math.ceil((this.month() + 1) / 3) : this.month(3 * (a - 1) + this.month() % 3) } function Kc(a) { var b = Math.round((this.clone().startOf("day") - this.clone().startOf("year")) / 864e5) + 1; return null == a ? b : this.add(a - b, "d") } function Lc(a, b) { b[Td] = t(1e3 * ("0." + a)) } function Mc() { return this._isUTC ? "UTC" : "" } function Nc() { return this._isUTC ? "Coordinated Universal Time" : "" } function Oc(a) { return sb(1e3 * a) } function Pc() { return sb.apply(null, arguments).parseZone() } function Qc(a) { return a } function Rc(a, b, c, d) { var e = ab(), f = k().set(d, b); return e[c](f, a) } function Sc(a, b, c) { if (f(a) && (b = a, a = void 0), a = a || "", null != b) return Rc(a, b, c, "month"); var d, e = []; for (d = 0; d < 12; d++) e[d] = Rc(a, d, c, "month"); return e } function Tc(a, b, c, d) { "boolean" == typeof a ? (f(b) && (c = b, b = void 0), b = b || "") : (b = a, c = b, a = !1, f(b) && (c = b, b = void 0), b = b || ""); var e = ab(), g = a ? e._week.dow : 0; if (null != c) return Rc(b, (c + g) % 7, d, "day"); var h, i = []; for (h = 0; h < 7; h++) i[h] = Rc(b, (h + g) % 7, d, "day"); return i } function Uc(a, b) { return Sc(a, b, "months") } function Vc(a, b) { return Sc(a, b, "monthsShort") } function Wc(a, b, c) { return Tc(a, b, c, "weekdays") } function Xc(a, b, c) { return Tc(a, b, c, "weekdaysShort") } function Yc(a, b, c) { return Tc(a, b, c, "weekdaysMin") } function Zc() { var a = this._data; return this._milliseconds = Ke(this._milliseconds), this._days = Ke(this._days), this._months = Ke(this._months), a.milliseconds = Ke(a.milliseconds), a.seconds = Ke(a.seconds), a.minutes = Ke(a.minutes), a.hours = Ke(a.hours), a.months = Ke(a.months), a.years = Ke(a.years), this } function $c(a, b, c, d) { var e = Rb(b, c); return a._milliseconds += d * e._milliseconds, a._days += d * e._days, a._months += d * e._months, a._bubble() } function _c(a, b) { return $c(this, a, b, 1) } function ad(a, b) { return $c(this, a, b, -1) } function bd(a) { return a < 0 ? Math.floor(a) : Math.ceil(a) } function cd() { var a, b, c, d, e, f = this._milliseconds, g = this._days, h = this._months, i = this._data; return f >= 0 && g >= 0 && h >= 0 || f <= 0 && g <= 0 && h <= 0 || (f += 864e5 * bd(ed(h) + g), g = 0, h = 0), i.milliseconds = f % 1e3, a = s(f / 1e3), i.seconds = a % 60, b = s(a / 60), i.minutes = b % 60, c = s(b / 60), i.hours = c % 24, g += s(c / 24), e = s(dd(g)), h += e, g -= bd(ed(e)), d = s(h / 12), h %= 12, i.days = g, i.months = h, i.years = d, this } function dd(a) { return 4800 * a / 146097 } function ed(a) { return 146097 * a / 4800 } function fd(a) { if (!this.isValid()) return NaN; var b, c, d = this._milliseconds; if ("month" === (a = J(a)) || "year" === a) return b = this._days + d / 864e5, c = this._months + dd(b), "month" === a ? c : c / 12; switch (b = this._days + Math.round(ed(this._months)), a) { case "week": return b / 7 + d / 6048e5; case "day": return b + d / 864e5; case "hour": return 24 * b + d / 36e5; case "minute": return 1440 * b + d / 6e4; case "second": return 86400 * b + d / 1e3; case "millisecond": return Math.floor(864e5 * b) + d; default: throw new Error("Unknown unit " + a) } } function gd() { return this.isValid() ? this._milliseconds + 864e5 * this._days + this._months % 12 * 2592e6 + 31536e6 * t(this._months / 12) : NaN } function hd(a) { return function () { return this.as(a) } } function id(a) { return a = J(a), this.isValid() ? this[a + "s"]() : NaN } function jd(a) { return function () { return this.isValid() ? this._data[a] : NaN } } function kd() { return s(this.days() / 7) } function ld(a, b, c, d, e) { return e.relativeTime(b || 1, !!c, a, d) } function md(a, b, c) { var d = Rb(a).abs(), e = $e(d.as("s")), f = $e(d.as("m")), g = $e(d.as("h")), h = $e(d.as("d")), i = $e(d.as("M")), j = $e(d.as("y")), k = e <= _e.ss && ["s", e] || e < _e.s && ["ss", e] || f <= 1 && ["m"] || f < _e.m && ["mm", f] || g <= 1 && ["h"] || g < _e.h && ["hh", g] || h <= 1 && ["d"] || h < _e.d && ["dd", h] || i <= 1 && ["M"] || i < _e.M && ["MM", i] || j <= 1 && ["y"] || ["yy", j]; return k[2] = b, k[3] = +a > 0, k[4] = c, ld.apply(null, k) } function nd(a) { return void 0 === a ? $e : "function" == typeof a && ($e = a, !0) } function od(a, b) { return void 0 !== _e[a] && (void 0 === b ? _e[a] : (_e[a] = b, "s" === a && (_e.ss = b - 1), !0)) } function pd(a) { if (!this.isValid()) return this.localeData().invalidDate(); var b = this.localeData(), c = md(this, !a, b); return a && (c = b.pastFuture(+this, c)), b.postformat(c) } function qd() { if (!this.isValid()) return this.localeData().invalidDate(); var a, b, c, d = af(this._milliseconds) / 1e3, e = af(this._days), f = af(this._months); a = s(d / 60), b = s(a / 60), d %= 60, a %= 60, c = s(f / 12), f %= 12; var g = c, h = f, i = e, j = b, k = a, l = d, m = this.asSeconds(); return m ? (m < 0 ? "-" : "") + "P" + (g ? g + "Y" : "") + (h ? h + "M" : "") + (i ? i + "D" : "") + (j || k || l ? "T" : "") + (j ? j + "H" : "") + (k ? k + "M" : "") + (l ? l + "S" : "") : "P0D" } var rd, sd; sd = Array.prototype.some ? Array.prototype.some : function (a) { for (var b = Object(this), c = b.length >>> 0, d = 0; d < c; d++) if (d in b && a.call(this, b[d], d, b)) return !0; return !1 }; var td = a.momentProperties = [], ud = !1, vd = {}; a.suppressDeprecationWarnings = !1, a.deprecationHandler = null; var wd; wd = Object.keys ? Object.keys : function (a) { var b, c = []; for (b in a) i(a, b) && c.push(b); return c }; var xd, yd = { sameDay: "[Today at] LT", nextDay: "[Tomorrow at] LT", nextWeek: "dddd [at] LT", lastDay: "[Yesterday at] LT", lastWeek: "[Last] dddd [at] LT", sameElse: "L" }, zd = { LTS: "h:mm:ss A", LT: "h:mm A", L: "MM/DD/YYYY", LL: "MMMM D, YYYY", LLL: "MMMM D, YYYY h:mm A", LLLL: "dddd, MMMM D, YYYY h:mm A" }, Ad = { future: "in %s", past: "%s ago", s: "a few seconds", ss: "%d seconds", m: "a minute", mm: "%d minutes", h: "an hour", hh: "%d hours", d: "a day", dd: "%d days", M: "a month", MM: "%d months", y: "a year", yy: "%d years" }, Bd = {}, Cd = {}, Dd = /(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g, Ed = /(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g, Fd = {}, Gd = {}, Hd = /[+-]?\d{6}/, Id = /Z|[+-]\d\d:?\d\d/gi, Jd = /Z|[+-]\d\d(?::?\d\d)?/gi, Kd = /[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i, Ld = {}, Md = {}, Nd = 0, Od = 1, Pd = 2, Qd = 3, Rd = 4, Sd = 5, Td = 6, Ud = 7, Vd = 8; xd = Array.prototype.indexOf ? Array.prototype.indexOf : function (a) { var b; for (b = 0; b < this.length; ++b) if (this[b] === a) return b; return -1 }, T("M", ["MM", 2], "Mo", function () { return this.month() + 1 }), T("MMM", 0, 0, function (a) { return this.localeData().monthsShort(this, a) }), T("MMMM", 0, 0, function (a) { return this.localeData().months(this, a) }), I("month", "M"), L("month", 8), Y("M", /\d\d?/), Y("MM", /\d\d?/, /\d\d/), Y("MMM", function (a, b) { return b.monthsShortRegex(a) }), Y("MMMM", function (a, b) { return b.monthsRegex(a) }), aa(["M", "MM"], function (a, b) { b[Od] = t(a) - 1 }), aa(["MMM", "MMMM"], function (a, b, c, d) { var e = c._locale.monthsParse(a, d, c._strict); null != e ? b[Od] = e : m(c).invalidMonth = a }); var Wd = /D[oD]?(\[[^\[\]]*\]|\s)+MMMM?/, Xd = "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), Yd = "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"), Zd = Kd, $d = Kd; T("Y", 0, 0, function () { var a = this.year(); return a <= 9999 ? "" + a : "+" + a }), T(0, ["YY", 2], 0, function () { return this.year() % 100 }), T(0, ["YYYY", 4], 0, "year"), T(0, ["YYYYY", 5], 0, "year"), T(0, ["YYYYYY", 6, !0], 0, "year"), I("year", "y"), L("year", 1), Y("Y", /[+-]?\d+/), Y("YY", /\d\d?/, /\d\d/), Y("YYYY", /\d{1,4}/, /\d{4}/), Y("YYYYY", /[+-]?\d{1,6}/, Hd), Y("YYYYYY", /[+-]?\d{1,6}/, Hd), aa(["YYYYY", "YYYYYY"], Nd), aa("YYYY", function (b, c) { c[Nd] = 2 === b.length ? a.parseTwoDigitYear(b) : t(b) }), aa("YY", function (b, c) { c[Nd] = a.parseTwoDigitYear(b) }), aa("Y", function (a, b) { b[Nd] = parseInt(a, 10) }), a.parseTwoDigitYear = function (a) { return t(a) + (t(a) > 68 ? 1900 : 2e3) }; var _d = N("FullYear", !0); T("w", ["ww", 2], "wo", "week"), T("W", ["WW", 2], "Wo", "isoWeek"), I("week", "w"), I("isoWeek", "W"), L("week", 5), L("isoWeek", 5), Y("w", /\d\d?/), Y("ww", /\d\d?/, /\d\d/), Y("W", /\d\d?/), Y("WW", /\d\d?/, /\d\d/), ba(["w", "ww", "W", "WW"], function (a, b, c, d) { b[d.substr(0, 1)] = t(a) }); var ae = { dow: 0, doy: 6 }; T("d", 0, "do", "day"), T("dd", 0, 0, function (a) { return this.localeData().weekdaysMin(this, a) }), T("ddd", 0, 0, function (a) { return this.localeData().weekdaysShort(this, a) }), T("dddd", 0, 0, function (a) { return this.localeData().weekdays(this, a) }), T("e", 0, 0, "weekday"), T("E", 0, 0, "isoWeekday"), I("day", "d"), I("weekday", "e"), I("isoWeekday", "E"), L("day", 11), L("weekday", 11), L("isoWeekday", 11), Y("d", /\d\d?/), Y("e", /\d\d?/), Y("E", /\d\d?/), Y("dd", function (a, b) { return b.weekdaysMinRegex(a) }), Y("ddd", function (a, b) { return b.weekdaysShortRegex(a) }), Y("dddd", function (a, b) { return b.weekdaysRegex(a) }), ba(["dd", "ddd", "dddd"], function (a, b, c, d) { var e = c._locale.weekdaysParse(a, d, c._strict); null != e ? b.d = e : m(c).invalidWeekday = a }), ba(["d", "e", "E"], function (a, b, c, d) { b[d] = t(a) }); var be = "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), ce = "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"), de = "Su_Mo_Tu_We_Th_Fr_Sa".split("_"), ee = Kd, fe = Kd, ge = Kd; T("H", ["HH", 2], 0, "hour"), T("h", ["hh", 2], 0, Qa), T("k", ["kk", 2], 0, Ra), T("hmm", 0, 0, function () { return "" + Qa.apply(this) + S(this.minutes(), 2) }), T("hmmss", 0, 0, function () { return "" + Qa.apply(this) + S(this.minutes(), 2) + S(this.seconds(), 2) }), T("Hmm", 0, 0, function () { return "" + this.hours() + S(this.minutes(), 2) }), T("Hmmss", 0, 0, function () { return "" + this.hours() + S(this.minutes(), 2) + S(this.seconds(), 2) }), Sa("a", !0), Sa("A", !1), I("hour", "h"), L("hour", 13), Y("a", Ta), Y("A", Ta), Y("H", /\d\d?/), Y("h", /\d\d?/), Y("k", /\d\d?/), Y("HH", /\d\d?/, /\d\d/), Y("hh", /\d\d?/, /\d\d/), Y("kk", /\d\d?/, /\d\d/), Y("hmm", /\d\d\d\d?/), Y("hmmss", /\d\d\d\d\d\d?/), Y("Hmm", /\d\d\d\d?/), Y("Hmmss", /\d\d\d\d\d\d?/), aa(["H", "HH"], Qd), aa(["k", "kk"], function (a, b, c) { var d = t(a); b[Qd] = 24 === d ? 0 : d }), aa(["a", "A"], function (a, b, c) { c._isPm = c._locale.isPM(a), c._meridiem = a }), aa(["h", "hh"], function (a, b, c) { b[Qd] = t(a), m(c).bigHour = !0 }), aa("hmm", function (a, b, c) { var d = a.length - 2; b[Qd] = t(a.substr(0, d)), b[Rd] = t(a.substr(d)), m(c).bigHour = !0 }), aa("hmmss", function (a, b, c) { var d = a.length - 4, e = a.length - 2; b[Qd] = t(a.substr(0, d)), b[Rd] = t(a.substr(d, 2)), b[Sd] = t(a.substr(e)), m(c).bigHour = !0 }), aa("Hmm", function (a, b, c) { var d = a.length - 2; b[Qd] = t(a.substr(0, d)), b[Rd] = t(a.substr(d)) }), aa("Hmmss", function (a, b, c) { var d = a.length - 4, e = a.length - 2; b[Qd] = t(a.substr(0, d)), b[Rd] = t(a.substr(d, 2)), b[Sd] = t(a.substr(e)) }); var he, ie = N("Hours", !0), je = { calendar: yd, longDateFormat: zd, invalidDate: "Invalid date", ordinal: "%d", dayOfMonthOrdinalParse: /\d{1,2}/, relativeTime: Ad, months: Xd, monthsShort: Yd, week: ae, weekdays: be, weekdaysMin: de, weekdaysShort: ce, meridiemParse: /[ap]\.?m?\.?/i }, ke = {}, le = {}, me = /^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?$/, ne = /^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?$/, oe = /Z|[+-]\d\d(?::?\d\d)?/, pe = [["YYYYYY-MM-DD", /[+-]\d{6}-\d\d-\d\d/], ["YYYY-MM-DD", /\d{4}-\d\d-\d\d/], ["GGGG-[W]WW-E", /\d{4}-W\d\d-\d/], ["GGGG-[W]WW", /\d{4}-W\d\d/, !1], ["YYYY-DDD", /\d{4}-\d{3}/], ["YYYY-MM", /\d{4}-\d\d/, !1], ["YYYYYYMMDD", /[+-]\d{10}/], ["YYYYMMDD", /\d{8}/], ["GGGG[W]WWE", /\d{4}W\d{3}/], ["GGGG[W]WW", /\d{4}W\d{2}/, !1], ["YYYYDDD", /\d{7}/]], qe = [["HH:mm:ss.SSSS", /\d\d:\d\d:\d\d\.\d+/], ["HH:mm:ss,SSSS", /\d\d:\d\d:\d\d,\d+/], ["HH:mm:ss", /\d\d:\d\d:\d\d/], ["HH:mm", /\d\d:\d\d/], ["HHmmss.SSSS", /\d\d\d\d\d\d\.\d+/], ["HHmmss,SSSS", /\d\d\d\d\d\d,\d+/], ["HHmmss", /\d\d\d\d\d\d/], ["HHmm", /\d\d\d\d/], ["HH", /\d\d/]], re = /^\/?Date\((\-?\d+)/i, se = /^((?:Mon|Tue|Wed|Thu|Fri|Sat|Sun),?\s)?(\d?\d\s(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(?:\d\d)?\d\d\s)(\d\d:\d\d)(\:\d\d)?(\s(?:UT|GMT|[ECMP][SD]T|[A-IK-Za-ik-z]|[+-]\d{4}))$/; a.createFromInputFallback = w("value provided is not in a recognized RFC2822 or ISO format. moment construction falls back to js Date(), which is not reliable across all browsers and versions. Non RFC2822/ISO date formats are discouraged and will be removed in an upcoming major release. Please refer to http://momentjs.com/guides/#/warnings/js-date/ for more info.", function (a) { a._d = new Date(a._i + (a._useUTC ? " UTC" : "")) }), a.ISO_8601 = function () { }, a.RFC_2822 = function () { }; var te = w("moment().min is deprecated, use moment.max instead. http://momentjs.com/guides/#/warnings/min-max/", function () { var a = sb.apply(null, arguments); return this.isValid() && a.isValid() ? a < this ? this : a : o() }), ue = w("moment().max is deprecated, use moment.min instead. http://momentjs.com/guides/#/warnings/min-max/", function () { var a = sb.apply(null, arguments); return this.isValid() && a.isValid() ? a > this ? this : a : o() }), ve = function () { return Date.now ? Date.now() : +new Date }, we = ["year", "quarter", "month", "week", "day", "hour", "minute", "second", "millisecond"]; Cb("Z", ":"), Cb("ZZ", ""), Y("Z", Jd), Y("ZZ", Jd), aa(["Z", "ZZ"], function (a, b, c) { c._useUTC = !0, c._tzm = Db(Jd, a) }); var xe = /([\+\-]|\d\d)/gi; a.updateOffset = function () { }; var ye = /^(\-)?(?:(\d*)[. ])?(\d+)\:(\d+)(?:\:(\d+)(\.\d*)?)?$/, ze = /^(-)?P(?:(-?[0-9,.]*)Y)?(?:(-?[0-9,.]*)M)?(?:(-?[0-9,.]*)W)?(?:(-?[0-9,.]*)D)?(?:T(?:(-?[0-9,.]*)H)?(?:(-?[0-9,.]*)M)?(?:(-?[0-9,.]*)S)?)?$/; Rb.fn = zb.prototype, Rb.invalid = yb; var Ae = Vb(1, "add"), Be = Vb(-1, "subtract"); a.defaultFormat = "YYYY-MM-DDTHH:mm:ssZ", a.defaultFormatUtc = "YYYY-MM-DDTHH:mm:ss[Z]"; var Ce = w("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.", function (a) { return void 0 === a ? this.localeData() : this.locale(a) }); T(0, ["gg", 2], 0, function () { return this.weekYear() % 100 }), T(0, ["GG", 2], 0, function () { return this.isoWeekYear() % 100 }), Cc("gggg", "weekYear"), Cc("ggggg", "weekYear"), Cc("GGGG", "isoWeekYear"), Cc("GGGGG", "isoWeekYear"), I("weekYear", "gg"), I("isoWeekYear", "GG"), L("weekYear", 1), L("isoWeekYear", 1), Y("G", /[+-]?\d+/), Y("g", /[+-]?\d+/), Y("GG", /\d\d?/, /\d\d/), Y("gg", /\d\d?/, /\d\d/), Y("GGGG", /\d{1,4}/, /\d{4}/), Y("gggg", /\d{1,4}/, /\d{4}/), Y("GGGGG", /[+-]?\d{1,6}/, Hd), Y("ggggg", /[+-]?\d{1,6}/, Hd), ba(["gggg", "ggggg", "GGGG", "GGGGG"], function (a, b, c, d) { b[d.substr(0, 2)] = t(a) }), ba(["gg", "GG"], function (b, c, d, e) { c[e] = a.parseTwoDigitYear(b) }), T("Q", 0, "Qo", "quarter"), I("quarter", "Q"), L("quarter", 7), Y("Q", /\d/), aa("Q", function (a, b) { b[Od] = 3 * (t(a) - 1) }), T("D", ["DD", 2], "Do", "date"), I("date", "D"), L("date", 9), Y("D", /\d\d?/), Y("DD", /\d\d?/, /\d\d/), Y("Do", function (a, b) { return a ? b._dayOfMonthOrdinalParse || b._ordinalParse : b._dayOfMonthOrdinalParseLenient }), aa(["D", "DD"], Pd), aa("Do", function (a, b) { b[Pd] = t(a.match(/\d\d?/)[0], 10) }); var De = N("Date", !0); T("DDD", ["DDDD", 3], "DDDo", "dayOfYear"), I("dayOfYear", "DDD"), L("dayOfYear", 4), Y("DDD", /\d{1,3}/), Y("DDDD", /\d{3}/), aa(["DDD", "DDDD"], function (a, b, c) { c._dayOfYear = t(a) }), T("m", ["mm", 2], 0, "minute"), I("minute", "m"), L("minute", 14), Y("m", /\d\d?/), Y("mm", /\d\d?/, /\d\d/), aa(["m", "mm"], Rd); var Ee = N("Minutes", !1); T("s", ["ss", 2], 0, "second"), I("second", "s"), L("second", 15), Y("s", /\d\d?/), Y("ss", /\d\d?/, /\d\d/), aa(["s", "ss"], Sd); var Fe = N("Seconds", !1); T("S", 0, 0, function () { return ~~(this.millisecond() / 100) }), T(0, ["SS", 2], 0, function () { return ~~(this.millisecond() / 10) }), T(0, ["SSS", 3], 0, "millisecond"), T(0, ["SSSS", 4], 0, function () { return 10 * this.millisecond() }), T(0, ["SSSSS", 5], 0, function () { return 100 * this.millisecond() }), T(0, ["SSSSSS", 6], 0, function () { return 1e3 * this.millisecond() }), T(0, ["SSSSSSS", 7], 0, function () { return 1e4 * this.millisecond() }), T(0, ["SSSSSSSS", 8], 0, function () { return 1e5 * this.millisecond() }), T(0, ["SSSSSSSSS", 9], 0, function () { return 1e6 * this.millisecond() }), I("millisecond", "ms"), L("millisecond", 16), Y("S", /\d{1,3}/, /\d/), Y("SS", /\d{1,3}/, /\d\d/), Y("SSS", /\d{1,3}/, /\d{3}/); var Ge; for (Ge = "SSSS"; Ge.length <= 9; Ge += "S") Y(Ge, /\d+/); for (Ge = "S"; Ge.length <= 9; Ge += "S") aa(Ge, Lc); var He = N("Milliseconds", !1); T("z", 0, 0, "zoneAbbr"), T("zz", 0, 0, "zoneName"); var Ie = q.prototype; Ie.add = Ae, Ie.calendar = Yb, Ie.clone = Zb, Ie.diff = ec, Ie.endOf = rc, Ie.format = jc, Ie.from = kc, Ie.fromNow = lc, Ie.to = mc, Ie.toNow = nc, Ie.get = Q, Ie.invalidAt = Ac, Ie.isAfter = $b, Ie.isBefore = _b, Ie.isBetween = ac, Ie.isSame = bc, Ie.isSameOrAfter = cc, Ie.isSameOrBefore = dc, Ie.isValid = yc, Ie.lang = Ce, Ie.locale = oc, Ie.localeData = pc, Ie.max = ue, Ie.min = te, Ie.parsingFlags = zc, Ie.set = R, Ie.startOf = qc, Ie.subtract = Be, Ie.toArray = vc, Ie.toObject = wc, Ie.toDate = uc, Ie.toISOString = hc, Ie.inspect = ic, Ie.toJSON = xc, Ie.toString = gc, Ie.unix = tc, Ie.valueOf = sc, Ie.creationData = Bc, Ie.year = _d, Ie.isLeapYear = qa, Ie.weekYear = Dc, Ie.isoWeekYear = Ec, Ie.quarter = Ie.quarters = Jc, Ie.month = ja, Ie.daysInMonth = ka, Ie.week = Ie.weeks = Aa, Ie.isoWeek = Ie.isoWeeks = Ba, Ie.weeksInYear = Gc, Ie.isoWeeksInYear = Fc, Ie.date = De, Ie.day = Ie.days = Ja, Ie.weekday = Ka, Ie.isoWeekday = La, Ie.dayOfYear = Kc, Ie.hour = Ie.hours = ie, Ie.minute = Ie.minutes = Ee, Ie.second = Ie.seconds = Fe, Ie.millisecond = Ie.milliseconds = He, Ie.utcOffset = Gb, Ie.utc = Ib, Ie.local = Jb, Ie.parseZone = Kb, Ie.hasAlignedHourOffset = Lb, Ie.isDST = Mb, Ie.isLocal = Ob, Ie.isUtcOffset = Pb, Ie.isUtc = Qb, Ie.isUTC = Qb, Ie.zoneAbbr = Mc, Ie.zoneName = Nc, Ie.dates = w("dates accessor is deprecated. Use date instead.", De), Ie.months = w("months accessor is deprecated. Use month instead", ja), Ie.years = w("years accessor is deprecated. Use year instead", _d), Ie.zone = w("moment().zone is deprecated, use moment().utcOffset instead. http://momentjs.com/guides/#/warnings/zone/", Hb), Ie.isDSTShifted = w("isDSTShifted is deprecated. See http://momentjs.com/guides/#/warnings/dst-shifted/ for more information", Nb); var Je = B.prototype; Je.calendar = C, Je.longDateFormat = D, Je.invalidDate = E, Je.ordinal = F, Je.preparse = Qc, Je.postformat = Qc, Je.relativeTime = G, Je.pastFuture = H, Je.set = z, Je.months = ea, Je.monthsShort = fa, Je.monthsParse = ha, Je.monthsRegex = ma, Je.monthsShortRegex = la, Je.week = xa, Je.firstDayOfYear = za, Je.firstDayOfWeek = ya, Je.weekdays = Ea, Je.weekdaysMin = Ga, Je.weekdaysShort = Fa, Je.weekdaysParse = Ia, Je.weekdaysRegex = Ma, Je.weekdaysShortRegex = Na, Je.weekdaysMinRegex = Oa, Je.isPM = Ua, Je.meridiem = Va, Za("en", { dayOfMonthOrdinalParse: /\d{1,2}(th|st|nd|rd)/, ordinal: function (a) { var b = a % 10; return a + (1 === t(a % 100 / 10) ? "th" : 1 === b ? "st" : 2 === b ? "nd" : 3 === b ? "rd" : "th") } }), a.lang = w("moment.lang is deprecated. Use moment.locale instead.", Za), a.langData = w("moment.langData is deprecated. Use moment.localeData instead.", ab); var Ke = Math.abs, Le = hd("ms"), Me = hd("s"), Ne = hd("m"), Oe = hd("h"), Pe = hd("d"), Qe = hd("w"), Re = hd("M"), Se = hd("y"), Te = jd("milliseconds"), Ue = jd("seconds"), Ve = jd("minutes"), We = jd("hours"), Xe = jd("days"), Ye = jd("months"), Ze = jd("years"), $e = Math.round, _e = { ss: 44, s: 45, m: 45, h: 22, d: 26, M: 11 }, af = Math.abs, bf = zb.prototype; return bf.isValid = xb, bf.abs = Zc, bf.add = _c, bf.subtract = ad, bf.as = fd, bf.asMilliseconds = Le, bf.asSeconds = Me, bf.asMinutes = Ne, bf.asHours = Oe, bf.asDays = Pe, bf.asWeeks = Qe, bf.asMonths = Re, bf.asYears = Se, bf.valueOf = gd, bf._bubble = cd, bf.get = id, bf.milliseconds = Te, bf.seconds = Ue, bf.minutes = Ve, bf.hours = We, bf.days = Xe, bf.weeks = kd, bf.months = Ye, bf.years = Ze, bf.humanize = pd, bf.toISOString = qd, bf.toString = qd, bf.toJSON = qd, bf.locale = oc, bf.localeData = pc, bf.toIsoString = w("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)", qd), bf.lang = Ce, T("X", 0, 0, "unix"), T("x", 0, 0, "valueOf"), Y("x", /[+-]?\d+/), Y("X", /[+-]?\d+(\.\d{1,3})?/), aa("X", function (a, b, c) { c._d = new Date(1e3 * parseFloat(a, 10)) }), aa("x", function (a, b, c) { c._d = new Date(t(a)) }), a.version = "2.18.2", function (a) { rd = a }(sb), a.fn = Ie, a.min = ub, a.max = vb, a.now = ve, a.utc = k, a.unix = Oc, a.months = Uc, a.isDate = g, a.locale = Za, a.invalid = o, a.duration = Rb, a.isMoment = r, a.weekdays = Wc, a.parseZone = Pc, a.localeData = ab, a.isDuration = Ab, a.monthsShort = Vc, a.weekdaysMin = Yc, a.defineLocale = $a, a.updateLocale = _a, a.locales = bb, a.weekdaysShort = Xc, a.normalizeUnits = J, a.relativeTimeRounding = nd, a.relativeTimeThreshold = od, a.calendarFormat = Xb, a.prototype = Ie, a
});
/**********************************************************
                moment js end
**********************************************************/

/**********************************************************
            momment time zone data file start
            referece file ==> moment-timezone-with-data-2012-2022.min.js
**********************************************************/
//<script src="/scripts/moment-timezone-with-data-2012-2022.min.js"></script>
//! moment-timezone.js
//! version : 0.5.13
//! Copyright (c) JS Foundation and other contributors
//! license : MIT
//! github.com/moment/moment-timezone
!function(a,b){"use strict";"function"==typeof define&&define.amd?define(["moment"],b):"object"==typeof module&&module.exports?module.exports=b(require("moment")):b(a.moment)}(this,function(a){"use strict";function b(a){return a>96?a-87:a>64?a-29:a-48}function c(a){var c,d=0,e=a.split("."),f=e[0],g=e[1]||"",h=1,i=0,j=1;for(45===a.charCodeAt(0)&&(d=1,j=-1),d;d<f.length;d++)c=b(f.charCodeAt(d)),i=60*i+c;for(d=0;d<g.length;d++)h/=60,c=b(g.charCodeAt(d)),i+=c*h;return i*j}function d(a){for(var b=0;b<a.length;b++)a[b]=c(a[b])}function e(a,b){for(var c=0;c<b;c++)a[c]=Math.round((a[c-1]||0)+6e4*a[c]);a[b-1]=1/0}function f(a,b){var c,d=[];for(c=0;c<b.length;c++)d[c]=a[b[c]];return d}function g(a){var b=a.split("|"),c=b[2].split(" "),g=b[3].split(""),h=b[4].split(" ");return d(c),d(g),d(h),e(h,g.length),{name:b[0],abbrs:f(b[1].split(" "),g),offsets:f(c,g),untils:h,population:0|b[5]}}function h(a){a&&this._set(g(a))}function i(a){var b=a.toTimeString(),c=b.match(/\([a-z ]+\)/i);c&&c[0]?(c=c[0].match(/[A-Z]/g),c=c?c.join(""):void 0):(c=b.match(/[A-Z]{3,5}/g),c=c?c[0]:void 0),"GMT"===c&&(c=void 0),this.at=+a,this.abbr=c,this.offset=a.getTimezoneOffset()}function j(a){this.zone=a,this.offsetScore=0,this.abbrScore=0}function k(a,b){for(var c,d;d=6e4*((b.at-a.at)/12e4|0);)c=new i(new Date(a.at+d)),c.offset===a.offset?a=c:b=c;return a}function l(){var a,b,c,d=(new Date).getFullYear()-2,e=new i(new Date(d,0,1)),f=[e];for(c=1;c<48;c++)b=new i(new Date(d,c,1)),b.offset!==e.offset&&(a=k(e,b),f.push(a),f.push(new i(new Date(a.at+6e4)))),e=b;for(c=0;c<4;c++)f.push(new i(new Date(d+c,0,1))),f.push(new i(new Date(d+c,6,1)));return f}function m(a,b){return a.offsetScore!==b.offsetScore?a.offsetScore-b.offsetScore:a.abbrScore!==b.abbrScore?a.abbrScore-b.abbrScore:b.zone.population-a.zone.population}function n(a,b){var c,e;for(d(b),c=0;c<b.length;c++)e=b[c],I[e]=I[e]||{},I[e][a]=!0}function o(a){var b,c,d,e=a.length,f={},g=[];for(b=0;b<e;b++){d=I[a[b].offset]||{};for(c in d)d.hasOwnProperty(c)&&(f[c]=!0)}for(b in f)f.hasOwnProperty(b)&&g.push(H[b]);return g}function p(){try{var a=Intl.DateTimeFormat().resolvedOptions().timeZone;if(a){var b=H[r(a)];if(b)return b;z("Moment Timezone found "+a+" from the Intl api, but did not have that data loaded.")}}catch(c){}var d,e,f,g=l(),h=g.length,i=o(g),k=[];for(e=0;e<i.length;e++){for(d=new j(t(i[e]),h),f=0;f<h;f++)d.scoreOffsetAt(g[f]);k.push(d)}return k.sort(m),k.length>0?k[0].zone.name:void 0}function q(a){return D&&!a||(D=p()),D}function r(a){return(a||"").toLowerCase().replace(/\//g,"_")}function s(a){var b,c,d,e;for("string"==typeof a&&(a=[a]),b=0;b<a.length;b++)d=a[b].split("|"),c=d[0],e=r(c),F[e]=a[b],H[e]=c,d[5]&&n(e,d[2].split(" "))}function t(a,b){a=r(a);var c,d=F[a];return d instanceof h?d:"string"==typeof d?(d=new h(d),F[a]=d,d):G[a]&&b!==t&&(c=t(G[a],t))?(d=F[a]=new h,d._set(c),d.name=H[a],d):null}function u(){var a,b=[];for(a in H)H.hasOwnProperty(a)&&(F[a]||F[G[a]])&&H[a]&&b.push(H[a]);return b.sort()}function v(a){var b,c,d,e;for("string"==typeof a&&(a=[a]),b=0;b<a.length;b++)c=a[b].split("|"),d=r(c[0]),e=r(c[1]),G[d]=e,H[d]=c[0],G[e]=d,H[e]=c[1]}function w(a){s(a.zones),v(a.links),A.dataVersion=a.version}function x(a){return x.didShowError||(x.didShowError=!0,z("moment.tz.zoneExists('"+a+"') has been deprecated in favor of !moment.tz.zone('"+a+"')")),!!t(a)}function y(a){return!(!a._a||void 0!==a._tzm)}function z(a){"undefined"!=typeof console&&"function"==typeof console.error&&console.error(a)}function A(b){var c=Array.prototype.slice.call(arguments,0,-1),d=arguments[arguments.length-1],e=t(d),f=a.utc.apply(null,c);return e&&!a.isMoment(b)&&y(f)&&f.add(e.parse(f),"minutes"),f.tz(d),f}function B(a){return function(){return this._z?this._z.abbr(this):a.call(this)}}function C(a){return function(){return this._z=null,a.apply(this,arguments)}}var D,E="0.5.13",F={},G={},H={},I={},J=a.version.split("."),K=+J[0],L=+J[1];(K<2||2===K&&L<6)&&z("Moment Timezone requires Moment.js >= 2.6.0. You are using Moment.js "+a.version+". See momentjs.com"),h.prototype={_set:function(a){this.name=a.name,this.abbrs=a.abbrs,this.untils=a.untils,this.offsets=a.offsets,this.population=a.population},_index:function(a){var b,c=+a,d=this.untils;for(b=0;b<d.length;b++)if(c<d[b])return b},parse:function(a){var b,c,d,e,f=+a,g=this.offsets,h=this.untils,i=h.length-1;for(e=0;e<i;e++)if(b=g[e],c=g[e+1],d=g[e?e-1:e],b<c&&A.moveAmbiguousForward?b=c:b>d&&A.moveInvalidForward&&(b=d),f<h[e]-6e4*b)return g[e];return g[i]},abbr:function(a){return this.abbrs[this._index(a)]},offset:function(a){return this.offsets[this._index(a)]}},j.prototype.scoreOffsetAt=function(a){this.offsetScore+=Math.abs(this.zone.offset(a.at)-a.offset),this.zone.abbr(a.at).replace(/[^A-Z]/g,"")!==a.abbr&&this.abbrScore++},A.version=E,A.dataVersion="",A._zones=F,A._links=G,A._names=H,A.add=s,A.link=v,A.load=w,A.zone=t,A.zoneExists=x,A.guess=q,A.names=u,A.Zone=h,A.unpack=g,A.unpackBase60=c,A.needsOffset=y,A.moveInvalidForward=!0,A.moveAmbiguousForward=!1;var M=a.fn;a.tz=A,a.defaultZone=null,a.updateOffset=function(b,c){var d,e=a.defaultZone;void 0===b._z&&(e&&y(b)&&!b._isUTC&&(b._d=a.utc(b._a)._d,b.utc().add(e.parse(b),"minutes")),b._z=e),b._z&&(d=b._z.offset(b),Math.abs(d)<16&&(d/=60),void 0!==b.utcOffset?b.utcOffset(-d,c):b.zone(d,c))},M.tz=function(b){return b?(this._z=t(b),this._z?a.updateOffset(this):z("Moment Timezone has no data for "+b+". See http://momentjs.com/timezone/docs/#/data-loading/."),this):this._z?this._z.name:void 0},M.zoneName=B(M.zoneName),M.zoneAbbr=B(M.zoneAbbr),M.utc=C(M.utc),a.tz.setDefault=function(b){return(K<2||2===K&&L<9)&&z("Moment Timezone setDefault() requires Moment.js >= 2.9.0. You are using Moment.js "+a.version+"."),a.defaultZone=b?t(b):null,a};var N=a.momentProperties;return"[object Array]"===Object.prototype.toString.call(N)?(N.push("_z"),N.push("_a")):N&&(N._z=null),w({version:"2017b",zones:["Africa/Abidjan|GMT|0|0||48e5","Africa/Khartoum|EAT|-30|0||51e5","Africa/Algiers|CET|-10|0||26e5","Africa/Lagos|WAT|-10|0||17e6","Africa/Maputo|CAT|-20|0||26e5","Africa/Cairo|EET EEST|-20 -30|01010|1M2m0 gL0 e10 mn0|15e6","Africa/Casablanca|WET WEST|0 -10|0101010101010101010101010101010101010101010|1H3C0 wM0 co0 go0 1o00 s00 dA0 vc0 11A0 A00 e00 y00 11A0 uM0 e00 Dc0 11A0 s00 e00 IM0 WM0 mo0 gM0 LA0 WM0 jA0 e00 Rc0 11A0 e00 e00 U00 11A0 8o0 e00 11A0 11A0 5A0 e00 17c0 1fA0 1a00|32e5","Europe/Paris|CET CEST|-10 -20|01010101010101010101010|1GNB0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0 WM0 1qM0 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0|11e6","Africa/Johannesburg|SAST|-20|0||84e5","Africa/Tripoli|EET CET CEST|-20 -10 -20|0120|1IlA0 TA0 1o00|11e5","Africa/Windhoek|WAST WAT|-20 -10|01010101010101010101010|1GQo0 11B0 1qL0 WN0 1qL0 11B0 1nX0 11B0 1nX0 11B0 1nX0 11B0 1nX0 11B0 1qL0 WN0 1qL0 11B0 1nX0 11B0 1nX0 11B0|32e4","America/Adak|HST HDT|a0 90|01010101010101010101010|1GIc0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0|326","America/Anchorage|AKST AKDT|90 80|01010101010101010101010|1GIb0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0|30e4","America/Santo_Domingo|AST|40|0||29e5","America/Araguaina|-03 -02|30 20|010|1IdD0 Lz0|14e4","America/Fortaleza|-03|30|0||34e5","America/Asuncion|-03 -04|30 40|01010101010101010101010|1GTf0 1cN0 17b0 1ip0 17b0 1ip0 17b0 1ip0 19X0 1fB0 19X0 1fB0 19X0 1ip0 17b0 1ip0 17b0 1ip0 19X0 1fB0 19X0 1fB0|28e5","America/Panama|EST|50|0||15e5","America/Bahia|-02 -03|20 30|01|1GCq0|27e5","America/Mexico_City|CST CDT|60 50|01010101010101010101010|1GQw0 1nX0 14p0 1lb0 14p0 1lb0 14p0 1lb0 14p0 1nX0 11B0 1nX0 11B0 1nX0 14p0 1lb0 14p0 1lb0 14p0 1nX0 11B0 1nX0|20e6","America/Managua|CST|60|0||22e5","America/La_Paz|-04|40|0||19e5","America/Lima|-05|50|0||11e6","America/Denver|MST MDT|70 60|01010101010101010101010|1GI90 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0|26e5","America/Campo_Grande|-03 -04|30 40|01010101010101010101010|1GCr0 1zd0 Lz0 1C10 Lz0 1C10 On0 1zd0 On0 1zd0 On0 1zd0 On0 1C10 Lz0 1C10 Lz0 1C10 On0 1zd0 On0 1zd0|77e4","America/Cancun|CST CDT EST|60 50 50|01010102|1GQw0 1nX0 14p0 1lb0 14p0 1lb0 Dd0|63e4","America/Caracas|-0430 -04|4u 40|01|1QMT0|29e5","America/Chicago|CST CDT|60 50|01010101010101010101010|1GI80 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0|92e5","America/Chihuahua|MST MDT|70 60|01010101010101010101010|1GQx0 1nX0 14p0 1lb0 14p0 1lb0 14p0 1lb0 14p0 1nX0 11B0 1nX0 11B0 1nX0 14p0 1lb0 14p0 1lb0 14p0 1nX0 11B0 1nX0|81e4","America/Phoenix|MST|70|0||42e5","America/Los_Angeles|PST PDT|80 70|01010101010101010101010|1GIa0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0|15e6","America/New_York|EST EDT|50 40|01010101010101010101010|1GI70 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0|21e6","America/Rio_Branco|-04 -05|40 50|01|1KLE0|31e4","America/Fort_Nelson|PST PDT MST|80 70 70|01010102|1GIa0 1zb0 Op0 1zb0 Op0 1zb0 Op0|39e2","America/Halifax|AST ADT|40 30|01010101010101010101010|1GI60 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0|39e4","America/Godthab|-03 -02|30 20|01010101010101010101010|1GNB0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0 WM0 1qM0 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0|17e3","America/Grand_Turk|EST EDT AST|50 40 40|010101012|1GI70 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0|37e2","America/Havana|CST CDT|50 40|01010101010101010101010|1GQt0 1qM0 Oo0 1zc0 Oo0 1zc0 Oo0 1zc0 Rc0 1zc0 Oo0 1zc0 Oo0 1zc0 Oo0 1zc0 Oo0 1zc0 Rc0 1zc0 Oo0 1zc0|21e5","America/Metlakatla|PST AKST AKDT|80 90 80|0121212121212121|1PAa0 Rd0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0|14e2","America/Miquelon|-03 -02|30 20|01010101010101010101010|1GI50 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0|61e2","America/Montevideo|-02 -03|20 30|01010101|1GI40 1o10 11z0 1o10 11z0 1o10 11z0|17e5","America/Noronha|-02|20|0||30e2","America/Port-au-Prince|EST EDT|50 40|010101010101010101010|1GI70 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 3iN0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0|23e5","Antarctica/Palmer|-03 -04|30 40|010101010|1H3D0 Op0 1zb0 Rd0 1wn0 Rd0 46n0 Ap0|40","America/Santiago|-03 -04|30 40|010101010101010101010|1H3D0 Op0 1zb0 Rd0 1wn0 Rd0 46n0 Ap0 1Nb0 Ap0 1Nb0 Ap0 1Nb0 Ap0 1Nb0 Ap0 1Nb0 Dd0 1Nb0 Ap0|62e5","America/Sao_Paulo|-02 -03|20 30|01010101010101010101010|1GCq0 1zd0 Lz0 1C10 Lz0 1C10 On0 1zd0 On0 1zd0 On0 1zd0 On0 1C10 Lz0 1C10 Lz0 1C10 On0 1zd0 On0 1zd0|20e6","Atlantic/Azores|-01 +00|10 0|01010101010101010101010|1GNB0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0 WM0 1qM0 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0|25e4","America/St_Johns|NST NDT|3u 2u|01010101010101010101010|1GI5u 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0|11e4","Antarctica/Casey|+11 +08|-b0 -80|010|1GAF0 blz0|10","Antarctica/Davis|+05 +07|-50 -70|01|1GAI0|70","Pacific/Port_Moresby|+10|-a0|0||25e4","Pacific/Guadalcanal|+11|-b0|0||11e4","Asia/Tashkent|+05|-50|0||23e5","Pacific/Auckland|NZDT NZST|-d0 -c0|01010101010101010101010|1GQe0 1cM0 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1cM0 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1a00|14e5","Asia/Baghdad|+03|-30|0||66e5","Antarctica/Troll|+00 +02|0 -20|01010101010101010101010|1GNB0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0 WM0 1qM0 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0|40","Asia/Dhaka|+06|-60|0||16e6","Asia/Amman|EET EEST|-20 -30|010101010101010101010|1GPy0 4bX0 Dd0 1qM0 WM0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0 11A0 1o00|25e5","Asia/Kamchatka|+12|-c0|0||18e4","Asia/Baku|+04 +05|-40 -50|010101010|1GNA0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00|27e5","Asia/Bangkok|+07|-70|0||15e6","Asia/Barnaul|+07 +06|-70 -60|010|1N7v0 3rd0","Asia/Beirut|EET EEST|-20 -30|01010101010101010101010|1GNy0 1qL0 11B0 1nX0 11B0 1nX0 11B0 1nX0 11B0 1qL0 WN0 1qL0 WN0 1qL0 11B0 1nX0 11B0 1nX0 11B0 1qL0 WN0 1qL0|22e5","Asia/Manila|+08|-80|0||24e6","Asia/Kolkata|IST|-5u|0||15e6","Asia/Chita|+10 +08 +09|-a0 -80 -90|012|1N7s0 3re0|33e4","Asia/Ulaanbaatar|+08 +09|-80 -90|01010|1O8G0 1cJ0 1cP0 1cJ0|12e5","Asia/Shanghai|CST|-80|0||23e6","Asia/Colombo|+0530|-5u|0||22e5","Asia/Damascus|EET EEST|-20 -30|01010101010101010101010|1GPy0 1nX0 11B0 1nX0 11B0 1qL0 WN0 1qL0 WN0 1qL0 11B0 1nX0 11B0 1nX0 11B0 1nX0 11B0 1qL0 WN0 1qL0 WN0 1qL0|26e5","Asia/Dili|+09|-90|0||19e4","Asia/Dubai|+04|-40|0||39e5","Asia/Famagusta|EET EEST +03|-20 -30 -30|01010101012|1GNB0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 15U0","Asia/Gaza|EET EEST|-20 -30|01010101010101010101010|1GPy0 1a00 1fA0 1cL0 1cN0 1nX0 1210 1nz0 1220 1qL0 WN0 1qL0 11B0 1nX0 11B0 1nX0 11B0 1qL0 WN0 1qL0 WN0 1qL0|18e5","Asia/Hong_Kong|HKT|-80|0||73e5","Asia/Hovd|+07 +08|-70 -80|01010|1O8H0 1cJ0 1cP0 1cJ0|81e3","Asia/Irkutsk|+09 +08|-90 -80|01|1N7t0|60e4","Europe/Istanbul|EET EEST +03|-20 -30 -30|01010101012|1GNB0 1qM0 11A0 1o00 1200 1nA0 11A0 1tA0 U00 15w0|13e6","Asia/Jakarta|WIB|-70|0||31e6","Asia/Jayapura|WIT|-90|0||26e4","Asia/Jerusalem|IST IDT|-20 -30|01010101010101010101010|1GPA0 1aL0 1eN0 1oL0 10N0 1oL0 10N0 1oL0 10N0 1rz0 W10 1rz0 W10 1rz0 10N0 1oL0 10N0 1oL0 10N0 1rz0 W10 1rz0|81e4","Asia/Kabul|+0430|-4u|0||46e5","Asia/Karachi|PKT|-50|0||24e6","Asia/Kathmandu|+0545|-5J|0||12e5","Asia/Yakutsk|+10 +09|-a0 -90|01|1N7s0|28e4","Asia/Krasnoyarsk|+08 +07|-80 -70|01|1N7u0|10e5","Asia/Magadan|+12 +10 +11|-c0 -a0 -b0|012|1N7q0 3Cq0|95e3","Asia/Makassar|WITA|-80|0||15e5","Europe/Athens|EET EEST|-20 -30|01010101010101010101010|1GNB0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0 WM0 1qM0 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0|35e5","Asia/Novosibirsk|+07 +06|-70 -60|010|1N7v0 4eN0|15e5","Asia/Omsk|+07 +06|-70 -60|01|1N7v0|12e5","Asia/Pyongyang|KST KST|-90 -8u|01|1P4D0|29e5","Asia/Rangoon|+0630|-6u|0||48e5","Asia/Sakhalin|+11 +10|-b0 -a0|010|1N7r0 3rd0|58e4","Asia/Seoul|KST|-90|0||23e6","Asia/Srednekolymsk|+12 +11|-c0 -b0|01|1N7q0|35e2","Asia/Tehran|+0330 +0430|-3u -4u|01010101010101010101010|1GLUu 1dz0 1cN0 1dz0 1cp0 1dz0 1cp0 1dz0 1cp0 1dz0 1cN0 1dz0 1cp0 1dz0 1cp0 1dz0 1cp0 1dz0 1cN0 1dz0 1cp0 1dz0|14e6","Asia/Tokyo|JST|-90|0||38e6","Asia/Tomsk|+07 +06|-70 -60|010|1N7v0 3Qp0|10e5","Asia/Vladivostok|+11 +10|-b0 -a0|01|1N7r0|60e4","Asia/Yekaterinburg|+06 +05|-60 -50|01|1N7w0|14e5","Europe/Lisbon|WET WEST|0 -10|01010101010101010101010|1GNB0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0 WM0 1qM0 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0|27e5","Atlantic/Cape_Verde|-01|10|0||50e4","Australia/Sydney|AEDT AEST|-b0 -a0|01010101010101010101010|1GQg0 1fA0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1fA0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0|40e5","Australia/Adelaide|ACDT ACST|-au -9u|01010101010101010101010|1GQgu 1fA0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1fA0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0 1cM0|11e5","Australia/Brisbane|AEST|-a0|0||20e5","Australia/Darwin|ACST|-9u|0||12e4","Australia/Eucla|+0845|-8J|0||368","Australia/Lord_Howe|+11 +1030|-b0 -au|01010101010101010101010|1GQf0 1fAu 1cLu 1cMu 1cLu 1cMu 1cLu 1cMu 1cLu 1cMu 1cLu 1cMu 1cLu 1fAu 1cLu 1cMu 1cLu 1cMu 1cLu 1cMu 1cLu 1cMu|347","Australia/Perth|AWST|-80|0||18e5","Pacific/Easter|-05 -06|50 60|010101010101010101010|1H3D0 Op0 1zb0 Rd0 1wn0 Rd0 46n0 Ap0 1Nb0 Ap0 1Nb0 Ap0 1Nb0 Ap0 1Nb0 Ap0 1Nb0 Dd0 1Nb0 Ap0|30e2","Europe/Dublin|GMT IST|0 -10|01010101010101010101010|1GNB0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0 WM0 1qM0 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0|12e5","Pacific/Tahiti|-10|a0|0||18e4","Pacific/Niue|-11|b0|0||12e2","Etc/GMT+12|-12|c0|0|","Pacific/Galapagos|-06|60|0||25e3","Etc/GMT+7|-07|70|0|","Pacific/Pitcairn|-08|80|0||56","Pacific/Gambier|-09|90|0||125","Etc/GMT-1|+01|-10|0|","Pacific/Fakaofo|+13|-d0|0||483","Pacific/Kiritimati|+14|-e0|0||51e2","Etc/GMT-2|+02|-20|0|","Etc/UCT|UCT|0|0|","Etc/UTC|UTC|0|0|","Europe/Astrakhan|+04 +03|-40 -30|010|1N7y0 3rd0","Europe/London|GMT BST|0 -10|01010101010101010101010|1GNB0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0 WM0 1qM0 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0|10e6","Europe/Chisinau|EET EEST|-20 -30|01010101010101010101010|1GNA0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0 WM0 1qM0 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0|67e4","Europe/Kaliningrad|+03 EET|-30 -20|01|1N7z0|44e4","Europe/Volgograd|+04 +03|-40 -30|01|1N7y0|10e5","Europe/Moscow|MSK MSK|-40 -30|01|1N7y0|16e6","Europe/Saratov|+04 +03|-40 -30|010|1N7y0 5810","Europe/Simferopol|EET EEST MSK MSK|-20 -30 -40 -30|0101023|1GNB0 1qM0 11A0 1o00 11z0 1nW0|33e4","Pacific/Honolulu|HST|a0|0||37e4","MET|MET MEST|-10 -20|01010101010101010101010|1GNB0 1qM0 11A0 1o00 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0 WM0 1qM0 11A0 1o00 11A0 1o00 11A0 1qM0 WM0 1qM0","Pacific/Chatham|+1345 +1245|-dJ -cJ|01010101010101010101010|1GQe0 1cM0 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1cM0 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1a00|600","Pacific/Apia|+14 +13|-e0 -d0|01010101010101010101010|1GQe0 1cM0 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1cM0 1fA0 1a00 1fA0 1a00 1fA0 1a00 1fA0 1a00|37e3","Pacific/Bougainville|+10 +11|-a0 -b0|01|1NwE0|18e4","Pacific/Fiji|+13 +12|-d0 -c0|01010101010101010101010|1Goe0 1Nc0 Ao0 1Q00 xz0 1SN0 uM0 1SM0 uM0 1VA0 s00 1VA0 uM0 1SM0 uM0 1SM0 uM0 1SM0 uM0 1VA0 s00 1VA0|88e4","Pacific/Guam|ChST|-a0|0||17e4","Pacific/Marquesas|-0930|9u|0||86e2","Pacific/Pago_Pago|SST|b0|0||37e2","Pacific/Norfolk|+1130 +11|-bu -b0|01|1PoCu|25e4","Pacific/Tongatapu|+13 +14|-d0 -e0|01010101010101|1S4d0 s00 1VA0 uM0 1SM0 uM0 1SM0 uM0 1SM0 uM0 1VA0 s00 1VA0|75e3"],links:["Africa/Abidjan|Africa/Accra","Africa/Abidjan|Africa/Bamako","Africa/Abidjan|Africa/Banjul","Africa/Abidjan|Africa/Bissau","Africa/Abidjan|Africa/Conakry","Africa/Abidjan|Africa/Dakar","Africa/Abidjan|Africa/Freetown","Africa/Abidjan|Africa/Lome","Africa/Abidjan|Africa/Monrovia","Africa/Abidjan|Africa/Nouakchott","Africa/Abidjan|Africa/Ouagadougou","Africa/Abidjan|Africa/Sao_Tome","Africa/Abidjan|Africa/Timbuktu","Africa/Abidjan|America/Danmarkshavn","Africa/Abidjan|Atlantic/Reykjavik","Africa/Abidjan|Atlantic/St_Helena","Africa/Abidjan|Etc/GMT","Africa/Abidjan|Etc/GMT+0","Africa/Abidjan|Etc/GMT-0","Africa/Abidjan|Etc/GMT0","Africa/Abidjan|Etc/Greenwich","Africa/Abidjan|GMT","Africa/Abidjan|GMT+0","Africa/Abidjan|GMT-0","Africa/Abidjan|GMT0","Africa/Abidjan|Greenwich","Africa/Abidjan|Iceland","Africa/Algiers|Africa/Tunis","Africa/Cairo|Egypt","Africa/Casablanca|Africa/El_Aaiun","Africa/Johannesburg|Africa/Maseru","Africa/Johannesburg|Africa/Mbabane","Africa/Khartoum|Africa/Addis_Ababa","Africa/Khartoum|Africa/Asmara","Africa/Khartoum|Africa/Asmera","Africa/Khartoum|Africa/Dar_es_Salaam","Africa/Khartoum|Africa/Djibouti","Africa/Khartoum|Africa/Juba","Africa/Khartoum|Africa/Kampala","Africa/Khartoum|Africa/Mogadishu","Africa/Khartoum|Africa/Nairobi","Africa/Khartoum|Indian/Antananarivo","Africa/Khartoum|Indian/Comoro","Africa/Khartoum|Indian/Mayotte","Africa/Lagos|Africa/Bangui","Africa/Lagos|Africa/Brazzaville","Africa/Lagos|Africa/Douala","Africa/Lagos|Africa/Kinshasa","Africa/Lagos|Africa/Libreville","Africa/Lagos|Africa/Luanda","Africa/Lagos|Africa/Malabo","Africa/Lagos|Africa/Ndjamena","Africa/Lagos|Africa/Niamey","Africa/Lagos|Africa/Porto-Novo","Africa/Maputo|Africa/Blantyre","Africa/Maputo|Africa/Bujumbura","Africa/Maputo|Africa/Gaborone","Africa/Maputo|Africa/Harare","Africa/Maputo|Africa/Kigali","Africa/Maputo|Africa/Lubumbashi","Africa/Maputo|Africa/Lusaka","Africa/Tripoli|Libya","America/Adak|America/Atka","America/Adak|US/Aleutian","America/Anchorage|America/Juneau","America/Anchorage|America/Nome","America/Anchorage|America/Sitka","America/Anchorage|America/Yakutat","America/Anchorage|US/Alaska","America/Campo_Grande|America/Cuiaba","America/Chicago|America/Indiana/Knox","America/Chicago|America/Indiana/Tell_City","America/Chicago|America/Knox_IN","America/Chicago|America/Matamoros","America/Chicago|America/Menominee","America/Chicago|America/North_Dakota/Beulah","America/Chicago|America/North_Dakota/Center","America/Chicago|America/North_Dakota/New_Salem","America/Chicago|America/Rainy_River","America/Chicago|America/Rankin_Inlet","America/Chicago|America/Resolute","America/Chicago|America/Winnipeg","America/Chicago|CST6CDT","America/Chicago|Canada/Central","America/Chicago|US/Central","America/Chicago|US/Indiana-Starke","America/Chihuahua|America/Mazatlan","America/Chihuahua|Mexico/BajaSur","America/Denver|America/Boise","America/Denver|America/Cambridge_Bay","America/Denver|America/Edmonton","America/Denver|America/Inuvik","America/Denver|America/Ojinaga","America/Denver|America/Shiprock","America/Denver|America/Yellowknife","America/Denver|Canada/Mountain","America/Denver|MST7MDT","America/Denver|Navajo","America/Denver|US/Mountain","America/Fortaleza|America/Argentina/Buenos_Aires","America/Fortaleza|America/Argentina/Catamarca","America/Fortaleza|America/Argentina/ComodRivadavia","America/Fortaleza|America/Argentina/Cordoba","America/Fortaleza|America/Argentina/Jujuy","America/Fortaleza|America/Argentina/La_Rioja","America/Fortaleza|America/Argentina/Mendoza","America/Fortaleza|America/Argentina/Rio_Gallegos","America/Fortaleza|America/Argentina/Salta","America/Fortaleza|America/Argentina/San_Juan","America/Fortaleza|America/Argentina/San_Luis","America/Fortaleza|America/Argentina/Tucuman","America/Fortaleza|America/Argentina/Ushuaia","America/Fortaleza|America/Belem","America/Fortaleza|America/Buenos_Aires","America/Fortaleza|America/Catamarca","America/Fortaleza|America/Cayenne","America/Fortaleza|America/Cordoba","America/Fortaleza|America/Jujuy","America/Fortaleza|America/Maceio","America/Fortaleza|America/Mendoza","America/Fortaleza|America/Paramaribo","America/Fortaleza|America/Recife","America/Fortaleza|America/Rosario","America/Fortaleza|America/Santarem","America/Fortaleza|Antarctica/Rothera","America/Fortaleza|Atlantic/Stanley","America/Fortaleza|Etc/GMT+3","America/Halifax|America/Glace_Bay","America/Halifax|America/Goose_Bay","America/Halifax|America/Moncton","America/Halifax|America/Thule","America/Halifax|Atlantic/Bermuda","America/Halifax|Canada/Atlantic","America/Havana|Cuba","America/La_Paz|America/Boa_Vista","America/La_Paz|America/Guyana","America/La_Paz|America/Manaus","America/La_Paz|America/Porto_Velho","America/La_Paz|Brazil/West","America/La_Paz|Etc/GMT+4","America/Lima|America/Bogota","America/Lima|America/Guayaquil","America/Lima|Etc/GMT+5","America/Los_Angeles|America/Dawson","America/Los_Angeles|America/Ensenada","America/Los_Angeles|America/Santa_Isabel","America/Los_Angeles|America/Tijuana","America/Los_Angeles|America/Vancouver","America/Los_Angeles|America/Whitehorse","America/Los_Angeles|Canada/Pacific","America/Los_Angeles|Canada/Yukon","America/Los_Angeles|Mexico/BajaNorte","America/Los_Angeles|PST8PDT","America/Los_Angeles|US/Pacific","America/Los_Angeles|US/Pacific-New","America/Managua|America/Belize","America/Managua|America/Costa_Rica","America/Managua|America/El_Salvador","America/Managua|America/Guatemala","America/Managua|America/Regina","America/Managua|America/Swift_Current","America/Managua|America/Tegucigalpa","America/Managua|Canada/East-Saskatchewan","America/Managua|Canada/Saskatchewan","America/Mexico_City|America/Bahia_Banderas","America/Mexico_City|America/Merida","America/Mexico_City|America/Monterrey","America/Mexico_City|Mexico/General","America/New_York|America/Detroit","America/New_York|America/Fort_Wayne","America/New_York|America/Indiana/Indianapolis","America/New_York|America/Indiana/Marengo","America/New_York|America/Indiana/Petersburg","America/New_York|America/Indiana/Vevay","America/New_York|America/Indiana/Vincennes","America/New_York|America/Indiana/Winamac","America/New_York|America/Indianapolis","America/New_York|America/Iqaluit","America/New_York|America/Kentucky/Louisville","America/New_York|America/Kentucky/Monticello","America/New_York|America/Louisville","America/New_York|America/Montreal","America/New_York|America/Nassau","America/New_York|America/Nipigon","America/New_York|America/Pangnirtung","America/New_York|America/Thunder_Bay","America/New_York|America/Toronto","America/New_York|Canada/Eastern","America/New_York|EST5EDT","America/New_York|US/East-Indiana","America/New_York|US/Eastern","America/New_York|US/Michigan","America/Noronha|Atlantic/South_Georgia","America/Noronha|Brazil/DeNoronha","America/Noronha|Etc/GMT+2","America/Panama|America/Atikokan","America/Panama|America/Cayman","America/Panama|America/Coral_Harbour","America/Panama|America/Jamaica","America/Panama|EST","America/Panama|Jamaica","America/Phoenix|America/Creston","America/Phoenix|America/Dawson_Creek","America/Phoenix|America/Hermosillo","America/Phoenix|MST","America/Phoenix|US/Arizona","America/Rio_Branco|America/Eirunepe","America/Rio_Branco|America/Porto_Acre","America/Rio_Branco|Brazil/Acre","America/Santiago|Chile/Continental","America/Santo_Domingo|America/Anguilla","America/Santo_Domingo|America/Antigua","America/Santo_Domingo|America/Aruba","America/Santo_Domingo|America/Barbados","America/Santo_Domingo|America/Blanc-Sablon","America/Santo_Domingo|America/Curacao","America/Santo_Domingo|America/Dominica","America/Santo_Domingo|America/Grenada","America/Santo_Domingo|America/Guadeloupe","America/Santo_Domingo|America/Kralendijk","America/Santo_Domingo|America/Lower_Princes","America/Santo_Domingo|America/Marigot","America/Santo_Domingo|America/Martinique","America/Santo_Domingo|America/Montserrat","America/Santo_Domingo|America/Port_of_Spain","America/Santo_Domingo|America/Puerto_Rico","America/Santo_Domingo|America/St_Barthelemy","America/Santo_Domingo|America/St_Kitts","America/Santo_Domingo|America/St_Lucia","America/Santo_Domingo|America/St_Thomas","America/Santo_Domingo|America/St_Vincent","America/Santo_Domingo|America/Tortola","America/Santo_Domingo|America/Virgin","America/Sao_Paulo|Brazil/East","America/St_Johns|Canada/Newfoundland","Antarctica/Palmer|America/Punta_Arenas","Asia/Baghdad|Antarctica/Syowa","Asia/Baghdad|Asia/Aden","Asia/Baghdad|Asia/Bahrain","Asia/Baghdad|Asia/Kuwait","Asia/Baghdad|Asia/Qatar","Asia/Baghdad|Asia/Riyadh","Asia/Baghdad|Etc/GMT-3","Asia/Baghdad|Europe/Minsk","Asia/Bangkok|Asia/Ho_Chi_Minh","Asia/Bangkok|Asia/Novokuznetsk","Asia/Bangkok|Asia/Phnom_Penh","Asia/Bangkok|Asia/Saigon","Asia/Bangkok|Asia/Vientiane","Asia/Bangkok|Etc/GMT-7","Asia/Bangkok|Indian/Christmas","Asia/Dhaka|Antarctica/Vostok","Asia/Dhaka|Asia/Almaty","Asia/Dhaka|Asia/Bishkek","Asia/Dhaka|Asia/Dacca","Asia/Dhaka|Asia/Kashgar","Asia/Dhaka|Asia/Qyzylorda","Asia/Dhaka|Asia/Thimbu","Asia/Dhaka|Asia/Thimphu","Asia/Dhaka|Asia/Urumqi","Asia/Dhaka|Etc/GMT-6","Asia/Dhaka|Indian/Chagos","Asia/Dili|Etc/GMT-9","Asia/Dili|Pacific/Palau","Asia/Dubai|Asia/Muscat","Asia/Dubai|Asia/Tbilisi","Asia/Dubai|Asia/Yerevan","Asia/Dubai|Etc/GMT-4","Asia/Dubai|Europe/Samara","Asia/Dubai|Indian/Mahe","Asia/Dubai|Indian/Mauritius","Asia/Dubai|Indian/Reunion","Asia/Gaza|Asia/Hebron","Asia/Hong_Kong|Hongkong","Asia/Jakarta|Asia/Pontianak","Asia/Jerusalem|Asia/Tel_Aviv","Asia/Jerusalem|Israel","Asia/Kamchatka|Asia/Anadyr","Asia/Kamchatka|Etc/GMT-12","Asia/Kamchatka|Kwajalein","Asia/Kamchatka|Pacific/Funafuti","Asia/Kamchatka|Pacific/Kwajalein","Asia/Kamchatka|Pacific/Majuro","Asia/Kamchatka|Pacific/Nauru","Asia/Kamchatka|Pacific/Tarawa","Asia/Kamchatka|Pacific/Wake","Asia/Kamchatka|Pacific/Wallis","Asia/Kathmandu|Asia/Katmandu","Asia/Kolkata|Asia/Calcutta","Asia/Makassar|Asia/Ujung_Pandang","Asia/Manila|Asia/Brunei","Asia/Manila|Asia/Kuala_Lumpur","Asia/Manila|Asia/Kuching","Asia/Manila|Asia/Singapore","Asia/Manila|Etc/GMT-8","Asia/Manila|Singapore","Asia/Rangoon|Asia/Yangon","Asia/Rangoon|Indian/Cocos","Asia/Seoul|ROK","Asia/Shanghai|Asia/Chongqing","Asia/Shanghai|Asia/Chungking","Asia/Shanghai|Asia/Harbin","Asia/Shanghai|Asia/Macao","Asia/Shanghai|Asia/Macau","Asia/Shanghai|Asia/Taipei","Asia/Shanghai|PRC","Asia/Shanghai|ROC","Asia/Tashkent|Antarctica/Mawson","Asia/Tashkent|Asia/Aqtau","Asia/Tashkent|Asia/Aqtobe","Asia/Tashkent|Asia/Ashgabat","Asia/Tashkent|Asia/Ashkhabad","Asia/Tashkent|Asia/Atyrau","Asia/Tashkent|Asia/Dushanbe","Asia/Tashkent|Asia/Oral","Asia/Tashkent|Asia/Samarkand","Asia/Tashkent|Etc/GMT-5","Asia/Tashkent|Indian/Kerguelen","Asia/Tashkent|Indian/Maldives","Asia/Tehran|Iran","Asia/Tokyo|Japan","Asia/Ulaanbaatar|Asia/Choibalsan","Asia/Ulaanbaatar|Asia/Ulan_Bator","Asia/Vladivostok|Asia/Ust-Nera","Asia/Yakutsk|Asia/Khandyga","Atlantic/Azores|America/Scoresbysund","Atlantic/Cape_Verde|Etc/GMT+1","Australia/Adelaide|Australia/Broken_Hill","Australia/Adelaide|Australia/South","Australia/Adelaide|Australia/Yancowinna","Australia/Brisbane|Australia/Lindeman","Australia/Brisbane|Australia/Queensland","Australia/Darwin|Australia/North","Australia/Lord_Howe|Australia/LHI","Australia/Perth|Australia/West","Australia/Sydney|Australia/ACT","Australia/Sydney|Australia/Canberra","Australia/Sydney|Australia/Currie","Australia/Sydney|Australia/Hobart","Australia/Sydney|Australia/Melbourne","Australia/Sydney|Australia/NSW","Australia/Sydney|Australia/Tasmania","Australia/Sydney|Australia/Victoria","Etc/UCT|UCT","Etc/UTC|Etc/Universal","Etc/UTC|Etc/Zulu","Etc/UTC|UTC","Etc/UTC|Universal","Etc/UTC|Zulu","Europe/Astrakhan|Europe/Ulyanovsk","Europe/Athens|Asia/Nicosia","Europe/Athens|EET","Europe/Athens|Europe/Bucharest","Europe/Athens|Europe/Helsinki","Europe/Athens|Europe/Kiev","Europe/Athens|Europe/Mariehamn","Europe/Athens|Europe/Nicosia","Europe/Athens|Europe/Riga","Europe/Athens|Europe/Sofia","Europe/Athens|Europe/Tallinn","Europe/Athens|Europe/Uzhgorod","Europe/Athens|Europe/Vilnius","Europe/Athens|Europe/Zaporozhye","Europe/Chisinau|Europe/Tiraspol","Europe/Dublin|Eire","Europe/Istanbul|Asia/Istanbul","Europe/Istanbul|Turkey","Europe/Lisbon|Atlantic/Canary","Europe/Lisbon|Atlantic/Faeroe","Europe/Lisbon|Atlantic/Faroe","Europe/Lisbon|Atlantic/Madeira","Europe/Lisbon|Portugal","Europe/Lisbon|WET","Europe/London|Europe/Belfast","Europe/London|Europe/Guernsey","Europe/London|Europe/Isle_of_Man","Europe/London|Europe/Jersey","Europe/London|GB","Europe/London|GB-Eire","Europe/Moscow|W-SU","Europe/Paris|Africa/Ceuta","Europe/Paris|Arctic/Longyearbyen","Europe/Paris|Atlantic/Jan_Mayen","Europe/Paris|CET","Europe/Paris|Europe/Amsterdam","Europe/Paris|Europe/Andorra","Europe/Paris|Europe/Belgrade","Europe/Paris|Europe/Berlin","Europe/Paris|Europe/Bratislava","Europe/Paris|Europe/Brussels","Europe/Paris|Europe/Budapest","Europe/Paris|Europe/Busingen","Europe/Paris|Europe/Copenhagen","Europe/Paris|Europe/Gibraltar","Europe/Paris|Europe/Ljubljana","Europe/Paris|Europe/Luxembourg","Europe/Paris|Europe/Madrid","Europe/Paris|Europe/Malta","Europe/Paris|Europe/Monaco","Europe/Paris|Europe/Oslo","Europe/Paris|Europe/Podgorica","Europe/Paris|Europe/Prague","Europe/Paris|Europe/Rome","Europe/Paris|Europe/San_Marino","Europe/Paris|Europe/Sarajevo","Europe/Paris|Europe/Skopje","Europe/Paris|Europe/Stockholm","Europe/Paris|Europe/Tirane","Europe/Paris|Europe/Vaduz","Europe/Paris|Europe/Vatican","Europe/Paris|Europe/Vienna","Europe/Paris|Europe/Warsaw","Europe/Paris|Europe/Zagreb","Europe/Paris|Europe/Zurich","Europe/Paris|Poland","Europe/Volgograd|Europe/Kirov","Pacific/Auckland|Antarctica/McMurdo","Pacific/Auckland|Antarctica/South_Pole","Pacific/Auckland|NZ","Pacific/Chatham|NZ-CHAT","Pacific/Easter|Chile/EasterIsland","Pacific/Fakaofo|Etc/GMT-13","Pacific/Fakaofo|Pacific/Enderbury","Pacific/Galapagos|Etc/GMT+6","Pacific/Gambier|Etc/GMT+9","Pacific/Guadalcanal|Antarctica/Macquarie","Pacific/Guadalcanal|Etc/GMT-11","Pacific/Guadalcanal|Pacific/Efate","Pacific/Guadalcanal|Pacific/Kosrae","Pacific/Guadalcanal|Pacific/Noumea","Pacific/Guadalcanal|Pacific/Pohnpei","Pacific/Guadalcanal|Pacific/Ponape","Pacific/Guam|Pacific/Saipan","Pacific/Honolulu|HST","Pacific/Honolulu|Pacific/Johnston","Pacific/Honolulu|US/Hawaii","Pacific/Kiritimati|Etc/GMT-14","Pacific/Niue|Etc/GMT+11","Pacific/Pago_Pago|Pacific/Midway","Pacific/Pago_Pago|Pacific/Samoa","Pacific/Pago_Pago|US/Samoa","Pacific/Pitcairn|Etc/GMT+8","Pacific/Port_Moresby|Antarctica/DumontDUrville","Pacific/Port_Moresby|Etc/GMT-10","Pacific/Port_Moresby|Pacific/Chuuk","Pacific/Port_Moresby|Pacific/Truk","Pacific/Port_Moresby|Pacific/Yap","Pacific/Tahiti|Etc/GMT+10","Pacific/Tahiti|Pacific/Rarotonga"]
}),a});
/**********************************************************
        momment time zone data file end
**********************************************************/