﻿app.service('basicsrchSrvc', ['$http', function ($http) {
    this.getPrefRadius = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/radius/";
        GetServiceByURL($http, url, funCallBack);
    };

    this.getMemberData = function (memId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/search/bsdata/" + memId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.getSearchResponse = function (searchObj, pgNo, pgSize, sortBy, sortOrder, funCallBack) {
        if (sortBy == 2) {
            if (sortOrder == 1)
                sortOrder = 0;
            else if (sortOrder == 0)
                sortOrder = 1;
        }
        var liveURL = "https://pcapi.pyar.com/api/search/bscsrch/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sortOrder;
        PostServiceByURL($http, liveURL, searchObj, funCallBack);
    };

    this.getMemberBasicSearchSuggestionInfo = function (memberId, funCallBack) {
        var liveUrl = "https://pcapi.pyar.com/api/search/srchsgprefinfo/" + memberId;
        GetServiceByURL($http, liveUrl, funCallBack);
    };

    //service for get all the  save the search data
    this.getMemSuggestionSrch = function (searchObj, pgNo, pgSize, sortBy, sortOrder, funCallBack) {
        if (sortBy == 2) {
            if (sortOrder == 1)
                sortOrder = 0;
            else if (sortOrder == 0)
                sortOrder = 1;
        }
        var liveURL = "https://pcapi.pyar.com/api/search/srchsgsg/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sortOrder;
        PostServiceByURL($http, liveURL, searchObj, funCallBack);
    };
}]);