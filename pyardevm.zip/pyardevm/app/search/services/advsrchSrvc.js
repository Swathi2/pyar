﻿app.service('advsrchSrvc', ['$http', function ($http) {
    this.prefRadius = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/radius";
        GetServiceByURL($http, url, funCallBack);
    };

    this.getMemberData = function (memId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/search/bsdata/" + memId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.getSearchResponse = function (searchObj, pgNo, pgSize, sortBy, sortOrder, funCallBack) {
        if (sortBy == 2) {
            if (sortOrder == 1)
                sortOrder = 0;
            else if (sortOrder == 0)
                sortOrder = 1;
        }
        var url = "https://pcapi.pyar.com/api/search/advsrch/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sortOrder;
        PostServiceByURL($http, url, searchObj, funCallBack);
    };

    //Getting Personality Traits
    this.getPT = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/Personalitytraits";
        GetServiceByURL($http, url, funCallBack);
    };

    this.profileInfo = function (memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/privacysettings/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.saveSearch = function (searchObj, title, funCallBack) {
        var url = "https://pcapi.pyar.com/api/search/saveSrch/" + title;
        PostServiceByURL($http, url, searchObj, funCallBack);
    };

    this.getSrchSugnInfo = function (memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/search/srchsgprefinfo/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.getSaveSearchData = function (memId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/search/getsavesrch/" + memId;
        GetServiceByURL($http, url, funCallBack);
    };

    //get all the dropdown data to bind default search
    this.getAllDdlData = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/getalldrpdwndata";
        GetServiceByURL($http, url, funCallBack);
    };

    //service for mark saved search as default saved search
    this.setRemoveDafaultSearch = function (mssid, memberId, status, funCallBack) {
        var url = "https://pcapi.pyar.com/api/search/dfltsrch/" + mssid + "/" + memberId + "/" + status;
        PostServiceByURL($http, url, status, funCallBack);
    };

    //service for delete the saved search
    this.deleteSaveSearch = function (mssid, memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/search/dltdfltsrch/" + mssid + "/" + memberId;
        PostServiceByURL($http, url, '', funCallBack);
    };
  
    // for binnding the data based on saved search 
    this.getSavedSearchById = function (mssid, memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/search/savesrchbyid/" + mssid + "/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    //service for get all the  save the search data
    this.getMemSuggestionSrch = function (srchObj, pgNo, pgSize, sortBy, sortOrder, funCallBack) {
        if (sortBy == 2) {
            if (sortOrder == 1)
                sortOrder = 0;
            else if (sortOrder == 0)
                sortOrder = 1;
        }
        var url = "https://pcapi.pyar.com/api/search/srchsgsg/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sortOrder;
        PostServiceByURL($http, url, srchObj, funCallBack);
    };
}]);