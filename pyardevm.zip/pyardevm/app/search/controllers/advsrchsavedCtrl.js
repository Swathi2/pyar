﻿angular.module("app").controller('advsrchsavedCtrl', ['advsrchSrvc', 'getSessionSrvc', '$rootScope', '$window', '$state', function (advsrchSrvc, getSessionSrvc, $rootScope, $window, $state) {
    vm = this;
    if ($window.localStorage.getItem("srchObj") == null) { $state.go("advancedsearch"); return; };
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.savedSrch = [];
    vm.emtyState = false;
    vm.edit = false;
    vm.dltdft = true;
    vm.markRemovetxt = "Marks";
    vm.isckd = false;
    vm.mssId = "";
    vm.showSavePop = false;

    if ($window.localStorage.getItem("saveSrchObj") != null) {
        vm.showSavePop = true;
        vm.edit = true;
    }

    //function used bind the search saved names.
    vm.getSaveSrch = function () {
        showLoader();
        advsrchSrvc.getSaveSearchData(vm.mId(), function (response, status) {
            if (status == 200) {
                if (response.length > 0) {
                    vm.savedSrch = response.reverse();
                    $.each(vm.savedSrch, function (i, e) {
                        if (e.isDefault) {
                            vm.mssId = e.mssId;
                            vm.markRemovetxt = "Remove";
                            vm.dftStatus = false;
                            vm.isckd = true;
                            return false;
                        }
                    });
                }
                else {
                    vm.emtyState = true;
                    vm.edit = null;
                }
            }
            hideLoader();
        });
    };
    vm.getSaveSrch();

    //close save search
    vm.ssClose = function () {
        $state.go("advancedsearch");
    };

    //change eidt mode
    vm.ssEdit = function () {
        vm.edit = true;
        vm.dltdft = true;
    };

    //cancel edit mode
    vm.ssCancel = function () {
        vm.edit = false;
    };

    //select save search
    vm.selectSaveSrch = function (mssId) {
        vm.mssId = mssId;
    };

    //search on selected save search
    vm.searchClk = function () {
        if (vm.mssId != "") {
            $rootScope.mssId = vm.mssId;
            $rootScope.showSrchBtn = false;
            $state.go("advancedsearch");
        }
    };

    //function used to check uncheck  saved names to add and remove default values.
    vm.setDeafultValue = function (mssId, index, event) {
        event.preventDefault();
        if (document.getElementById("r1" + index).checked == true) {
            document.getElementById("r1" + index).checked = false;
            vm.mssId = "";
            vm.dltdft = true;
        }
        else {
            document.getElementById("r1" + index).checked = true;
            vm.mssId = mssId;
            vm.dltdft = false;
        }
        vm.dftStatus = true;
        vm.markRemovetxt = "Marks";
        vm.defaultSearchBold(mssId);
    };

    vm.defaultSearchBold = function (mssId) {
        for (var i = 0; i < vm.savedSrch.length; i++) {
            if (vm.savedSrch[i].mssId == mssId && vm.savedSrch[i].isDefault) {
                vm.markRemovetxt = "Remove";
                vm.dftStatus = false;
                break;
            }
        }
    };

    //Function used to Add and renmove default values 
    vm.MarkandRemoveDefault = function () {
        if (vm.mssId) {
            showLoader();
            advsrchSrvc.setRemoveDafaultSearch(vm.mssId, vm.mId(), vm.dftStatus, function (response, status) {
                if (status == 200)
                    vm.updateSearchObject(vm.mssId);
                hideLoader();
            });
            vm.edit = false;
            vm.dltdft = true;
        }
    };

    //manage save search object if database get updated successfully
    vm.updateSearchObject = function () {
        if (vm.dftStatus == false) {
            vm.markRemovetxt = "Marks";
            vm.dftStatus = true;         
            for (var i = 0; i < vm.savedSrch.length; i++) {
                if (vm.savedSrch[i].mssId == vm.mssId) {
                    vm.savedSrch[i].isDefault = false;
                    vm.mssId = "";
                    break;
                }
            }
        } else {
            for (var i = 0; i < vm.savedSrch.length; i++) {
                //set all isdefault as zero and 
                if (vm.savedSrch[i].isDefault)
                    vm.savedSrch[i].isDefault = false;
                //set isDefault using mssId
                if (vm.savedSrch[i].mssId == vm.mssId) {
                    vm.savedSrch[i].isDefault = true;
                    vm.defaultSearchBold(vm.mssId);
                }
            }
        }
    };

    //show delete popup
    vm.chkSaveSrchDel = function () {
        if (vm.mssId)
            $("#AdvsaveddDelete").modal('show');
    };

    //delete save search button click
    vm.delSaveSrch = function () {
        if (vm.mssId) {
            showLoader();
            advsrchSrvc.deleteSaveSearch(vm.mssId, vm.mId(), function (response, status) {
                if (status == 200) {
                    vm.edit = false;
                    $("#AdvsaveddDelete").modal('hide');
                    $.each(vm.savedSrch, function (i, e) {
                        if (e.mssId == vm.mssId) {
                            vm.savedSrch.splice(i, 1);
                            return false;
                        }
                    });

                    //check delete search and bind search same then empty title
                    var srchObj = JSON.parse($window.localStorage.getItem("srchObj"))
                    if (srchObj && srchObj.mssId == vm.mssId) {
                        srchObj.title = "";
                        srchObj.mssId = null;
                        $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
                    }

                    //check empty state
                    if (vm.savedSrch.length == 0)
                        vm.getSaveSrch();
                    else {
                        //on member request delete and save new search
                        if (vm.showSavePop) {
                            vm.showSavePop = false;
                            $("#mdlsvdSrchName").modal('show');
                        }
                    }
                }
                hideLoader();
            });
        }
    };

    vm.saveSearch = function () {
        var searchObj = JSON.parse($window.localStorage.getItem("saveSrchObj"));
        if (searchObj && vm.srchSvdName != "" && vm.srchSvdName.length <= 150) {
            showLoader();
            advsrchSrvc.saveSearch(searchObj, vm.srchSvdName, function (response, status) {
                if (status == 200 && response) {
                    $("#mdlsvdSrchName").modal('hide');
                    vm.srchSvdName = "";
                    $window.localStorage.removeItem("saveSrchObj");
                    vm.getSaveSrch();
                }
                hideLoader();
            });
        }
    };

    vm.limitKeypress = function ($event, value, maxLength) {
        if (value != undefined && value.toString().length >= maxLength) {
            $event.preventDefault();
        }
    };
}]);