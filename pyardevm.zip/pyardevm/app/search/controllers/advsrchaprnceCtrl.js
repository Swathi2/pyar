﻿angular.module("app").controller('advsrchaprnceCtrl', ['getSessionSrvc', 'selfprofileSrvc', '$window', '$state', '$timeout', '$rootScope', function (getSessionSrvc, selfprofileSrvc, $window, $state, $timeout, $rootScope) {
    vm = this;
    if ($window.localStorage.getItem("srchObj") == null) { $state.go("advancedsearch"); return; };
    vm.gender = function () { return getSessionSrvc.p_gndr(); };
    vm.measure = function () { return getSessionSrvc.p_uts(); };
    vm.genderPref = JSON.parse($window.localStorage.getItem("srchObj")).basic.genderPref;
    vm.appearance = JSON.parse($window.localStorage.getItem("srchObj")).appearance;

    //eye
    vm.eyeClrIdArry = [];
    if (vm.appearance.eyeColor.length > 0) {
        $.each(vm.appearance.eyeColor, function (i, e) { 
            vm.eyeClrIdArry.push(e.id);
        });
    }
    vm.eyeImageBinding = function () {
        if (vm.genderPref == true) {
            if (vm.eyeClrIdArry == null || vm.eyeClrIdArry == undefined || vm.eyeClrIdArry.length == 0)
                vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-black.png';
            else {
                angular.forEach(vm.eyeClrIdArry, function (data) {
                    if (data == 1 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-black.png';
                    if (data == 2 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-blue.png';
                    if (data == 3 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-brown.png';
                    if (data == 4 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-grey.png';
                    if (data == 5 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-green.png';
                    if (data == 6 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-hazel.png';
                    if (data == 7 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-purple.png';
                });
            }
        }
        else {
            if (vm.eyeClrIdArry == null || vm.eyeClrIdArry == undefined || vm.eyeClrIdArry.length == 0)
                vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-black.png';
            else {
                angular.forEach(vm.eyeClrIdArry, function (data) {
                    if (data == 1 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-black.png';
                    else if (data == 2 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-blue.png';
                    else if (data == 3 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-brown.png';
                    else if (data == 4 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-grey.png';
                    else if (data == 5 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-green.png';
                    else if (data == 6 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-hazel.png';
                    else if (data == 7 && vm.eyeClrIdArry[vm.eyeClrIdArry.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-purple.png';
                });
            }
        }
    };
    vm.selectEyeClr = function (eyeClrId) {
        var index = -1;
        $.each(vm.appearance.eyeColor, function (i, e) {
            if (e.id == eyeClrId) {
                index = i;
                return false;
            }
        });

        if (index == -1) {
            $.each(vm.eyecolor, function (i, e) {
                if (e.val == eyeClrId) {
                    vm.eyeClrTxt = e.txt.replace("eyes", "").replace(" ", "");
                    vm.appearance.eyeColor.push({ id: e.val, value: vm.eyeClrTxt });
                    return false;
                }
            });
            vm.eyeClrIdArry.push(eyeClrId);
        }
        else {
            vm.appearance.eyeColor.splice(index, 1);
            vm.eyeClrIdArry.splice(index, 1);
        }
        vm.eyeImageBinding();
    };
    vm.eyeImageBinding();

    //hair
    vm.hairClrIdArry = [];
    if (vm.appearance.hairColor.length !== 0) {
        $.each(vm.appearance.hairColor, function (i, e) {
            vm.hairClrIdArry.push(e.id);
        });
    };
    vm.hairImageBinding = function () {
        if (vm.genderPref == true) {
            if (vm.hairClrIdArry == null || vm.hairClrIdArry == undefined || vm.hairClrIdArry.length == 0)
                vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hblk.png';
            else {
                angular.forEach(vm.hairClrIdArry, function (data) {
                    if (data == 1 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hblk.png';
                    else if (data == 2 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hbrwn.png';
                    else if (data == 3 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hlgtbrwn.png';
                    else if (data == 4 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hylw.png';
                    else if (data == 5 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hred.png';
                    else if (data == 6 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hgray.png';
                    else if (data == 7 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hwht.png';
                    else if (data == 8 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hbald.png';
                    else if (data == 9 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hprpl.png';
                });
            }
        }
        else {
            if (vm.hairClrIdArry == null || vm.hairClrIdArry == undefined || vm.hairClrIdArry.length == 0)
                vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hblk.png';
            else {
                angular.forEach(vm.hairClrIdArry, function (data) {
                    if (data == 1 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hblk.png';
                    else if (data == 2 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hdrkbwn.png';
                    else if (data == 3 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hlgtbwn.png';
                    else if (data == 4 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hylw.png';
                    else if (data == 5 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hred.png';
                    else if (data == 6 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hgray.png';
                    else if (data == 7 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hwht.png';
                    else if (data == 8 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hbald.png';
                    else if (data == 9 && vm.hairClrIdArry[vm.hairClrIdArry.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hprpl.png';
                });
            }
        }
    };
    vm.selectedHiarClrFunc = function (hairclrId) {
        var index = -1;
        $.each(vm.appearance.hairColor, function (i, e) {
            if (e.id == hairclrId) {
                index = i;
                return false;
            }
        });

        if (index == -1) {
            $.each(vm.haircolor, function (i, e) {
                if (e.val == hairclrId) {
                    vm.hairClrTxt = e.txt.replace("hair", "").replace(" ", "");
                    vm.appearance.hairColor.push({ id: e.val, value: vm.hairClrTxt });
                    return false;
                }
            })
            vm.hairClrIdArry.push(hairclrId);
        }
        else {
            vm.appearance.hairColor.splice(index, 1)
            vm.hairClrIdArry.splice(index, 1);
        }
        vm.hairImageBinding();
    };
    vm.hairImageBinding();

    //get dropdown values and bind
    vm.getAprnceDat = function () {
        selfprofileSrvc.ddlsMyAppearence(function (response, status) {
            vm.build = response.build;
            vm.height = response.height;
            vm.eyecolor = response.eyecolor;
            vm.haircolor = response.haircolor;
            if (vm.appearance.minHeight.length == 0 && vm.appearance.maxHeight.length == 0) {
                vm.ddlminheight = [];
                for (var i = 0; i < vm.height.length; i++) {
                    var item = {};
                    item['val'] = vm.height[i].val;
                    item['txt'] = vm.getddlHeight(vm.height[i].txt);
                    vm.ddlminheight.push(item);
                }
                vm.ddlmaxheight = []
                for (var i = 0; i < vm.height.length; i++) {
                    var item = {};
                    item['val'] = vm.height[i].val;
                    item['txt'] = vm.getddlHeight(vm.height[i].txt);
                    vm.ddlmaxheight.push(item);
                }
            }
            else if (vm.appearance.minHeight.length == 0 && vm.appearance.maxHeight.length != 0) {
                if ((vm.appearance.maxHeight[0].id).toString() == 1)
                    vm.maxHeightDdlPreparefst(1);
                else {
                    // for maximum dropdown when the min height dropwn emtpy...
                    vm.ddlmaxheight = [];
                    for (var i = 0; i < vm.height.length; i++) {
                        if (vm.height[i].val <= parseInt(vm.appearance.maxHeight[0].id)) {
                            var item = {};
                            item['val'] = vm.height[i].val;
                            item['txt'] = vm.getddlHeight(vm.height[i].txt);
                            vm.ddlmaxheight.push(item);
                        }
                    }
                }
                //setting min and max selected value
                vm.selectedheightMax = (vm.appearance.maxHeight[0].id).toString();
                //for min height based on max height value
                vm.minHeightDdlPrepare(vm.appearance.maxHeight[0].id);
            }
            else if (vm.appearance.minHeight.length != 0 && vm.appearance.maxHeight.length == 0) {
                if ((vm.appearance.minHeight[0].id).toString() == vm.height.length)
                    vm.minHeightDdlPrepare(vm.height.length + 1);
                else {
                    // for getting minimum height dropdown when the maxheight is  empty...
                    vm.ddlminheight = [];
                    for (var i = 0; i < vm.height.length; i++) {
                        if (vm.height[i].val >= parseInt(vm.appearance.minHeight[0].id)) {
                            var item = {};
                            item['val'] = vm.height[i].val;
                            item['txt'] = vm.getddlHeight(vm.height[i].txt);
                            vm.ddlminheight.push(item);
                        }
                    }
                }
                vm.selectedheightMin = (vm.appearance.minHeight[0].id).toString();
                //for maximum height based on min height
                vm.maxHeightDdlPrepare(vm.appearance.minHeight[0].id);
            }
            else {
                vm.selectedheightMax = (vm.appearance.maxHeight[0].id).toString();
                vm.selectedheightMin = (vm.appearance.minHeight[0].id).toString();
                vm.minHeightDdlPrepare(vm.appearance.maxHeight[0].id);
                vm.maxHeightDdlPrepare(vm.appearance.minHeight[0].id);
            }
        });
    }
    vm.getAprnceDat();

    vm.buildAdd = function () {
        var index = -1;
        $.each(vm.appearance.build, function (i, e) {
            if (e.id == vm.selectedBuild.val) {
                index = i;
                return false;
            }
        });

        if (index == -1) {
            vm.appearance.build.push({
                id: parseInt(vm.selectedBuild.val),
                value: vm.selectedBuild.txt,
            });
        }
        vm.selectedBuild = "Add Build";
        $timeout(function () { window.scrollTo(0, $(window).height()); }, 0);
    };

    vm.buildRemove = function (val) {
        $.each(vm.appearance.build, function (i, e) {
            if (e.id == val) {
                vm.appearance.build.splice(i, 1);
                return false;
            }
        });
    };

    //done
    vm.appearDoneclk = function () {
        vm.checkHeight();
        var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
        $rootScope.showSrchBtn = !(JSON.stringify(vm.appearance) === JSON.stringify(srchObj.appearance));
        srchObj.appearance = vm.appearance;
        $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
        $state.go("advancedsearch");
    };

    //cancel
    vm.navigatCancel = function () {
        $state.go("advancedsearch");
    };

    //function to preapare Min HeightDdl
    vm.minHeightDdlPrepare = function (value) {
        var maxvalue = parseInt(value);
        if (maxvalue) {
            vm.ddlminheight = []
            for (var i = 0; i < vm.height.length; i++) {
                if (vm.height[i].val < maxvalue) {
                    var item = {};
                    item['val'] = vm.height[i].val;
                    item['txt'] = vm.getddlHeight(vm.height[i].txt);
                    vm.ddlminheight.push(item);
                }
            }
        }
    };

    //function to prepare Max heightDdl
    vm.maxHeightDdlPrepare = function (value) {
        var minvalue = parseInt(value);
        if (minvalue) {
            vm.ddlmaxheight = []
            for (var i = 0; i < vm.height.length; i++) {
                if (vm.height[i].val > minvalue) {
                    var item = {};
                    item['val'] = vm.height[i].val;
                    item['txt'] = vm.getddlHeight(vm.height[i].txt);
                    vm.ddlmaxheight.push(item);
                }
            }
        }
    };

    vm.maxHeightDdlPreparefst = function (value) {
        var minvalue = parseInt(value);
        if (minvalue) {
            vm.ddlmaxheight = []
            for (var i = 0; i < vm.height.length; i++) {
                if (vm.height[i].val >= minvalue) {
                    var item = {};
                    item['val'] = vm.height[i].val;
                    item['txt'] = vm.getddlHeight(vm.height[i].txt);
                    vm.ddlmaxheight.push(item);
                }
            }
        }
    };

    vm.getddlHeight = function (height) {
        var fields = height.split('or');
        var unit1 = fields[0];
        var unit2 = fields[1];
        if (vm.measure() == 1) {
            unit1 = replaceInches(unit1, " feet", "'");
            unit1 = replaceInches(unit1, " inches", "''");
            return unit1;
        }
        else
            return unit2;
    };

    vm.minmaxHeight = function (val, minmaxtxt) {
        var minmaxhght = parseInt(val);
        if (minmaxtxt == "min") {
            vm.appearance.minHeight = [];
            vm.height.forEach(function (data) {
                if (data.val == val)
                    vm.appearance.minHeight.push({
                        id: data.val,
                        value: vm.getddlHeight(data.txt),

                    });
            })
            vm.maxHeightDdlPrepare(val);
        }
        else {
            vm.appearance.maxHeight = [];
            vm.height.forEach(function (data) {
                if (data.val == val)
                    vm.appearance.maxHeight.push({
                        id: data.val,
                        value: vm.getddlHeight(data.txt),
                    });
            });
            vm.minHeightDdlPrepare(val)
        }
    };

    vm.checkHeight = function () {
        if (vm.appearance.minHeight.length > 0 && vm.appearance.maxHeight.length == 0) {
            vm.appearance.maxHeight.push({
                id: vm.ddlminheight[vm.ddlminheight.length-1].val,
                value: vm.ddlminheight[vm.ddlminheight.length - 1].txt,
            });
        }
        else if (vm.appearance.minHeight.length == 0 && vm.appearance.maxHeight.length > 0) {
            vm.appearance.minHeight.push({
                id: vm.ddlminheight[0].val,
                value: vm.ddlminheight[0].txt,
            });
        }
    };
}]);