﻿angular.module("app").controller('advsrchbasicsCtrl', ['advsrchSrvc', 'getSessionSrvc', 'cmnSrvc', '$scope', '$rootScope', '$window', '$timeout', '$state', function (advsrchSrvc, getSessionSrvc,cmnSrvc, $scope, $rootScope, $window, $timeout, $state) {
    var vm = this;
    if ($window.localStorage.getItem("srchObj") == null) { $state.go("advancedsearch"); return; };
    vm.units = function () { return getSessionSrvc.p_uts(); };
    vm.cntryId = function () { return getSessionSrvc.p_cntryId(); };
    $rootScope.dvToggle = false;//for  account toggle icon
    vm.basic = JSON.parse($window.localStorage.getItem("srchObj")).basic;
    if (vm.units() == 1)
        vm.unitsTxt = "Miles";
    else
        vm.unitsTxt = "Kms";

    // for default basic info when the srchObj is not availble
    var dftbasic = JSON.parse($window.localStorage.getItem("defaultbasic"));
    if (!vm.basic.minAge)
        vm.basic.minAge = dftbasic.minAge;
    if (!vm.basic.maxAge)
        vm.basic.maxAge = dftbasic.maxAge;
    if (!vm.basic.locRadius)
        vm.basic.locRadius = dftbasic.locRadius;
    if (!vm.basic.locType)
        vm.basic.locType = 1;
    if (!vm.basic.latitude)
        vm.basic.latitude = dftbasic.latitude;
    if (!vm.basic.longitute)
        vm.basic.longitute = dftbasic.longitute;
    if (!vm.basic.countryId)
        vm.basic.countryId = dftbasic.countryId;

    vm.minMaxageClk = function (val, minmaxtxt) {
        if (minmaxtxt == "min") {
            vm.basic.minAge = val;
            getMaxddl(parseInt(val));
        }
        else {
            vm.basic.maxAge = val;
            getminddl(parseInt(val));
        }
    }

    var min = 18;
    var max = 130;
    getMaxddl(vm.basic.minAge);
    getminddl(vm.basic.maxAge);

    function getMaxddl(val) {
        vm.maxddl = [];
        for (var i = val; i <= max; i++) {
            vm.maxddl.push(i);
        }
    };

    function getminddl(val) {
        vm.minddl = [];
        for (var i = min; i <= val; i++) {
            vm.minddl.push(i);
        }
    };

    //location radius bind function starts here
    mpDistanceFuncG(function (response) {
        $scope.step = "1";
        $scope.ticks = [];
        $scope.labels = [];
        //binding the radius data
        for (var i = 0; i < response.length; i++) {
            $scope.ticks.push(response[i].rdId);
            $scope.labels.push(response[i].radius == 1000 ? (response[i].radius + "+") : response[i].radius)
        }
        if (vm.basic.locRadius)
            $timeout(function () { $scope.slide(vm.basic.locRadius); }, 100);
    });

    vm.srchNameChng = function () {
        if (vm.basic.firstName.length > 30) {
            vm.srchTxt = true;
            vm.basic.firstName = "Must be < 30 characters";
            vm.kpCls = "vlderr";
        }
    };

    vm.txtsearchCheck = function () {
        if (vm.srchTxt == true) {
            vm.basic.firstName = "";
            vm.kpCls = '';
            vm.srchTxt = false;
        }
    };
    $scope.slide = function (val) {
        if (!val)
            val = 1;
        $('.slider-tick-label').removeClass("ticklblclr");
        var element = $('.slider-tick-label')[val - 1];
        if (element)
            element.className = element.className + " ticklblclr";
    }
    //location radius bind function end

    function mpDistanceFuncG(callBackFun) {
        showLoader();
        advsrchSrvc.prefRadius(function (response, status) {
            if (status == 200) {
                callBackFun(response);
                hideLoader();
            }
        });
    }

    vm.setMyLoc = function () {     
        vm.basic.locType = 1;
        vm.loctext = false;
        var dftbasic = JSON.parse($window.localStorage.getItem("defaultbasic"));
        vm.basic.countryId = dftbasic.countryId;
        vm.basic.cityId = dftbasic.cityId;
        vm.basic.latitude = dftbasic.latitude;
        vm.basic.longitute = dftbasic.longitute;
    };

    vm.setCurLoc = function () {
        vm.basic.countryId = "";//clear previous countryId(because wait function is added in search click up to get country id).
        vm.basic.locType = 2;
        vm.loctext = false;
        getLatitudeLangitude();
    };

    vm.setOtherLoc = function () {       
        vm.basic.locType = 3;
        vm.basic.latitude = "";
        vm.basic.longitute = "";
        $rootScope.$broadcast("showLocation", "curLocation");
    };

    vm.locRemove = function () {
        vm.setMyLoc();
        vm.curLocation = "";
        vm.loctext = false;
    };

    function getLatitudeLangitude() {
        if (navigator.geolocation)
            navigator.geolocation.getCurrentPosition(showPosition, geoError);
        else
            alert("Geolocation is not supported by this browser.");
    };

    function showPosition(position) {
        vm.basic.latitude = position.coords.latitude;
        vm.basic.longitute = position.coords.longitude;
        if (vm.basic.latitude != "" && vm.basic.longitute != "") {
            getCountryCodeUsingLatLong(cmnSrvc, vm.basic.latitude, vm.basic.longitute, function (response) {
                vm.basic.countryId = response;
            });
        }
    };

    function geoError(error) {
        switch (error.code) {
            case error.PERMISSION_DENIED:
                {
                    vm.setMyLoc();
                    alert("User denied the request for Geolocation.");
                    break;
                }
            case error.POSITION_UNAVAILABLE:
                alert("Location information is unavailable.");
                break;
            case error.TIMEOUT:
                alert("The request to get user location timed out.");
                break;
            case error.UNKNOWN_ERROR:
                alert("An unknown error occurred.");
                break;
        }
    }

    vm.loctext = false;
    vm.showloc = false;

    if (vm.basic.locType==3 && vm.basic.countryId && vm.basic.cityId) {
        $timeout(function () {
            $rootScope.$broadcast("GetCity", "curLocation", vm.basic.countryId, vm.basic.cityId);
        }, 1000);
    }

    $scope.$on("BindCity", function (e, locId, citObj) {
        if (locId == "curLocation") {
            vm.loctext = true;
            vm.curLocation = bindLocation(citObj, vm.cntryId());
        }
    });

    $scope.$on("countryBind", function (e, locId, countryId, data) {
        if (locId == "curLocation") {
            vm.basic.locType = 3;
            vm.loctext = true;
            vm.basic.countryId = data.countryId;
            vm.basic.cityId = data.cityId;
            vm.basic.latitude = data.lat;
            vm.basic.longitute = data.long;
            vm.curLocation = bindLocation(data, vm.cntryId());
            $timeout(function () { window.scrollTo(0, $(window).height()); }, 0);
        }
    });

    $scope.$on("countryUnBind", function (e, locId, data) {
        if (locId == "curLocation")
            vm.setMyLoc();
    });

    vm.basicDoneclk = function () {
        //wait untill to get countryId if we select current location
        if (vm.basic.locType == 2 && !vm.basic.countryId) {
            $timeout(function () {
                vm.basicDoneclk();
                return;
            }, 500);
        }
        else {
            var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
            $rootScope.showSrchBtn = !(JSON.stringify(vm.basic) === JSON.stringify(srchObj.basic));
            srchObj.basic = vm.basic;
            $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
            $state.go("advancedsearch");
        }
    };

    vm.navigatCancel = function () {
        $state.go("advancedsearch");
    };
}]);