﻿angular.module("app").controller('advsrchlifestyleCtrl', ['selfprofileSrvc', '$scope', '$window', '$timeout', '$state', '$rootScope', function (selfprofileSrvc, $scope, $window, $timeout, $state, $rootScope) {
    vm = this;
    if ($window.localStorage.getItem("srchObj") == null) { $state.go("advancedsearch"); return; };
    vm.lifestyle = JSON.parse($window.localStorage.getItem("srchObj")).lifestyle;
    vm.fmlyLangObj = false;
    vm.prefLangObj = false;

    //page load event
    vm.bindLifeStyle = function () {
        selfprofileSrvc.ddlsMyLifeStyleDDlData(function (response, status) {
            if (vm.lifestyle.diet.length == 0)
                vm.lifestyle.diet = response.diet;
            vm.smoke = response.smoke;
            vm.drink = response.drink;
            vm.idealRelationshipDdl = response.IdealRelationShip;
            vm.childrenCntDdl = response.numOfChildren;
            vm.childrenPrefDdl = response.childrenPref;
            vm.petsCntDdl = response.numOfPets;
            vm.petsPrefDdl = response.petPref;
            vm.languages = response.language;
            vm.fmlyLanguages = response.language;
            vm.religiousDdl = response.Religious;
            vm.traditionalDdl = response.traditional;
            if (vm.lifestyle.childrenCnt.length == 0) 
                vm.sliderValueChldrnCnt = 0;            
            else
                vm.sliderValueChldrnCnt = vm.lifestyle.childrenCnt[0].val;          
            if (vm.lifestyle.petsCnt.length==0) 
                vm.sliderValuePetsCnt = 0;                          
            else 
                vm.sliderValuePetsCnt =vm.lifestyle.petsCnt[0].val;                         
            //smoke slider binding starts here
            $scope.smokstep = "1";
            $scope.smokeTicks = [];
            $scope.smokeLabels = [];
            vm.smoke.forEach(function (data) {
                $scope.smokeTicks.push(data.val);
                $scope.smokeLabels.push(data.txt)
            });
            if (vm.lifestyle.smoke.length > 0) {
                vm.smokeVal = vm.lifestyle.smoke[0].val;
                $timeout(function () { $scope.smokeSlide(vm.smokeVal); }, 100);
            }

            //drink slider binding starts
            $scope.drinkStep = "1";
            $scope.drinkTicks = [];
            $scope.drinkLabels = [];
            vm.drink.forEach(function (data) {
                $scope.drinkTicks.push(data.val);
                $scope.drinkLabels.push(data.txt)
            });
            if (vm.lifestyle.drink.length > 0) {
                vm.drinkVal = vm.lifestyle.drink[0].val;
                $timeout(function () { $scope.drinkSlide(vm.drinkVal); }, 100);
            }

            //child preferance slider binding
            $scope.wntchdStep = "1";
            $scope.wntchTicks = [];
            $scope.wntchLabels = [];
            vm.childrenPrefDdl.forEach(function (data) {
                $scope.wntchTicks.push(data.val);
                $scope.wntchLabels.push(data.txt)
            })
            if (vm.lifestyle.children.length > 0) {
                vm.childPrefVal = vm.lifestyle.children[0].val;
                $timeout(function () { $scope.chldrnSlide(vm.childPrefVal); }, 100);
            }

            //pets preferance slider binding
            $scope.wntptsStep = "1";
            $scope.wntptsTicks = [];
            $scope.wntptsLabels = [];
            vm.petsPrefDdl.forEach(function (data) {
                $scope.wntptsTicks.push(data.val);
                $scope.wntptsLabels.push(data.txt)
            })
            if (vm.lifestyle.pets.length > 0) {
                vm.petsPrefVal = vm.lifestyle.pets[0].val;
                $timeout(function () { $scope.petsSlide(vm.petsPrefVal); }, 100);
            }

            //religious slider binding
            $scope.rglsStep = "1";
            $scope.rlgsTicks = [];
            $scope.rlgsLabels = [];
            vm.religiousDdl.forEach(function (data) {
                $scope.rlgsTicks.push(data.val);
                $scope.rlgsLabels.push(data.txt)
            })
            if (vm.lifestyle.religious.length > 0) {
                vm.rlgsVal = vm.lifestyle.religious[0].val;
                $timeout(function () { $scope.rglsSlide(vm.rlgsVal); }, 100);
            }

            //traditional/cultural slider binding
            $scope.trdtnlstep = "1";
            $scope.trdtnlTicks = [];
            $scope.trdtnlLabels = [];
            vm.traditionalDdl.forEach(function (data) {
                $scope.trdtnlTicks.push(data.val);
                $scope.trdtnlLabels.push(data.txt)
            })
            if (vm.lifestyle.traditional.length > 0) {
                vm.trdtnlVal = vm.lifestyle.traditional[0].val;
                $timeout(function () { $scope.trdtnlSlide(vm.trdtnlVal); }, 100);
            }
        });
    }
    vm.bindLifeStyle();

    //diet
    vm.checkedmpDtIds = [];
    vm.dietAddRemove = function (dietObj, dietId) {
        dietObj.selected = !dietObj.selected;
        if (vm.checkedmpDtIds.indexOf(dietId) == -1)
            vm.checkedmpDtIds.push(dietId);
        else
            vm.checkedmpDtIds.splice(vm.checkedmpDtIds.indexOf(dietId), 1);
    };

    //idealRelationship
    vm.irsAddRemove = function (val, txt, event) {
        $(event.target).toggleClass('active');
        if (vm.lifestyle.idealRelationship.length > 0)
            if (vm.lifestyle.idealRelationship[0].val == val)
                vm.lifestyle.idealRelationship = [];
            else
                vm.lifestyle.idealRelationship = [{ val: val, txt: txt }];
            else
                vm.lifestyle.idealRelationship = [{ val: val, txt: txt }];       
    };

    //childrenCount
    vm.chdrnIncr = function () {      
        if (vm.sliderValueChldrnCnt < 6) {
            vm.sliderValueChldrnCnt++;
            $.each(vm.childrenCntDdl, function (i, e) {
                if (e.val == vm.sliderValueChldrnCnt) {
                    vm.lifestyle.childrenCnt = [];
                    vm.lifestyle.childrenCnt.push({ val: e.val, txt: e.txt });                  
                    return false;
                }
            });
        }
    };

    vm.chdrnDecr = function () {       
        if (vm.sliderValueChldrnCnt == 1) {
            vm.sliderValueChldrnCnt--;
            vm.lifestyle.childrenCnt = [];
        }
        else if (vm.sliderValueChldrnCnt > 0) {
            vm.sliderValueChldrnCnt--;
            $.each(vm.childrenCntDdl, function (i, e) {
                if (e.val == vm.sliderValueChldrnCnt) {
                     vm.lifestyle.childrenCnt =[];
                    vm.lifestyle.childrenCnt.push({ val: e.val, txt: e.txt });                 
                    return false;
                }
            });
        }
    };

    //petscount
    vm.petsIncr = function () {       
        if (vm.sliderValuePetsCnt < 4) {
            vm.sliderValuePetsCnt++;
            $.each(vm.petsCntDdl, function (i, e) {
                if (e.val == vm.sliderValuePetsCnt) {
                    vm.lifestyle.petsCnt = [];
                    vm.lifestyle.petsCnt.push({ val: e.val, txt: e.txt });                  
                    return false
                }
            })
        }
    };

    vm.petsDecr = function () {     
        if (vm.sliderValuePetsCnt == 1) {
            vm.sliderValuePetsCnt--;
            vm.lifestyle.petsCnt = [];
        }
        else if (vm.sliderValuePetsCnt > 0) {
            vm.sliderValuePetsCnt--;
            $.each(vm.petsCntDdl, function (i, e) {
                if (e.val == vm.sliderValuePetsCnt) {
                    vm.lifestyle.petsCnt = [];
                    vm.lifestyle.petsCnt.push({ val: e.val, txt: e.txt });
                    return false;
                }
            });
        }
    }

    //preferred languages
    vm.prefLangAdd = function () {
        var index = -1;
        $.each(vm.lifestyle.languages, function (i, e) {
            if (e.id == vm.selectedPrefLang.val) {
                index = i;
                return false;
            }
        });

        if (index == -1) {
            vm.lifestyle.languages.push({
                id: parseInt(vm.selectedPrefLang.val),
                value: vm.selectedPrefLang.txt,
            });
        }
        vm.selectedPrefLang = "Add language";
    };

    vm.prefLangRemove = function (id) {
        $.each(vm.lifestyle.languages, function (i, e) {
            if (e.id == id) {
                vm.lifestyle.languages.splice(i, 1);
                return false;
            }
        });
    };

    //family languages
    vm.familyLangAdd = function () {
        var index = -1;
        $.each(vm.lifestyle.fmlyLanguages, function (i, e) {
            if (e.id == vm.selectedFamilyLang.val) {
                index = i;
                return false;
            }
        });

        if (index == -1) {
            vm.lifestyle.fmlyLanguages.push({
                id: parseInt(vm.selectedFamilyLang.val),
                value: vm.selectedFamilyLang.txt,
            });
        }
        vm.selectedFamilyLang = "Add language";
    };

    vm.familyLangRemove = function (fmlyLangObj) {
        $.each(vm.lifestyle.fmlyLanguages, function (i, e) {
            if (e.id == fmlyLangObj) {
                vm.lifestyle.fmlyLanguages.splice(i, 1);
                return false;
            }
        });
    };

    //smoke
    $scope.smokeSlide = function (val) {
        if (!val)
            val = 1;
        $('.smkSldr .slider-tick-label').removeClass("ticklblclr");
        var element = $('.smkSldr .slider-tick-label')[val - 1];
        if (element)
            element.className = element.className + " ticklblclr";
        $.each(vm.smoke, function (i, e) {
            if (e.val == val) {
                vm.lifestyle.smoke = [{ val: e.val, txt: e.txt }];
                return false;
            }
        });
    };

    vm.smokeRefresh = function () {
        vm.smokeVal = null;
        vm.lifestyle.smoke = [];
        $('.smkSldr .slider-tick-label').removeClass("ticklblclr");
    };

    //drink
    $scope.drinkSlide = function (val) {
        if (!val)
            val = 1;
        $('.dnkSldr .slider-tick-label').removeClass("ticklblclr");
        var element = $('.dnkSldr .slider-tick-label')[val - 1];
        if (element)
            element.className = element.className + " ticklblclr";
        $.each(vm.drink, function (i, e) {
            if (e.val == val) {
                vm.lifestyle.drink = [{ val: e.val, txt: e.txt }];
                return false;
            }
        });
    };

    vm.drinkRefresh = function () {
        vm.drinkVal = null;
        vm.lifestyle.drink = [];
        $('.dnkSldr .slider-tick-label').removeClass("ticklblclr");
    };

    //children
    $scope.chldrnSlide = function (val) {
        if (!val)
            val = 1;
        $('.wntChldrn .slider-tick-label').removeClass("ticklblclr");
        var element = $('.wntChldrn .slider-tick-label')[val - 1];
        if (element)
            element.className = element.className + " ticklblclr";
        $.each(vm.childrenPrefDdl, function (i, e) {
            if (e.val == val) {
                vm.lifestyle.children = [{ val: e.val, txt: e.txt }];
                return false;
            }
        });
    };

    vm.childPrefRefresh = function () {
        vm.childPrefVal = null;
        vm.lifestyle.children = [];
        $('.wntChldrn .slider-tick-label').removeClass("ticklblclr");
    };

    //pets
    $scope.petsSlide = function (val) {
        if (!val)
            val = 1;
        $('.wntPts .slider-tick-label').removeClass("ticklblclr");
        var element = $('.wntPts .slider-tick-label')[val - 1];
        if (element)
            element.className = element.className + " ticklblclr";
        $.each(vm.petsPrefDdl, function (i, e) {
            if (e.val == val) {
                vm.lifestyle.pets = [{ val: e.val, txt: e.txt }];
                return false;
            }
        });
    };

    vm.petsprfRefresh = function () {
        $('.wntPts .slider-tick-label').removeClass("ticklblclr");
        vm.petsPrefVal = null;
        vm.lifestyle.pets = [];
    };

    //religious
    $scope.rglsSlide = function (val) {
        if (!val)
            val = 1;
        $('.rgls .slider-tick-label').removeClass("ticklblclr");
        var element = $('.rgls .slider-tick-label')[val - 1];
        if (element)
            element.className = element.className + " ticklblclr";
        $.each(vm.religiousDdl, function (i, e) {
            if (e.val == val) {
                vm.lifestyle.religious = [{ val: e.val, txt: e.txt }];
                return false;
            }
        });
    };

    vm.relgsRefresh = function () {
        $('.rgls .slider-tick-label').removeClass("ticklblclr");
        vm.rlgsVal = null;
        vm.lifestyle.religious = [];
    };

    //traditional/Cultural
    $scope.trdtnlSlide = function (val) {
        if (!val)
            val = 1;
        $('.trdtnl .slider-tick-label').removeClass("ticklblclr");
        var element = $('.trdtnl .slider-tick-label')[val - 1];
        if (element)
            element.className = element.className + " ticklblclr";
        $.each(vm.traditionalDdl, function (i, e) {
            if (e.val == val) {
                vm.lifestyle.traditional = [{ val: e.val, txt: e.txt }];
                return false;
            }
        });
    };

    vm.trdtnRefresh = function () {
        $('.trdtnl .slider-tick-label').removeClass("ticklblclr");
        vm.trdtnlVal = null;
        vm.lifestyle.traditional = [];
    };

    //done
    vm.lfstyleDnClk = function () {
        var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
        $rootScope.showSrchBtn = !(JSON.stringify(vm.lifestyle) === JSON.stringify(srchObj.lifestyle));
        srchObj.lifestyle = vm.lifestyle;   
        $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
        $state.go("advancedsearch");
    };

    //cancel
    vm.navigatCancel = function () {
        $state.go("advancedsearch");
    };
}]);