﻿angular.module("app").controller('advsrchprsnltyECtrl', ['advsrchSrvc', '$window', '$state', '$rootScope', function (advsrchSrvc, $window, $state, $rootScope) {
    vm = this;
    if ($window.localStorage.getItem("srchObj") == null) { $state.go("advancedsearch"); return; };
    vm.PrsnltyTrait = "";
    var result = {};

    showLoader();
    advsrchSrvc.getPT(function (response) {
        var key = 'ptcId';
        for (var i = 0; i < response.length; i++) {
            if (!result[response[i][key]]) {
                result[response[i][key]] = [];
            }
            result[response[i][key]].push(response[i])
        }
        vm.PrsnltyTraitsList = result;
        vm.traitImgBind();
        hideLoader();
    });

    vm.loadTraits = function () {
        showLoader();
        vm.personalityTraits = JSON.parse($window.localStorage.getItem("srchObj")).personalityTraits;
        if (vm.personalityTraits.ptcId == undefined || vm.personalityTraits.ptcId == "")
            vm.personalityTraits.ptcId = [];

        vm.checkedTrIds = [];
        if (vm.personalityTraits.pt.length > 0) {
            var data_id = vm.personalityTraits.pt.map(function (item) {
                vm.checkedTrIds.push(item.id);
            })
        }
        hideLoader();
    };
    vm.loadTraits();

    //changing personality  value to load particular traits for personality
    vm.getPrsnltyTrait = function (PrsnltyTrait) {
        vm.PrsnltyTrait = PrsnltyTrait;
        vm.ptcId = PrsnltyTrait;
        vm.PrsnltyTraitsList = result[PrsnltyTrait];
    };

    //Default personality page 
    vm.PrsnltyTraitCancel = function () {
        vm.PrsnltyTrait = "";
        vm.loadTraits();
    }

    //personality traits click function
    vm.ptAddRemove = function (ptId, ptcId, ptName) {
        vm.ptcId = ptcId;
        var index = -1;
        $.each(vm.personalityTraits.pt, function (i, e) {
            if (e.id == ptId) {
                index = i;
                return false;
            }
        });
        // if not exist the element of object
        if (index == -1) {
            vm.personalityTraits.pt.push({
                id: ptId,
                value: ptName,
            });
            vm.checkedTrIds.push(ptId);
        }
        else {
            vm.personalityTraits.pt.splice(index, 1);
            vm.checkedTrIds.splice(index, 1);
        }
    };

    vm.trait_done = function () {
        vm.traitImgBind();
        vm.PrsnltyTrait = "";
        //check pt category
        $.each(vm.PrsnltyTraitsList, function (i, e) {
            if (vm.checkedTrIds.indexOf(e.ptId) == -1) {
                if (vm.personalityTraits.ptcId.indexOf(vm.ptcId) !== -1) {
                    var index = vm.personalityTraits.ptcId.indexOf(vm.ptcId);
                    vm.personalityTraits.ptcId.splice(index, 1);
                }
            }
            else {
                if (vm.personalityTraits.ptcId.indexOf(vm.ptcId) == -1)
                    vm.personalityTraits.ptcId.push(vm.ptcId);
                return false;
            }
        });
        //update local storage values
        var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
        $rootScope.showSrchBtn = !(JSON.stringify(vm.personalityTraits) === JSON.stringify(srchObj.personalityTraits));
        srchObj.personalityTraits = vm.personalityTraits;
        $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
    };

    //done
    vm.ptDoneClk = function () {
        $state.go("advancedsearch");
    };

    //cancel
    vm.navigatCancel = function () {
        $state.go("advancedsearch");
    };

    vm.traitImgBind = function () {
        vm.ptCat1Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt1.png';
        vm.ptCat2Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt2.png';
        vm.ptCat3Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt3.png';
        vm.ptCat4Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt4.png';
        vm.ptCat5Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt5.png';
        vm.ptCat6Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt6.png';
        vm.ptCat7Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt7.png';
        vm.personalityTraits.pt.forEach(function (val) {
            if (val.id >= 1 & val.id <= 6)
                vm.ptCat1Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta1.png';
            else if (val.id >= 7 & val.id <= 12)
                vm.ptCat2Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta2.png';
            else if (val.id >= 13 & val.id <= 18)
                vm.ptCat3Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta3.png';
            else if (val.id >= 19 & val.id <= 24)
                vm.ptCat4Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta4.png';
            else if (val.id >= 25 & val.id <= 30)
                vm.ptCat5Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta5.png';
            else if (val.id >= 31 & val.id <= 36)
                vm.ptCat6Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta6.png';
            else if (val.id >= 37 & val.id <= 42)
                vm.ptCat7Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta7.png';
        });
    };
}]);