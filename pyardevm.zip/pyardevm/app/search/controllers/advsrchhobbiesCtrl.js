﻿angular.module("app").controller('advsrchhobbiesCtrl', ['selfprofileSrvc', 'getSessionSrvc', '$window', '$state', '$rootScope', function (selfprofileSrvc, getSessionSrvc, $window, $state, $rootScope) {
    var vm = this;
    if ($window.localStorage.getItem("srchObj") == null) { $state.go("advancedsearch"); return; };
    showLoader();
    vm.hobbies = JSON.parse($window.localStorage.getItem("srchObj")).hobbies;
    vm.activehbIds = [];

    vm.getHobbies = function () {
        selfprofileSrvc.HobbiesList(function (response, status) {
            if (status == 200) {
                var result = {};
                var key = 'categoryName';
                for (var i = 0; i < response.length; i++) {
                    if (!result[response[i][key]]) {
                        result[response[i][key]] = [];
                    }
                    result[response[i][key]].push(response[i]);
                }
                vm.hobbylst = response;
                vm.lstHobbies = result;
                vm.bindhobbies();
            }
            hideLoader();
        });
    };
    vm.getHobbies();

    vm.hobbiesAddRemove = function (HcId, HobbyId, event, hobbyName) {
        if (vm.activehbIds.indexOf(HobbyId) == -1) {
            vm.activehbIds.push(HobbyId);
            vm.hobbies.hobbies.push({ id: parseInt(HobbyId), value: hobbyName });
        }
        else {
            var index = vm.activehbIds.indexOf(HobbyId);
            vm.activehbIds.splice(index, 1);
            vm.hobbies.hobbies.splice(index, 1);
        }
    };

    vm.bindhobbies = function () {
        if (vm.hobbies.hobbies.length > 0) {
            angular.forEach(vm.hobbies.hobbies, function (data) {
                vm.activehbIds.push(parseInt(data.id));
            })
        }
    };

    //done
    vm.hobbiesdoneclk = function () {
        var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
        $rootScope.showSrchBtn = !(JSON.stringify(vm.hobbies) === JSON.stringify(srchObj.hobbies));
        srchObj.hobbies = vm.hobbies;
        $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
        $state.go("advancedsearch");
    };

    //cancel
    vm.navigatCancel = function () {
        $state.go("advancedsearch");
    };
}]);