﻿angular.module('app').controller('basicsrchCtrl', ['basicsrchSrvc', 'getSessionSrvc', 'hbySearchFact', 'cmnSrvc', '$scope', '$location', '$state', '$timeout', '$window', '$rootScope', function (basicsrchSrvc, getSessionSrvc, hbySearchFact, cmnSrvc, $scope, $location, $state, $timeout, $window, $rootScope) {
    var vm = this;
    vm.sId = function () { return getSessionSrvc.p_sub(); };
    if (vm.sId() == 2) { $window.localStorage.removeItem("srchObj"); $state.go("advancedsearch"); return; }
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.cntryId = function () { return getSessionSrvc.p_cntryId(); };
    vm.country = function () { return getSessionSrvc.p_cntry(); };
    vm.units = function () { return getSessionSrvc.p_uts(); };
    vm.gender = function () { return getSessionSrvc.p_gndr() };
    setFooterIcon("srch");
    vm.isBSInfo = false;
    vm.showloc = false;
    vm.showSrchBtn = false;
    vm.showSrchFields = true;
    vm.srchObj = null;
    vm.srchType = 1;
    vm.prefGender = null;
    vm.radius = 5;
    vm.min = 18;
    vm.max = 130;
    vm.memInfo = null;
    vm.mmc = false;
    vm.mmcScrollTo = 0;

    if (vm.units() == 1)
        vm.unitTxt = "Miles";
    else
        vm.unitTxt = "Kms";

    vm.getMemInfo = function (callBackFun) {
        basicsrchSrvc.getMemberData(vm.mId(), function (response, status) {
            if (status == 200) {
                vm.memInfo = response;
                callBackFun();
                vm.showSrchBtn = true;
                vm.isBSInfo = true;
            }
        });
    };

    vm.srchNameChng = function () {
        if (vm.txtsearchByName.length > 30) {
            vm.srchTxt = true;
            vm.txtsearchByName = "Must be < 30 characters";         
            vm.kpCls = "vlderr";
        }
    };

    vm.txtsearchCheck = function () {
        if (vm.srchTxt == true) {
            vm.txtsearchByName = "";
            vm.kpCls = '';
            vm.srchTxt = false;
        }
    };

    vm.getLocReadius = function (callBackFun) {
        basicsrchSrvc.getPrefRadius(function (response, status) {
            if (status == 200)
                callBackFun(response);
        });
    };

    vm.bindMemInfo = function () {
        vm.txtsearchByName = "";
        vm.profilePhotos = false;
        vm.onlineMatches = false;
        vm.prefGender = vm.memInfo.genderPref
        var age = calculateAge(vm.memInfo.dob);
        vm.minAge = age - 5;
        vm.maxAge = age + 5;
        if (vm.minAge < 18)
            vm.minAge = 18;
        if (vm.maxAge > 130)
            vm.maxAge = 130;
        vm.bindMaxddl(vm.minAge);
        vm.bindMinddl(vm.maxAge);
        vm.radius = 5;
        vm.locType = 1;
        vm.curLocation = "";
        vm.growupLocation = "";
        vm.mmcScrollTo = 0;

        // Hobby based Search implementation.
        var hbySearch = hbySearchFact.gethbySearchData();
        if (hbySearch && hbySearch.length > 0) {//hbySearch is array
            vm.srchType = 2;//hobby search
            hbySearch = jQuery.parseJSON(hbySearch);
            vm.bindSrchSugns(hbySearch.refId, hbySearch.refType, hbySearch.sugName);
            hbySearchFact.sethbySearchData(null);
        };
    };

    vm.bindLocReadius = function (response) {
        $scope.ticks = [];
        $scope.labels = [];
        vm.ddlRadius = response;
        for (var i = 0; i < response.length; i++) {
            $scope.ticks.push(response[i].rdId);
            $scope.labels.push(response[i].radius == 1000 ? (response[i].radius + "+") : response[i].radius)
        }
        $scope.step = "1";
        $timeout(function () { $scope.slide(); }, 100);
    };

    $scope.slide = function () {
        if (!vm.radius)
            vm.radius = 1;
        $('.slider-tick-label').removeClass("ticklblclr");
        var element = $('.slider-tick-label')[vm.radius - 1];
        if (element)
            element.className = element.className + " ticklblclr";
    };

    vm.bindMaxddl = function (val) {
        vm.maxddl = [];
        for (var i = val; i <= vm.max; i++)
            vm.maxddl.push(i);
    };

    vm.bindMinddl = function (val) {
        vm.minddl = [];
        for (var i = vm.min; i <= val; i++)
            vm.minddl.push(i);
    };

    vm.setMyLoc = function () {
        vm.locType = 1;
        vm.curLocation = "";
        vm.growupLocation="";
    };

    vm.setCurLoc = function () {
        vm.countryId = "";//clear previous countryId(because wait function is added in search click up to get country id).
        vm.locType = 2;
        vm.curLocation = "";
        vm.getLatitudeLangitude();
    };

    vm.setOtherLoc = function () {
        vm.locType = 3;
        $rootScope.$broadcast("showLocation", "bsLoc");
    };

    vm.getLatitudeLangitude = function () {
        try {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition, geoError);
            }
            else
                alert("Geolocation is not supported by this browser.");
        } catch (e) {
            alert(e.message);
        }
    };

    function geoError(error) {
        switch (error.code) {
            case error.PERMISSION_DENIED:
                {
                    vm.setMyLoc();
                    alert("User denied the request for Geolocation.");
                    break;
                }
            case error.POSITION_UNAVAILABLE:
                alert("Location information is unavailable.");
                break;
            case error.TIMEOUT:
                alert("The request to get user location timed out.");
                break;
            case error.UNKNOWN_ERROR:
                alert("An unknown error occurred.");
                break;
        }
    }

    function showPosition(position) {
        vm.lat = position.coords.latitude;
        vm.long = position.coords.longitude;
        if (vm.lat != "" && vm.long != "") {
            getCountryCodeUsingLatLong(cmnSrvc, vm.lat, vm.long, function (response) {
                vm.countryId = response;
            });
        }
    };

    $scope.$on("countryBind", function (e, locId, countryId, locObj) {
        vm.bindLoc(locId, locObj);
        $timeout(function () { window.scrollTo(0, $(window).height()); }, 0);
    });

    $scope.$on("BindCity", function (e, locId, locObj) {
        vm.bindLoc(locId, locObj);
    });

    $scope.$on("countryUnBind", function (e, locId, data) {
        if (locId == "bsLoc" && vm.growupLocation == "")
            vm.setMyLoc();
    });

    vm.bindLoc = function (locId, locObj) {
        if (locId == "bsLoc") {
            vm.locType = 3;
            vm.countryId = locObj.countryId;
            vm.cityId = locObj.cityId;
            vm.OtherLocLatitude = locObj.lat;
            vm.OtherLocLongitude = locObj.long;
            vm.growupLocation = bindHtLocation(locObj.cityName, locObj.stateName, locObj.countryName, vm.country(), vm.units(), locObj.distance);
        }
    };  
    vm.getLocText = function (locObj) {
        return vm.curLocation = bindHtLocation(locObj.city, locObj.state, locObj.country, vm.country(), vm.units(), locObj.distance);
    };

    vm.basicText = function () {
        vm.basictext = "";
        if (vm.txtsearchByName)
            vm.basictext += vm.txtsearchByName + ", ";
        if (vm.profilePhotos)
            vm.basictext+= "Profile with photo ONLY,";
        if (vm.onlineMatches)
            vm.basictext += "Online matches ONLY,";
        if (vm.prefGender)
            vm.basictext += "Seeking men,";
        else
            vm.basictext += "Seeking women,";
        if (vm.minAge && vm.maxAge)
            vm.basictext += " Ages " + vm.minAge + "-" + vm.maxAge + ",";
        vm.basictext += getLocBindText(vm.locType, vm.radius, vm.unitTxt);
    };

    //Page Load event
    vm.getMemInfo(vm.bindMemInfo);
    vm.getLocReadius(vm.bindLocReadius);
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH API CALL ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.busy = false;
    vm.stopScroll = false;
    vm.showRslt = null;
    vm.pgNo = 1;
    vm.pgSize = 200;
    vm.serviceRecCnt = 200;
    vm.srchRslt = [];
    vm.localPgSize = 20;
    vm.limitToMemTileCnt = 20;
    vm.sortOrder = 1;
    // 2 - pyar %, 3 - name, 4 - Recently online,5 - Distance 
    vm.sortBy = 2;

    vm.search = function () {
        showLoader();
        //wait untill to get countryId if we select current location
        if (vm.locType == 2 && !vm.countryId) {
            $timeout(function () {
                vm.search();
                return;
            }, 100);
        }
        else {
            vm.showRslt = null;
            vm.srchType = 1;
            vm.srchRslt = [];
            vm.limitToMemTileCnt = 20;
            vm.srchObj = vm.getSrchObj();
            vm.showSrchFields = false;
            vm.stopScroll = false;
            vm.searchMembers();
            vm.basicText();
            vm.setBodyStyle();
        }

    };

    vm.resetSrch = function () {
        vm.pgNo = 1;
        vm.limitToMemTileCnt = 20;
        vm.bindMemInfo();
        vm.basicText();
        if (vm.showSrchFields == false) {
            window.scroll(0, 0);
            vm.setBodyStyle();
        }
        vm.srchEdit();
    };

    vm.setBodyStyle = function () {
        var styles = $("body").attr("style").split(";");
        styles = styles[0] + ";" + styles[1] + ";margin-top:65px;margin-bottom:0px;"
        $("body").attr("style", styles);

    };

    vm.srchEdit = function () {
        hideLoader();
        vm.srchType = 1;
        vm.showSrchFields = true;
        window.scroll(0, 0);
    };

    vm.searchMembers = function () {
        showLoader();
        vm.busy = true;
        if (vm.srchType == 1) {
            vm.srchRspMsg = "Success! I think we did good!";
            basicsrchSrvc.getSearchResponse(vm.srchObj, vm.pgNo, vm.pgSize, vm.sortBy, vm.sortOrder, function (response, status) {
                vm.bindSrchResp(response, status);
            });
        }
        else if (vm.srchType == 2) {
            vm.srchRspMsg = "Success! We found matches for '" + vm.sugName + "'";
            basicsrchSrvc.getMemSuggestionSrch(vm.srchSugnObj, vm.pgNo, vm.pgSize, vm.sortBy, vm.sortOrder, function (response, status) {
                vm.bindSrchResp(response, status)
            });
        }
    };

    vm.bindSrchResp = function (response, status) {
        if (status == 200 && response.length > 0) {
            vm.showRslt = true;
            angular.forEach(response, function (data) {
                vm.srchRslt.push(data);
            });

            if (response.length < vm.pgSize)
                vm.stopScroll = true;

            if (vm.pgNo == 1 && response.length <= 5) {
                if (vm.srchType == 1)
                    vm.srchRspMsg = "Oh no… looks kinda deserted here. Try expanding your filter!";
                else if (vm.srchType == 2)
                    vm.srchRspMsg = "Oh no… looks kinda deserted here for '" + vm.sugName + "'. Try another filter!";
            }
        } else if (status == 204 || response.length == 0) {
            vm.stopScroll = true;
            vm.showRslt = false;
        }
        vm.busy = false;
        hideLoader();
    };

    vm.getSrchObj = function () {
        var cntryId, lat, long;
        if (vm.locType == 1) {
            cntryId = vm.memInfo.countryId;
            lat = vm.memInfo.lat;
            long = vm.memInfo.long;
        } else if (vm.locType == 2) {
            cntryId = vm.countryId;
            lat = vm.lat;
            long = vm.long;
        } else if (vm.locType == 3) {
            cntryId = vm.countryId;
            lat = vm.OtherLocLatitude;
            long = vm.OtherLocLongitude;
        }
        return {
            "memberId": vm.mId(),
            "firstName": vm.txtsearchByName,
            "isProfilePicUpld": vm.profilePhotos,
            "isOnline": vm.onlineMatches,
            "gender": vm.prefGender,
            "genderPref": vm.gender(),
            "minAge": parseInt(vm.minAge),
            "maxAge": parseInt(vm.maxAge),
            "locRadius": parseInt(vm.radius),
            "locRadiusDistance": prepareRadiusVal(vm.radius, vm.units()),
            "countryId": cntryId,
            "lat": lat,
            "long": long
        };
    };

    //Hobby based search 
    vm.bindSrchSugns = function (refId, refType, sugName) {
        vm.sugName = sugName;
        basicsrchSrvc.getMemberBasicSearchSuggestionInfo(vm.mId(), function (response, status) {
            if (status == 200) {
                vm.suggestion = refId;
                vm.suggestionType = refType;
                var minAge = 0, maxAge = 0;
                if (response.minAge)
                    minAge = response.minAge;
                else
                    minAge = vm.minAge;
                if (response.maxAge)
                    maxAge = response.maxAge;
                else
                    maxAge = vm.maxAge;

                angular.forEach(vm.ddlRadius, function (data) {
                    if (data.rdId == response.locRadius) {
                        vm.srchSugnObj = {
                            "memberId": vm.mId(),
                            "gender": vm.memInfo.genderPref,
                            "genderPref": vm.memInfo.gender,
                            "minAge": vm.minAge,
                            "maxAge": vm.maxAge,
                            "locRadius": response.locRadius,
                            "locRadiusDistance ": calculateRadius(vm.units(), response.locRadius),
                            "countryId": response.countryId,
                            "lat": response.latitude,
                            "long": response.longitute,
                            "suggestionType": vm.suggestionType,
                            "suggestion": vm.suggestion
                        };
                        showLoader();
                        vm.showRslt = null;
                        vm.srchRslt = [];
                        vm.limitToMemTileCnt = 20;
                        vm.showSrchFields = false;
                        vm.stopScroll = false;
                        vm.basicText();
                        vm.setBodyStyle();
                        vm.searchMembers();
                    }
                });
            }
        });
    };

    $scope.scrollLoad = function () {
        vm.limitToMemTileCnt += vm.localPgSize;
        if (vm.limitToMemTileCnt >= vm.srchRslt.length && vm.stopScroll == false) {
            console.log("call service");
            vm.pgNo++;
            vm.searchMembers();
        }
    };

    vm.getPP = function (pp, gender) {
        if (pp) return "https://pccdn.pyar.com" + pp;
        else if (gender == true) return "https://pccdn.pyar.com/pcmbr/defaults/profilemtnb.jpg";
        else if (gender == false) return "https://pccdn.pyar.com/pcmbr/defaults/profileftnb.jpg";
    };

    //calculate age for sear tails
    vm.calculateAge = function (dob) { return calculateAge(dob); };

    vm.getPyarPernt = function (val) {
        if (val == -1 || val == -2)
            return "?"
        else
            return val;
    };

    vm.getMatchQ = function (val) {
        if (val == -1 || val == -2)
            return "";
        else
            return "%";
    };

    vm.setTrphyImg = function (trophies) {
        return vm.trphyImg = getTrophies(trophies);
    };
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH API CALL END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.curMemId = "";
    vm.curMemTileIndex = 0;
    vm.curName = "";
    vm.curGender = null;
    vm.curProfilePic = "";
    vm.favType = null;
    vm.flrtType = null;

    //FAVARITE MODULE START
    vm.setFavIcnImg = function (favType) {
        return favType == 1 ? "https://pccdn.pyar.com/pcimgs/m/favact.png" : "https://pccdn.pyar.com/pcimgs/m/fav.png";
    };

    vm.setFlirtIcnImg = function (flirttype) {
        return flirttype == 1 ? "https://pccdn.pyar.com/pcimgs/m/flirtact.png" : "https://pccdn.pyar.com/pcimgs/m/flirt.png";
    };

    //FAVARITE MODULE Starts
    vm.favIcnClk = function (memId, Name, favType, Gender, index) {
        vm.curMemTileIndex = index;
        vm.curMemId = memId;
        $rootScope.$broadcast("FavMbrAct", memId, Name, favType, Gender, "basicsrchrpage");
    };

    $scope.$on("favRemoveDone", function (e) {
        modifySearchObjFvrt(vm.curMemTileIndex, vm.curMemId, 2);
        $("#imgFav" + vm.curMemTileIndex).attr("src", "https://pccdn.pyar.com/pcimgs/m/fav.png");
    });

    $scope.$on("favAddDone", function (e) {
        modifySearchObjFvrt(vm.curMemTileIndex, vm.curMemId, 1);
        $("#imgFav" + vm.curMemTileIndex).attr("src", "https://pccdn.pyar.com/pcimgs/m/favact.png");
    });

    //modifyType 1 for add and 2 for remove
    function modifySearchObjFvrt(index, memId, modifyType) {
        var memTile = vm.srchRslt[index];
        if (memTile.memId == memId && modifyType == 1)
            vm.srchRslt[index].fav = 1;
        else if (memTile.memId == memId && modifyType == 2)
            vm.srchRslt[index].fav = 0;
    };
    //FAVARITE MODULE END

    //FLIRT MODULE START  
    vm.FlrtHvrDv = false;
    vm.flirtIcnClk = function (memId, Name, favType, Gender, flirtType, index) {
        vm.curMemTileIndex = index;
        vm.curMemId = memId;
        $rootScope.$broadcast("FlirtMbrAct", memId, Name, favType, Gender, flirtType);
    };

    $scope.$on("FlirtAddDone", function (e) {
        modifySearchObjFlrt(vm.curMemTileIndex, vm.curMemId);
        $("#imgFlirt" + vm.curMemTileIndex).attr("src", "https://pccdn.pyar.com/pcimgs/m/flirtact.png");
    });

    //modifyType 1 for add flirt and 2 for remove flirt
    function modifySearchObjFlrt(index, memId) {
        var memTile = vm.srchRslt[index];
        if (memTile.memId == memId)
            vm.srchRslt[index].flirt = 1;
    };
    //FLIRT MODULE START END

    //Actions MODULE START
    vm.memHideCheck = function (memHideId, firstName, gender, index) {
        vm.curMemTileIndex = index;
        $rootScope.$broadcast("MbrOtherAct", memHideId, firstName, gender);
    };

    // BLOCK MEMBER START
    $scope.$on("blockDone", function (e, tmId) {
        vm.srchRslt.splice(vm.curMemTileIndex, 1);
    });
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS END )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    //goto profile page
    vm.gotoProfile = function (mId, index) {
        vm.curMemTileIndex = index;
        vm.curMemId = mId;
        vm.mmcScrollTo = $(window).scrollTop();
        vm.mmc = true;
        $rootScope.$broadcast("openMatch", getSessionSrvc.pce(mId), "BS");
    };

    $scope.$on("closeMatch", function (e, refPgType) {
        if (refPgType == "BS") {
            vm.mmc = false;
            $timeout(function () { window.scrollTo(0, vm.mmcScrollTo); }, 0);
        }
    });

    $scope.$on("srchSugns", function (e) {
        $timeout(function () { vm.mmc = false; }, 200);
        vm.bindMemInfo();
    });

    //open messanger
    vm.openChat = function (tmId, fn) {
        try {
            if (vm.sId() == 2) {
                vm.mmcScrollTo = $(window).scrollTop();
                vm.mmc = true;
                $rootScope.$broadcast("openMMC", tmId, fn, "BS");
            }
            else {
                $rootScope.$broadcast("showPremiumPopup", "RM");
            }
        } catch (e) {
            console.log("basic search openChat  --  " + e.message);
            alert("basic search openChat  --  " + e.message);
        }
    };

    $scope.$on("closeMMC", function (e, refPgType) {
        if (refPgType == "BS") {
            vm.mmc = false;
            $timeout(function () { window.scrollTo(0, vm.mmcScrollTo); }, 0);
        }
    });
    //End here
}]);