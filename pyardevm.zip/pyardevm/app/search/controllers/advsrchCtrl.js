﻿angular.module("app").controller('advsrchCtrl', ['advsrchSrvc', 'getSessionSrvc', 'cmnSrvc', '$scope', '$window', '$rootScope', '$timeout', 'hbySearchFact', '$location', '$state', function (advsrchSrvc, getSessionSrvc, cmnSrvc, $scope, $window, $rootScope, $timeout, hbySearchFact, $location, $state) {
    var vm = this;
    vm.sId = function () { return getSessionSrvc.p_sub(); };
    if (vm.sId() == 1) { $state.go("basicsearch"); return; }
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.gender = function () { return getSessionSrvc.p_gndr(); };
    vm.cntryId = function () { return getSessionSrvc.p_cntryId(); };
    vm.country = function () { return getSessionSrvc.p_cntry(); };
    vm.units = function () { return getSessionSrvc.p_uts(); };
    setFooterIcon("srch");
    $window.localStorage.removeItem("saveSrchObj");
    vm.radius = [];
    $rootScope.dvToggle = true;
    if ($rootScope.showSrchBtn != null)
        vm.showSrchBtn = $rootScope.showSrchBtn;
    else {
        vm.showSrchBtn = true;
        $rootScope.showSrchBtn = true;
    }

    vm.srchType = 1;
    vm.searchObj = null;
    vm.txtlength = 55;
    vm.basictext = vm.abtmetext = vm.personalitytext = vm.appearanctext = vm.lftext = vm.hobbietext = "";
    //search
    vm.pgNo = 1;
    vm.pgSize = 200;
    vm.srchRslt = [];
    vm.localPgSize = 20;
    vm.limitToMemTileCnt = 20;
    vm.isBSInfo = false;
    vm.stopScroll = false;
    vm.showrsltErr = false;
    vm.shwempty = false;
    vm.sortOrder = 1;
    // 2 - pyar %, 3 - name, 4 - Recently online,5 - Distance 
    vm.sortBy = 2;
    vm.sugName = "";
    vm.hbySearch = hbySearchFact.gethbySearchData();//check hobby search

    if (vm.units() == 1)
        vm.unitsTxt = "Miles";
    else
        vm.unitsTxt = "Kms";

    // autoscroll to previous position when inner page navigate 
    if ($rootScope.asScroll)
        $timeout(function () { window.scrollTo(0, $rootScope.asScroll); $rootScope.asScroll = 0; }, 0);

    vm.getMemData = function (callBackFun) {
        showLoader();
        advsrchSrvc.getMemberData(vm.mId(), function (response, status) {
            hideLoader();
            if (status == 200) {
                callBackFun(response);
                vm.isBSInfo = true;
            }
        });
    };

    vm.getSavedSearchById = function (mssId, funCallBack) {
        showLoader();
        advsrchSrvc.getSavedSearchById(mssId, vm.mId(), function (response, status) {
            hideLoader();
            if (status == 200)
                funCallBack(response);
        });
    };

    vm.bindSrchText = function () {
        showLoader();
        vm.savedtext = JSON.parse($window.localStorage.getItem("srchObj")).title;
        vm.basicText();
        vm.aboutText();
        vm.persnalityText();
        vm.appearanceText();
        vm.lifestyetext();
        vm.hobbytext();
        hideLoader();
    };

    vm.basicText = function () {
        vm.basictext = "";
        var basicInfo = JSON.parse($window.localStorage.getItem("srchObj")).basic;
        if (basicInfo) {
            if (basicInfo.firstName)
                vm.basictext += basicInfo.firstName + ", ";
            if (basicInfo.isProfilePicUpld)
                vm.basictext = "Profile with photo ONLY,";
            if (basicInfo.isOnline)
                vm.basictext += " Online matches ONLY,";
            if (basicInfo.genderPref)
                vm.basictext += "Seeking men,";
            else
                vm.basictext += "Seeking women,";
            if (basicInfo.minAge && basicInfo.maxAge)
                vm.basictext += " Ages " + basicInfo.minAge + "-" + basicInfo.maxAge + ",";
            if (basicInfo.locRadius)
                vm.basictext += getLocBindText(basicInfo.locType, basicInfo.locRadius, vm.unitsTxt);
            else
                vm.basictext = vm.basictext.substring(0, vm.basictext.length - 1);
        }
    };

    vm.aboutText = function () {
        vm.abtmetext = "";
        var about = JSON.parse($window.localStorage.getItem("srchObj")).about;
        if (about) {
            if (about.ethinicities.length > 0) {
                angular.forEach(about.ethinicities, function (data) {
                    vm.abtmetext += data.value + "/";
                });
                vm.abtmetext = vm.abtmetext.substring(0, vm.abtmetext.length - 1) + ", ";
            }
            if (about.religions.length > 0) {
                angular.forEach(about.religions, function (data) {
                    vm.abtmetext += data.value + "/";
                });
                vm.abtmetext = vm.abtmetext.substring(0, vm.abtmetext.length - 1) + ", ";
            }         

            if (about.areaWork.length > 0)
                vm.abtmetext += about.areaWork[0].value + ", ";

            if (about.rShipStatus.length > 0) {
                angular.forEach(about.rShipStatus, function (data) {
                    vm.abtmetext += data.value + "/";
                });
                vm.abtmetext = vm.abtmetext.substring(0, vm.abtmetext.length - 1) + ", ";
            }
            if (about.highestEdu.length > 0)
                vm.abtmetext += about.highestEdu[0].value + ", ";

            if (about.htCountry && about.htCity) {
                // for getting the hometown text
                $timeout(function () {
                    $rootScope.$broadcast("GetCity", "abtTxtBind", about.htCountry, about.htCity);
                }, 1000);

                $scope.$on("BindCity", function (e, locId, citObj) {
                    if (locId == "abtTxtBind")
                        vm.abtmetext += "Grew up in " + bindLocation(citObj, vm.cntryId());
                });
            }
            else if (vm.abtmetext)
                vm.abtmetext = vm.abtmetext.substring(0, vm.abtmetext.length - 2);
        }
    };

    vm.persnalityText = function () {
        vm.personalitytext = "";
        var personalityTraits = JSON.parse($window.localStorage.getItem("srchObj")).personalityTraits;
        if (personalityTraits) {
            angular.forEach(personalityTraits.pt, function (data) {
                vm.personalitytext += data.value + ", ";
            });
            if (vm.personalitytext)
                vm.personalitytext = vm.personalitytext.substring(0, vm.personalitytext.length - 2);
        }
    };

    vm.appearanceText = function () {
        vm.appearanctext = "";
        var appearance = JSON.parse($window.localStorage.getItem("srchObj")).appearance;
        if (appearance) {
            if (appearance.eyeColor.length > 0) {
                angular.forEach(appearance.eyeColor, function (data) {
                    vm.appearanctext += data.value + "/";
                });
                vm.appearanctext = vm.appearanctext.substring(0, vm.appearanctext.length - 1) + " eyes, ";
            }

            if (appearance.hairColor.length > 0) {
                angular.forEach(appearance.hairColor, function (data) {
                    vm.appearanctext += data.value + "/";
                });
                vm.appearanctext = vm.appearanctext.substring(0, vm.appearanctext.length - 1) + " hair, ";
            }

            if (appearance.build.length > 0) {
                angular.forEach(appearance.build, function (data) {
                    vm.appearanctext += data.value + "/";
                });
                vm.appearanctext = vm.appearanctext.substring(0, vm.appearanctext.length - 1) + ", ";
            }

            if (appearance.maxHeight.length > 0) {
                angular.forEach(appearance.maxHeight, function (data) {
                    vm.appearanctext += "max:" + data.value + "/";
                });
                vm.appearanctext = vm.appearanctext.substring(0, vm.appearanctext.length - 1) + ", ";
            }

            if (appearance.minHeight.length > 0) {
                angular.forEach(appearance.minHeight, function (data) {
                    vm.appearanctext += "min:" + data.value + "/";
                });
                vm.appearanctext = vm.appearanctext.substring(0, vm.appearanctext.length - 1) + ", ";
            }

            if (vm.appearanctext)
                vm.appearanctext = vm.appearanctext.substring(0, vm.appearanctext.length - 2);
        }
    };

    vm.lifestyetext = function () {
        vm.lftext = "";
        var lifestyle = JSON.parse($window.localStorage.getItem("srchObj")).lifestyle;
        if (lifestyle) {
            if (lifestyle.diet.length > 0) {
                angular.forEach(lifestyle.diet, function (data) {
                    if (data.selected == true)
                        vm.lftext += data.txt + "/";
                });
                if (vm.lftext.length > 0)
                    vm.lftext = vm.lftext.substring(0, vm.lftext.length - 1) + ", ";
            }

            if (lifestyle.smoke.length > 0)
                vm.lftext += lifestyle.smoke[0].txt + " smokes, ";

            if (lifestyle.drink.length > 0)
                vm.lftext += lifestyle.drink[0].txt + " drinks, ";

            if (lifestyle.idealRelationship.length > 0)
                vm.lftext += "Wants a " + lifestyle.idealRelationship[0].txt + " relationship, ";

            if (lifestyle.childrenCnt.length > 0) {
                if (lifestyle.childrenCnt[0].txt == 0)
                    vm.lftext += "Has no children, ";
                else if (lifestyle.childrenCnt[0].txt == 1)
                    vm.lftext += "Has " + lifestyle.childrenCnt[0].txt + " child, ";
                else
                    vm.lftext += "Has " + lifestyle.childrenCnt[0].txt + " children, ";
            }

            if (lifestyle.children.length > 0) {
                if (lifestyle.children[0].val == 1)
                    vm.lftext += "Wants children, ";
                else if (lifestyle.children[0].val == 2)
                    vm.lftext += "Doesn't want children, ";
                else
                    vm.lftext += "May want children, ";
            }

            if (lifestyle.petsCnt.length > 0) {
                if (lifestyle.petsCnt[0].txt == 0)
                    vm.lftext += "Has no pets, ";
                else if (lifestyle.petsCnt[0].txt == 1)
                    vm.lftext += "Has " + lifestyle.petsCnt[0].txt + " pet, ";
                else
                    vm.lftext += "Has " + lifestyle.petsCnt[0].txt + " pets, ";
            }

            if (lifestyle.pets.length > 0) {
                if (lifestyle.pets[0].val == 1)
                    vm.lftext += "Wants pets, ";
                else if (lifestyle.pets[0].val == 2)
                    vm.lftext += "Doesn't want pets, ";
                else
                    vm.lftext += "May want pets, ";
            }

            if (lifestyle.languages.length > 0) {
                angular.forEach(lifestyle.languages, function (data) {
                    vm.lftext += "Prefers " + data.value + "/";
                });
                vm.lftext = vm.lftext.substring(0, vm.lftext.length - 1) + ", ";
            }

            if (lifestyle.fmlyLanguages.length > 0) {
                angular.forEach(lifestyle.fmlyLanguages, function (data) {
                    vm.lftext += "Family speaks " + data.value + "/";
                });
                vm.lftext = vm.lftext.substring(0, vm.lftext.length - 1) + ", ";
            }

            if (lifestyle.religious.length > 0)
                vm.lftext += lifestyle.religious[0].txt + " religious, ";

            if (lifestyle.traditional.length > 0)
                vm.lftext += lifestyle.traditional[0].txt + " traditional, ";
            if (vm.lftext)
                vm.lftext = vm.lftext.substring(0, vm.lftext.length - 2);
        }
    };

    vm.hobbytext = function () {
        vm.hobbietext = "";
        var hobbies = JSON.parse($window.localStorage.getItem("srchObj")).hobbies;
        if (hobbies) {
            angular.forEach(hobbies.hobbies, function (data) {
                vm.hobbietext += data.value + "/";
            });
            vm.hobbietext = vm.hobbietext.substring(0, vm.hobbietext.length - 1);
        }
    };

    vm.removeSearch = function (pgType, event) {
        event.stopPropagation();
        vm.showSrchBtn = true;
        $rootScope.showSrchBtn = true;
        vm.checkAndClearSrchResults();
        var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
        if (srchObj) {
            if (pgType == 2) {
                srchObj.about.ethinicities = [];
                srchObj.about.religions = [];
                srchObj.about.areaWork = [];
                srchObj.about.rShipStatus = [];
                srchObj.about.highestEdu = [];
                srchObj.about.htCountry = null;
                srchObj.about.htZipCode = null;
                srchObj.about.htCity = null;
                vm.abtmetext = "";
            }
            else if (pgType == 3) {
                srchObj.personalityTraits.pt = [];
                srchObj.personalityTraits.ptcId = [];
                vm.personalitytext = "";
            }
            else if (pgType == 4) {
                srchObj.appearance.eyeColor = [];
                srchObj.appearance.hairColor = [];
                srchObj.appearance.minHeight = [];
                srchObj.appearance.maxHeight = [];
                srchObj.appearance.build = [];
                vm.appearanctext = "";
            }
            else if (pgType == 5) {
                srchObj.lifestyle.diet = [];
                srchObj.lifestyle.smoke = [];
                srchObj.lifestyle.drink = [];
                srchObj.lifestyle.idealRelationship = [];
                srchObj.lifestyle.children = [];
                srchObj.lifestyle.childrenCnt = [];
                srchObj.lifestyle.pets = [];
                srchObj.lifestyle.petsCnt = [];
                srchObj.lifestyle.languages = [];
                srchObj.lifestyle.fmlyLanguages = [];
                srchObj.lifestyle.religious = [];
                srchObj.lifestyle.traditional = [];
                vm.lftext = "";
            }
            else if (pgType == 6) {
                srchObj.hobbies.hobbies = [];
                vm.hobbietext = "";
            }
            else if (pgType == 7)
                vm.savedtext = "";
            $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
        }
    };

    vm.searchClear = function (pgType) {
        $window.localStorage.removeItem("srchObj");
        vm.showSrchBtn = true;
        $rootScope.showSrchBtn = true;
        vm.checkAndClearSrchResults();
        createSearchObj()
        //set all fields empty
        vm.basictext = "";
        vm.abtmetext = "";
        vm.lftext = "";
        vm.hobbietext = "";
        vm.personalitytext = "";
        vm.appearanctext = "";
        vm.savedtext = "";
        //set default data
        var dftbasic = JSON.parse($window.localStorage.getItem("defaultbasic"));
        srchObj.basic.gender = vm.gender();
        srchObj.basic.genderPref = dftbasic.genderPref;
        srchObj.basic.minAge = parseInt(dftbasic.minAge);
        srchObj.basic.maxAge = parseInt(dftbasic.maxAge);
        srchObj.basic.locRadius = parseInt(dftbasic.locRadius);
        srchObj.basic.locType = dftbasic.locType;
        srchObj.basic.countryId = dftbasic.countryId;
        srchObj.basic.cityId = dftbasic.cityId;
        srchObj.basic.latitude = dftbasic.latitude;
        srchObj.basic.longitute = dftbasic.longitute;
        srchObj.basic.locRadius = parseInt(dftbasic.locRadius);

        //save to local storage
        $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
        vm.basicText();
        window.scrollTo(0, 0);
        if (pgType)
            vm.navigate(pgType);
    };

    //get member basic info and default save search and bind to view
    vm.bindBasicInfo = function () {
        showLoader();
        vm.getMemData(function (response) {
            vm.meberresponse = response;
            var memAge = calculateAge(vm.meberresponse.dob);
            createSearchObj();
            var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
            srchObj.basic.gender = vm.meberresponse.gender;
            srchObj.basic.genderPref = vm.meberresponse.genderPref;
            srchObj.basic.minAge = (memAge - 5) < 18 ? 18 : memAge - 5;
            srchObj.basic.maxAge = (memAge + 5) > 130 ? 130 : memAge + 5;
            srchObj.basic.countryId = vm.meberresponse.countryId;
            srchObj.basic.cityId = vm.meberresponse.cityId;
            srchObj.basic.latitude = vm.meberresponse.lat;
            srchObj.basic.longitute = vm.meberresponse.long;
            srchObj.basic.locType = 1;
            srchObj.basic.locRadius = 5;
            $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
            $window.localStorage.setItem("defaultbasic", JSON.stringify(srchObj.basic));
            vm.basicText();
            hideLoader();
            //search implementation based on hobby
            if (vm.hbySearch && vm.hbySearch.length > 0)
                vm.bindSrchSugns();
            else if (response.defaultSearchData != null && response.defaultSearchData != undefined)
                vm.bindSaveSrch(response.defaultSearchData, false);
        });
    };

    vm.bindSaveSrch = function (saveSrch, autoSearch) {
        showLoader();
        vm.searchClear();
        var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
        vm.savedtext = srchObj.title = saveSrch.title;
        srchObj.mssId = saveSrch.mssId;
        advsrchSrvc.getAllDdlData(function (response, status) {
            if (status == 200) {
                //basic module
                srchObj.basic["firstName"] = saveSrch.firstName;
                srchObj.basic["isProfilePicUpld"] = saveSrch.isProfilePicUpld;
                srchObj.basic["isOnline"] = saveSrch.isOnline;
                srchObj.basic["genderPref"] = saveSrch.gender;
                srchObj.basic["gender"] = vm.gender();
                srchObj.basic["minAge"] = saveSrch.minAge;
                srchObj.basic["maxAge"] = saveSrch.maxAge;
                srchObj.basic["locRadius"] = parseInt(saveSrch.locRadius);
                srchObj.basic["locType"] = saveSrch.locType;
                if (saveSrch.locType == 1) {
                    var basic = JSON.parse($window.localStorage.getItem("defaultbasic"));
                    srchObj.basic["countryId"] = basic.countryId;
                    srchObj.basic["latitude"] = basic.latitude;
                    srchObj.basic["longitute"] = basic.longitute;
                }
                else if (saveSrch.locType == 2) {
                    if (navigator.geolocation)
                        navigator.geolocation.getCurrentPosition(showPosition, geoError);
                    else
                        alert("Geolocation is not supported by this browser.");
                }
                else if (saveSrch.locType == 3) {
                    srchObj.basic["countryId"] = saveSrch.countryId;
                    srchObj.basic["cityId"] = saveSrch.cityId;
                    srchObj.basic["latitude"] = saveSrch.latitude;
                    srchObj.basic["longitute"] = saveSrch.longitute;
                }

                function geoError(error) {
                    switch (error.code) {
                        case error.PERMISSION_DENIED:
                            {
                                var basic = JSON.parse($window.localStorage.getItem("defaultbasic"));
                                srchObj.basic["countryId"] = basic.countryId;
                                srchObj.basic["latitude"] = basic.latitude;
                                srchObj.basic["longitute"] = basic.longitute;
                                //alert("User denied the request for Geolocation.");
                                break;
                            }
                            //case error.POSITION_UNAVAILABLE:
                            //    alert("Location information is unavailable.");
                            //    break;
                            //case error.TIMEOUT:
                            //    alert("The request to get user location timed out.");
                            //    break;
                            //case error.UNKNOWN_ERROR:
                            //    alert("An unknown error occurred.");
                            //    break;
                    }
                };

                //About module
                //Ethnicicy
                if (saveSrch.ethinicities) {
                    angular.forEach(response.aboutmeData.Ethnicity, function (data) {
                        angular.forEach(saveSrch.ethinicities.split(','), function (id) {
                            if (id == data.ethnicityId)
                                srchObj.about.ethinicities.push({ "id": data.ethnicityId, "value": data.ethnicityName });
                        })
                    })
                }

                //Religion
                if (saveSrch.religions) {
                    angular.forEach(response.aboutmeData.Religion, function (data) {
                        angular.forEach(saveSrch.religions.split(','), function (id) {
                            if (id == data.religionId)
                                srchObj.about.religions.push({ "id": data.religionId, "value": data.religionName });
                        })
                    })
                }

                //Relationship status
                if (saveSrch.rShipStatus) {
                    angular.forEach(response.aboutmeData.Status, function (data) {
                        angular.forEach(saveSrch.rShipStatus.split(','), function (id) {
                            if (id == data.val)
                                srchObj.about.rShipStatus.push({ "id": data.val, "value": data.txt });
                        })
                    })
                }

                //Area of work
                if (saveSrch.areaWork) {
                    for (var i = 0; i < response.aboutmeData.AreaOfWork.length; i++) {
                        if (saveSrch.areaWork == response.aboutmeData.AreaOfWork[i].awId) {
                            srchObj.about.areaWork.push({ "id": response.aboutmeData.AreaOfWork[i].awId, "value": response.aboutmeData.AreaOfWork[i].awName });
                            break;
                        }
                    }
                }

                //Education
                if (saveSrch.highestEdu) {
                    for (var i = 0; i < response.aboutmeData.Degree.length; i++) {
                        if (saveSrch.highestEdu == response.aboutmeData.Degree[i].val)
                            srchObj.about.highestEdu.push({
                                "id": response.aboutmeData.Degree[i].val, "value": response.aboutmeData.Degree[i].txt
                            });
                    }
                }

                //Home town(grow up)
                if (saveSrch.htCountry && saveSrch.htCity) {
                    srchObj.about["htCountry"] = saveSrch.htCountry;
                    srchObj.about["htCity"] = saveSrch.htCity;
                }
                //About module end here

                //personality module
                if (saveSrch.personalityTraits) {
                    angular.forEach(response.ptData, function (data) {
                        angular.forEach(saveSrch.personalityTraits.split(','), function (id) {
                            if (id == data.ptId) {
                                srchObj.personalityTraits.pt.push({ "id": data.ptId, "value": data.personalityName });
                                if (srchObj.personalityTraits.ptcId.indexOf(data.ptcId) == -1)
                                    srchObj.personalityTraits.ptcId.push(data.ptcId);
                            }
                        })
                    });
                }

                //Apperance module
                if (saveSrch.eyeColor) {
                    angular.forEach(response.appearanceData.eyecolor, function (data) {
                        angular.forEach(saveSrch.eyeColor.split(','), function (id) {
                            if (id == data.val)
                                srchObj.appearance.eyeColor.push({ "id": data.val, "value": data.txt.replace("eyes", "") });
                        })
                    });
                }

                if (saveSrch.hairColor) {
                    angular.forEach(response.appearanceData.haircolor, function (data) {
                        angular.forEach(saveSrch.hairColor.split(','), function (id) {
                            if (id == data.val)
                                srchObj.appearance.hairColor.push({ "id": data.val, "value": data.txt.replace("hair", "") });
                        })
                    })
                }

                if (saveSrch.build) {
                    angular.forEach(response.appearanceData.build, function (data) {
                        angular.forEach(saveSrch.build.split(','), function (id) {
                            if (id == data.val)
                                srchObj.appearance.build.push({ "id": data.val, "value": data.txt });
                        })
                    })
                }

                if (saveSrch.minHeight) {
                    angular.forEach(response.appearanceData.height, function (data) {
                        if (data.val == saveSrch.minHeight)
                            srchObj.appearance.minHeight.push({ "id": data.val, "value": data.txt });
                    })
                }

                if (saveSrch.maxHeight) {
                    angular.forEach(response.appearanceData.height, function (data) {
                        if (data.val == saveSrch.maxHeight)
                            srchObj.appearance.maxHeight.push({ "id": data.val, "value": data.txt });
                    })
                }

                //Life style module
                if (saveSrch.diet) {
                    angular.forEach(response.lifeStyleData.diet, function (data) {
                        if (saveSrch.diet.split(',').indexOf(data.val.toString()) == -1)
                            srchObj.lifestyle.diet.push({ "val": data.val, "txt": data.txt, "selected": false });
                        else
                            srchObj.lifestyle.diet.push({ "val": data.val, "txt": data.txt, "selected": true });
                    })
                }

                if (saveSrch.smoke) {
                    angular.forEach(response.lifeStyleData.smoke, function (data) {
                        if (data.val == saveSrch.smoke)
                            srchObj.lifestyle.smoke.push({ "val": data.val, "txt": data.txt });
                    });
                }

                if (saveSrch.drink) {
                    angular.forEach(response.lifeStyleData.drink, function (data) {
                        if (data.val == saveSrch.drink)
                            srchObj.lifestyle.drink.push({ "val": data.val, "txt": data.txt });
                    });
                }

                if (saveSrch.idealRelationship) {
                    angular.forEach(response.lifeStyleData.IdealRelationShip, function (data) {
                        if (data.val == saveSrch.idealRelationship) {
                            srchObj.lifestyle.idealRelationship.push({ "val": data.val, "txt": data.txt });
                        }
                    })
                }

               
                if (saveSrch.childrenCnt) {
                    angular.forEach(response.lifeStyleData.numOfChildren, function (data) {
                        if (data.val == saveSrch.childrenCnt)
                            srchObj.lifestyle.childrenCnt.push({ "val": data.val, "txt": data.txt });
                    });
                }
                if (saveSrch.petsCnt) {
                    angular.forEach(response.lifeStyleData.numOfPets, function (data) {
                        if (data.val == saveSrch.petsCnt)
                            srchObj.lifestyle.petsCnt.push({ "val": data.val, "txt": data.txt });
                    });
                }              

                if (saveSrch.children) {
                    angular.forEach(response.lifeStyleData.childrenPref, function (data) {
                        if (data.val == saveSrch.children)
                            srchObj.lifestyle.children.push({ "val": data.val, "txt": data.txt });
                    });
                }

                if (saveSrch.pets) {
                    angular.forEach(response.lifeStyleData.petPref, function (data) {
                        if (data.val == saveSrch.pets)
                            srchObj.lifestyle.pets.push({ "val": data.val, "txt": data.txt });
                    })
                }

                if (saveSrch.religious) {
                    angular.forEach(response.lifeStyleData.Religious, function (data) {
                        if (data.val == saveSrch.religious)
                            srchObj.lifestyle.religious.push({ "val": data.val, "txt": data.txt });
                    })
                }

                if (saveSrch.traditional) {
                    angular.forEach(response.lifeStyleData.traditional, function (data) {
                        if (data.val == saveSrch.traditional)
                            srchObj.lifestyle.traditional.push({ "val": data.val, "txt": data.txt });
                    })

                }

                if (saveSrch.languages) {
                    angular.forEach(response.lifeStyleData.language, function (data) {
                        angular.forEach(saveSrch.languages.split(','), function (id) {
                            if (id == data.val)
                                srchObj.lifestyle.languages.push({ "id": data.val, "value": data.txt });
                        })
                    })
                }

                if (saveSrch.fmlyLanguages) {
                    angular.forEach(response.lifeStyleData.language, function (data) {
                        angular.forEach(saveSrch.fmlyLanguages.split(','), function (id) {
                            if (id == data.val)
                                srchObj.lifestyle.fmlyLanguages.push({ "id": data.val, "value": data.txt });
                        })
                    })
                }

                //HOBBIES MODULE   
                if (saveSrch.hobbies) {
                    angular.forEach(response.hbyData, function (data) {
                        angular.forEach(saveSrch.hobbies.split(','), function (id) {
                            if (id == data.HobbyId)
                                srchObj.hobbies.hobbies.push({ "id": data.HobbyId, "value": data.HobbyName });
                        })
                    })
                };

                $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
                vm.bindSrchText();
                if (autoSearch) {
                    vm.search();
                }
            }
            hideLoader();
        });
    };

    vm.getRadius = function () {
        advsrchSrvc.prefRadius(function (response, status) {
            if (status == 200)
                vm.radius = response;
        });
    };

    //pageload call evnet
    vm.getRadius();
    showLoader();
    if ($window.localStorage.getItem("srchObj") == null)
        vm.getMemData(vm.bindBasicInfo);
    else {
        if ($rootScope.mssId) {
            vm.getSavedSearchById($rootScope.mssId, function (response) {
                vm.bindSaveSrch(response, true);
            });
            $rootScope.mssId = null;
        }
        else {
            vm.bindSrchText();
            var srchRslt = JSON.parse($window.localStorage.getItem("srchRslt"));
            if (srchRslt) {
                vm.limitToMemTileCnt = srchRslt.limit;
                vm.pgNo = srchRslt.pgNo;
                vm.srchType = srchRslt.srchType;
                vm.sugName = srchRslt.sugName;
                vm.searchObj = srchRslt.searchObj;
                if (vm.srchType == 1)
                    vm.srchRspMsg = "Success! I think we did good!";
                else
                    vm.srchRspMsg = "Success! We found matches for '" + vm.sugName + "'";
                bindSrchResp(srchRslt.srchRslt, 200);
            }
        }
        $window.localStorage.removeItem("srchRslt");
    }
    if (JSON.parse($window.localStorage.getItem("defaultbasic")))
        vm.isBSInfo = true;
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SAVE SEARCH MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.checkSaveSrch = function () {
        showLoader();
        advsrchSrvc.getSaveSearchData(vm.mId(), function (response, status) {
            if (status == 200) {
                if (response.length >= 10)
                    $("#manySavedSearch").modal('show');
                else {
                    vm.srchSvdName = "";
                    $("#mdlSrchName").modal("show");
                    document.getElementById("txtsrchname").focus();
                }
            }
            hideLoader();
        });
    };

    vm.saveSearch = function () {
        if (vm.srchSvdName != "" && vm.srchSvdName.length <= 150) {
            showLoader();
            advsrchSrvc.saveSearch(vm.prepareSearchObject(), vm.srchSvdName, function (response, status) {
                if (response && status == 200) {
                    $("#mdlSrchName").modal("hide");
                    vm.srchSvdName = "";
                } else if (status == 200 && response == false) {
                    $("#mdlSrchName").modal("hide");
                    $("#manySavedSearch").modal('show');
                }
                hideLoader();
            });
        }
    };

    vm.viewSaveSrch = function () {
        $('.modal-backdrop').remove();
        $("body").removeClass("modal-open");
        $window.localStorage.setItem("saveSrchObj", JSON.stringify(vm.prepareSearchObject()));
        $state.go("advsrchsaved");
    };

    vm.limitKeypress = function ($event, value, maxLength) {
        if (value != undefined && value.toString().length >= maxLength)
            $event.preventDefault();
    };
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SAVE SEARCH MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH Navigation start))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.navigate = function (pgType) {
        $rootScope.asScroll = $(window).scrollTop();
        vm.saveSrchResult();
        if (pgType == 1)
            $state.go("advsrchbasics");
        else if (pgType == 2)
            $state.go("advsrchabout");
        else if (pgType == 3)
            $state.go("advsrchprsnltyE");
        else if (pgType == 4)
            $state.go("advsrchaprnce");
        else if (pgType == 5)
            $state.go("advsrchlifestyle");
        else if (pgType == 6)
            $state.go("advsrchhobbies");
        else if (pgType == 7)
            $state.go("advsrchsaved");
    };

    vm.saveSrchResult = function () {
        if (vm.srchRslt.length > 0) {
            var srchRslt = { "srchRslt": vm.srchRslt, "sugName": vm.sugName, "limit": vm.limitToMemTileCnt, "pgNo": vm.pgNo, "srchType": vm.srchType, "searchObj": vm.searchObj };
            $window.localStorage.setItem("srchRslt", JSON.stringify(srchRslt));
        }
        else
            $window.localStorage.removeItem("srchRslt");
    };

    vm.search = function () {
        showLoader();
        var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
        //wait untill to get response
        if (!srchObj) {
            $timeout(function () {
                vm.search();
                return;
            }, 100);
        }
        else {
            vm.sortBy = 2;
            vm.srchRslt = [];
            vm.limitToMemTileCnt = 20;
            vm.pgNo == 1;
            vm.srchType = 1;
            vm.showrsltErr = false;
            vm.shwempty = true;
            vm.stopScroll = false;
            vm.searchObj = vm.prepareSearchObject();
            vm.searchMembers();
        }
    };

    vm.searchMembers = function () {
        showLoader();
        vm.busy = true;
        // $timeout(function () { $('html,body').animate({ scrollTop: $('#dvEmpty').offset().top }, 'slow'); }, 0);
        if (vm.srchType == 1) {
            vm.srchRspMsg = "Success! I think we did good!";
            advsrchSrvc.getSearchResponse(vm.searchObj, vm.pgNo, vm.pgSize, vm.sortBy, vm.sortOrder, function (response, status) {
                bindSrchResp(response, status);
                if (vm.pgNo == 1) {
                    vm.showSrchBtn = false;
                    $rootScope.showSrchBtn = false;
                }
            });
        }
        else if (vm.srchType == 2) {
            vm.srchRspMsg = "Success! We found matches for '" + vm.sugName + "'";
            advsrchSrvc.getMemSuggestionSrch(vm.searchObj, vm.pgNo, vm.pgSize, vm.sortBy, vm.sortOrder, function (response, status) {
                bindSrchResp(response, status);
                if (vm.pgNo == 1) {
                    vm.showSrchBtn = false;
                    $rootScope.showSrchBtn = false;
                }
            });
        }
    };

    function bindSrchResp(response, status) {
        vm.busy = false;
        $timeout(function () { $('body').animate({ scrollTop: $('#dvEmpty').position().top }, 'slow'); }, 0);
        if (status == 200 && response.length > 0) {
            angular.forEach(response, function (data) {
                vm.srchRslt.push(data);
            });

            if (response.length < vm.pgSize)
                vm.stopScroll = true;

            if (vm.pgNo == 1 && response.length <= 5) {
                if (vm.srchType == 1)
                    vm.srchRspMsg = "Oh no… looks kinda deserted here. Try expanding your filter!";
                else if (vm.srchType == 2)
                    vm.srchRspMsg = "Oh no… looks kinda deserted here for '" + vm.sugName + "'. Try another filter!";
            }
            vm.shwempty = false;
            vm.showrsltErr = false;
        } else if (status == 204 || response.length == 0) {
            vm.stopScroll = true;
            vm.showrsltErr = true;
            vm.shwempty = false;
        }
        hideLoader();
    };

    $scope.scrollLoad = function () {
        vm.limitToMemTileCnt += vm.localPgSize;
        if (vm.limitToMemTileCnt >= vm.srchRslt.length && vm.stopScroll == false) {
            vm.pgNo++;
            vm.searchMembers();
        }
    };

    vm.bindSrchSugns = function () {
        showLoader();
        vm.hbySearch = JSON.parse(vm.hbySearch);
        hbySearchFact.sethbySearchData(null);
        vm.sugName = vm.hbySearch.sugName;
        advsrchSrvc.getSrchSugnInfo(vm.mId(), function (response, status) {
            hideLoader();
            if (status == 200) {
                var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
                vm.sortBy = 2;
                var minAge = 0, maxAge = 0;
                if (response.minAge)
                    minAge = response.minAge;
                else
                    minAge = srchObj.basic.minAge;
                if (response.maxAge)
                    maxAge = response.maxAge;
                else
                    maxAge = srchObj.basic.maxAge;
                $.each(vm.radius, function (i, e) {
                    if (e.rdId == response.locRadius) {
                        vm.searchObj = {
                            "memberId": vm.mId(),
                            "gender": srchObj.basic.genderPref,
                            "genderPref": srchObj.basic.gender,
                            "minAge": minAge,
                            "maxAge": maxAge,
                            "locRadius": response.locRadius,
                            "locRadiusDistance ": calculateRadius(vm.units(), e.radius),
                            "countryId": response.countryId,
                            "lat": response.latitude,
                            "long": response.longitute,
                            "suggestionType": vm.hbySearch.refType,
                            "suggestion": vm.hbySearch.refId
                        };
                        vm.srchType = 2;
                        vm.shwempty = true;
                        srchObj.hobbies.hobbies.push({ "id": vm.hbySearch.refId, "value": vm.hbySearch.sugName });
                        $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
                        vm.bindSrchText();
                        vm.searchMembers();
                        return false;
                    }
                });
            }
        });
    };

    vm.prepareSearchObject = function () {
        var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
        var searchObj = null;
        if (srchObj) {
            //set propeties
            searchObj =
                {
                    "memberId": vm.mId(), "firstName": "", "gender": vm.gender(), "genderPref": null, "minAge": null, "maxAge": null,
                    "locRadius": null, "locType": null, "countryId": null, "cityId": null, "latitude": null, "longitute": null,
                    "locRadiusDistance": null, "isOnline": false, "isProfilePicUpld": false, "ethinicities": "", "religions": "",
                    "areaWork": null, "rShipStatus": "", "highestEdu": null, "htCountry": null, "htCity": null,
                    "personalityTraits": "", "eyeColor": "", "hairColor": "", "minHeight": null, "maxHeight": null, "build": "",
                    "diet": "", "smoke": null, "drink": null, "idealRelationship": null, "children": null, "childrenCnt": "",
                    "pets": null, "petsCnt": "", "languages": "", "fmlyLanguages": "", "religious": null, "traditional": null,
                    "hobbies": "", "sId": vm.sId()
                };
            //basic start
            searchObj["memberId"] = vm.mId();
            searchObj["sId"] = vm.sId();
            searchObj["firstName"] = !srchObj.basic.firstName ? "" : srchObj.basic.firstName;
            searchObj["gender"] = srchObj.basic.genderPref;
            searchObj["genderPref"] = vm.gender();
            searchObj["minAge"] = parseInt(srchObj.basic.minAge);
            searchObj["maxAge"] = parseInt(srchObj.basic.maxAge);
            searchObj["isOnline"] = srchObj.basic.isOnline;
            searchObj["isProfilePicUpld"] = srchObj.basic.isProfilePicUpld;
            searchObj["locRadius"] = parseInt(srchObj.basic.locRadius);
            searchObj["locType"] = srchObj.basic.locType;
            searchObj["countryId"] = srchObj.basic.countryId;
            searchObj["cityId"] = srchObj.basic.cityId;
            searchObj["latitude"] = srchObj.basic.latitude;
            searchObj["longitute"] = srchObj.basic.longitute;
            for (var i = 0; i < vm.radius.length; i++) {
                if (vm.radius[i].rdId == srchObj.basic.locRadius) {
                    searchObj["locRadiusDistance"] = calculateRadius(vm.units(), vm.radius[i].radius);
                    break;
                }
            }
            //basic end

            //about start
            if (srchObj.about.ethinicities.length > 0) {
                var checkedSrchECIds = "";
                angular.forEach(srchObj.about.ethinicities, function (data) {
                    checkedSrchECIds += data.id + ",";
                });
                searchObj["ethinicities"] = checkedSrchECIds.substring(0, checkedSrchECIds.length - 1);
            }
            else
                searchObj["ethinicities"] = "";

            if (srchObj.about.areaWork.length > 0)
                searchObj["areaWork"] = srchObj.about.areaWork[0].id;
            else
                searchObj["areaWork"] = null;

            if (srchObj.about.rShipStatus.length > 0) {
                var checkedSrchRSSIds = "";
                angular.forEach(srchObj.about.rShipStatus, function (data) {
                    checkedSrchRSSIds += data.id + ",";
                });
                searchObj["rShipStatus"] = checkedSrchRSSIds.substring(0, checkedSrchRSSIds.length - 1);
            }
            else
                searchObj["rShipStatus"] = "";

            if (srchObj.about.religions.length > 0) {
                var checkedmpRlgnIds = "";
                angular.forEach(srchObj.about.religions, function (data) {
                    checkedmpRlgnIds += data.id + ",";
                });
                searchObj["religions"] = checkedmpRlgnIds.substring(0, checkedmpRlgnIds.length - 1);
            }
            else
                searchObj["religions"] = "";

            if (srchObj.about.highestEdu.length > 0)
                searchObj["highestEdu"] = srchObj.about.highestEdu[0].id;
            else
                searchObj["highestEdu"] = null;

            searchObj["htCountry"] = srchObj.about.htCountry;
            searchObj["htCity"] = srchObj.about.htCity;
            //about end

            //personality Traits start
            if (srchObj.personalityTraits.pt.length > 0) {
                var checkedTrIds = "";
                angular.forEach(srchObj.personalityTraits.pt, function (data) {
                    checkedTrIds += data.id + ",";
                });
                searchObj["personalityTraits"] = checkedTrIds.substring(0, checkedTrIds.length - 1);
            }
            else
                searchObj["personalityTraits"] = "";
            //personality Traits end

            //appearance start
            if (srchObj.appearance.eyeColor.length > 0) {
                var eyclrIds = "";
                angular.forEach(srchObj.appearance.eyeColor, function (data) {
                    eyclrIds += data.id + ",";
                });
                searchObj["eyeColor"] = eyclrIds.substring(0, eyclrIds.length - 1);
            }
            else
                searchObj["eyeColor"] = "";

            if (srchObj.appearance.hairColor.length > 0) {
                var hairclrIds = "";
                angular.forEach(srchObj.appearance.hairColor, function (data) {
                    hairclrIds += data.id + ",";
                });
                searchObj["hairColor"] = hairclrIds.substring(0, hairclrIds.length - 1);
            }
            else
                searchObj["hairColor"] = "";

            if (srchObj.appearance.build.length > 0) {
                var checkedSrchBuildIds = "";
                angular.forEach(srchObj.appearance.build, function (data) {
                    checkedSrchBuildIds += data.id + ",";
                });
                searchObj["build"] = checkedSrchBuildIds.substring(0, checkedSrchBuildIds.length - 1);
            }
            else
                searchObj["build"] = "";

            if (srchObj.appearance.minHeight.length > 0)
                searchObj["minHeight"] = srchObj.appearance.minHeight[0].id;
            else
                searchObj["minHeight"] = null;

            if (srchObj.appearance.maxHeight.length > 0)
                searchObj["maxHeight"] = srchObj.appearance.maxHeight[0].id;
            else
                searchObj["maxHeight"] = null;
            //apperance end

            //lifestyle start
            if (srchObj.lifestyle.diet.length > 0) {
                var checkedmpDtIds = "";
                angular.forEach(srchObj.lifestyle.diet, function (data) {
                    if (data.selected == true)
                        checkedmpDtIds += data.val + ","
                });
                searchObj["diet"] = checkedmpDtIds.substring(0, checkedmpDtIds.length - 1);
            }
            else
                searchObj["diet"] = "";

            if (srchObj.lifestyle.smoke.length > 0)
                searchObj["smoke"] = srchObj.lifestyle.smoke[0].val;
            else
                searchObj["smoke"] = null;

            if (srchObj.lifestyle.drink.length > 0)
                searchObj["drink"] = srchObj.lifestyle.drink[0].val;
            else
                searchObj["drink"] = null;

            if (srchObj.lifestyle.childrenCnt.length > 0)
            searchObj["childrenCnt"] = srchObj.lifestyle.childrenCnt[0].val;
            else
                searchObj["childrenCnt"] = "";
            if (srchObj.lifestyle.children.length > 0)
                searchObj["children"] = srchObj.lifestyle.children[0].val;
            else
                searchObj["children"] = null;

            if (srchObj.lifestyle.religious.length > 0)
                searchObj["religious"] = srchObj.lifestyle.religious[0].val;
            else
                searchObj["religious"] = null;

            if (srchObj.lifestyle.pets.length > 0)
                searchObj["pets"] = srchObj.lifestyle.pets[0].val;
            else
                searchObj["pets"] = null;

            if (srchObj.lifestyle.petsCnt.length > 0)
                searchObj["petsCnt"] = srchObj.lifestyle.petsCnt[0].val;
            else
                searchObj["petsCnt"] = "";         

            if (srchObj.lifestyle.traditional.length > 0)
                searchObj["traditional"] = srchObj.lifestyle.traditional[0].val;
            else
                searchObj["traditional"] = null;

            if (srchObj.lifestyle.idealRelationship.length > 0)
                searchObj["idealRelationship"] = srchObj.lifestyle.idealRelationship[0].val;
            else
                searchObj["idealRelationship"] = null;

            if (srchObj.lifestyle.languages.length > 0) {
                var checkedmpPrefLangIds = "";
                angular.forEach(srchObj.lifestyle.languages, function (data) {
                    checkedmpPrefLangIds += data.id + ","
                });
                searchObj["languages"] = checkedmpPrefLangIds.substring(0, checkedmpPrefLangIds.length - 1);
            }
            else
                searchObj["languages"] = "";

            if (srchObj.lifestyle.fmlyLanguages.length > 0) {
                var checkedmpFmlyLangIds = "";
                angular.forEach(srchObj.lifestyle.fmlyLanguages, function (data) {
                    checkedmpFmlyLangIds += data.id + ",";
                });
                searchObj["fmlyLanguages"] = checkedmpFmlyLangIds.substring(0, checkedmpFmlyLangIds.length - 1);
            }
            else
                searchObj["fmlyLanguages"] = "";

            if (srchObj.hobbies.hobbies.length > 0) {
                var activehbIds = "";
                angular.forEach(srchObj.hobbies.hobbies, function (data) {
                    activehbIds += data.id + ",";
                });
                searchObj["hobbies"] = activehbIds.substring(0, activehbIds.length - 1);
            }
            else
                searchObj["hobbies"] = "";
            //hobbies end
        }
        return searchObj;
    };

    function showPosition(position) {
        var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
        srchObj.basic["latitude"] = position.coords.latitude;
        srchObj.basic["longitute"] = position.coords.longitude;
        $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
        if (position.coords.latitude != "" && position.coords.longitude != "") {
            getCountryCodeUsingLatLong(cmnSrvc, position.coords.latitude, position.coords.longitude, function (response) {
                var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
                srchObj.basic["countryId"] = response;
                $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
            });
        }
    };

    vm.getAge = function (val) { return calculateAge(val); };

    vm.getPP = function (pp, gender) {
        if (pp) return "https://pccdn.pyar.com" + pp;
        else if (gender == true) return "https://pccdn.pyar.com/pcmbr/defaults/profilemtnb.jpg";
        else if (gender == false) return "https://pccdn.pyar.com/pcmbr/defaults/profileftnb.jpg";
    };

    vm.getLocText = function (locObj) {
        return vm.curLocation = bindHtLocation(locObj.city, locObj.state, locObj.country, vm.country(), vm.units(), locObj.distance);
    };

    vm.getPyarPernt = function (val) {
        if (val == -1 || val == -2)
            return "?"
        else
            return val;
    };

    vm.getMatchQ = function (val) {
        if (val == -1 || val == -2)
            return "";
        else
            return "%";
    };

    vm.setTrphyImg = function (trophies) {
        return vm.trphyImg = getTrophies(trophies);
    };
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SEARCH Navigation End))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.curMemId = "";
    vm.curMemTileIndex = 0;
    vm.curName = "";
    vm.curGender = null;
    vm.curProfilePic = "";
    vm.favType = null;
    vm.flrtType = null;

    //FAVARITE MODULE START
    vm.setFavIcnImg = function (favType) {
        return favType == 1 ? "https://pccdn.pyar.com/pcimgs/m/favact.png" : "https://pccdn.pyar.com/pcimgs/m/fav.png";
    };

    vm.setFlirtIcnImg = function (flirttype) {
        return flirttype == 1 ? "https://pccdn.pyar.com/pcimgs/m/flirtact.png" : "https://pccdn.pyar.com/pcimgs/m/flirt.png";
    };

    //FAVARITE MODULE Starts
    vm.favIcnClk = function (memId, Name, favType, Gender, index) {
        vm.curMemTileIndex = index;
        vm.curMemId = memId;
        $rootScope.$broadcast("FavMbrAct", memId, Name, favType, Gender, "searchpage");
    };

    $scope.$on("favRemoveDone", function (e) {
        modifySearchObjFvrt(vm.curMemTileIndex, vm.curMemId, 2);
        $("#imgFav" + vm.curMemTileIndex).attr("src", "https://pccdn.pyar.com/pcimgs/m/fav.png");
    });

    $scope.$on("favAddDone", function (e) {
        modifySearchObjFvrt(vm.curMemTileIndex, vm.curMemId, 1);
        $("#imgFav" + vm.curMemTileIndex).attr("src", "https://pccdn.pyar.com/pcimgs/m/favact.png");
    });

    //modifyType 1 for add and 2 for remove
    function modifySearchObjFvrt(index, memId, modifyType) {
        var memTile = vm.srchRslt[index];
        if (memTile.memId == memId && modifyType == 1)
            vm.srchRslt[index].fav = 1;
        else if (memTile.memId == memId && modifyType == 2)
            vm.srchRslt[index].fav = 0;
        $window.localStorage.setItem("srchresult", JSON.stringify(vm.srchRslt));
    };
    //FAVARITE MODULE END

    //FLIRT MODULE START  
    vm.FlrtHvrDv = false;
    vm.flirtIcnClk = function (memId, Name, favType, Gender, flirtType, index) {
        vm.curMemTileIndex = index;
        vm.curMemId = memId;
        $rootScope.$broadcast("FlirtMbrAct", memId, Name, favType, Gender, flirtType);
    };

    $scope.$on("FlirtAddDone", function (e) {
        modifySearchObjFlrt(vm.curMemTileIndex, vm.curMemId);
        $("#imgFlirt" + vm.curMemTileIndex).attr("src", "https://pccdn.pyar.com/pcimgs/m/flirtact.png");
    });

    //modifyType 1 for add flirt and 2 for remove flirt
    function modifySearchObjFlrt(index, memId) {
        var memTile = vm.srchRslt[index];
        if (memTile.memId == memId) {
            vm.srchRslt[index].flirt = 1;
        }
        $window.localStorage.setItem("srchresult", JSON.stringify(vm.srchRslt));
    };
    //FLIRT MODULE START END

    //Actions MODULE START
    vm.memHideCheck = function (memHideId, firstName, gender, index) {
        vm.curMemTileIndex = index;
        $rootScope.$broadcast("MbrOtherAct", memHideId, firstName, gender);
    }

    // BLOCK MEMBER START
    $scope.$on("blockDone", function (e, tmId) {
        vm.srchRslt.splice(vm.curMemTileIndex, 1);
        $window.localStorage.setItem("srchresult", JSON.stringify(vm.srchRslt));
    });
    //BLOCK MEMBER END

    //Actions MODULE END
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT SEARCH MEMBER ACTIONS END )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.gotoProfile = function (mId, index) {
        vm.curMemTileIndex = index;
        vm.curMemId = mId;
        vm.mmcScrollTo = $(window).scrollTop();
        vm.mmc = true;
        $rootScope.$broadcast("openMatch", getSessionSrvc.pce(mId), "AS");
    };

    $scope.$on("closeMatch", function (e, refPgType) {
        if (refPgType == "AS") {
            vm.mmc = false;
            $timeout(function () { window.scrollTo(0, vm.mmcScrollTo); }, 0);
        }
    });

    $scope.$on("srchSugns", function (e) {
        vm.hbySearch = hbySearchFact.gethbySearchData();//check hobby search
        vm.searchClear(null);
        $window.localStorage.removeItem("srchRslt");
        $timeout(function () { vm.mmc = false; }, 200);
        vm.bindSrchSugns();
    });

    //open messanger
    vm.mmc = false;
    vm.mmcScrollTo = 0;

    vm.openChat = function (tmId, fn) {
        try {
            if (vm.sId() == 2) {
                vm.mmcScrollTo = $(window).scrollTop();
                vm.mmc = true;
                $rootScope.$broadcast("openMMC", tmId, fn, "AS");
            }
            else
                $rootScope.$broadcast("showPremiumPopup", "RM");
        } catch (e) {
            console.log("search openChat  --  " + e.message);
            alert("search openChat  --  " + e.message);
        }
    }

    $scope.$on("closeMMC", function (e, refPgType) {
        if (refPgType == "AS") {
            vm.mmc = false;
            $timeout(function () { window.scrollTo(0, vm.mmcScrollTo); }, 0);
        }
    });
    //End here

    vm.checkAndClearSrchResults = function () {
        if (vm.showSrchBtn) {
            $window.localStorage.removeItem("srchRslt");
            vm.srchRslt = [];
        }
    };
    vm.checkAndClearSrchResults();
    if (vm.srchRslt.length == 0) {
        vm.showSrchBtn = true;
        $rootScope.showSrchBtn = true;
    }
}]);