﻿angular.module("app").controller('advsrchaboutCtrl', ['selfprofileSrvc', 'getSessionSrvc', '$scope', '$window', '$http', '$location', '$rootScope', '$timeout', '$state', function (selfprofileSrvc, getSessionSrvc, $scope, $window, $http, $location, $rootScope, $timeout, $state) {
    var vm = this;
    if ($window.localStorage.getItem("srchObj") == null) { $state.go("advancedsearch"); return; };
    vm.cntryId = function () { return getSessionSrvc.p_cntryId(); };
    vm.about = JSON.parse($window.localStorage.getItem("srchObj")).about;

    vm.ddlAbtMe = function () {
        showLoader();
        // about me dropdowns service called
        selfprofileSrvc.StaticDropDownList(function (response, status) {
            vm.ethnicitiesDdl = response.Ethnicity;
            vm.religionsDdl = response.Religion;
            vm.areaofworksDdl = response.AreaOfWork;
            vm.statusDdl = response.Status;
            vm.degreeDdl = response.Degree;
            vm.countriesDdl = response.Countries;
            hideLoader();
        });
    }
    vm.ddlAbtMe();

    //ethnicity
    vm.ethntyAdd = function () {
        var index = -1;
        $.each(vm.about.ethinicities, function (i, e) {
            if (e.id == vm.selectedEtncty.ethnicityId) {
                index = i;
                return false;
            }
        });

        if (index == -1) {
            vm.about.ethinicities.push({
                id: parseInt(vm.selectedEtncty.ethnicityId),
                value: vm.selectedEtncty.ethnicityName,
            });
        }
        vm.selectedEtncty = "Add ethnicity";
    };
    vm.ethntyRemove = function (ethncityId) {
        $.each(vm.about.ethinicities, function (i, e) {
            if (e.id == ethncityId) {
                vm.about.ethinicities.splice(i, 1);
                return false;
            }
        });
    };

    //religion
    vm.rlgnAdd = function () {
        var index = -1;
        $.each(vm.about.religions, function (i, e) {
            if (e.id == vm.selectedRelgn.religionId) {
                index = i;
                return false;
            }
        });
        if (index == -1) {
            vm.about.religions.push({
                id: parseInt(vm.selectedRelgn.religionId),
                value: vm.selectedRelgn.religionName,
            });
        }
        vm.selectedRelgn = "Add Religion";
    };
    vm.rlgnRemove = function (relgionId) {
        $.each(vm.about.religions, function (i, e) {
            if (e.id == relgionId) {
                vm.about.religions.splice(i, 1);
                return false;
            }
        });
    };

    //area of work
    vm.aowRemove = function () { vm.about.areaWork = []; }
    vm.aowAdd = function () {
        vm.about.areaWork.push({
            id: parseInt(vm.selectedAofWrk.awId),
            value: vm.selectedAofWrk.awName
        });
        vm.selectedAofWrk = "Add Area of work";
    };

    //relationship status
    vm.rsStatusAdd = function () {
        var index = -1;
        $.each(vm.about.rShipStatus, function (i, e) {
            if (e.id == vm.selectedRelstatus.val) {
                index = i;
                return false;
            }
        });
        if (index == -1) {
            vm.about.rShipStatus.push({
                id: parseInt(vm.selectedRelstatus.val),
                value: vm.selectedRelstatus.txt,
            });
        }
        vm.selectedRelstatus = "Add Relation status";
    };
    vm.rsStatusRemove = function (rssId) {
        $.each(vm.about.rShipStatus, function (i, e) {
            if (e.id == rssId) {
                vm.about.rShipStatus.splice(i, 1);
                return false;
            }
        });
    };

    //education
    vm.eduRemove = function () { vm.about.highestEdu = []; }
    vm.eduAdd = function () {
        vm.about.highestEdu.push({
            id: parseInt(vm.selectedDgr.val),
            value: vm.selectedDgr.txt
        });
        vm.selectedDgr = "Add Highest degree";
    };
    
    //done
    vm.abtmeDoneclk = function () {
        var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
        $rootScope.showSrchBtn = !(JSON.stringify(vm.about) === JSON.stringify(srchObj.about));
        srchObj.about = vm.about;
        $window.localStorage.setItem("srchObj", JSON.stringify(srchObj));
        $state.go("advancedsearch");
    };

    //cancel
    vm.navigatCancel = function () {
        $state.go("advancedsearch");
    };

    //grow up
    vm.locRemove = function () { vm.about.htCountry = null; vm.about.htCity = null; };

    vm.selectLoc = function () {
        $rootScope.$broadcast("showLocation", "hmeTwnLoc");
    };

    //city intelligence module
    $scope.$on("countryBind", function (e, locId, countryId, data) {
        if (locId == "hmeTwnLoc") {
            vm.about.htCountry = data.countryId;
            vm.about.htCity = data.cityId;
            vm.htlocation = bindLocation(data, vm.cntryId());
            $timeout(function () { window.scrollTo(0, $(window).height()); }, 0);
        }
    });

    $scope.$on("countryUnBind", function (e, locId, data) {
        if (locId=="hmeTwnLoc") {
            var srchObj = JSON.parse($window.localStorage.getItem("srchObj"));
            vm.about.htCountry = srchObj.about.htCountry;
            vm.about.htCity = srchObj.about.htCity;
            if (vm.about.htCountry && vm.about.htCity)
                vm.GetCity("hmeTwnLoc", vm.about.htCountry, vm.about.htCountry, vm.about.htCity);
        }
    });

    $scope.$on("BindCity", function (e, locId, citObj) {
        if (locId == "hmeTwnLoc")
            vm.htlocation = bindLocation(citObj, vm.cntryId());
    });

    vm.GetCity = function (locId, countryId, cityId) {
        $rootScope.$broadcast("GetCity", locId, countryId, cityId);
    };

    if (vm.about.htCountry && vm.about.htCity) {
        $timeout(function () {
            $rootScope.$broadcast("GetCity", "hmeTwnLoc", vm.about.htCountry, vm.about.htCity);
        }, 1000);
    }
}]);