﻿angular.module("app").controller('mpVrfyCtrl', ['getSessionSrvc', 'cmnSrvc', '$rootScope', '$scope', '$state', '$interval', '$timeout', '$window', function (getSessionSrvc, cmnSrvc, $rootScope, $scope, $state, $interval, $timeout, $window) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.countryId = function () { return getSessionSrvc.p_cntryId(); };
    vm.step = 1;
    vm.otpId = null;
    vm.cntryCode = "";
    vm.countryCode = "+";
    vm.mblNo = "";
    vm.btnResend = true;
    vm.startTime = 30;
    vm.errMsg = "";
    vm.mobErrMsg
    vm.intrvl = null;
    vm.vrfyOtp = true;
    //get country code
    vm.getCountryCode = function () {
        showLoader();
        cmnSrvc.getCountryCode(vm.countryId(), function (response, status) {
            if (status == 200 && response) {
                vm.countryCode = "+" + response;
                vm.countryCodeChg();
            }
            hideLoader();
            $timeout(function () { $("#txtMblNum").focus(); }, 500);
        })
    };
    vm.getCountryCode();

    vm.countryCodeChg = function () {
        if (vm.countryCode) {
            vm.cntryCode = getOnlyNumber(vm.countryCode);
            vm.countryCode = "+" + vm.cntryCode;
        }
    };

    vm.resetOTPFields = function () {
        vm.otpDigit1 = vm.otpDigit2 = vm.otpDigit3 = vm.otpDigit4 = vm.otpDigit5 = vm.otpDigit6 = "";
        vm.mobErrMsg = "";
        vm.errMsg = "";
        $("input#OtpDigit1").focus();
    };

    vm.back = function () {
        vm.step = 1;
    };

    vm.sendOTP = function () {
        if (vm.cntryCode && vm.mblNo && vm.mblNo.length > 6 && vm.mId()) {
            showLoader();
            vm.mobErrMsg = "";
            vm.errMsg = "";
            cmnSrvc.sendMblCode(vm.mId(), vm.cntryCode, vm.mblNo, function (response, status) {
                if (status == 200) {
                    if (response == 0)
                        vm.errMsg = "Number in use";
                    else if ((parseInt(response) == -1) || (parseInt(response) == -2))
                        vm.mobErrMsg = "Message sending failed";
                    else if (response) {
                        vm.otpId = response;
                        vm.step = 2;
                        vm.resetOTPFields();
                    }
                }
                else
                    vm.mobErrMsg = "Invalid member info";
                hideLoader();
            });
        }
    };

    vm.reSendOTP = function () {
        if (vm.cntryCode && vm.mblNo && vm.mblNo.length > 6 && vm.mId()) {
            vm.otpErr = "";
            showLoader();
            cmnSrvc.reSendMblCode(vm.mId(), vm.cntryCode, vm.mblNo, function (response, status) {
                vm.startTimer();
                if (status == 200 && response) {
                    vm.otpId = response;
                    vm.step = 2;
                    vm.resetOTPFields();
                }
                hideLoader();
            });
        }
    };

    vm.keyPress = function (txtIndexId, event) {
        if (event.keyCode == 13)
            vm.keyUp(txtIndexId, event);
    };

    vm.keyUp = function (txtIndexId, event) {
            var keyCode = event.keyCode;
            if ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105) || keyCode == 13) {
                vm.otpErr = "";
                vm.errorOtpMsg = "";
                vm.otpVerify();
                //focus next elements
                txtIndexId++;
                $('input[tabindex=' + (txtIndexId) + ']').focus();

            }       
    };

    vm.otpVerify = function () {
        if (vm.vrfyOtp == true && vm.otpId && vm.mId() && vm.otpDigit1 && vm.otpDigit2 && vm.otpDigit3 && vm.otpDigit4 && vm.otpDigit5 && vm.otpDigit6) {
            showLoader();
            vm.vrfyOtp = false;
            var code = vm.otpDigit1 + vm.otpDigit2 + vm.otpDigit3 + vm.otpDigit4 + vm.otpDigit5 + vm.otpDigit6;
            cmnSrvc.verifyOTPCode(vm.mId(), vm.otpId, code, function (response, status) {
                if (status == 200) {
                    vm.vrfyOtp = true;
                    if (response) {
                        updateMblVrfySession(response, getSessionSrvc, $rootScope);
                        $rootScope.$broadcast("showBnrMsg", 1);
                        $state.go("dashboard");
                    }
                    else {
                        vm.resetOTPFields();
                        vm.otpErr = "That’s incorrect. Please try again.";
                    }
                }
                hideLoader();
            });
        }
    };

    vm.startTimer = function () {
        vm.btnResend = false;
        vm.resendTimer = true;
        vm.startTime = 30;
        vm.intrvl = $interval(function () {
            vm.startTime = vm.startTime - 1
            if (vm.startTime.toString().length < 2)
                vm.startTime = "0" + vm.startTime;
            if (vm.startTime == "00") {
                vm.btnResend = true;
                vm.resendTimer = false;
                $interval.cancel(vm.intrvl);
                return false;
            }
        }, 1000);
    };
}]);