﻿angular.module('app').service('socialLgnSrvc', ['$http', '$window', function ($http, $window) {
    this.lgnCheck = function (lgnCheckObj, funCallBack) {
        var data = JSON.stringify(lgnCheckObj);
        var url = "https://pcapi.pyar.com/api/registersignin/regsocchk";
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.lgnWithFbPh = function (regId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/registersignin/regsocsec/" + regId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.otpverify = function (otpCheckObj, funCallBack) {
        var data = JSON.stringify(otpCheckObj);
        var url = "https://pcapi.pyar.com/api/registersignin/regotpvrfy";
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.linkdin = function (myKeyVals, funCallBack) {
        var url = "https://pcapi.pyar.com/api/registersignin/lnkdin";
        PostServiceByURL($http, url, myKeyVals, funCallBack);
    };
}])