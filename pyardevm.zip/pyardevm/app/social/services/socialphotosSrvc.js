﻿angular.module('app').service('socialphotosSrvc', ['$http', '$window', function ($http, $window) {
    this.getAlbums = function (client_id, accessToken, funCallBack) {
        $http({
            method: "GET",
            url: "https://graph.facebook.com/me/albums?access_token=" + accessToken + "&client_id=" + client_id,
            data: { access_token: accessToken },
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            funCallBack(response, status);
        }).error(function (error, status) {
            errStatuChk(status);
        });
    };

    this.bindPhotos = function (albumId, accessToken, funCallBack) {
        $http({
            method: "GET",
            url: "https://graph.facebook.com/" + albumId + "/photos?access_token=" + accessToken,
            data: { access_token: accessToken },
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'dataType': 'json'
            }
        }).success(function (response, status) {
            funCallBack(response, status);
        }).error(function (error, status) {
            errStatuChk(status);
        });
    };

    this.bindPhotosIN = function (accessToken, funCallBack) {
        $.ajax({
            url: 'https://api.instagram.com/v1/users/self/media/recent',
            dataType: 'jsonp',
            type: 'GET',
            data: { access_token: accessToken, count: 100 },
            success: function (data) {
                funCallBack(data);
            },
            error: function (data) {
                console.log(data);
            }
        });
    };
}]);