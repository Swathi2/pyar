﻿angular.module("app").controller('socialPhotosCtrl', ["$scope", "$rootScope", "$window", "$http", "socialphotosSrvc", "prflphotodataSrvc", "$location", function ($scope, $rootScope, $window, $http, socialphotosSrvc, prflphotodataSrvc, $location) {
    //variable declaration
    var vm = this;
    vm.accessToken = "";
    vm.imgPath = "";
    vm.albumId = "";
    vm.btnNextActive = "prvbtn";
    vm.btnValid = true;
    vm.albums = [];
    vm.maxWidth = 1920;
    vm.maxHeight = 1920;
    vm.minWidth = 400;
    vm.minHeight = 400;
    vm.btnSelectPhoto = false;
    $rootScope.dvAlbumPhotos = false;    
    $rootScope.srcType = 1; //1 device uploading,2 facebook uploading,3 instagram uploading  
    //variable declaration end

    //get images from facebook
    vm.btnFBPhotos = function (pagetype) {
        FB.login(function (response) {
            if (response.authResponse) {
                showLoader();
                var access_token = FB.getAuthResponse()['accessToken'];
                vm.accessToken = access_token;
                socialphotosSrvc.getAlbums(getFBClntId(), access_token, function (response, status) {
                    var albumsList = [];
                    for (var i = 0; i < response.data.length; i++) {
                        albumsList.push({ albumId: response.data[i].id, albumName: response.data[i].name });
                    }
                    $rootScope.srcType = 2;
                    $("#glryActions").modal('hide');
                    vm.albums = albumsList;
                    $("#dvAlbums").modal('show');
                    hideLoader();
                });
            }
        }, {
            scope: 'user_photos',
            return_scopes: true
        });
    };
    //get photos by albums photos when click on album name 
    vm.getAlbumPhotos = function () {
        var photUrls = [];
        socialphotosSrvc.bindPhotos(vm.albumId, vm.accessToken, function (response, status) {
            if (status == 200) {
                var albumsList = [];
                for (var i = 0; i < response.data.length; i++) {
                    var url = "https://graph.facebook.com/" + response.data[i].id + "/picture?access_token=" + vm.accessToken;
                    photUrls.push({ "imgUrl": url });
                }
                vm.istgrm = false;
                vm.albumPhotos = photUrls;
                $("#dvAlbums").modal('hide');
                $("#dvtoggle").hide();
                $("#pcFtr").hide();
                $rootScope.dvpgVisble = false;
                $rootScope.dvAlbumPhotos = true;                              
            }
        });
    };
    //Back from facebook albums 
    vm.fbalbumCancel = function () {
        $("#pcFtr").show();
        $("#dvtoggle").show();
        $("#dvAlbums").modal('hide');
        $rootScope.dvpgVisble = true;
    };

    vm.fbalbumPhotoCancel = function () {
        if (vm.istgrm == true) {
            $rootScope.instagram = false;
            $rootScope.dvAlbumPhotos = false;
            $rootScope.dvpgVisble = true;
            $("#pcFtr").show();
            $("#dvtoggle").show();
            history.pushState(null, null, location.pathname);//change visible url with out refreshing page.
        }
        else {
            $("#dvAlbums").modal('show');
            $rootScope.dvAlbumPhotos = false;
        }
    };
    //image from my pc
    vm.btnMyPC = function () {
        //rise a file upload click event  
        $("#fupPhtGlry").click();
        $("#glryActions").modal('hide');
    };

    //Take phote from device camera   
    //click on album name 
    vm.selectAlbum = function (albumId, index) {
        if (albumId != "" && albumId != undefined && albumId != null) {
            vm.albumId = albumId;
            vm.getAlbumPhotos();
        }
    };
    
    $("#fupPhtGlry").click(function () {       
        $("#fupPhtGlry").val(null);
    });

    //Action for image small popup Ok
    vm.photoSmlOk = function () {
        hideLoader();
        $("#photoSmallpop").modal('hide');
        if ($rootScope.srcType == 1) {
            $("#glryActions").modal('show');
        }
    };

    // cancel from cropping
    vm.btnBackCrpPhoto = function () {
        $('#cropImg').croppie('destroy');
        $("#srcAdjustProfilePhotoPopup").modal('hide');
        if ($rootScope.srcType != 1) {
            $rootScope.dvpgVisble = false;
            $rootScope.dvAlbumPhotos = true;
        }
        $rootScope.srcType = 1;
    };
   
    function loadImage(imgPath, index, calBackFun) {
        $("<img/>").load(function () {
            vm.imgRealWidth = this.width;
            vm.imgRealHeight = this.height;
            if (vm.imgRealWidth < vm.minWidth || vm.imgRealHeight < vm.minHeight) {
                $("#photoSmallpop").modal('show');
                $("#btnSelectPhoto").attr('disabled', true);
                $("#btnSelectPhoto").addClass("abnsbmt");
                $("#btnSelectPhoto1").removeClass("srclrbtn");
            }
            else {
                $("#btnSelectPhoto").attr('disabled', false);
                $("#btnSelectPhoto").addClass("srclrbtn");
                $("#btnSelectPhoto").removeClass("abnsbmt");
                vm.imgHeight = vm.imgRealHeight;
                vm.imgwidth = vm.imgRealWidth;

                if (vm.imgRealWidth > vm.imgRealHeight) {
                    if (vm.imgRealWidth > vm.maxWidth) {
                        vm.imgHeight = vm.imgRealHeight * (vm.maxWidth / vm.imgRealWidth);
                        vm.imgwidth = vm.maxWidth;
                    }
                } else {
                    if (vm.imgRealHeight > vm.maxHeight) {
                        vm.imgwidth = vm.imgRealWidth * (vm.maxHeight / vm.imgRealHeight);
                        vm.imgHeight = vm.maxHeight;
                    }
                }
                $rootScope.imgPath = imgPath;
                $rootScope.realWidth = vm.imgwidth;
                $rootScope.realHeight = vm.imgHeight;
            }
        }).attr("src", imgPath);
    };
    
    vm.albumImgClick = function (imgPath, index) {
        $("[id^='selectedImg']").removeClass("bxshdw");
        $("#selectedImg" + index).addClass("bxshdw");
        loadImage(imgPath, index);
    };
    
    vm.btnINPhotos = function () {
        showLoader();
        var clientid = getIGClntId();
       // var redirectUri = "http://localhost:58364" + location.pathname + "";
        var redirectUri = "https://devm.pyar.com" + location.pathname + "";
        $window.location.href = "https://api.instagram.com/oauth/authorize/?client_id=" + clientid + "&redirect_uri=" + redirectUri + "&response_type=token";
    };
  
    function getUrlVars() {
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('#') + 1).split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    };

    var hasAccessToken = getUrlVars();
    if (hasAccessToken == "access_token") {
        showLoader();
        $rootScope.instagramAcess = true;
        var access_token = hasAccessToken["access_token"];
        var photUrls = [];
        socialphotosSrvc.bindPhotosIN(access_token, function (response) {
            var albumsList = [];
            for (var i = 0; i < response.data.length; i++) {
                var url = response.data[i].images.standard_resolution.url;
                photUrls.push({ "imgUrl": url });
            }
            vm.albumPhotos = photUrls;
            vm.istgrm = true;
            $rootScope.srcType = 3;
            $("#dvAlbums").modal('hide');
            $("#dvtoggle").hide();
            $("#pcFtr").hide();
            $rootScope.dvpgVisble = false;
            $rootScope.dvAlbumPhotos = true;
            hideLoader();
        });
    }
}]);