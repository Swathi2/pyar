﻿angular.module("app").controller('registersocialsecCtrl', ['$scope', '$window', 'socialLgnSrvc', 'getSessionSrvc', '$location','$state', function ($scope, $window, socialLgnSrvc, getSessionSrvc, $location,$state) {
    var vm = this;
    vm.lclstrgValues = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("memreg")));
    if (!vm.lclstrgValues) {
       $state.go("register");
        return false;
    }

    vm.dvpgVisble = true;
    vm.dvErrMsg500 = false;
    vm.dvErrMsg404 = false;
    vm.mId = vm.lclstrgValues.mid;
    vm.ageCnfrm = false;
    vm.agree = false;

    //show privacy policy and terms of use
    // type - 1 for privacy-policy
    // type - 2 for terms of use
    vm.showPolicies = function (type) {
        var secObj = {"ageCnfrm": vm.ageCnfrm, "agree": vm.agree };
        $window.localStorage.setItem("secObj", getSessionSrvc.pce(JSON.stringify(secObj)));
        if (type == 1)
            $state.go("privacy-policy");
        else
            $state.go("terms-conditions");
    };

    //used to check if he redirect to policy pages and came back bind selected values
    vm.checkPolicies = function () {
        if ($window.localStorage.getItem("secObj")) {
            var secObj = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("secObj")))
            vm.ageCnfrm = secObj.ageCnfrm;
            vm.agree = secObj.agree;
            $window.localStorage.removeItem("secObj");
        }
    };
    vm.checkPolicies();

    //submit form function
    $scope.submitForm = function () {
        if ($scope.frmSecurity.$valid) {
            showLoader();
            socialLgnSrvc.lgnWithFbPh(vm.mId, function (response, status) {
                if (status = 200) {
                    //1: invalid id, 2: no recored found (or) loginType mismatch ,3:invalid login type, 4:OTP Sent fail (or) email sent fail
                    if (response == 1 || response == 2 || response == 3) {
                        $window.localStorage.removeItem("memreg");
                        vm.dvpgVisble = false;
                        vm.dvErrMsg404 = true;
                    }
                    else if (response == 4) {
                        $window.localStorage.removeItem("memreg");
                        vm.dvpgVisble = false;
                        vm.dvErrMsg500 = true;
                    }
                    else if (response.type == 1) {
                        vm.jsonSession = { "mid": response.id };
                        $window.localStorage.setItem("memreg", getSessionSrvc.pce(JSON.stringify(vm.jsonSession)));
                        $state.go("register/security/details");
                    }
                    else if (response.type == 2) {
                        vm.jsonSession = { "mid": response.id };
                        $window.localStorage.setItem("memreg", getSessionSrvc.pce(JSON.stringify(vm.jsonSession)));
                        $state.go("register/security/email");
                    }
                    hideLoader();
                }
            });
        }
    };
}]);