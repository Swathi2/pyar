﻿angular.module("app").controller('registersocialemlCtrl', ['socialLgnSrvc', 'getSessionSrvc', '$scope', '$window', '$state', function (socialLgnSrvc, getSessionSrvc, $scope, $window, $state) {
    var vm = this;
    //getting values for localstorage to assign socialText
    vm.lclstrgValues = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("memreg")));
    if (!vm.lclstrgValues) {
        $state.go("register");
        return false;
    }

    if (vm.lclstrgValues.lgnType == 3)
        vm.socialText = "Facebook";
    else
        vm.socialText = "LinkedIn";
    vm.socialText = "Facebook";

    vm.email = "";
    vm.emlErr = false;
    vm.emailErr = false;
    vm.emailErrMsg = "";
    vm.EmailPlaceholder = "Email address";
    vm.emailRegexs = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
 
    //Email textbox keypress event
    vm.emailKeyPress = function () { vm.emlErr = false; };

    //Email textbox blur event
    vm.emailCheck = function () {
        if (vm.email) {
            vm.email = vm.email.toLowerCase();
            vm.emlErr = false;
            vm.emailErrMsg = '';
        }
        else {
            vm.emlErr = true;
            vm.emailErrMsg = 'Invalid email address';
            vm.email = "";
        }
    };

    vm.errMsg = function (emailErr, email, emailErrMsg) {
        vm.emailErr = emailErr;
        vm.email = email;
        vm.emailErrMsg = emailErrMsg;
    };

    //submit form function
    vm.submitForm = function () {
        if ($scope.frmRegFbEml.$valid) {
            showLoader();
            var regData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("memreg")));
            if (regData) {
                var lgnCheckObj = { fn: regData.fn, socId: regData.socId, eml: vm.email, lgnType: regData.lgnType };
                socialLgnSrvc.lgnCheck(lgnCheckObj, function (response, status) {
                    if (status == 200) {
                        if (getSessionSrvc.validateSessionInfo(response)) {
                            getSessionSrvc.setLoginData(response);
                            $state.go("dashboard");
                        }
                        else if (rspStaus(3, response) == true) { navigate(response, "profilehide"); }
                        else if (rspStaus(1, response) == true) { navigate(response, "privacy-policy-pop"); }
                        else if (rspStaus(2, response) == true) { navigate(response, "terms-conditionspop"); }
                        else if (response == 8) {
                            alert("Your account has been suspended. Please contact our helpdesk for further information");
                            $state.go("register");
                        }
                        else if (response == 7) {
                            alert("Please login with LInkedIn");
                            $state.go("/");
                        }
                        else if (response == 6) {
                            alert("Please login with Facebook");
                            $state.go("/");
                        }
                        else if (response == 2) {
                            vm.errMsg(true, null, "Email already registered");
                        }
                        else if (response) {
                            var regData = { "mid": response };
                            $window.localStorage.setItem("memreg", getSessionSrvc.pce(JSON.stringify(regData)));
                            $window.localStorage.removeItem("secObj");
                            $state.go("register/social/security");
                        }
                    }
                    hideLoader();
                });
            }
        }
    };

    //function change url
    function navigate(response, url) {
        $window.sessionStorage.setItem("8B3414FB", response.id);
        $state.go(url);
    };

    //function for getting response Id's based on index
    function rspStaus(id, response) {
        if (response.refId != undefined) {
            return response.refId.indexOf(id) > -1;
        }
    };
}]);