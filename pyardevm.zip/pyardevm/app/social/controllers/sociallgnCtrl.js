﻿angular.module("app").controller('sociallgnCtrl', ["socialLgnSrvc", "selfprofileSrvc", "getSessionSrvc", "$scope", "$window", '$rootScope', '$state', '$location', function (socialLgnSrvc, selfprofileSrvc, getSessionSrvc, $scope, $window, $rootScope, $state, $location) {
    var vm = this;
    vm.trophyPopsocEmpty = true;
    vm.trophyPopsoc = false;
    
    //fb start
    vm.fbLgn = function (trop) {
        //removing if any previous storage values exist
        vm.clearStorageData();
        fbLogin(function (response) {
            showLoader();
            if (response != undefined) {
                if (trop == 'T') {
                    selfprofileSrvc.socTrophy(getSessionSrvc.p_mId(), function (response, status) {
                    });
                    $scope.$apply(function () {
                        vm.trophyPopsocEmpty = false;
                        vm.trophyPopsoc = true;
                    });
                    hideLoader();
                }
                else {
                    if (response.email)
                        vm.lgnType = 2;
                    else
                        vm.lgnType = 3;
                    var lgnCheckObj = { fn: response.first_name, socId: response.id, eml: response.email, lgnType: vm.lgnType };
                    socialLgnSrvc.lgnCheck(lgnCheckObj, function (outVal, status) {
                        loginCheck(outVal, status, response, 2);
                    });
                    hideLoader();
                }
            }
            else {
                hideLoader();
                alert("Login Failed Please try again..");
                return false;
            }
        });
    };
    //fb end

    //function to check member acc info using response
    function loginCheck(response, status, responseData, lgnType) {
        if (status == 200) {
            if (getSessionSrvc.validateSessionInfo(response)) {
                getSessionSrvc.setLoginData(response);
                $state.go("dashboard");
            }
            else if (rspStaus(3, response) == true) { navigate(response, "profilehide"); }
            else if (rspStaus(1, response) == true) { navigate(response, "privacy-policy-pop"); }
            else if (rspStaus(2, response) == true) { navigate(response, "terms-conditionspop"); }
            else if (response == 8) {
                alert("Your account has been suspended. Please contact our helpdesk for further information");
                $state.go("register");
            }
            else if (response == 7)
                alert("Please login with LInkedIn");
            else if (response == 6)
                alert("Please login with Facebook");
            else if (response == 1) {// email not submited need to redireact opp's page
                var regData;
                if (lgnType == 2)
                    regData = { "fn": responseData.first_name, "socId": responseData.id, "lgnType": 3 };
                if (lgnType == 4)
                    regData = { "fn": responseData.firstName, "socId": responseData.id, "lgnType": 5 };
                $window.localStorage.setItem("memreg", getSessionSrvc.pce(JSON.stringify(regData)));
                $state.go("register/security/social/email");
            }
            else if (response == 2)// email already registered
                $state.go("registerd/social/user");
            else if (response) {
                var regData = { "mid": response, "LoginType": 2 };
                $window.localStorage.setItem("memreg", getSessionSrvc.pce(JSON.stringify(regData)));
                $window.localStorage.removeItem("secObj");
                $state.go("register/social/security");
            }
        }
    };

    //function change url
    function navigate(response, url) {
        $window.sessionStorage.setItem("8B3414FB", response.id);
        $state.go(url);
    };

    //function for getting response Id's based on index
    function rspStaus(id, response) {
        if (response.refId != undefined) {
            return response.refId.indexOf(id) > -1;
        }
    };

    //validate session info end
    vm.clearStorageData = function () {
        $window.localStorage.removeItem("memreg");
    };
    vm.clearStorageData();
}]);