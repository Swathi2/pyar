﻿angular.module("app").controller('registerdSocialCtrl', ['$state', function ($state) {
    var vm = this;  
    vm.navSignin = function (val) {
        $state.go('signin');
    };
}]);