﻿angular.module("app").controller('mbrActCtrl', ['mbrActSrvc', 'getSessionSrvc', 'msgSrvc', '$scope', '$rootScope', '$filter', '$timeout', '$state', 'cmnSrvc', function (mbrActSrvc, getSessionSrvc, msgSrvc, $scope, $rootScope, $filter, $timeout, $state, cmnSrvc) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.fn = function () { return getSessionSrvc.p_fn(); };
    vm.pp = function () { return getSessionSrvc.p_ppic(); };
    vm.gender = function () { return getSessionSrvc.p_gndr(); };
    vm.p_ftPop = function () { return getSessionSrvc.p_ftPop(); }
    vm.rptMemId = "";
    vm.rptPhotoId = "";

    /*Event Listeners*/
    //Favorite Actions Starts
    $scope.$on("FavMbrAct", function (e, tmId, tmfn, tmfavType, tmGender, pgtype) {
        vm.mbrFavAct(tmId, tmfn, tmfavType, tmGender, pgtype);
    });

    vm.mbrFavAct = function (tmId, tmfn, tmfavType, tmGender, pgtype) {
        if (tmId && tmfn && tmfavType != null && tmfavType != undefined && tmGender != null && tmGender != undefined) {            
            vm.curMemId = tmId;
            vm.gndrTxtHeOrShe = tmGender ? "he" : "she";
            vm.curName = tmfn;
            vm.pagetype = pgtype;
            if (tmfavType == 1) {
                if (cmnSrvc.ftPOPCheck(3)) {
                    $("#mbrFavoriteModal").modal('show');
                    vm.removeFavPop = true;
                    vm.addFavPop = false;                 
                }
                else
                vm.FavRemoveClk();
            }
            else {
                mbrActSrvc.addFavorite(vm.mId(), vm.curMemId, function (response, status) {
                    if (status == 200) {
                        if (cmnSrvc.ftPOPCheck(2)) {
                            $("#mbrFavoriteModal").modal('show');
                            vm.removeFavPop = false;
                            vm.addFavPop = true;
                            cmnSrvc.ftPOPUpdate(2);
                            $rootScope.dashboardFav = true;
                        }
                        $rootScope.$broadcast("favAddDone");
                    }
                    else
                        alert("member has not added to favorites!!")
                });
            }
        }
        else
            alert("incorrect input");
    };  
    vm.FavRemoveClk = function () {
        if (vm.mId() && vm.curMemId) {
            mbrActSrvc.removeFavorite(vm.mId(), vm.curMemId, function (response, status) {
                if (status == 200 && response == true) {
                    cmnSrvc.ftPOPUpdate(3);
                    $("#mbrFavoriteModal").modal('hide');
                    $rootScope.$broadcast("favRemoveDone");
                }
                else
                    alert("member has not removed from favorites!!")
            });
        }
        else
            alert("incorrect input");
    };

    vm.favClose = function () {
        $rootScope.$broadcast("favClose");
    };

    vm.viewFavorites = function () {
        $("#mbrFavoriteModal").modal('hide');
        $('body').removeClass().removeAttr('style');
        $('.modal-backdrop').remove();
        $rootScope.tabtype = "favorite";
        if (vm.pagetype == "dashboard")
            $state.reload("dashboard");
        else
            $state.go("dashboard");

        //activate  footer  matches icon.
        $("#nvbrimg li:nth-child(3)").click();
    };
    //Favorite Action Ends

    //Flirt Actions Starts
    $scope.$on("FlirtMbrAct", function (e, tmId, tmfn, tmfavType, tmGender, tmflirtType) {
        if (tmId && tmfn && tmfavType != null && tmfavType != undefined && tmGender != null && tmGender != undefined) {
            $("#mbrFlirtModal").modal('show');
            vm.gndrTxtHisOrHer = tmGender ? "him" : "her";
            vm.gndrTxtHeOrShe = tmGender ? "he" : "she";
            vm.curMemId = tmId;
            vm.curName = tmfn;
            vm.curGender = tmGender;
            vm.favType = tmfavType;
            if (tmflirtType == 1) {
                vm.alreadyFlrtPop = true;
                vm.FlrtFvrtPop = false;
                vm.FlrtPop = false;
                $timeout(function () {
                    vm.alreadyFlrtPop = false;
                    $('.modal-backdrop').remove();
                    $("#mbrFlirtModal").modal('hide');
                }, 1500);
            }
            else {
                if (tmfavType == 1) {
                    vm.FlrtPop = true;
                    vm.FlrtFvrtPop = false;                   
                    vm.alreadyFlrtPop = false;
                } else {
                    vm.FlrtFvrtPop = true;
                    vm.FlrtPop = false;
                    vm.alreadyFlrtPop = false;
                }
            }
        }
        else
            alert("incorrect input");
    });

    vm.FlirtAddClk = function () {
        if (vm.mId() && vm.curMemId) {
            vm.FlrtPop = false;
            vm.FlrtFvrtPop = false;
            mbrActSrvc.addFlirt(vm.mId(), vm.curMemId, function (response, status) {
                if (status == 200 && response == true) {
                    var notifyType = 51;//flirtt
                    if (msgSrvc.conId)
                        msgSrvc.sendMemberNotifications(vm.curMemId, vm.fn(), vm.pp(), vm.gender(), notifyType, new Date());
                    else
                        $rootScope.ntfnData.push({ "sendType": 1, "tmId": vm.curMemId, "fn": vm.fn(), "pp": vm.pp(), "gender": vm.gender(), "type": notifyType, "date": new Date() });
                    $rootScope.$broadcast("FlirtAddDone");
                    vm.flirtsent = true;
                    $timeout(function () {
                        vm.flirtsent = false;
                        $('.modal-backdrop').remove();
                        $("#mbrFlirtModal").modal('hide');
                    }, 1500);
                }
            });
        }
    };

    vm.FavAddClk = function () {
        vm.FlrtPop = false;
        vm.FlrtFvrtPop = false;
        $("#mbrFlirtModal").modal('hide');
        $('.modal-backdrop').remove();
        vm.mbrFavAct(vm.curMemId, vm.curName, vm.favType, vm.curGender, "");
    };
    //Flirt Actions Ends

    //Member other actions Starts
    $scope.$on("MbrOtherAct", function (e, tmId, tmfn, tmGender) {
        if (tmId && tmfn && tmGender != null && tmGender != undefined) {
            $("#mbrothersaction").modal('show');
            vm.gndrTxtHisOrHer = tmGender ? "him" : "her";
            vm.gndrTxtHeOrShe = tmGender ? "he" : "she";
            vm.curMemId = tmId;
            vm.curName = tmfn;
            vm.curGender = tmGender;
            vm.hideType = 2;
            mbrActSrvc.MemberHideCheck(vm.mId(), vm.curMemId, function (response, status) {
                if (status == 200 && response == true) {
                    vm.hideUnHideTxt = "Unhide";
                    vm.hideType = 2;
                } else {
                    vm.hideUnHideTxt = "Hide";
                    vm.hideType = 1;
                }
            });
        }
        else
            alert("incorrect input");
    });

    // Hide Action Starts
    vm.hidePopChk = function () {
        $("#mbrothersaction").modal('hide');
        $("#mbrHideModal").modal('show');
        if (vm.hideType == 1) {
            vm.hidePop = true;
            vm.hidePop2 = false;
        } else
            vm.unHideClk();
    };

    vm.hideClk = function () {
        if (vm.mId() && vm.curMemId) {
            vm.hidePop = false;
            mbrActSrvc.addHide(vm.mId(), vm.curMemId, function (response, status) {
                if (status == 200 && response == true) {
                    vm.hidePop2 = true;
                    $timeout(function () {
                        vm.hidePop2 = false;
                        $("#mbrHideModal").modal('hide');
                        $('.modal-backdrop').remove();
                        $rootScope.$broadcast("hideDone");
                    }, 1500);

                    vm.hideUnHideTxt = "Unhide";
                    vm.hideType = 2;
                }
            });
        }
    };

    vm.unHideClk = function () {
        if (vm.mId() && vm.curMemId) {
            mbrActSrvc.removeHide(vm.mId(), vm.curMemId, function (response, status) {
                if (status == 200 && response == true) {
                    vm.hidePop = false;
                    $("#mbrHideModal").modal('hide');
                    $('.modal-backdrop').remove();
                    vm.hideUnHideTxt = "Hide";
                    vm.hideType = 1;
                }
            });
        }
    };
    // Hide Action Ends

    //Block Action Starts
    vm.BlckPopClk = function () {
        $("#mbrothersaction").modal('hide');
        $("#mbrBlockModal").modal('show');
        vm.BlckPop = true;
        vm.BlckPop2 = false;
    };

    vm.BlockSubmit = function () {
        if (vm.mId() && vm.curMemId) {
            vm.BlckPop = false;
            mbrActSrvc.addBlock(vm.mId(), vm.curMemId, function (response, status) {
                if (status == 200 && response == true) {
                    vm.BlckPop2 = true;
                    $timeout(function () {
                        vm.BlckPop2 = false;
                        $("#mbrBlockModal").modal('hide');
                        $('.modal-backdrop').remove();
                        $rootScope.$broadcast("blockDone", vm.curMemId);
                    }, 1500);
                }
            });
        }
    };
    //Block Action Ends

    //Report Action Starts
    vm.frmReport = false;
    var limitNum = 250;
    vm.reportPlaceHolder = "Tell us what happened";
    vm.reportJson = [{ name: "Spam", value: "1" }, { name: "Inappropriate", value: "2" }, { name: "Abuse/Threat", value: "3" }, { name: "Other", value: "4" }];

    vm.ReportPopClk = function () {
        $("#mbrothersaction").modal('hide');
        $("#mbrReportModal").modal('show');
        vm.ReportDv = true;
        vm.ReportDv3 = false;
    };

    vm.ReportClk = function () {
        vm.ReportDv = false;
        $("#mbrReportModal").modal("hide");
        $('.modal-backdrop').remove();
        $("#mbrReportPage").modal('show');
        vm.ReportPage = true;
        vm.reportPlaceHolder = "Tell us what happened";
        vm.txtCls = "";
        vm.frmReport = false;
        vm.RepErrMsg = "";
        vm.RptRsnVal = "";
    };

    vm.reportCancel = function () {
        $("#mbrReportPage").modal('hide');
        $('.modal-backdrop').remove();
        vm.ReportPage = false;
    };

    vm.RptRsnClk = function (val) {
        vm.RptRsnVal = val;
        vm.frmReport = true;
        vm.reportPlaceHolder = "Tell us what happened";
        vm.txtCls = "";
    };

    vm.RptSubmit = function (submitType) {
        //need to check vm.RptRsnVal shood not be empty/null
        if (vm.RptRsnVal == 4 && !vm.reportTxt) {
            vm.txtCls = "txteror";
            vm.reportPlaceHolder = 'Since you selected "Other" as your reason, please give us some details.';
            vm.RepErrMsg = "";
        }
        else {
            if (submitType == 1) {
                vm.rprtOnmbrId = vm.curMemId;
                vm.rptPhotoId = vm.curMemId;
            }
            else {
                vm.rprtOnmbrId = vm.rptMemId;
                vm.rptPhotoId = vm.rptPhotoId;
            }
            mbrActSrvc.memReport(vm.mId(), vm.rprtOnmbrId, submitType, vm.rptPhotoId, vm.RptRsnVal, vm.reportTxt, function (response, status) {
                if (status == 200 && response == true) {
                    if (submitType == 1) {
                        vm.reportTxt = "";
                        $("#mbrReportPage").modal("hide");
                        $("#mbrReportModal").modal('show');
                        vm.ReportDv3 = true;
                        $timeout(function () {
                            $("#mbrReportModal").modal('hide');
                            $('.modal-backdrop').remove();
                            vm.ReportPage = false;
                            vm.ReportDv3 = false;
                        }, 1500);
                    }
                    else {
                        $("#mbrReportThnksModal").modal("show");
                        vm.rptPhoto = false;
                        $timeout(function () {
                            $("#mbrReportThnksModal").modal("hide");
                        }, 1500);
                    }
                }
            });

        }
    };

    //Showing report text error message.    
    vm.reportLimit = function () {
        if (vm.reportTxt) {
            if (vm.reportTxt.length > limitNum) {
                vm.RepErrMsg = "Please ensure that your Details do not exceed 250 characters..";
                vm.reportTxt = "";
                vm.reportPlaceHolder = "Tell us what happened";
                vm.txtCls = "";
            }
            else
                vm.RepErrMsg = "";
        }
        else {
            vm.reportPlaceHolder = "Tell us what happened";
            vm.txtCls = "";
        }
    };

    $scope.$on("rptOnMbrPhotoAction", function (e, rptMemId, rptPhotoId) {
        if (rptMemId && rptPhotoId) {
            vm.rptMemId = rptMemId;
            vm.rptPhotoId = rptPhotoId;
            $("#mbrphotoReportModal").modal("show");
        }
        else
            alert("incorrect input");
    });

    vm.photoReportClk = function () {
        vm.rptPhoto = true;
        $("#mbrphotoReportModal").modal("hide");
        vm.frmReport = false;
        vm.reportPlaceHolder = "Tell us what happened";
        vm.txtCls = "";
        vm.reportTxt = "";
        vm.frmReport = false;
        vm.RepErrMsg = "";
        vm.RptRsnVal = "";
    };

    vm.photoReportCncl = function () {
        vm.rptPhoto = false;
    };
}]);