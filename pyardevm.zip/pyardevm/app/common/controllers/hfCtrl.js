﻿app.controller('headerCtrl', function ($scope, $rootScope, $window, $location, $state, $timeout, getSessionSrvc, abndnSrvc, cmnSrvc, msgSrvc) {
    var vm = this;
    $rootScope.dvToggle = true;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.sId = function () { return getSessionSrvc.p_sub() };

    // set body to and bottom accordeing to header and footer
    vm.setBodyStyle = function () {
        var vm = this;
        if (vm.path == "/membership.html" || vm.path == "/non-membership.html" ||vm.path == "/refrfrnd.html" || vm.path == "/terms-conditions.html" || vm.path == "/help-faqs.html" || vm.path == "/privacy-policy.html" || vm.path == "/aboutus.html" || vm.path == "/account.html")
            vm.bdyCls = "";
        else
            vm.bdyCls = "margin-bottom:60px;";
    };

    //used for removing mask when toggle menu links clicked
    vm.checkToggleMast = function () {
        //removing mask when url changes
        if ($("#mnav-mask"))
            $("#mnav-mask").click();
    };

    vm.account_Clk = function () {
        $rootScope.acTabType = "GS";
        $state.go("account");
    };

    // code for signout 
    vm.signOutMember = function () {
        //used for display signout message in home page
        abndnSrvc.rmvSsn();
        $window.localStorage.setItem("pgType", 1);
        // instgram logout
        if ($rootScope.instagramAcess) {
            var s = document.createElement("script");
            s.src = "https://instagram.com/accounts/logout";
            $("head").append(s);
        }
    };

    //toggle Menu Click event
    vm.toggleClick = function () {
        $rootScope.toggleReferrer = location.pathname;
        $("body").append("<div id='mnav-mask'></div>");
        $("#mnav-mask").on('click', function () {
            $("#dvcstmnav").css("right", "-280px");
            $("#mnav-mask").remove();
        });

        $("#dvcstmnav").css("right", "0");
        if (!$("#mnav-mask").hasClass("overlayed"))
            $('#mnav-mask').addClass('overlayed');
    };
    //go to membership page
    $rootScope.goMbrshp = function (divId) {
        $("#" + divId).modal('hide');
        $('body').removeClass().removeAttr('style');
        $('.modal-backdrop').remove();
        $rootScope.toggleReferrer = $location.path();
    };
    //set toggle menu set basic or premium link
    vm.setToggleMemberLink = function () {
        if (getSessionSrvc.p_sub() == 2) {
            if (getSessionSrvc.p_subtm())
                vm.mstitle = "Go Premium";
            else
                vm.mstitle = "My Premium";
        }
        else
            vm.mstitle = "Go Premium";

        if (vm.path == "/profile.html") {
            vm.toggleCls = "nvtgleP";
            vm.toggleImg = "https://pccdn.pyar.com/pcimgs/m/drawer-menu-pf.png";
        }
        else {
            vm.toggleCls = "nvtgle";
            vm.toggleImg = "https://pccdn.pyar.com/pcimgs/m/drawer-menu.png";
        }
    };

    $scope.$on('refreshHdrPP', function (e, imgPath) {
        var dtn = new Date().valueOf();
        vm.profilePic = imgPath.replace("/p/tns/", "/p/tnb/") + "?v=" + dtn;
    });

    //invisible browsing
    vm.chgInvBrw = function () {
        if (vm.mId()) {
            cmnSrvc.updateInvBrw(vm.mId(), vm.invBrw, function (response, status) {
                if (status == 200 && response == true)
                    getSessionSrvc.u_ssnd("invisibleBrowsing", vm.invBrw);
            });
        }
    };

    //navigate back to toggle referrer
    $rootScope.toggleBack = function () {
        if (vm.sId() == 2 && $rootScope.toggleReferrer == "/advancedsearch.html") {
            $rootScope.showSrchBtn = true;
            clearSearch($window);
        }
        if ($rootScope.toggleReferrer)
            $location.path($rootScope.toggleReferrer);
        else
            $location.path("/dashboard.html")
    };

    //check invisible browsing
    vm.setInvBrw = function () {
        vm.invBrw = getSessionSrvc.p_ib();
        if (vm.sId() == 2) {
            $rootScope.browseInvisbly = true;          
        }
        else
            $rootScope.browseInvisbly = false;
    };
    vm.showInfo = false;
    vm.InvsbleBrwInfoshw = function () {
        vm.showInfo = true;
    }
    vm.InvsbleBrwInfohde = function () {
        vm.showInfo = false;
    }
  //profile picture checking
    vm.setProfilePic = function () {
        if (vm.mId() != null) {
            var pic = getSessionSrvc.p_ppic();
            var gndr = getSessionSrvc.p_gndr();
            if (pic == null || pic == "")
                if (gndr == true) vm.profilePic = 'https://pccdn.pyar.com/pcimgs/avatarM.png';
                else vm.profilePic = 'https://pccdn.pyar.com/pcimgs/avatarF.png';
            else
                vm.profilePic = "https://pccdn.pyar.com" + pic.replace("/p/tns/", "/p/tnb/");
        };
    };

    //if page refresh
    vm.setProfilePic();
    vm.setInvBrw();

    //state change event
    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
       
        //try {
        //    $.getScript("https://m.pyar.com/app/version.js")
        //   .done(function (script, textStatus) {
        //       var curntVersion = GetVersion();
        //       var sysVersion = $window.localStorage.getItem("version");
        //       if (!(sysVersion && curntVersion == sysVersion)) {
        //           $.getScript("https://m.pyar.com/app/app.js")
        //          .done(function (script, textStatus) {
        //              console.log("script version updated");
        //          })
        //          .fail(function (jqxhr, settings, exception) {
        //              console.log("script version updation failed");
        //          });
        //           $window.localStorage.setItem("version", curntVersion);
        //       }
        //   });
        //}
        //catch (e) {
        //    console.log("script version updation error  --  " + e.message);
        //}

        showLoader();
        //reading url path
        vm.path = toState.url;
        vm.setBodyStyle();
        vm.checkToggleMast();
        vm.setToggleMemberLink();
    });

    $rootScope.$on('$stateChangeSuccess', function () {
        hideLoader();
        $('html, body').scrollTop(0);
    });

    //once login set default actions
    $scope.$on("login", function (e) {
        vm.setProfilePic();
        vm.setInvBrw();
    });

    $rootScope.$on("showPremiumPopup", function (e, type) {
        $("#dvMV").modal("show");
        if (type == "NTFN")
            vm.step = 1;
        else if (type == "NM" || type == "RM")
            vm.step = 2;
        else
            vm.step = 2;
    });

    $rootScope.$on("showBnrMsg", function (e, bnrType) {
        if (bnrType) {
            vm.bnrType = bnrType;
            $timeout(function () { $("#dvtmPop").fadeIn(1500); }, 500);
            $timeout(function () { $("#dvtmPop").fadeOut(1500); }, 6000);
        }
    });

    vm.unlockPrem = function () {
        $state.go("mpVrfy");
    };
});

angular.module("app").controller("footerCtrl", ['getSessionSrvc', 'msgSrvc', '$scope', '$location', '$window', '$rootScope', '$state', function (getSessionSrvc, msgSrvc, $scope, $location, $window, $rootScope, $state) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.sId = function () { return getSessionSrvc.p_sub(); };

    if ($location.path() == "/dashboard.html")
        $("#nvbrimg li:nth-child(3)").click();
    else if ($location.path() == "/notifications.html")
        $("#nvbrimg li:nth-child(1)").click();
    else if ($location.path() == "/profile.html")
        $("#nvbrimg li:nth-child(2)").click();
    else if ($location.path() == "/msgcenter.html")
        $("#nvbrimg li:nth-child(4)").click();
    else if ($location.path() == "/advancedsearch.html" || $location.path() == "/basicsearch.html")
        $("#nvbrimg li:nth-child(5)").click();

    // for default search binding 
    vm.setSrchclk = function () {
        if (vm.sId() == 2) {
            if (location.pathname != "/advancedsearch.html") {
                $rootScope.showSrchBtn = true;
                clearSearch($window);
                $state.go("advancedsearch");
            }
        }
        else
            $state.go("basicsearch");
    };

    //msg nav actions
    if (!$rootScope.mnCnt)
        $rootScope.mnCnt = 0;

    if (!$rootScope.mmCnt)
        $rootScope.mmCnt = [];

    $rootScope.$on("msgSrvcReady", function (e) {
        try {
            vm.getMemberMsgCounts();
            vm.sendNotifications();
        } catch (e) {
            console.log("msgSrvcReady  --  " + e.message);
        }
    });

    $scope.$on("receiveMsg", function (e, tmId, fn, msg, tmpp, convrnId, dt, sender) {
        try {
            if (!sender) {
                vm.incrMsgCount(tmId);
                $scope.$digest();
            }
        } catch (e) {
            console.log("receiveMsg listener  --  " + e.message);
        }
    });

    $scope.$on("chgMsgReadCount", function (e, tmIds, status) {
        try {
            for (var i = 0; i < tmIds.length; i++) {
                if (status)
                    vm.incrMsgCount(tmIds[i]);
                else
                    vm.decrMsgCount(tmIds[i]);
            };
        } catch (e) {
            console.log("chgMsgReadCount  --  " + e.message);
        }
    });

    $scope.$on("setMsgReadCount", function (e, tmIds) {
        $rootScope.mmCnt = tmIds;
    });

    vm.getMemberMsgCounts = function () {
        try {
            if (getSessionSrvc.p_mId()) {
                msgSrvc.getMessagesCount(getSessionSrvc.p_mId(), function (response, status) {
                    if (status == 200) {
                        $rootScope.mmCnt = response.tmIds;
                        $rootScope.mnCnt = response.notifyCnt;
                        //on refresh page 
                        if ($location.path() == "/notifications.html" && $rootScope.mnCnt > 0)
                            $rootScope.$broadcast("resetNMCnt");
                    }
                });
            }
        } catch (e) {
            console.log("vm.getMemberMsgCounts  --  " + e.message);
        }
    };

    vm.incrMsgCount = function (mId) {
        try {
            var notExist = true;
            if ($rootScope.mmCnt && $rootScope.mmCnt.length > 0) {
                for (var i = 0; i < $rootScope.mmCnt.length; i++) {
                    if ($rootScope.mmCnt[i] == mId) {
                        notExist = false;
                        break;
                    }
                }
            }
            if (notExist)
                $rootScope.mmCnt.push(mId);
        } catch (e) {
            console.log("vm.incrMsgCount  --  " + e.message);
        }
    };

    vm.decrMsgCount = function (mId) {
        try {
            if ($rootScope.mmCnt && $rootScope.mmCnt.length > 0) {
                for (var i = 0; i < $rootScope.mmCnt.length; i++) {
                    if ($rootScope.mmCnt[i] == mId) {
                        $rootScope.mmCnt.splice(i, 1);
                        break;
                    }
                }
            }
        } catch (e) {
            console.log("vm.decrMsgCount  --  " + e.message);
        }
    };
    //End here

    //receive notification
    $scope.$on("receiveNotifications", function (e, tmId, firstname, profilepic, gender, type, date) {
        if ($location.path() != "/notifications.html") {
            $rootScope.mnCnt++;
            $scope.$digest();
        }
    });
    
    vm.sendNotifications = function () {
        if (vm.mId() && $rootScope.ntfnData) {
            while ($rootScope.ntfnData.length > 0 && msgSrvc.conId) {
                if ($rootScope.ntfnData[0].sendType == 1)
                    msgSrvc.sendMemberNotifications($rootScope.ntfnData[0].tmId, $rootScope.ntfnData[0].fn, $rootScope.ntfnData[0].pp, $rootScope.ntfnData[0].gender, $rootScope.ntfnData[0].notifyType, $rootScope.ntfnData[0].date);
                else
                    msgSrvc.sendMemberNWNotifications($rootScope.ntfnData[0].tmId, $rootScope.ntfnData[0].fn, $rootScope.ntfnData[0].pp, $rootScope.ntfnData[0].gender, $rootScope.ntfnData[0].notifyType, $rootScope.ntfnData[0].date);
                $rootScope.ntfnData.splice(0, 1);
            }
        }
    };
}]);