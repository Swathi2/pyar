﻿angular.module("app").controller('countryIntlCtrl', ['countryIntlSrv', '$scope', '$rootScope', '$timeout', '$filter', function (countryIntlSrv, $scope, $rootScope, $timeout, $filter) {
    var vm = this;
    vm.showLoc = false;
    vm.NR = false;
    vm.locId = "";
    vm.countries = [];
    vm.cities = [];
    vm.ResultStore = [];
    vm.cities = [];
    vm.newCities = [];
    vm.countryId = null;
    vm.countryName = "";
    vm.cityObj = null;
    vm.txtCity = "";
    vm.pgType = 1;
    vm.timeoutRef = null;
    vm.reqWait = false;

    vm.GetCountries = function () {
        showLoader();
        countryIntlSrv.GetCountries(function (response, status) {
            hideLoader();
            if (status == 200 && response.length > 0) {
                response = $filter("orderBy")(response, "priority");
                vm.countries = response;
            }
            else
                vm.countries = [];
        });
    };

    vm.countrySelect = function (countryId, countryName) {
        if (countryId && countryName) {
            vm.countryId = countryId;
            vm.countryName = countryName;
        }
    };

    vm.citySelect = function (cityObj) {
        if (cityObj) {
            vm.cityObj = cityObj;
            vm.cities = [];
            vm.txtCity = cityObj.cityName;
        }
    };

    vm.cityRemove = function () {
        vm.cityObj = null;
        vm.txtCity = "";
    };

    vm.cancel = function () {
        if (vm.pgType == 1 && vm.locId) {
            $("body").css("overflow", "");
            $rootScope.$broadcast("countryUnBind", vm.locId);
            vm.showLoc = false;
        }
        if (vm.pgType == 2)
            vm.pgType = 1;
    };

    vm.countryNext = function () {
        vm.pgType = 2;
        vm.cityObj = null;
        vm.NR = false;
        vm.cities = [];
        vm.txtCity = "";
    };

    vm.cityDone = function () {
        $("body").css("overflow", "");
        if (vm.locId && vm.countryId && vm.cityObj)
            $rootScope.$broadcast("countryBind", vm.locId, vm.countryId, vm.cityObj);
        vm.showLoc = false;
    };

    vm.cityFocus = function () {
        if (vm.txtCity && vm.txtCity.length > 3)
            vm.getCities();
    };

    vm.cityChg = function () {
        //if user typing continuously wait for finshing typing
        if (vm.txtCity) {
            if (vm.timeoutRef) {
                $timeout.cancel(vm.timeoutRef);
                vm.timeoutRef = null;
            }

            if (vm.txtCity.length < 3)
                vm.cities = [];
            else if (vm.txtCity.length == 3)
                vm.getCities();
            else if (vm.txtCity.length > 3)
                vm.CallGetCities();
            else
                hideLoader();
        }
    };

    //call GetDate function after 500 milly seconds
    vm.CallGetCities = function () {
        vm.timeoutRef = $timeout(function () {
            if (vm.reqWait)
                vm.CallGetCities();
            else
                vm.getCities();
        }, 500);
    };

    vm.getCities = function () {
        showLoader();
        vm.NR = false;
        vm.cities = [];
        if (vm.txtCity.length == 3) {
            showLoader();
            if (!vm.CheckResultsExist(vm.countryId, vm.txtCity)) {
                vm.reqWait = true;
                var keyword = vm.txtCity;
                countryIntlSrv.GetCities(vm.countryId, keyword, function (response, status) {
                    vm.reqWait = false;
                    if (status == 200) {
                        //save result if response is empty or not(becasuse if no cities are found second time you will not to hit service)
                        vm.SaveResults(vm.countryId, keyword, response);
                        vm.ShowResults(keyword);
                    }
                });
            }
            else
                vm.ShowResults(vm.txtCity);
        }
        else if (vm.txtCity.length > 3) {
            showLoader();
            vm.ShowResults(vm.txtCity);
        }
    };

    vm.SaveResults = function (countryId, keyword, response) {
        if (!vm.CheckResultsExist(countryId, keyword))
            vm.ResultStore.push({ "countryId": countryId, "keyword": keyword, "response": response });
    };

    vm.ShowResults = function (keyword) {
        var objArr = vm.GetResult(keyword);
        if (objArr.length > 0) {
            for (var i = 0; i < objArr.length; i++) {
                if (objArr[i].cityName.toLowerCase().startsWith(keyword.toLowerCase()))
                    vm.cities.push(objArr[i]);
            }
        }
        if (vm.cities.length == 0) {
            vm.NR = true;
            vm.CheckAndAddCity(vm.countryId, keyword);
        }
        hideLoader();
    };

    vm.GetResult = function (keyword) {
        if (!vm.countryId)
            return "";

        var obj = "";
        for (var i = 0; i < vm.ResultStore.length; i++) {
            if (vm.countryId == vm.ResultStore[i].countryId && keyword.toLowerCase().startsWith(vm.ResultStore[i].keyword.toLowerCase())) {
                obj = vm.ResultStore[i].response;
                break;
            }
        }
        return obj;
    };

    vm.CheckResultsExist = function (countryId, keyword) {
        var keywordExists = false;
        for (var i = 0; i < vm.ResultStore.length; i++) {
            if (countryId == vm.ResultStore[i].countryId && keyword.toLowerCase().startsWith(vm.ResultStore[i].keyword.toLowerCase()))
                keywordExists = true;
        }
        return keywordExists;
    };

    vm.CheckAndAddCity = function (countryId, cityName) {
        var cityExist = false;
        for (var i = 0; i < vm.newCities.length; i++) {
            if (vm.newCities[i].countryId == countryId && cityName.toLowerCase() == vm.newCities[i].cityName.toLowerCase().toLowerCase()) {
                cityExist = true;
                break;
            }
        }
        if (!cityExist) {
            vm.newCities.push({ "countryId": countryId, "cityName": cityName });
            countryIntlSrv.AddNewCites(countryId, cityName);
        }
    };

    vm.GetCity = function (locId, countryId, cityId) {
        if (locId && countryId && cityId) {
            if (vm.countries.length == 0) {
                countryIntlSrv.GetCountries(function (response, status) {
                    if (response && response.length) {
                        response = $filter("orderBy")(response, "priority");
                        vm.countries = response;
                        vm.FindCity(locId, countryId, cityId);
                    }
                })
            }
            vm.FindCity(locId, countryId, cityId);
        }
    };

    vm.FindCity = function (locId, countryId, cityId) {
        for (var i = 0; i < vm.countries.length; i++) {
            if (countryId == vm.countries[i].countryId) {
                countryIntlSrv.GetCityById(countryId, cityId, function (response, status) {
                    if (status == 200 && response)
                        $rootScope.$broadcast("BindCity", locId, response);
                })
            }
        }
    };

    //Event Listeners
    $scope.$on("showLocation", function (e, locId) {
        if (locId) {
            $("body").css("overflow", "hidden");
            vm.showLoc = true;
            vm.locId = locId;
            vm.cities = [];
            vm.countryId = null;
            vm.cityObj = null;
            vm.txtCity = "";
            vm.pgType = 1;
            if (vm.countries.length == 0)
                vm.GetCountries();
        }
    });

    $scope.$on("GetCity", function (e, locId, countryId, cityId) {
        vm.GetCity(locId, countryId, cityId);
    });
    //End here
}]);