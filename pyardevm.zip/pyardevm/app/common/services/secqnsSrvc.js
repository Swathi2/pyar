﻿app.service('secqnsSrvc', ['$http', function ($http) {
    this.securityQuns = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/secq";
        GetServiceByURL($http, url, funCallBack);
    };
}]);