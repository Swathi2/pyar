﻿app.service('countryIntlSrv', ['$http', '$timeout', '$rootScope', function ($http, $timeout, $rootScope) {
    var vm = this;
    vm.GetCountries = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/countries";
        GetServiceByURL($http, url, funCallBack);
    };

    vm.GetCities = function (countryId, cityName, funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/gci/" + countryId + "/" + cityName;
        GetServiceByURL($http, url, funCallBack);
    };

    vm.GetCityById = function (countryId, cityId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/gcbyId/" + countryId + "/" + cityId;
        GetServiceByURL($http, url, funCallBack);
    };

    vm.AddNewCites = function (countryId, cityName) {
        var url = "https://pcapi.pyar.com/api/utils/ctmre";
        var data = { "countryId": countryId, "cityName": cityName };
        PostServiceByURL($http, url, data, function (response, status) {
        });
    };
}]);