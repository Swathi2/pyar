﻿app.service('mbrActSrvc', ['$http', function ($http) {
    //Service for adding favorite
    this.addFavorite = function (memberId, memFavId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/adfav/" + memberId + "/" + memFavId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Service for remove favorite
    this.removeFavorite = function (memberId, mFavId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/rmfav/" + memberId + "/" + mFavId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Service for add flirt
    this.addFlirt = function (memberId, memFlirtId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/adflrt/" + memberId + "/" + memFlirtId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Service for add Block
    this.addBlock = function (memberId, memBlockedId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/adblk/" + memberId + "/" + memBlockedId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Service for Add Hide
    this.addHide = function (memberId, memHideId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/adhd/" + memberId + "/" + memHideId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Service for Remove Hide
    this.removeHide = function (memberId, mHdId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/rmhd/" + memberId + "/" + mHdId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Service for Member Hide check
    this.MemberHideCheck = function (memberId, memHideId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/hdchk/" + memberId + "/" + memHideId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Service for member report 
    this.memReport = function (reportedBy, reportedOn, refType, refId, rptReasonType, rptReason, funCallBack) {
        //refType: 1- reporting on member, 2- reporting on Photo
        //refId: 1- memeberId, 2- PhotoId
        var data = { reportedBy: reportedBy, reportedOn: reportedOn, refType: refType, refId: refId, rptReasonType: rptReasonType, rptReason: rptReason }
        var url = "https://pcapi.pyar.com/api/profile/rptmbr";
        PostServiceByURL($http, url, data, funCallBack);
    };   
}]);