﻿/**********************************************************
                Common Service start
**********************************************************/
angular.module("app").service('cmnSrvc', ['$http','getSessionSrvc',  function ($http,getSessionSrvc) {
    this.updateInvBrw = function (memId, invBrw, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/invbrwng/" + memId + "/" + invBrw;
        GetServiceByURL($http, url, funCallBack);
    };

    this.getCountryIdByShortName = function (countryShortName, funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/getcntrybysn/" + countryShortName;
        GetServiceByURL($http, url, funCallBack);
    };

    this.GetCountryIdByLatLong = function (lat, long, funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/getcntryidbylatlong/" + lat + "/" + long + "/";
        GetServiceByURL($http, url, funCallBack);
    };

    this.ftPOPCheck = function (id) {
         var p_ftMpop = getSessionSrvc.p_ftPop().split(",")[1].split("#");
        if (p_ftMpop[id - 1] == "1")
            return true;
        else
            return false;
    };
    this.ftPOPCheckTrophy = function (trophies, refid) {
        var ftpop = trophies.split("#");
        if (ftpop[refid - 1] == "1")
            return true;
        else
            return false;
    }

    this.ftPOPUpdate = function (id) {
        var ftPOPS = getSessionSrvc.p_ftPop().split(",");
        var ftpop = ftPOPS[1].split("#");
        ftpop[id - 1] = "0";
        var ftpopNew = ftpop.join("#");
        getSessionSrvc.u_ssnd("ftPOP", ftPOPS[0] + "," + ftpopNew);
        var url = "https://pcapi.pyar.com/api/registersignin/ftpopu/" + getSessionSrvc.p_mId() + "/" + id + "/false";
        GetServiceByURL($http, url, '');
    };

    //freetrail
    this.sendMblCode = function (memberId, countryCode, mblNo, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/sndphvc/";
        var data = { "memberId": memberId, "countryCode": countryCode, "mobileNo": mblNo };
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.reSendMblCode = function (memberId, countryCode, mblNo, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/resndphvc/";
        var data = { "memberId": memberId, "countryCode": countryCode, "mobileNo": mblNo };
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.verifyOTPCode = function (memberId, codeId, code, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/chkphvc/" + memberId + "/" + codeId + "/" + code;
        GetServiceByURL($http, url, funCallBack);
    };

    this.getCountryCode = function (countryId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/countrycode/" + countryId;
        GetServiceByURL($http, url, funCallBack);
    };
}]);
/**********************************************************
                Common Service end
**********************************************************/


/**********************************************************
                Common factories start
**********************************************************/
angular.module("app").factory('hbySearchFact', function () {
    var hbySearchData = [];
    function sethbySearchData(data) { hbySearchData = data; }
    function gethbySearchData() { return hbySearchData; }
    return {
        sethbySearchData: sethbySearchData,
        gethbySearchData: gethbySearchData,
    }
});
/**********************************************************
                Common factories end
**********************************************************/


/**********************************************************
                Common directives start
**********************************************************/
//directive for side and bottom navigation
app.directive("pcToggle", function () { return { templateUrl: "/app/common/templates/toggleMenu.html" } });
app.directive("pcFooter", function () { return { templateUrl: "/app/common/templates/footer.html" } });
//popups directive
app.directive("pcPopups", function () { return { templateUrl: "/app/common/templates/cmnpopups.html" } });
//Country Intl Service
app.directive("pcLocation", function () {
    return {
        restrict: 'E',
        templateUrl: "/app/common/templates/countryIntl.html",
        controller: "countryIntlCtrl",
        controllerAs: "countryIntlCtrlAs"
    }
});

//match profile
app.directive("pcMatch", function () {
    return {
        restrict: 'E',
        templateUrl: '/app/profile/others/templates/match.html',
        controller: 'matchCtrl',
        controllerAs: 'matchCtrlAs'
    }
});

//member action Service
app.directive("pcMbrActions", function () {
    return {
        restrict: 'E',
        templateUrl: "/app/common/templates/mbrAct.html",
        controller: "mbrActCtrl",
        controllerAs: "mbrActCtrlAs"
    }
});

//message conversation
app.directive("pcMbrMsgConvrn", function () {
    return {
        restrict: 'E',
        templateUrl: "/app/messages/templates/chatConversation.html",
        controller: "chatConversationCtrl",
        controllerAs: "chatConversationCtrlAs"
    }
});

//new message
app.directive("pcMbrNewMsg", function () {
    return {
        restrict: 'E',
        templateUrl: "/app/messages/templates/newmessage.html",
        controller: "newMessageCtrl",
        controllerAs: "newMessageCtrlAs"
    }
});

//creating custom directive for Comparing 
//ngCompare={{model which need to compare}}
app.directive('ngCompare', function () {
    return {
        require: 'ngModel',
        link: function (scope, currentEl, attrs, ctrl) {
            var comparefield = document.getElementsByName(attrs.ngCompare)[0]; //getting first element
            compareEl = angular.element(comparefield);

            //current field key up
            currentEl.on('keyup', function () {
                if (compareEl.val() != "") {
                    var isMatch = currentEl.val() === compareEl.val();
                    ctrl.$setValidity('compare', isMatch);
                    scope.$digest();
                }
            });

            //Element to compare field key up
            compareEl.on('keyup', function () {
                if (currentEl.val() != "") {
                    var isMatch = currentEl.val() === compareEl.val();
                    ctrl.$setValidity('compare', isMatch);
                    scope.$digest();
                }
            });
        }
    }
});

//creating custom directive for Allow only Aphabets 
//allow-only-alphabets
app.directive('allowOnlyAlphabets', function () {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {
                if (event.which >= 65 && event.which <= 90) // to allow alphabets keys  
                    return true;
                else if ([8, 9, 13, 27, 32, 35, 36, 37, 38, 39, 40, 46].indexOf(event.which) > -1) // to allow backspace, enter, escape, arrows  
                    return true;
                else { // to stop others  
                    event.preventDefault();
                    return false;
                }
            });
        }
    }
});

app.directive('allowOnlyLettersAndSpace', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                var transformedInput = text.replace(/[^a-zA-Z ]/g, '');
                if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                    ngModelCtrl.$render();
                }
                return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    }
});

//creating custom directive for DOB Format
app.directive('dobFormat', function () {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {
                if (event.which >= 48 && event.which <= 57) // numLock keys on
                    return true;
                else if (event.which >= 96 && event.which <= 105 || event.which == 191)
                    return true;
                else if ([8, 9, 13, 27, 35, 36, 37, 38, 39, 40, 46].indexOf(event.which) > -1)// to allow backspace, enter, escape, arrows  
                    return true;
                else { // to stop others  
                    event.preventDefault();
                    return false;
                }
            });
        }
    }
});

app.directive('allowOnlyNumbers', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                var transformedInput = text.replace(/[^0-9]/g, '');
                if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                    ngModelCtrl.$render();
                }
                return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    }
});

//directive from textbox text limit
app.directive('textLength', function () {
    return {      
        restrict: 'A',
        link: function (scope, elem, attrs) {
            var limit = parseInt(attrs.textLength);
            angular.element(elem).on("keypress", function (e) {
                if (this.value.length == limit) {
                    if (e.which != 8 && e.which != 16 && e.which != 35 && e.which != 36 && e.which != 46) {
                        e.preventDefault();
                    }
                }
            });
        }
    }
});
app.directive('limitTo', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attrs) {
            var limit = parseInt(attrs.limitTo);
            angular.element(elem).on("keypress", function (e) {
                if (this.value.length == limit)
                    e.preventDefault();
            });
        }
    }
});

app.filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
         keys = [];
        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });
        return output;
    };
});

app.directive('trphyPrsnltySlider', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            $timeout(scope.$eval(attrs.trphyPrsnltySlider), 0);
        }
    }
});

app.directive('onFinishRender', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true)
                $timeout(function () { scope.$emit(attr.onFinishRender); });
        }
    }
});

app.directive('onFinishRenderSortbyAsc', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$first === true)
                $timeout(function () { scope.$emit(attr.onFinishRenderSortbyAsc); });
        }
    }
});
/**********************************************************
                Common directives end
**********************************************************/



/**********************************************************
                Common functions start
**********************************************************/
//get fb clientId
function getFBClntId() { return "208096986336968"; };
//get instagram clientId
function getIGClntId() { return "5127b09dd06f4f10ae7b558f37e665f1"; };
//get google recaptcha clientId
function getGoogleClntId() { return "6LeeqRUUAAAAAPQap6b-AN2mNtol3kq72cxfyhlh"; };

function getOnlyNumber(text) {
    return text.replace(/[^0-9]/g, '');
};

function updateMblVrfySession(ssnObj, getSessionSrvc, $rootScope) {
    if (ssnObj && ssnObj.length > 0) {
        var subDays = null, trailType = null;
        for (var i = 0; i < ssnObj.length; i++) {
            if (ssnObj[i].Key == "sId")
                getSessionSrvc.u_ssnd("sId", ssnObj[i].Value);
            else if (ssnObj[i].Key == "subscribeStrtDT")
                getSessionSrvc.u_ssnd("dateTimeSubscrbSt", ssnObj[i].Value);
            else if (ssnObj[i].Key == "subscribeExprDT")
                getSessionSrvc.u_ssnd("dateTimeSubscrbExp", ssnObj[i].Value);
            else if (ssnObj[i].Key == "trailMember")
                getSessionSrvc.u_ssnd("trailMember", ssnObj[i].Value);
            else if (ssnObj[i].Key == "subscribeDays")
                subDays = ssnObj[i].Value;
            else if (ssnObj[i].Key == "trailType")
                trailType = ssnObj[i].Value;
        }
        if (getSessionSrvc.p_sub() == 2)
            $rootScope.browseInvisbly = true;
    }
};

// to close the modal and its backdrop when user click browser back/forward buttons
jQuery(document).ready(function ($) {
    if (window.history && window.history.pushState) {
        $(window).on('popstate', function () {
            $(".modal").hide();
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove();

        });
    }
});
function showLoader() {
    $("#pcldr").show();
};
   
function hideLoader() {
    $("#pcldr").hide();
};

function setFooterIcon(liId) {
    $('ul#nvbrimg li').each(function (i, e) {
        $(e).removeClass('active');
        var imagName = $(e).find('img').attr('src').substring(0, $(e).find('img').attr('src').lastIndexOf('.'));
        if (imagName[imagName.length - 1] == "a") {
            var imagName = imagName.substring(0, imagName.length - 1);
            $(e).find('img').attr('src', imagName + '.png');
        }
    });

    var liActive = $('ul#nvbrimg li#' + liId);
    if (liActive.length > 0) {
        liActive.addClass('active');
        liActive.find('img').attr('src', liActive.find("img").attr('src').replace('.png', 'a.png'));
    }
};

function isCurrentDate(date) {
    var today = moment.utc(new Date()).format("YYYY-MM-DD");
    var dt = moment.utc(date).format("YYYY-MM-DD");
    if (moment(today).isSame(dt))
        return true;
    else
        return false;
};

$(window).resize(function () {
    if ($("#pcldr").css('display') != "none") {
        showLoader();
    }
});

function calculateAge(dateOfBirth) {
    var dob = new Date(dateOfBirth);
    var today = new Date();
    var age = Math.floor((today - dob) / (365.25 * 24 * 60 * 60 * 1000));
    return age;
};

function calculateRadius(units, radius) {
    if (units != null && units == 2)
        return Math.round(radius / 1.6);
    else
        return radius;
};

//function for comparing array object
function compareArray(newArr, oldArr) {
    if (JSON.stringify(newArr.sort()) != JSON.stringify(oldArr.sort()))
        return true;
    else
        return false;
};

//function for replace feets and inches to ' and ''
function replaceInches(str, find, replace) {
    return str.replace(new RegExp(find, 'g'), replace);
};

function setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find('.modal-content');
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find('.modal-header').outerHeight() || 0;
    var footerHeight = this.$element.find('.modal-footer').outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.$content.css({
        'overflow': 'hidden'
    });

    this.$element
      .find('.modal-body').css({
          'max-height': maxHeight,
          'overflow-y': 'auto'
      });
};

$('.modal').on('show.bs.modal', function () {
    $(this).show();
    setModalMaxHeight(this);
});

$(window).resize(function () {
    if ($('.modal.in').length != 0) {
        setModalMaxHeight($('.modal.in'));
    }
});

function errStatuChk(status) {
    if (status == -1) {
        //doing nothing. no alert.
    }
    else {
        $("#ApiErrMsg").text("Something went wrong!");
        $("#ErrAlert").modal("show");
    }
};

    // Service for Get Method
function GetServiceByURL($http, url, funCallBack) {
    $http({
        method: "GET",
        url: url,
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'dataType': 'json'
        }
    }).success(function (response, status) {
        if (funCallBack && typeof funCallBack === 'function') {
            funCallBack(response, status);
        }
    }).error(function (reason, status) {
        hideLoader();
        errStatuChk(status);
    });
};

// Service for Post Method
function PostServiceByURL($http, url, jsonData, funCallBack) {
    $http({
        method: "POST",
        url: url,
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'dataType': 'json'
        },
        data: jsonData,
    }).success(function (response, status) {
        //checking function type, if it is function or not
        if (funCallBack && typeof funCallBack === 'function') {
            funCallBack(response, status);
        }
    }).error(function (reason, status) {
        hideLoader();
        errStatuChk(status);
    });
};

    //used to change text box type as password or text
function showHideText(obj, txtid) {
    var txtObj = $("#" + txtid);
    if (txtObj.attr("type").toLowerCase() == "password") {
        txtObj.attr("type", "text");
        var imgSrc = $(obj).attr("src");
        $(obj).attr("src", $(obj).attr("nextsrc"));
        $(obj).attr("nextsrc", imgSrc);
    }
    else {
        txtObj.attr("type", "password");
        var imgSrc = $(obj).attr("src");
        $(obj).attr("src", $(obj).attr("nextsrc"));
        $(obj).attr("nextsrc", imgSrc);
    }
};

function getDate(dob) {
    var date = dob.getDate();
    var month = dob.getMonth() + 1;
    var year = dob.getFullYear();
    return month + "/" + date + "/" + year;
};

function getDateDiffByDays(date1, date2) {
    var d1 = new Date(date1);
    var d2 = new Date(date2);
    return Math.round((d2 - d1) / (1000 * 60 * 60 * 24));
};

//http://jsfiddle.net/ThinkingStiff/6qrbn/
function getBrowserType() {
    var standalone = window.navigator.standalone,
        userAgent = window.navigator.userAgent.toLowerCase(),
        safari = /safari/.test(userAgent),
        ios = /iphone|ipod|ipad/.test(userAgent);
    return ios;
};

function getCountryCodeUsingLatLong(cmnSrvc, lat, long, callBackFun) {
    if (lat != "" && long != "") {
        $.ajax({
            url: 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' + lat + ',' + long + '&sensor=true&key=AIzaSyAKJ6fi1Vqv7Y6BxgykUsoOn7UFNO7V-4M',
            success: function (response) {
                if (response.results.length > 0) {
                    var shortName = "";
                    angular.forEach(response, function (key1) {
                        angular.forEach(key1[0].address_components, function (key2) {
                            if (key2.types[0].trim().toLowerCase()=="country") {
                                shortName = key2.short_name;
                                return;
                            }
                        });
                        if (shortName) return;
                    });

                    if (shortName) {
                        cmnSrvc.getCountryIdByShortName(shortName, function (response, status) {
                            if (status == 200)
                                callBackFun(response);
                        });
                    }
                }
                else {
                    alert("No location available for provided details.");
                }
            }
        });
    }
    else {
        alert("latitude and longitudes are required");
    }
};

function base64ToBlobFileConvertion(imgSrc, callBackFun) {
    var dataURL = imgSrc;
    var blobBin = atob(dataURL.split(',')[1]);
    var array = [];
    for (var i = 0; i < blobBin.length; i++)
        array.push(blobBin.charCodeAt(i));
    var contentType = dataURL.split(',')[0].split(':')[1];
    var file = new Blob([new Uint8Array(array)], { type: contentType });
    callBackFun(file);
};

function convertFileToDataURLviaFileReader(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        var reader = new FileReader();
        reader.onloadend = function () {
            callback(reader.result);
        }
        reader.readAsDataURL(xhr.response);
    };
    xhr.open('GET', url);
    xhr.responseType = 'blob';
    xhr.send();
};

function resizingImage(imgRes, callbackImgResponse) {
    var dataURL = imgRes;
    var blobBin = atob(dataURL.split(',')[1]);
    var array = [];
    for (var i = 0; i < blobBin.length; i++)
        array.push(blobBin.charCodeAt(i));
    var contentType = dataURL.split(',')[0].split(':')[1];
    var imgFile = new Blob([new Uint8Array(array)], { type: 'image/png' });

    canvasResize(imgFile, {
        width: 1920,
        height: 1920,
        crop: false,
        quality: 100,
        callback: function (data, width, height) {
            callbackImgResponse(data)
        }
    });
};

var tnCroppie;
function CreateGlryThumbNail(imgSrc, imgWidth, imgHeight, callbackFun) {
    $('#crpThmnl').croppie('destroy');
    tnCroppie = $('#crpThmnl').croppie({
        viewport: {
            width: 200,
            height: 200,
            type: 'square' // or 'circle'
        },
        showZoomer: true,
        enableOrientation: true,
        customClass: '',
        mouseWheelZoom: true,
    });

    $('#crpThmnl').croppie('bind', 'url').then(function () {
        $('#crpThmnl').croppie('setZoom', 0);
    });

    $('#crpThmnl').croppie('bind', {
        url: imgSrc,
        zoom: 0.1,
    });
    callbackFun();
};

function GetGalleryTnResponse(tmbnWidth, tmbnHeight, $timeout, callbackFun) {
    $timeout(function () {
        $('#crpThmnl').croppie('result', {
            type: 'canvas',
            size: { width: tmbnWidth, height: tmbnHeight }
        }).then(function (response) {
            callbackFun(response);
        });
    }, 1000);
};

function createBlurImage(imgSrc, callBackFun) {
    var canvas = document.createElement('canvas');
    canvas.setAttribute('id', "backgroud_div");
    $(canvas).blurIt(imgSrc, 20, function (resonse) {
        callBackFun(resonse);
    });
};

function CropPBPhoto(imagePath, VP_Width, VP_Height, $timeout) {
    showLoader();
    $("#srcAdjustProfilePhotoPopup").modal("show");
    croppie = $('#cropImg').croppie({
        // viewport options
        viewport: {
            width: VP_Width,
            height: VP_Height,
            type: 'square' // or 'circle'
        },
        //  boundary: { width: VP_Width, height: VP_Height },
        showZoomer: false,
        //enableOrientation: true,
        customClass: '',
        mouseWheelZoom: true,
    });

    //$('#dvGlryImgTn').croppie('get');
    croppie.croppie('bind', 'url').then(function () {
        croppie.croppie('setZoom', 0)
    });
    $timeout(function () {
        $('#cropImg').croppie('bind', {
            url: imagePath,
            zoom: 0.1,
            //  orientation: 0
            //points: [0, 0, 0, 0]
        });
        hideLoader();
    }, 500);
};

function CroppedImageResult(width, height, callBackFun) {
    croppie.croppie('result', {
        type: 'canvas',
        size: { width: width, height: height }
    }).then(function (response) {
        callBackFun(response);
    });
};

function getBrowserType() {
    var standalone = window.navigator.standalone,
        userAgent = window.navigator.userAgent.toLowerCase(),
        safari = /safari/.test(userAgent),
        ios = /iphone|ipod|ipad/.test(userAgent);
    return ios;
};



    //check element is visible to screen or not
(function ($) {
    $.fn.visible = function (partial) {
        if ($(this).length > 0) {
            var $t = $(this),
                $w = $(window),
                viewTop = $w.scrollTop(),
                viewBottom = viewTop + $w.height(),
                _top = $t.offset().top,
                _bottom = _top + $t.height(),
                compareTop = partial === true ? _bottom : _top,
                compareBottom = partial === true ? _top : _bottom;

            return ((compareBottom <= viewBottom) && (compareTop >= viewTop));
        }
        return false;
    };

})(jQuery);

    //check div has scroll or not
(function ($) {
    $.fn.hasScrollBar = function () {
        return this.get(0).scrollHeight > this.height();
    }
})(jQuery);

function bindLocation(data, cntryId) {
    var htlocation = [];
    if (data.cityName)
        htlocation.push(data.cityName);
    if (data.stateShortName)
        htlocation.push(data.stateShortName);
    else
        htlocation.push(data.stateName);
    if (data.countryName)
        if (data.countryId != cntryId)
            htlocation.push(data.countryName);
    var locjoinTxt = htlocation.join(', ');
    htlocation = locjoinTxt.toString();
    return htlocation;
};

//tile location binding 
function bindHtLocation(tmcity, tmstate, tmcountry, lgnCountry, units, distance) {
    var htlocation = [];
    if (distance && distance <= 50) {
        var dstnceType = "";
        if (units == 2) {
            dstnceType = "kms"
            distance = Math.round(distance * 1.609344);
            if (distance <= 5)
                distance = 5;
        }
        else {
            dstnceType = "miles"
            distance = Math.round(distance);
            if (distance <= 5)
                distance = 5;
        }
        htlocation.push(distance + "  " + dstnceType + "  " + "away");
    }
    else {
        if (tmcity)
            htlocation.push(tmcity);
        if (tmstate)
            htlocation.push(tmstate);
        if (tmcountry && tmcountry != lgnCountry)
            htlocation.push(tmcountry);
    }
    var locjoinTxt = htlocation.join(', ');
    htlocation = locjoinTxt.toString();
    return htlocation;
};

//Comma seperated check functionality
function commaSeperatedNumbStrCheck(val) {
    if (val == "" || val == null)
        return true;
    if (val) {
        if (/^[0-9]+(,[0-9]+)*$/.test(val)) {
            return true;
        } else {
            return false;
        }
    }
};

    //Common functionalities in search page
    //Get Location Text
function getLocBindText(lctype, redius, units) {
    var rslttext = "";
    var locationTxt = "";
    if (lctype == 1)
        locationTxt = " of where I live";
    else if (lctype == 2)
        locationTxt = " of Current Location";
    else if (lctype == 3)
        locationTxt = " of another location";

    if (redius == 1)
        rslttext += " Within 25 " + units + locationTxt;
    else if (redius == 2)
        rslttext += " Within 50 " + units + locationTxt;
    else if (redius == 3)
        rslttext += " Within 100 " + units + locationTxt;
    else if (redius == 4)
        rslttext += " Within 250 " + units + locationTxt;
    else if (redius == 5)
        rslttext += " Within 500 " + units + locationTxt;
    else if (redius == 6)
        rslttext += " Within 1000+ " + units + locationTxt;
    return rslttext;
};

    //Return Search radius
function prepareRadiusVal(radius, units) {
    var rslt = 0;
    if (radius == 1)
        rslt = 25;
    else if (radius == 2)
        rslt = 50;
    else if (radius == 3)
        rslt = 100;
    else if (radius == 4)
        rslt = 250;
    else if (radius == 5)
        rslt = 500;
    else if (radius == 6)
        rslt = 1000;
    var SrchRadius = calculateRadius(units, rslt);
    return SrchRadius;
};

function clearSearch($window) {
    $window.localStorage.removeItem("srchObj");
    $window.localStorage.removeItem("defaultbasic");
    $window.localStorage.removeItem("srchRslt");
};

function createSearchObj() {
    srchObj = {
        "title": "",
        "mssId": null,
        "basic": {
            "firstName": "",
            "gender": null,
            "genderPref": null,
            "minAge": null,
            "maxAge": null,
            "locRadius": null,
            "locType": null,
            "countryId": null,
            "cityId": null,
            "latitude": "",
            "longitute": "",
            "isOnline": false,
            "isProfilePicUpld": false,
        },
        "about": {
            "ethinicities": [],
            "religions": [],
            "areaWork": [],
            "rShipStatus": [],
            "highestEdu": [],
            "htCountry": null,
            "htCity": null
        },
        "personalityTraits": {
            "pt": [],
            "ptcId": []
        },
        "appearance": {
            "eyeColor": [],
            "hairColor": [],
            "minHeight": [],
            "maxHeight": [],
            "build": [],
        },
        "lifestyle": {
            "diet": [],
            "smoke": [],
            "drink": [],
            "idealRelationship": [],
            "children": [],
            "childrenCnt": [],
            "pets": [],
            "petsCnt": [],
            "languages": [],
            "fmlyLanguages": [],
            "religious": [],
            "traditional": [],
        },
        "hobbies": {
            "hobbies": []
        }
    };
    var srchObjString = JSON.stringify(srchObj);
    window.localStorage.setItem("srchObj", srchObjString);
};

//Displaying Time to resend the mail and OTP and Disabling the resend  button
function startInterval(vm, $interval) {
    vm.resendEmailVal = false;
    vm.startTime = 30;
    var intrvl = $interval(function () {
        vm.startTime = vm.startTime - 1
        if (vm.startTime.toString().length < 2) {
            vm.startTime = "0" + vm.startTime;
        }
        if (vm.startTime == "00") {
            vm.resendEmailVal = true;
            $interval.cancel(intrvl);
            return false;
        }
    }, 1000);
};

function getTrophies(trophies) {
    var trphyImg = "";
    var trophies = trophies.split('#');
    var count = 0;
    for (var i = 0; i <= trophies.length; i++)
    {
        if(trophies[i]==1)
            count++
    }
    if (count == 0)
        trphyImg = "https://pccdn.pyar.com/pcimgs/m/tr6.png";
    if (count == 1)
        trphyImg = "https://pccdn.pyar.com/pcimgs/m/tr1.png";
    if (count == 2)
        trphyImg = "https://pccdn.pyar.com/pcimgs/m/tr2.png"
    if (count==3)
        trphyImg = "https://pccdn.pyar.com/pcimgs/m/tr3.png";
    if (count == 4)
        trphyImg = "https://pccdn.pyar.com/pcimgs/m/tr4.png";
    if (count == 5)
        trphyImg = "https://pccdn.pyar.com/pcimgs/m/tr5.png";  
    return trphyImg;
};

function getTimeZones() {
    var timeZones = moment.tz.names();
    var zonesArrObj = [];
    for (var i = 0; i < timeZones.length; i++) {
        zonesArrObj.push({ "val": parseInt(i) + 1, "zone": timeZones[i], "GMT": moment.tz(timeZones[i]).format('Z'), "txt": "(GMT" + moment.tz(timeZones[i]).format('Z') + ") " + timeZones[i] });
    }
    return zonesArrObj;
};

function getTimeZoneById(tzId) {
    var zone = "";
    var zonesArrObj = getTimeZones();
    for (var i = 0; i < zonesArrObj.length; i++) {
        if (zonesArrObj[i].val == tzId) {
            zone = zonesArrObj[i].zone;
            break;
        }
    }

    if (zone == "")
        zone = moment.tz.guess();
    return zone;
};

function getTZIdByZone(zone) {
    if (!zone)
        zone = moment.tz.guess();
    var tzId = null;
    var zonesArrObj = getTimeZones();
    for (var i = 0; i < zonesArrObj.length; i++) {
        if (zonesArrObj[i].zone == zone) {
            tzId = zonesArrObj[i].val;
            break;
        }
    }
    return tzId;
};
/**********************************************************
                Common functions end
**********************************************************/