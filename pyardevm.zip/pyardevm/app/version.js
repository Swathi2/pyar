﻿
function GetVersion() {
    return "1.0";
}