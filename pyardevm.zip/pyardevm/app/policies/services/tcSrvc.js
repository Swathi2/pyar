﻿app.service('tcSrvc', ['$http', function ($http) {
    // get Terms conditons
    this.TCService = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/policies/tc";
        GetServiceByURL($http, url, funCallBack);
    };
    // update Terms conditons
    this.tcUpdate = function (ids, funCallBack) {
        var data = {}
        var url = "https://pcapi.pyar.com/api/registersignin/tcacpt/" + ids;
        PostServiceByURL($http, url, data, funCallBack);
    };
}]);