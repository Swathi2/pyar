﻿app.service('ppSrvc', ['$http', function ($http) {
    //Privacy policy service creation
    this.PPService = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/policies/pp";
        GetServiceByURL($http, url, funCallBack);
    };
    this.ppUpdate = function (ids, funCallBack) {
        var data = {}
        var url = "https://pcapi.pyar.com/api/registersignin/ppacpt/" + ids;
        PostServiceByURL($http, url, data, funCallBack);
    };
}]);