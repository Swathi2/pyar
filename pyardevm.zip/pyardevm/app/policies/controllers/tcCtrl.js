﻿angular.module("app").controller('tcCtrl', ['tcSrvc', 'getSessionSrvc', '$rootScope', '$window', '$state', '$filter', '$sce', function (tcSrvc, getSessionSrvc, $rootScope, $window, $state, $filter, $sce) {
    var vm = this;
    vm.tcvalidChk = false;
    var ids = $window.sessionStorage.getItem("8B3414FB");
    //setting body
    if ($("body").attr("class"))
        $("body").attr("class", $("body").attr("class") + " faqbg");
    else
        $("body").attr("class", "faqbg");

    vm.termsCondtions = function () {
        tcSrvc.TCService(function (response, status) {
            if (status == 204) {
                alert("the content is not there (take the appropriate action)");
                return false;
            }
            else if (status = 200) {
                vm.tcVersion = "Version " + eval(JSON.stringify(response.version));
                vm.lstUpdated = "Last updated: " + $filter('date')(eval(JSON.stringify(response.dateCreated)), "MMMM d, yyyy");
                vm.tcContent = $sce.trustAsHtml(response.policytext);
            }
        });
    };
    vm.termsCondtions();

    vm.validateTC = function () {
        if (vm.tcchk)
            vm.tcvalidChk = true;
        else
            vm.tcvalidChk = false;
    };

    vm.tcUpdateClk = function () {
        if (vm.tcvalidChk) {
            if (ids != "") {
                showLoader();
                tcSrvc.tcUpdate(ids, function (response, status) {
                    hideLoader();
                    if (status == 200) {
                        if (vm.rspStaus(10, response) == true) { alert("server error"); }
                        else if (vm.rspStaus(3, response) == true) { vm.navigate("profilehide", response); }
                        else if (vm.rspStaus(1, response) == true) { vm.navigate("privacy-policy-pop", response); }
                        else if (vm.rspStaus(4, response) == true) { vm.navigate("signinpwdrotation", response); }
                        else if (getSessionSrvc.validateSessionInfo(response)) {
                            $window.sessionStorage.removeItem("8B3414FB");
                            getSessionSrvc.setLoginData(response);
                            $state.go('dashboard');
                        }
                    }
                });
            }
        }
    };

    vm.rspStaus = function (id, response) {
        if (response.refId != undefined) {
            return response.refId.indexOf(id) > -1;
        }
    };

    vm.navigate = function (url, response) {
        $('.modal-backdrop').remove();
        $window.sessionStorage.setItem("8B3414FB", response.id);
        $state.go(url);
    };

    //back to previous page
    vm.backtoPrvsPage = function () {
        vm.lclstrgValues = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("memreg")));
        if (vm.lclstrgValues == null)
            $state.go("contactus");
        else {
            if (vm.lclstrgValues.LoginType == 1)
                $state.go('register/security');
            else
                $state.go('register/social/security');
        }
    };
}]);