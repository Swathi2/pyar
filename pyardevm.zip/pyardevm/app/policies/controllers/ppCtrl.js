﻿angular.module("app").controller('ppCtrl', ['ppSrvc', 'getSessionSrvc', '$rootScope', '$filter', '$window', '$state','$sce', function (ppSrvc, getSessionSrvc, $rootScope, $filter, $window, $state,$sce) {
    var vm = this;
    vm.ppvalidChk = false;
    var ids = $window.sessionStorage.getItem("8B3414FB");
    //set class to body 
    if ($("body").attr("class"))
        $("body").attr("class", $("body").attr("class") + " faqbg");
    else
        $("body").attr("class", "faqbg");

    vm.privacyPolicy = function () {
        ppSrvc.PPService(function (response, status) {
            if (status == 204) {
                alert("the content is not there (take the appropriate action)");
                return false;
            }
            else if (status == 200) {
                vm.ppVersion = "Version " + eval(JSON.stringify(response.version));
                vm.lstUpdated = "Last updated: " + $filter('date')(eval(JSON.stringify(response.dateCreated)), "MMMM d, yyyy");
                vm.ppContent = $sce.trustAsHtml(response.policytext);
            }
        });
    }
    vm.privacyPolicy();
    vm.validatePP = function () {
        if (vm.ppchk)
            vm.ppvalidChk = true;
        else
            vm.ppvalidChk = false;
    };

    vm.ppUpdateClk = function () {
        if (vm.ppvalidChk) {
            if (ids != "") {
                showLoader();
                ppSrvc.ppUpdate(ids, function (response, status) {
                    hideLoader();
                    if (status == 200) {
                        if (vm.rspStaus(10, response) == true) { alert("server error"); }
                        else if (vm.rspStaus(3, response) == true) { vm.navigate("profilehide", response); }
                        else if (vm.rspStaus(2, response) == true) { vm.navigate("terms-conditionspop", response); }
                        else if (vm.rspStaus(4, response) == true) { vm.navigate("signinpwdrotation", response); }
                        else if (getSessionSrvc.validateSessionInfo(response)) {
                            $window.sessionStorage.removeItem("8B3414FB");
                            getSessionSrvc.setLoginData(response);
                            $state.go('dashboard');
                        }
                    }

                });
            }
        }
    };

    vm.rspStaus = function (id, response) {
        if (response.refId != undefined) {
            return response.refId.indexOf(id) > -1;
        }
    };

    vm.navigate = function (url, response) {
        $('.modal-backdrop').remove();
        $window.sessionStorage.setItem("8B3414FB", response.id);
        $state.go(url);
    };
    //back to previous page
    vm.backtoPrvsPage = function () {
        vm.lclstrgValues = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("memreg")));
        if (vm.lclstrgValues == null)
            $state.go("contactus");
        else {
            if (vm.lclstrgValues.LoginType == 1)
                $state.go('register/security');
            else
                $state.go('register/social/security');
        }
    };
}]);