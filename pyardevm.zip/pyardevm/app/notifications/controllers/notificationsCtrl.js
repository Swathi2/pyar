﻿angular.module("app").controller('notificationsCtrl', ['notificationSrvc', 'getSessionSrvc', 'msgSrvc', '$scope', '$filter', '$rootScope', "$timeout", "$location", "$state", function (notificationSrvc, getSessionSrvc, msgSrvc, $scope, $filter, $rootScope, $timeout, $location, $state) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.sId = function () { return getSessionSrvc.p_sub(); };
    vm.fn = function () { return getSessionSrvc.p_fn(); };
    vm.tz = function () { return getSessionSrvc.p_tz(); };
    vm.match = false;
    setFooterIcon("alrt");
    vm.pvFromDt = "";
    vm.pvToDt = "";
    vm.notifyTypes = { flirt: 51, profileFillReminder: 52, profilePhoto: 53, galleryPhoto: 54, profileView: 61, profileViewMulti: 62, profileViewBasic: 63 };
    vm.busy = false;
    vm.NoAlrts = null;
    vm.editMode = false;
    vm.searchOn = false;
    vm.zone = function () { return getTimeZoneById(vm.tz()); };
    vm.imageCDN = "https://pccdn.pyar.com";
    vm.showEdit = false;
    vm.notifications = [];
    vm.nonSysNotify = [];
    vm.pgNo = 1;
    vm.pgSize = 20;
    vm.hideType = 1;
    $("#notifyHide").hide();
    vm.alertsList = [];
    vm.basicSearch = 'search';
    vm.resetAlert = false;
    vm.nmTypes = [];
    vm.ntfns = [];
    vm.pvs = [];
    vm.busy = true;
    vm.stopScroll = false;

    vm.getNMTypes = function (funCallBack) {
        notificationSrvc.getNMTypes(function (response, status) {
            funCallBack(response, status);
        });
    };

    // to get list notifications based on mId
    vm.getNotifications = function () {
        if (vm.stopScroll) return;
        vm.busy = true;
        showLoader();
        notificationSrvc.getNotifications(vm.mId(), vm.sId(), vm.pgNo, vm.pgSize, vm.pvFromDt, vm.pvToDt, function (response, status) {
            if (status == 200) {
                vm.ntfns = vm.ntfns.concat(response.notifications);
                vm.pvs = vm.pvs.concat(response.profileViews);

                //check respone length less than pgSize then stop calling on scroll
                if (response.notifications.length < vm.pgSize)
                    vm.stopScroll = true;

                if (vm.pgNo == 1) {
                    //check unread alerts exist reset to 0
                    vm.resetNMCount();

                    //if alerts are empty show empty state
                    if (vm.ntfns.length == 0 && vm.pvs.length == 0) {
                        vm.NoAlrts = true;
                        vm.showEdit = false;
                    }
                    else
                        vm.NoAlrts = false;
                }
                vm.pgNo++;
                vm.prepareNotifications(response.notifications, response.profileViews);
            }
            vm.busy = false;
            hideLoader();
        });
    };

    vm.prepareNotifications = function (ntfns, pvs) {
        if (pvs.length > 0) {
            var date = new Date($filter("orderBy")(pvs, "dtCreated")[0].dtCreated);
            date.setDate(date.getDate() + 1);
            vm.pvToDt = getDate(date);
            ntfns = ntfns.concat(pvs);
        }
        else {
            var date = new Date($filter("orderBy")(ntfns, "dtCreated")[0].dtCreated);
            date.setDate(date.getDate() + 1);
            vm.pvToDt = getDate(date);
        }

        //bind notification msg based on notifyType       

        for (var j = 0; j < ntfns.length; j++) {
            for (var i = 0; i < vm.nmTypes.length; i++) {
                if (ntfns[j].notifyType == vm.nmTypes[i].notifyType) {
                    ntfns[j].NotificationMsg = ($filter('notifyMsg')(vm.nmTypes[i].notificationMsg, ntfns[j].fn, ntfns[j].gender, vm.fn(), ntfns[j].pvCnt));
                    ntfns[j].pp = vm.getPP(ntfns[j].pp, ntfns[j].gender);
                    break;
                }
            }
        }
        //push to existing notifications      
        angular.forEach(ntfns, function (ntfn) {
            vm.notifications.push(ntfn);
        });
        vm.nonSysNotify = vm.nonSysNotify.concat($filter('nonSysNotify')(ntfns, true));
        // if member alters(non-system alerts are exists show edit button
        if (vm.showEdit == false && vm.nonSysNotify.length > 0)
            vm.showEdit = true;
    };

    //Page load start
    vm.getNMTypes(function (response, status) {
        if (status == 200) {
            vm.nmTypes = response;
            vm.getNotifications();
        }
    });
    //page load end

    //edit mode on 
    vm.editOn = function () {
        vm.editMode = true;
        $(".nvtgle").hide();
        $("#pcFtr").hide();
        $("#notifyHide").show();
        vm.hideUnHideTxt = "Hide";
    };

    //edit mode off
    vm.editOff = function () {
        vm.editMode = false;
        $(".nvtgle").show();
        $("#pcFtr").show();
        $("#notifyHide").hide();
        //remove active class and  check
        vm.enableHideBtn = false;
        if ($("#hide" + vm.index))
            $("#hide" + vm.index).removeAttr("checked");
    };

    //check box validation for edit mode
    vm.updateSelection = function (index, notifyData, event) {
        event.preventDefault();
        vm.index = index;
        vm.notifyData = notifyData;
        if (document.getElementById("hide" + vm.index).checked == true) {
            vm.enableHideBtn = false;
            document.getElementById("hide" + vm.index).checked = false;
        }
        else {
            document.getElementById("hide" + vm.index).checked = true;
            vm.enableHideBtn = true;
            vm.memberHideCheck();
        }
    };

    vm.memberHideCheck = function () {
        if (vm.mId() && vm.notifyData.mId) {
            showLoader();
            notificationSrvc.memberHideCheck(vm.mId(), vm.notifyData.mId, function (response, status) {
                if (status == 200) {
                    if (response == true) {
                        vm.hideUnHideTxt = "Unhide";
                        vm.hideType = 2;
                    } else {
                        vm.hideUnHideTxt = "Hide";
                        vm.hideType = 1;
                    }
                }
                hideLoader();
            });
        }
    };

    //hide Click function
    vm.hideClk = function () {
        vm.hideName = vm.notifyData.fn;
        if (vm.hideType == 1)
            $("#hideCnfrmPopup").modal('show');
        else
            vm.unHideClk();
    };

    //hide notification api integration
    vm.hideCnfrmClk = function () {
        if (vm.mId() && vm.notifyData.mId) {
            showLoader();
            $("#hideCnfrmPopup").modal('hide');
            notificationSrvc.addHide(vm.mId(), vm.notifyData.mId, function (response, status) {
                if (status == 200 && response == true) {
                    $("#hidePopup").modal('show');
                    $timeout(function () { $("#hidePopup").modal('hide'); vm.editOff(); }, 2000);
                }
                hideLoader();
            });
        }
    };

    vm.unHideClk = function () {
        if (vm.mId() && vm.notifyData.mId) {
            showLoader();
            notificationSrvc.removeHide(vm.mId(), vm.notifyData.mId, function (response, status) {
                if (status == 200 && response == true)
                    vm.editOff();
                hideLoader();
            });
        }
    };

    //to cancel search and empty srch string
    vm.cancelSrch = function () {
        vm.searchOn = false;
        vm.srchStr = "";
        vm.basicSearch = 'search';
        vm.lenErr = false;
    };

    vm.getPP = function (imageUrl, gender) {
        if (imageUrl)
            return vm.imageCDN + imageUrl.replace("/p/tnb/", "/p/tns/");
        else
            return gender ? vm.imageCDN + "/pcmbr/defaults/profilemtns.jpg" : vm.imageCDN + "/pcmbr/defaults/profileftns.jpg";
    };

    vm.navigate = function (notifyType, tmId) {
        if (notifyType == vm.notifyTypes.flirt || notifyType == vm.notifyTypes.profilePhoto || notifyType == vm.notifyTypes.galleryPhoto) {
            vm.mmcScrollTo = $(window).scrollTop();
            vm.mmc = true;
            $rootScope.$broadcast("openMatch", getSessionSrvc.pce(tmId), "NF");
        }
        else if (notifyType == vm.notifyTypes.profileView || notifyType == vm.notifyTypes.profileViewMulti || notifyType == vm.notifyTypes.profileViewBasic) {
            if (vm.sId() == 2) {
                vm.mmcScrollTo = $(window).scrollTop();
                vm.mmc = true;
                $rootScope.$broadcast("openMatch", getSessionSrvc.pce(tmId), "NF");
            }
            else
                $rootScope.$broadcast("showPremiumPopup", "NTFN");
        }
        else if (notifyType == vm.notifyTypes.profileFillReminder)
            $state.go("profile");
    };

    $scope.$on("closeMatch", function (e, refPgType) {
        if (refPgType == "NF") {
            vm.mmc = false;
            $timeout(function () { window.scrollTo(0, vm.mmcScrollTo); }, 0);
        }
    });
    //empty srch string
    vm.clear = function () {
        vm.srchStr = "";
        vm.basicSearch = 'search';
        vm.lenErr = false;
    };

    //search functionality for notifications
    vm.fetchSrchResults_chg = function (strg) {
        vm.noSrchResults = false;
        vm.basicSearch = 'search';
        vm.lenErr = false;
        if (strg.length >= 1) {
            vm.searchOn = true;
        }
        if (strg.length == 0) {
            vm.noSrchResults = true;
        }
        //content pasted into srch box and length>30
        if (vm.pasted == true && strg.length > 30) {
            vm.srchStr = "";
            vm.basicSearch = "Must be <30 characters";
            vm.lenErr = true;
            vm.pasted = false;
            return;
        }
        else
            vm.lenErr = false;
    };

    //receive live notification
    vm.alerts = [];

    $scope.$on("resetNMCnt", function (e) {
        vm.resetNMCount();
    });

    $scope.$on("receiveNotifications", function (e, tmId, fn, pp, gender, type, date) {
        try {
            if (pp)
                pp = pp + "?v=" + new Date().valueOf();
            vm.alerts.push({ "notifyType": type, "mId": tmId, "fn": fn, "gender": gender, "pp": pp, "dtCreated": date, "NotificationMsg": "", "pvCnt": 1 });
            vm.pushNM();
            if ($rootScope.mnCnt && $rootScope.mnCnt > 0)
                $rootScope.mnCnt += 1;
            else
                $rootScope.mnCnt = 1;
            vm.resetNMCount();
        } catch (e) {
            console.log("receiveNotifications  --  " + e.message);
            alert("receiveNotifications  --  " + e.message);
        }
    });

    vm.resetNMCount = function () {
        if (msgSrvc.conId && $rootScope.mnCnt && $rootScope.mnCnt > 0) {
            msgSrvc.updateMbrNtfnView(vm.mId(), 'R', function (response, status) {
                if (status == 200 && response == true) {
                    $rootScope.mnCnt = 0;
                    vm.resetAlert = false;
                }
            });
        }
    };

    vm.pushNM = function () {
        while (vm.alerts.length > 0) {
            for (var i = 0; i < vm.nmTypes.length; i++) {
                if (vm.alerts[0].notifyType == vm.nmTypes[i].notifyType) {
                    vm.alerts[0].NotificationMsg = ($filter('notifyMsg')(vm.nmTypes[i].notificationMsg, vm.alerts[0].fn, vm.alerts[0].gender, vm.fn(), vm.alerts[0].pvCnt));                   
                    vm.alerts[0].pp = vm.getPP(vm.alerts[0].pp, vm.alerts[0].gender);
                    vm.notifications.unshift(vm.alerts[0]);                   
                    vm.nonSysNotify = vm.nonSysNotify.concat($filter('nonSysNotify')(vm.alerts, true));
                    vm.alerts.splice(0, 1);
                    break;
                }
            }
        }
        // if member alters(non-system alerts are exists show edit button
        if (vm.showEdit == false && $filter('nonSysNotify')(vm.notifications, true).length > 0)
            vm.showEdit = true;
        //check if previouslly notifications empty 
        if (vm.NoAlrts == true && vm.notifications.length > 0)
            vm.NoAlrts = false;
    };

    vm.getDateOrTime = function (dt) {
        try {
            var dtObj = msgSrvc.getDateTimeBasedOnZone(vm.zone(), dt);
            if (dtObj.date)
                return dtObj.date;
            else if (dtObj.time)
                return dtObj.time;
            else
                return "";
        } catch (e) {
            console.log("vm.getDateOrTime notifications  --  " + e.message);
            alert("vm.getDateOrTime notifications  --  " + e.message);
        }
    };
}]);