﻿app.factory('prflphotodataSrvc', function () {
    var imgIndex = null;
    function setImgIndex(data) { imgIndex = data; }
    function getImgIndex() { return imgIndex; }
    return {
        setImgIndex: setImgIndex,
        getImgIndex: getImgIndex
    }
});