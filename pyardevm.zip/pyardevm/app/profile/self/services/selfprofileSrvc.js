﻿app.service('selfprofileSrvc', ['$http', function ($http) {
    this.profileInfo = function (memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/GetProfileInfo/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.GetPrfInfoExt1 = function (memberId, profileInfo, funCallBack) {
        var data = {
            memberId: profileInfo.memberId,
            countryId: profileInfo.countryId,
            stateId: profileInfo.stateId,
            cityId: profileInfo.cityId,
            ethinicityId: profileInfo.ethinicityId,
            rsStatus: profileInfo.rsStatus,
            religionId: profileInfo.religionId,
            highestEdu: profileInfo.highestEdu,
            awId: profileInfo.awId,
            htCountry: profileInfo.htCountry,
            htState: profileInfo.htState,
            htCity: profileInfo.htCity,
            pt: profileInfo.pt
        }
        var url = "https://pcapi.pyar.com/api/profile/GetProfileInfoExt1/" + memberId;
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.GetPrfInfoExt2 = function (memberId, profileInfo, funCallBack) {
        var data = {
            eyeColor: profileInfo.eyeColor,
            height: profileInfo.height,
            hairColor: profileInfo.hairColor,
            build: profileInfo.build,
            diet: profileInfo.diet,
            smoke: profileInfo.smoke,
            drink: profileInfo.drink,
            idealRelationship: profileInfo.idealRelationship,
            childrenCnt: profileInfo.childrenCnt,
            childrenPref: profileInfo.childrenPref,
            petsCnt: profileInfo.petsCnt,
            petsPref: profileInfo.petsPref,
            lang: profileInfo.lang,
            familyLangs: profileInfo.familyLangs,
            religious: profileInfo.religious,
            traditional: profileInfo.traditional,
            hobbies: profileInfo.hobbies
        }
        var url = "https://pcapi.pyar.com/api/profile/GetProfileInfoExt2/" + memberId;
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.MemberHideCheck = function (memberId, memHideId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/hdchk/" + memberId + "/" + memHideId;
        GetServiceByURL($http, url, funCallBack);
    };
    // Page load services End    

    // About Me Services Starts
    // About Me View Dropdowns 
    this.StaticDropDownList = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/AboutMeData";
        GetServiceByURL($http, url, funCallBack);
    };

    //About Me Search Info
    this.aboutmeSearch = function (countryId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/searchdata/" + countryId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.aboutmeUpdate = function (memberId, ethinicityId, religionId, awId, rsStatus, highestEdu, htCountry, htState, htCity, htZipCode, profileCmplnPrcnt, funCallBack) {
        var data = {
            memberId: memberId, ethinicityId: ethinicityId, religionId: religionId, awId: awId,
            rsStatus: rsStatus, highestEdu: highestEdu, htCountry: htCountry, htState: htState, htCity: htCity, htZipCode: htZipCode, profileCmplnPrcnt: profileCmplnPrcnt
        }
        var url = "https://pcapi.pyar.com/api/profile/AboutMeU";
        PostServiceByURL($http, url, data, funCallBack);
    };
    //About Me services End

    //Personality Traits Services Starts
    //Getting Personality Traits
    this.PrsnltyTraitsListG = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/Personalitytraits";
        GetServiceByURL($http, url, funCallBack);
    };

    this.PrsnltyTraitsListIU = function (memberId, multiVal, profileCmplnPrcnt, funCallBack) {
        //checking comma based multi val is in correct format or not
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: profileCmplnPrcnt }
            var url = "https://pcapi.pyar.com/api/profile/MyPTU";
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    };
    //PersonalitytraitsServices End

    this.myBioU = function (memberId, bio, profileCmplnPrcnt, funCallBack) {
        var data = { memberId: memberId, bio: bio, profileCmplnPrcnt: profileCmplnPrcnt }
        var url = "https://pcapi.pyar.com/api/profile/MyBioU";
        PostServiceByURL($http, url, data, funCallBack);
    };
    // my bio services End

    //My Photo gallery services starts
    this.getGalleryPhotos = function (memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/getmbrphotos/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Getting all images
    this.getAllImages = function (memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/mbrphotos/getallimgs/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    //upload gallery image
    this.uploadGlryImages = function (memberId, picOrder, formData, funCallBack) {
        var request = {
            method: 'POST',
            url: 'https://pcapi.pyar.com/api/mbrphotos/galleryI/' + memberId + "/" + picOrder,
            data: formData,
            headers: {
                'Content-Type': undefined
            }
        };
        $http(request).success(function (response, status) {
            funCallBack(response, status);
        }).error(function () {
            hideLoader();
        });
    };

    //add gallery photo
    this.GalleryPhotoI = function (memberId, srcImg, srctnImg, photoOrder, funCallBack) {
        var data = { memberId: memberId, srcImg: srcImg, srctnImg: srctnImg, photoOrder: photoOrder };
        var url = "https://pcapi.pyar.com/api/profile/mga";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //delete gallery photo
    this.GalleryPhotoD = function (memberId, mupId, funCallBack) {
        var data = { memberId: memberId, mupId: mupId };
        var url = "https://pcapi.pyar.com/api/mbrphotos/glimgd/" + memberId + "/" + mupId;
        PostServiceByURL($http, url, data, funCallBack);
    };

    //delete profile photo
    this.ProfilePhotoD = function (memberId, mupId, funCallBack) {
        var data = {};
        var url = "https://pcapi.pyar.com/api/mbrphotos/prflimgd/" + memberId + "/" + mupId;
        PostServiceByURL($http, url, data, funCallBack);
    };

    //delete profile photo for social registered user
    this.mbrProfilePhotoD = function (memberId, funCallBack) {
        var data = {};
        var url = "https://pcapi.pyar.com/api/mbrphotos/prflimgd/" + memberId;
        PostServiceByURL($http, url, data, funCallBack);
    };

    //1 for add,2 for edit ppImg:ProfilePic,pptImg:ProfilePicTile,pptnImg:ProfilePicThumbNail
    this.ProfilePhotoAU = function (memberId, actionType, srcImg, ppImg, pptImg, pptnImg, funCallBack) {
        var data = { memberId: memberId, actionType: actionType, srcImg: srcImg, ppImg: ppImg, pptImg: pptImg, pptnImg: pptnImg };
        var url = "https://pcapi.pyar.com/api/profile/mpiae";
        PostServiceByURL($http, url, data, funCallBack);
    };
   
    this.SwapProfilePic = function (memberId, mpuGId, mpuPId, ppImg, pptImg, pptnImg, gallarytnImg, funCallBack) {
        var data = { memberId: memberId, mpuGId: mpuGId, mpuPId: mpuPId, ppImg: ppImg, pptImg: pptImg, pptnImg: pptnImg, gallarytnImg: gallarytnImg };
        var url = "https://pcapi.pyar.com/api/profile/mpiswap";
        PostServiceByURL($http, url, data, funCallBack);
    };
    //My Photo gallery services End

    //My trophies Services starts
    //My Trophies starts(Tatish)
    this.getCountryCode = function (countryId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/countrycode/" + countryId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.socTrophy = function (memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/soctroph/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.sendOtp = function (memberId, countryCode, phone, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/sndtphvc";
        var data = { "memberId": memberId, "countryCode": countryCode, "mobileNo": phone };
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.resendOtp = function (memberId, countryCode, phone, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/resndtphvc";
        var data = { "memberId": memberId, "countryCode": countryCode, "mobileNo": phone };
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.verifyOtp = function (memberId, codeId, code, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/chktphvc/" + memberId + "/" + codeId + "/" + code;
        GetServiceByURL($http, url, funCallBack);
    };
    //My trophies Services End

    //My appearance services starts
    //My appearence service for ddls Starts
    this.ddlsMyAppearence = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/MyAppearanceDDlData";
        GetServiceByURL($http, url, funCallBack);
    };

    //My appearence update service Starts
    this.myAppearenceU = function (memberId, eyeColor, hairColor, build, height, profileCmplnPrcnt, funCallBack) {
        var data = { memberId: memberId, eyeColor: eyeColor, hairColor: hairColor, build: build, height: height, profileCmplnPrcnt: profileCmplnPrcnt }
        var url = "https://pcapi.pyar.com/api/profile/MyAppearanceU";
        PostServiceByURL($http, url, data, funCallBack);
    };
    //My appearance services End

    // My LifeStyle Services starts
    //My life style service for ddls service
    this.ddlsMyLifeStyleDDlData = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/MyLifeStyleDDlData";
        GetServiceByURL($http, url, funCallBack);
    };

   //My MyLifeStyle update service Starts
    this.myLifeStyleU = function (memberId, diet, smoke, drink, idealRelationship, childrenCnt, childrenPref, petsCnt, petsPref, lang, familyLangs, religious, traditional, profileCmplnPrcnt, funCallBack) {
        if (commaSeperatedNumbStrCheck(lang) && commaSeperatedNumbStrCheck(familyLangs)) {
            var data = {
                memberId: memberId,
                diet: diet,
                smoke: smoke,
                drink: drink,
                idealRelationship: idealRelationship,
                childrenCnt: childrenCnt,
                childrenPref: childrenPref,
                petsCnt: petsCnt,
                petsPref: petsPref,
                lang: lang,
                familyLangs: familyLangs,
                religious: religious,
                traditional: traditional,
                profileCmplnPrcnt: profileCmplnPrcnt
            }
            var url = "https://pcapi.pyar.com/api/profile/MyLifeStyleU";
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    };
    //My LifeStyles Services End

    //My hobbies Services Starts
    //Hobbies List service
    this.HobbiesList = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/hobbies";
        GetServiceByURL($http, url, funCallBack);
    };

    this.HobbiesInsert = function (memberId, multiVal, profileCmplnPrcnt, funCallBack) {
        //checking comma based multi val is in correct format or not       
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: profileCmplnPrcnt }
            var url = "https://pcapi.pyar.com/api/profile/MyHobbiesU";
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    };
   //My hobbies Services End

    //saving location
    this.saveLocation = function (memId, countryId, cityId, funCallBack) {
        var localURL = "https://pcapi.pyar.com/api/account/lctn/" + memId + "/" + countryId + "/" + cityId;
        GetServiceByURL($http, localURL, funCallBack);
    };

    //swap image
    this.swapImages = function (memberId, gmpuId, formData, funCallBack) {
        var request = {
            method: 'POST',
            url: 'https://pcapi.pyar.com/api/mbrphotos/swapimg/' + memberId + "/" + gmpuId,
            data: formData,
            headers: {
                'Content-Type': undefined
            }
        };
        $http(request).success(function (response, status) {
            funCallBack(response, status); console.log(response);
        }).error(function () {
            hideLoader();
        });
    };

    //upload profile image
    this.uploadPrflImages = function (memberId, actionType, formData, funCallBack) {
        var request = {
            method: 'POST',
            url: 'https://pcapi.pyar.com/api/mbrphotos/prfImgIU/' + memberId + "/" + actionType,
            data: formData,
            headers: {
                'Content-Type': undefined
            }
        };
        $http(request).success(function (response, status) {
            funCallBack(response, status);
        }).error(function () {
            hideLoader();
        });
    };
}]);