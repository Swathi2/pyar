﻿app.service('selfmatchprefSrvc', ['$http', 'getSessionSrvc', function ($http, getSessionSrvc) {
    var mId = getSessionSrvc.p_mId();
    //member matchprefData
    this.getmmp = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/getmmp/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    // About Me View Dropdowns 
    this.aboutMe = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/AboutMeData";
        GetServiceByURL($http, url, funCallBack);
    };

    //My appearence service for ddls Starts
    this.myAppearance = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/MyAppearanceDDlData";
        GetServiceByURL($http, url, funCallBack);
    };

    //My life style service for ddls Starts
    this.myLifeStyle = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/MyLifeStyleDDlData";
        GetServiceByURL($http, url, funCallBack);
    };

    var updateMpData = { memberId: mId, minAge: "", maxAge: "", locRadius: "", locType: "", countryId: "", stateId: "", cityId: "", zipCode: "", awId: "", highestEdu: "", htCountry: "", htState: "", htCity: "", htZipCode: "", minHeight: "", maxHeight: "", smoke: "", drink: "", idealRelationship: "", childrenCnt: "", childrenPref: "", petsCnt: "", petsPref: "", religious: "", traditional: "" }
    this.prefAge = function (minAge, maxAge, funCallBack) {
        updateMpData.minAge = minAge;
        updateMpData.maxAge = maxAge;
        var url = "https://pcapi.pyar.com/api/matchpref/age";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefDistance = function (locRadius, locType, countryId, stateId, cityId, latitude, longitute, locRadiusDistance, funCallBack) {
        updateMpData.locRadius = locRadius;
        updateMpData.locType = locType;
        updateMpData.countryId = countryId;
        updateMpData.stateId = stateId;
        updateMpData.cityId = cityId;
        updateMpData.latitude = latitude;
        updateMpData.longitute = longitute;
        updateMpData.locRadiusDistance = locRadiusDistance;
        var url = "https://pcapi.pyar.com/api/matchpref/distance";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefAreaOfWork = function (awId, funCallBack) {
        updateMpData.awId = awId;
        var url = "https://pcapi.pyar.com/api/matchpref/areaofwork";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefEducation = function (highestEdu, funCallBack) {
        updateMpData.highestEdu = highestEdu;
        var url = "https://pcapi.pyar.com/api/matchpref/education";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefHometown = function (htCountry, htState, htCity, htZipCode, funCallBack) {
        updateMpData.htCountry = htCountry;
        updateMpData.htState = htState;
        updateMpData.htCity = htCity;
        updateMpData.htZipCode = htZipCode;
        var url = "https://pcapi.pyar.com/api/matchpref/hometown";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefHeight = function (minHeight, maxHeight, funCallBack) {
        updateMpData.minHeight = minHeight;
        updateMpData.maxHeight = maxHeight;
        var url = "https://pcapi.pyar.com/api/matchpref/heights";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefSmoking = function (smoke, funCallBack) {
        updateMpData.smoke = smoke;
        var url = "https://pcapi.pyar.com/api/matchpref/smoking";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefDrinking = function (drink, funCallBack) {
        updateMpData.drink = drink;
        var url = "https://pcapi.pyar.com/api/matchpref/drinking";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefRelationship = function (idealRelationship, funCallBack) {
        updateMpData.idealRelationship = idealRelationship;
        var url = "https://pcapi.pyar.com/api/matchpref/relationship";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefChildrenCnt = function (childrenCnt, funCallBack) {
        updateMpData.childrenCnt = childrenCnt;
        var url = "https://pcapi.pyar.com/api/matchpref/children";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefChildren = function (childrenPref, funCallBack) {
        updateMpData.childrenPref = childrenPref;
        var url = "https://pcapi.pyar.com/api/matchpref/childpref";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefPets = function (petsCnt, funCallBack) {
        updateMpData.petsCnt = petsCnt;
        var url = "https://pcapi.pyar.com/api/matchpref/pets";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefPetPref = function (petsPref, funCallBack) {
        updateMpData.petsPref = petsPref;
        var url = "https://pcapi.pyar.com/api/matchpref/petpref";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefReligious = function (religious, funCallBack) {
        updateMpData.religious = religious;
        var url = "https://pcapi.pyar.com/api/matchpref/religious";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefCultural = function (traditional, funCallBack) {
        updateMpData.traditional = traditional;
        var url = "https://pcapi.pyar.com/api/matchpref/cultural";
        PostServiceByURL($http, url, updateMpData, funCallBack);
    };

    this.prefRadius = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/utils/radius/";
        GetServiceByURL($http, url, funCallBack);
    };

    this.getMpPrefData = function (memId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/memberpref/" + memId;
        GetServiceByURL($http, url, funCallBack);
    };
    //My MyLifeStyle update service End

    //Ethnicities
    this.getMpEthnicities = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/ethnicities/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Religions
    this.getMpReligions = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/religions/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    //RelationshipStatus
    this.getMpRSStatus = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/status/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    //PersonalityTraits
    this.getMpPTraits = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/traits/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    //EyeColour
    this.getMpEyeColour = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/eyecolour/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    //HairColour
    this.getMpHairColour = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/haircolour/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Build
    this.getMpBuild = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/build/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Diet
    this.getMpDiet = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/diet/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Languages
    this.getMpLanguages = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/languages/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Family Languages
    this.getMpFamLanguage = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/famlanguage/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Hobbies
    this.getMphobbies = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/hobbies/" + mId;
        GetServiceByURL($http, url, funCallBack);
    };
    
    this.EthnicitiesIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = "https://pcapi.pyar.com/api/matchpref/ethncty";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        }
        else
            alert("Incorrect Id's Formation");
    };
   
    this.ReligionsIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = "https://pcapi.pyar.com/api/matchpref/rlgns";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);

        }
        else
            alert("Incorrect Id's Formation");
    };
   
    this.RSStatusIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = "https://pcapi.pyar.com/api/matchpref/rssts";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    };
     
    this.PersonalityTraitsIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = "https://pcapi.pyar.com/api/matchpref/pts";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    };
        
    this.EyeColourIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = "https://pcapi.pyar.com/api/matchpref/eyeclr";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        }
        else
            alert("Incorrect Id's Formation");
    };
     
    this.HairColourIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = "https://pcapi.pyar.com/api/matchpref/hrclr";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        }
        else
            alert("Incorrect Id's Formation");
    };

    this.BuildIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = "https://pcapi.pyar.com/api/matchpref/blds";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        }
        else
            alert("Incorrect Id's Formation");
    };

    this.DietIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = "https://pcapi.pyar.com/api/matchpref/dts";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        }
        else
            alert("Incorrect Id's Formation");
    };
    
    this.LanguagesIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = "https://pcapi.pyar.com/api/matchpref/langs";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        }
        else
            alert("Incorrect Id's Formation");
    };
    
    this.FamLanguagesIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = "https://pcapi.pyar.com/api/matchpref/fmlylangs";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        }
        else
            alert("Incorrect Id's Formation");
    };

    this.HobbiesIU = function (memberId, multiVal, funCallBack) {
        if (commaSeperatedNumbStrCheck(multiVal)) {
            var url = "https://pcapi.pyar.com/api/matchpref/hobbies";
            var data = { memberId: memberId, multiVal: multiVal, profileCmplnPrcnt: null }
            PostServiceByURL($http, url, data, funCallBack);
        } else
            alert("Incorrect Id's Formation");
    };

    // Match summary getMpPrefDataExt1
    this.getMpPrefDataExt1 = function (prefData, funCallBack) {
        var data = {
            countryId: prefData.countryId,
            stateId: prefData.stateId,
            cityId: prefData.cityId,
            awId: prefData.awId,
            highestEdu: prefData.highestEdu,
            htCountry: prefData.htCountry,
            htState: prefData.htState,
            htCity: prefData.htCity,
            htZipCode: prefData.htZipCode,
            smoke: prefData.smoke,
            drink: prefData.drink,
            idealRelationship: prefData.idealRelationship,
            childrenPref: prefData.childrenPref,
            petsPref: prefData.petsPref,
            religious: prefData.religious,
            traditional: prefData.traditional
        }
        var url = "https://pcapi.pyar.com/api/matchpref/matchprefinfo";
        PostServiceByURL($http, url, data, funCallBack);
    };

    // Match summary getMpPrefDataExt2
    this.getMpPrefDataExt2 = function (memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/matchpref/matchprefmultiple/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };
}]);