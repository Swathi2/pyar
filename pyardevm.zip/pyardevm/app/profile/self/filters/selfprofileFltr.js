﻿//filter for changing text to pets count
angular.module("app").filter("petCountFltr", function () {
    return function (ptsCnt) {
        if (ptsCnt == 0 || ptsCnt == null || ptsCnt == "") return "I have no pets";
        else if (ptsCnt == 1) return "I have " + ptsCnt + " pet";
        else return "I have " + ptsCnt + " pets";
    }
});

//filter changing text to pets preference
angular.module("app").filter("petsPrefFltr", function () {
    return function (ptspref) {
        if (ptspref == "Yes") return "I want pets";
        else if (ptspref == "No") return "I don’t want pets";
        else if (ptspref == "Unsure") return "I may want pets";
    }
});

//filter for changing text to children count
angular.module("app").filter("childCountFltr", function () {
    return function (chldCnt) {
        if (chldCnt == 0 || chldCnt == null || chldCnt == "") return "I have no children";
        else if (chldCnt == 1) return "I have " + chldCnt + " child";
        else return "I have " + chldCnt + " children";
    }
});

//filter for changing text to children preference
angular.module("app").filter("childPrefFltr", function () {
    return function (chldPref) {
        if (chldPref == "Yes") return "I want children";
        else if (chldPref == "No") return "I don’t want children";
        else if (chldPref == "Unsure") return "I may want children";
    }
});

//filter for changing profile pic based on gender
angular.module("app").filter("PrflPicFltr", function () {
    var dtn = new Date().valueOf();
    return function (pic, gndr, storageCollection) {
        if (pic == null || pic == "") 
            if (gndr == true) return gndr = "https://pccdn.pyar.com/pcmbr/defaults/profilemtnb.jpg";
            else return gndr = "https://pccdn.pyar.com/pcmbr/defaults/profileftnb.jpg";
     else
            return gndr = "https://pccdn.pyar.com/" + pic
  }
});

angular.module("app").filter("otherPrflPicFltr", function () {
    var dtn = new Date().valueOf();
    return function (pic, gndr, storageCollection) {
        if (pic == null || pic == "")
             if (gndr == true) return gndr = "https://pccdn.pyar.com/pcimgs/profilePicM.jpg";
             else return gndr = "https://pccdn.pyar.com/pcimgs/profilePicF.jpg";
        else
          return gndr = "https://pccdn.pyar.com/" + pic.replace("/tnb/", "/tn/");
    }
});

//changing gender image based on gender
angular.module("app").filter("GenderPicFltr", function () {
    return function (gndr) {
        if (gndr == true) return "https://pccdn.pyar.com/pcimgs/m/male-syn.png";
        else return "https://pccdn.pyar.com/pcimgs/m/female-syn.png";
    }
});

//change text gender (Men or Women)
angular.module("app").filter("gndrTxtFltr", function () {
    return function (gdrPrf) {
        if (gdrPrf == true) return "Men";
        else return "Women";
    }
});

//change text gender (he or she)
angular.module("app").filter("gndrTxtHorSFltr", function () {
    return function (gdrPrf) {
        if (gdrPrf == true) return "he";
        else return "she";
    }
});

//change text genderPrf (his or Her)
angular.module("app").filter("gndrTxtHerOrHimSFltr", function () {
    return function (gdrPrf) {
        if (gdrPrf == true) return "him";
        else return "her";
    }
});

//change text gender (his or Her)
angular.module("app").filter("gndrHerOrHisSFltr", function () {
    return function (gndr) {
        if (gndr == true) return "his";
        else return "her";
    }
});

//change text gender (him or Her)
angular.module("app").filter("gndrHerOrHimSFltr", function () {
    return function (gndr) {
        if (gndr == true) return "him";
        else return "her";
        }
});

//change gender small Image
angular.module("app").filter("smGndrImgFltr", function () {
    return function (gdrPrf) {
        if (gdrPrf == true) return "https://pccdn.pyar.com/pcimgs/m/male-sfsyn.png";
        else return "https://pccdn.pyar.com/pcimgs/m/female-sfsyn.png";
    }
});

//change large small Image
angular.module("app").filter("lrgGndrImgFltr", function () {
    return function (gdrPrf) {
        if (gdrPrf == true) return "https://pccdn.pyar.com/pcimgs/m/male-icon.png";
        else return "https://pccdn.pyar.com/pcimgs/m/female-icon.png";
    }
});