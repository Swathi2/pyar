﻿function IsValueExists(status) {
    if (status != "" && status != null && status != undefined && status.length != 0)
        return true
    else
        return false;
};

function GetHmCntry(Country, State) {
    if (Country == "" || Country == null) return State;
    else return State + ", " + Country;
};

//Splitting response data into two parts
function tblSplit(data, callBack) {
    var t1 = Math.round(data.length / 2);
    var t2 = (data.length) - t1;
    callBack(t1, t2);
};

//Get JSON Data that Contains status property true only.
function getJSonActiveData(data, pushVal) {
    if (data != null || data != undefined) {
        for (var i = 0; i < data.length; i++) {
            if (data[i].status == true) {
                pushVal.push(data[i]);
            }
        }
    }
};

function getJSonActiveDataText(data, pushVal) {
    if (data != null) {
        for (var i = 0; i < data.length; i++) {
            pushVal.push(" " + data[i].txt);
        }
    }
};

//Santhosh: This functions is using in Match Summary popups both self profile & others profile:  Starts
function AboutMeMSFunc(Ethnicities, Religions, AreaOfWork, RSStatus, HighestEduc, Location) {
    var EthnicitiesArr = []; getJSonActiveDataText(Ethnicities, EthnicitiesArr);
    var ReligionsArr = []; getJSonActiveDataText(Religions, ReligionsArr);
    var RSStatusArr = []; getJSonActiveDataText(RSStatus, RSStatusArr);

    if (typeof (Ethnicities) == "object") { Ethnicities = EthnicitiesArr.join(); }
    if (typeof (Religions) == "object") { Religions = ReligionsArr.join(); }
    if (typeof (RSStatus) == "object") { RSStatus = RSStatusArr.join(); }

    return [{ Id: Ethnicities, Img: "https://pccdn.pyar.com/pcimgs/m/hm-b.png", status: IsValueExists(Ethnicities) },
           { Id: Religions, Img: "https://pccdn.pyar.com/pcimgs/m/regn-b.png", status: IsValueExists(Religions) },
           { Id: AreaOfWork, Img: "https://pccdn.pyar.com/pcimgs/m/aow-b.png", status: IsValueExists(AreaOfWork) },
           { Id: RSStatus, Img: "https://pccdn.pyar.com/pcimgs/m/rel-b.png", status: IsValueExists(RSStatus) },
           { Id: HighestEduc, Img: "https://pccdn.pyar.com/pcimgs/m/edu-b.png", status: IsValueExists(HighestEduc) },
           { Id: Location, Img: "https://pccdn.pyar.com/pcimgs/m/loc-b.png", status: IsValueExists(Location) }];
};

function MyApprnceMSFunc(EyeColour, HairColour, maxHeight, Build, genderImg) {
    var eyeColourArr = []; getJSonActiveDataText(EyeColour, eyeColourArr);
    var hairColourArr = []; getJSonActiveDataText(HairColour, hairColourArr);
    var buildArr = []; getJSonActiveDataText(Build, buildArr);
    genderImg = genderImg ? "https://pccdn.pyar.com/pcimgs/m/hairm-b.png" : "https://pccdn.pyar.com/pcimgs/m/hairfm.png";

    if (typeof (EyeColour) == "object") { EyeColour = eyeColourArr.join(); }
    if (typeof (HairColour) == "object") { HairColour = hairColourArr.join(); }
    if (typeof (Build) == "object") { Build = buildArr.join(); }

    return [{ Id: EyeColour, Img: "https://pccdn.pyar.com/pcimgs/m/eyeo-b.png", status: IsValueExists(EyeColour) },
           { Id: HairColour, Img: genderImg, status: IsValueExists(HairColour) },
           { Id: maxHeight, Img: "https://pccdn.pyar.com/pcimgs/m/hgt-b.png", status: IsValueExists(maxHeight) },
           { Id: Build, Img: "https://pccdn.pyar.com/pcimgs/m/bld-b.png", status: IsValueExists(Build) }];
};

function LifeStyleMSFunc($filter, Diet, Smoke, Drink, IdealRelationship, ChildrenCount, ChildrenPref, PetsCount, PetsPref, Languages, FamilyLanguages, Religious, Traditional) {
    var DietArr = []; getJSonActiveDataText(Diet, DietArr);
    var LangArr = []; getJSonActiveDataText(Languages, LangArr);
    var FmlyLangArr = []; getJSonActiveDataText(FamilyLanguages, FmlyLangArr);

    if (typeof (Diet) == "object") { Diet = DietArr.join(); }
    if (typeof (Languages) == "object") { Languages = LangArr.join(); }
    if (typeof (FamilyLanguages) == "object") { FamilyLanguages = FmlyLangArr.join(); }

    return [{ Id: Diet, Img: "https://pccdn.pyar.com/pcimgs/m/diet-b.png", status: IsValueExists(Diet) },
           { Id: Smoke + " smoke", Img: "https://pccdn.pyar.com/pcimgs/m/smoke-b.png", status: IsValueExists(Smoke) },
           { Id: Drink + " drink", Img: "https://pccdn.pyar.com/pcimgs/m/drink-b.png", status: IsValueExists(Drink) },
           { Id: "I want a " + IdealRelationship + " relationship", Img: "https://pccdn.pyar.com/pcimgs/m/relsts-b.png", status: IsValueExists(IdealRelationship) },
           { Id: $filter('childCountFltr')(ChildrenCount), Img: "https://pccdn.pyar.com/pcimgs/m/chld-b.png", status: IsValueExists(ChildrenCount) },
           { Id: $filter('childPrefFltr')(ChildrenPref), Img: "https://pccdn.pyar.com/pcimgs/m/chld-b.png", status: IsValueExists(ChildrenPref) },
           { Id: $filter('petCountFltr')(PetsCount), Img: "https://pccdn.pyar.com/pcimgs/m/pets-b.png", status: IsValueExists(PetsCount) },
           { Id: $filter('petsPrefFltr')(PetsPref), Img: "https://pccdn.pyar.com/pcimgs/m/pets-b.png", status: IsValueExists(PetsPref) },
           { Id: "Prefer " + Languages, Img: "https://pccdn.pyar.com/pcimgs/m/glb-b.png", status: IsValueExists(Languages) },
           { Id: "Family speaks " + FamilyLanguages, Img: "https://pccdn.pyar.com/pcimgs/m/glb-b.png", status: IsValueExists(FamilyLanguages) },
           { Id: Religious + " religious", Img: "https://pccdn.pyar.com/pcimgs/m/regs-b.png", status: IsValueExists(Religious) },
           { Id: Traditional + " traditional", Img: "https://pccdn.pyar.com/pcimgs/m/hbts-b.png", status: IsValueExists(Traditional) }];
};
//Santhosh: This functions is using in Match Summary popups both self profile & others profile:  End

//for calculating profile completion
function prfCmpltn(firstName, gender, dob, cityId, ethinicityId, religionId, awId, rsStatus, highestEdu, htCountry, htCity, myBioData,
    eyeColor, hairColor, build, height, diet, smoke, drink, idealRelationship, childrenCnt, childrenPref, petsCnt,
    petsPref, familyLang, langPref, religious, traditional, PersonalityTraits, hobbies) {

    var myVal = 0;
    var paramCount = 0;
    //for get paramters count, passed to this function
    paramCount = prfCmpltn.length;

    function IncVal() { myVal = myVal + 1; }
    function getVal(val) { if (val != "" && val != null && val != undefined && val.length != 0) { IncVal(); } }

    getVal(firstName);
    getVal(gender);
    getVal(dob);
    getVal(cityId);
    getVal(ethinicityId);
    getVal(religionId);
    getVal(awId);
    getVal(rsStatus);
    getVal(highestEdu);
    getVal(htCountry);
    getVal(htCity);
    getVal(eyeColor);
    getVal(hairColor);
    getVal(build);
    getVal(height);
    getVal(diet);
    getVal(smoke);
    getVal(drink);
    getVal(idealRelationship);
    getVal(childrenCnt);
    getVal(childrenPref);
    getVal(petsCnt);
    getVal(petsPref);
    getVal(familyLang);
    getVal(langPref);
    getVal(religious);
    getVal(traditional);
    getVal(myBioData);
    getVal(PersonalityTraits);
    getVal(hobbies);
    var percentage = Math.round(myVal / paramCount * 100);
    return percentage;
};

function getProfilepercent(sfData) {
    var prflData = sfData.prflData;
    var abtme = sfData.abtme;
    var apprnce = sfData.apprnce;
    var hbbys = sfData.hbbys;
    var lfstyl = sfData.lfstyl;
    var prsnlty = sfData.prsnlty;
    var Bio = sfData.Bio;
    return prfCmpltn(prflData.firstName, JSON.stringify(prflData.Gender), prflData.dob, prflData.cityId,
        abtme.etnctyId, abtme.rglnId, abtme.aOfWrkId, abtme.stsId, abtme.dgrId, abtme.htcntryId, prflData.htCity, Bio.mybio,
        apprnce.eyeId, apprnce.hairId, apprnce.bldId, apprnce.htId, lfstyl.ditId, lfstyl.smkId, lfstyl.drnkId, lfstyl.irltnshpId, lfstyl.chldrnCntId, lfstyl.chldrnPrefId, lfstyl.ptsCntId,
        lfstyl.ptsPrefId, lfstyl.lstylelngPrefIds.join(), lfstyl.lstylefmlyLangIds.join(), lfstyl.rlgsId, lfstyl.trdtnlId, prsnlty.join(), hbbys.join());
};