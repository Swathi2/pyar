﻿angular.module("app").controller('eplhbysCtrl', ['selfprofileSrvc', 'getSessionSrvc', '$window', '$state', function (selfprofileSrvc,getSessionSrvc, $window, $state) {
    showLoader();
    var vm = this;
    vm.hbbys = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo"))).hbbys;
    if (!vm.hbbys) {$state.go('profile');return;}
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.activehbIds = vm.hbbys;

    selfprofileSrvc.HobbiesList(function (response) {
        var result = {};
        var key = 'categoryName';
        for (var i = 0; i < response.length; i++) {
            if (!result[response[i][key]]) {
                result[response[i][key]] = [];
            }
            result[response[i][key]].push(response[i]);
        }
        vm.hobbylst = response;
        vm.lstHobbies = result;
        hideLoader();
    });

    vm.hobbiesChkClick = function (HobbyId) {
        if (vm.activehbIds.indexOf(HobbyId) == -1)
            vm.activehbIds.push(HobbyId);
        else
            vm.activehbIds.splice(vm.activehbIds.indexOf(HobbyId), 1);
    };

    vm.myHobbiesCancel = function () {
        $state.go('editprofile');
    };

    vm.myHobbiesDone = function () {
        showLoader();
        var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
        sfData.hbbys = vm.activehbIds;
        vm.prfPercentage = getProfilepercent(sfData);
        if (vm.activehbIds != undefined) {
            selfprofileSrvc.HobbiesInsert(vm.mId(), vm.activehbIds.join(), vm.prfPercentage, function (response, status) {
                hideLoader();
                if (status == 200 && response == true) {
                    $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                    $state.go('editprofile');
                }
                else
                    alert("Error in saving data");
            });
        }
    };
}]);