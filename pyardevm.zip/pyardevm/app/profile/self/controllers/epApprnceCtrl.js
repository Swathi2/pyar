﻿angular.module("app").controller('epApprnceCtrl', ['selfprofileSrvc', 'getSessionSrvc', '$window', '$state', function (selfprofileSrvc, getSessionSrvc, $window, $state) {
    showLoader();
    var vm = this;
    vm.apprnce = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo"))).apprnce;
    if (!vm.apprnce) { $state.go('profile'); return; }
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.gender = function () { return getSessionSrvc.p_gndr(); };
    vm.measure = function () { return getSessionSrvc.p_uts(); }
    
    if (!vm.apprnce.eyeId)
        vm.eyeIdTxt = "";
    if (!vm.apprnce.hairId)
        vm.hairIdTxt = "";
    if (!vm.apprnce.htId)
        vm.htIdTxt = "";
    if (!vm.apprnce.bldId)
        vm.bldIdTxt = "";
    vm.eyeClrs = { 1: 'black', 2: 'blue', 3: 'brown', 4: 'grey', 5: 'green', 6: 'hazel', 7: 'purple' };
    vm.fmlHairClrs = { 1: 'hblk', 2: 'hdrkbwn', 3: 'hlgtbwn', 4: 'hylw', 5: 'hred', 6: 'hgray', 7: 'hwht', 8: 'hbald', 9: 'hprpl' };
    vm.mlHairClrs = { 1: 'hblk', 2: 'hbrwn', 3: 'hlgtbrwn', 4: 'hylw', 5: 'hred', 6: 'hgray', 7: 'hwht', 8: 'hbald', 9: 'hprpl' }
    //My appearance ddls service called starts
    selfprofileSrvc.ddlsMyAppearence(function (response, status) {
        vm.build = response.build;
        vm.height = response.height;
        vm.eyecolor = response.eyecolor;
        vm.haircolor = response.haircolor;

        angular.forEach(vm.eyecolor, function (data) {
            if (data.val == vm.apprnce.eyeId)
                vm.eyeIdTxt = data.txt;
        });

        angular.forEach(vm.haircolor, function (data) {
            if (data.val == vm.apprnce.hairId)
                vm.hairIdTxt = data.txt;
        });

        angular.forEach(vm.build, function (data) {
            if (data.val == vm.apprnce.bldId)
                vm.bldIdTxt = data.txt;
        });

        angular.forEach(vm.height, function (data) {
            if (data.val == vm.apprnce.htId) {
                vm.htIdTxt = data.txt;
                vm.htIdTxt = vm.getddlHeight(vm.htIdTxt);
            }
        });
        hideLoader();
    });
    //My appearance ddls service called ends
    //Eyecolor Image Binding
    vm.eyeImageBinding = function () {
        vm.color = vm.eyeClrs[vm.apprnce.eyeId];
        if (vm.gender() == true) {
            if (!vm.apprnce.eyeId)
                vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-black.png';
            else 
                vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-' + vm.color + '.png';                       
        }
        else {
            if (!vm.apprnce.eyeId)
                vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-black.png';      
          else
            vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-' + vm.color + '.png';         
        }
    };
    vm.eyeImageBinding();

    //Haircolor Image Binding
    vm.hairImageBinding = function () {
        if (vm.gender() == true) {
            vm.hair = vm.mlHairClrs[vm.apprnce.hairId];
            if (!vm.apprnce.hairId )
                vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hblk.png';
            else 
                vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-' + vm.hair + '.png';
        }
        else {
            vm.hair = vm.fmlHairClrs[vm.apprnce.hairId];
            if (!vm.apprnce.hairId)
                vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hblk.png';
            else 
                vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-' + vm.hair + '.png';
        }
        //add active class for clicked one
        $("#ul #imgHair" + vm.apprnce.hairId).addClass('active');
        //removing active class for links (tab data links)
        $("#ul img[id^='imgHair']").not("#imgHair" + vm.apprnce.hairId).removeClass('active');
    };
    vm.hairImageBinding();

    //Click function for eye
    vm.selectEyeclr = function (eyeId) {
        if ($("#imgeye" + eyeId).hasClass('active')) {
            $("#imgeye" + eyeId).removeClass('active');
            vm.apprnce.eyeId = null;
            vm.eyeIdTxt = '';
        }
        else {
            vm.apprnce.eyeId = eyeId;
            vm.eyecolor.forEach(function (data) {
                if (data.val == eyeId)
                    vm.eyeIdTxt = data.txt;
            });
        }
        vm.eyeImageBinding();
    };

    //Click function for hair
    vm.selectHairclr = function (hairId) {
        
        if ($("#imgHair" + hairId).hasClass('active')) {
            $("#imgHair" + hairId).removeClass('active');
            vm.apprnce.hairId = null;
            vm.hairIdTxt = '';
        }
        else {
            vm.apprnce.hairId = hairId;
            vm.haircolor.forEach(function (data) {
                if (data.val == hairId)
                    vm.hairIdTxt = data.txt;
            });
        }
        vm.hairImageBinding();
    };

    //Clear values 
    vm.heightIU = function () {
        vm.apprnce.htId = '';
        vm.htIdTxt = '';
        vm.selectedheight = '';
    };

    vm.buildIU = function () {
        vm.apprnce.bldId = '';
        vm.bldIdTxt = '';
        vm.selectedbuild = '';
    };

    vm.ddlhightChange = function () {
        vm.apprnce.htId = vm.selectedheight.val;
        vm.htIdTxt = vm.selectedheight.txt;
        vm.htIdTxt = vm.getddlHeight(vm.htIdTxt);
    };

    vm.ddlbuildChange = function () {
        vm.apprnce.bldId = vm.selectedbuild.val;
        vm.bldIdTxt = vm.selectedbuild.txt;
    };

    //function to getting inches or cm text
    vm.getddlHeight = function (height) {
        var fields = height.split('or');
        var unit1 = fields[0];
        var unit2 = fields[1];
        if (vm.measure() == 1) {
            unit1 = replaceInches(unit1, " feet", "'");
            unit1 = replaceInches(unit1, " inches", "''");
            return unit1 + " tall";
        }
        else
            return unit2;
    };

    //Appearace cancel functionality
    vm.myappearanceCancel = function () {
        $state.go('editprofile');
    };

    //Apperance done functionality
    vm.myappearanceDone = function () {
        showLoader();
        var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
        sfData.apprnce = vm.apprnce;
        vm.prfPercentage = getProfilepercent(sfData);
        selfprofileSrvc.myAppearenceU(vm.mId(), vm.apprnce.eyeId, vm.apprnce.hairId, vm.apprnce.bldId, vm.apprnce.htId, vm.prfPercentage, function (response, status) {
            hideLoader();
            if (status == 200 && response == true) {
                $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                $state.go('editprofile');
            }
        });
    };
}]);