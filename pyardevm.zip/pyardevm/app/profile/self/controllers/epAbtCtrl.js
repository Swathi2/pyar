﻿angular.module("app").controller('epAbtCtrl', ['selfprofileSrvc', 'getSessionSrvc', '$scope', '$window', '$rootScope', '$state', '$timeout', function (selfprofileSrvc, getSessionSrvc, $scope, $window, $rootScope, $state, $timeout) {
    showLoader();
    var vm = this;
    vm.abtme = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo"))).abtme;
    if (!vm.abtme) { $state.go('profile'); return; }
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.cntryId = function () { return getSessionSrvc.p_cntryId() };
    vm.setDefaultvalues = function () {
        if (!vm.abtme.etnctyId)
            vm.etnctyIdTxt = "";
        if (!vm.abtme.rglnId)
            vm.rglnIdTxt = "";
        if (!vm.abtme.aOfWrkId)
            vm.aOfWrkIdTxt = "";
        if (!vm.abtme.stsId)
            vm.stsIdTxt = "";
        if (!vm.abtme.dgrId)
            vm.dgrIdTxt = "";
        if (!vm.abtme.htcntryId)
            vm.abtme.htcntryId = "";
        if (!vm.abtme.htcityId)
            vm.abtme.htcityId = "";
    };
    vm.setDefaultvalues();

    vm.etnctyIU = function () { vm.abtme.etnctyId = ''; vm.etnctyIdTxt = ''; vm.selectedEtncty = ''; };
    vm.rglnIU = function () { vm.abtme.rglnId = ''; vm.rglnIdTxt = ''; vm.selectedRgln = ''; };
    vm.aOfWrkIU = function () { vm.abtme.aOfWrkId = ''; vm.aOfWrkIdTxt = ''; vm.selectedAofWrk = ''; };
    vm.rsStatusIU = function () { vm.abtme.stsId = ''; vm.stsIdTxt = ''; vm.selectedRsStatus = ''; };
    vm.dgrIU = function () { vm.abtme.dgrId = ''; vm.dgrIdTxt = ''; vm.selectedDgr = ''; };
    vm.locationIU = function () { vm.abtme.htcntryId = ""; vm.abtme.htcityId = ""; };

    // about me dropdowns service called
    selfprofileSrvc.StaticDropDownList(function (response, status) {
        vm.ethnicitiesDdl = response.Ethnicity;
        vm.religionsDdl = response.Religion;
        vm.areaofworksDdl = response.AreaOfWork;
        vm.statusDdl = response.Status;
        vm.degreeDdl = response.Degree;
        
        angular.forEach(vm.ethnicitiesDdl, function (data) {
            if (data.ethnicityId == vm.abtme.etnctyId)
                vm.etnctyIdTxt = data.ethnicityName;
        });

        angular.forEach(vm.religionsDdl, function (data) {
            if (data.religionId == vm.abtme.rglnId)
                vm.rglnIdTxt = data.religionName;
        });

        angular.forEach(vm.areaofworksDdl, function (data) {
            if (data.awId == vm.abtme.aOfWrkId)
                vm.aOfWrkIdTxt = data.awName;
        });

        angular.forEach(vm.statusDdl, function (data) {
            if (data.val == vm.abtme.stsId)
                vm.stsIdTxt = data.txt;
        });

        angular.forEach(vm.degreeDdl, function (data) {
            if (data.val == vm.abtme.dgrId)
                vm.dgrIdTxt = data.txt;
        });
        hideLoader();
    });

    //Drop down  clear functions 
    vm.ddletnctyChange = function () { vm.abtme.etnctyId = vm.selectedEtncty.ethnicityId; vm.etnctyIdTxt = vm.selectedEtncty.ethnicityName;}
    vm.ddlrglnChange = function () { vm.abtme.rglnId = vm.selectedRgln.religionId; vm.rglnIdTxt = vm.selectedRgln.religionName; }
    vm.ddlaOfWrkChange = function () { vm.abtme.aOfWrkId = vm.selectedAofWrk.awId; vm.aOfWrkIdTxt = vm.selectedAofWrk.awName; }
    vm.ddlrsStatusChange = function () { vm.abtme.stsId = vm.selectedRsStatus.val; vm.stsIdTxt = vm.selectedRsStatus.txt; }
    vm.ddldgrChange = function () { vm.abtme.dgrId = vm.selectedDgr.val; vm.dgrIdTxt = vm.selectedDgr.txt; }

    //About cancel functionallity
    vm.aboutMeCancel = function () {
        $state.go('editprofile');
    };

    // About done functionallity
    vm.aboutMeDone = function () {
        showLoader();
        var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
        sfData.abtme = vm.abtme;
        vm.prfPercentage = getProfilepercent(sfData);
        selfprofileSrvc.aboutmeUpdate(vm.mId(), vm.abtme.etnctyId, vm.abtme.rglnId, vm.abtme.aOfWrkId, vm.abtme.stsId, vm.abtme.dgrId, vm.abtme.htcntryId, vm.abtme.htstateId, vm.abtme.htcityId, 11111, vm.prfPercentage, function (response, status) {
            hideLoader();
            if (status == 200 && response == true) {
                $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                $state.go('editprofile');
            }
        });
    };
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( BINDING LOCATION FUNCTIONALITY STARTS HERE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
    /*******************************************************************************************************************************************************************/
    vm.countryPageOpen = function () {
        $rootScope.$broadcast("showLocation", "bindLoction");
    };

    //city intelligence module
    $scope.$on("countryBind", function (e, locId, countryId, data) {
        vm.abtme.htcntryId = data.countryId;
        vm.abtme.htcityId = data.cityId;
        if (vm.mId() != null && vm.abtme.htcntryId && vm.abtme.htcityId)
            vm.location = bindLocation(data, vm.cntryId());
    });

    vm.GetCity = function (locId, countryId, cityId) {
        $rootScope.$broadcast("GetCity", locId, countryId, cityId);
    };

    $scope.$on("BindCity", function (e, locId, data) {
        vm.location = bindLocation(data, vm.cntryId());
        hideLoader();
    });
   
    $scope.$on("countryUnBind", function (e, locId, data) {
        var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));;
        vm.abtme.htcntryId = sfData.abtme.htcntryId;
        vm.abtme.htcityId = sfData.abtme.htcityId;
        vm.GetCity("bindLoction", vm.abtme.htcntryId, vm.abtme.htcityId);
    });

    if (vm.abtme.htcntryId && vm.abtme.htcityId) {
        $timeout(function () {
            vm.GetCity("bindLoction", vm.abtme.htcntryId, vm.abtme.htcityId);
        }, 1000);
    }
    else
        hideLoader();
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( BINDING LOCATION FUNCTIONALITY ENDS HERE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
    /*******************************************************************************************************************************************************************/
}]);