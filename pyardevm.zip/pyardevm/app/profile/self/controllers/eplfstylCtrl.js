﻿angular.module("app").controller('eplfstylCtrl', ['selfprofileSrvc', 'getSessionSrvc', '$scope', '$window', '$state', '$timeout', function (selfprofileSrvc, getSessionSrvc, $scope, $window, $state, $timeout) {
    showLoader();
    var vm = this;
    vm.lfstyl = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo"))).lfstyl;
    if (!vm.lfstyl) { $state.go('profile'); return; }
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.langLimit = 30;
    
    selfprofileSrvc.ddlsMyLifeStyleDDlData(function (response, status) {
        vm.diets = response.diet;
        vm.smoke = response.smoke;
        vm.drinkDdl = response.drink;
        vm.idealRelationship = response.IdealRelationShip;
        vm.numOfChildren = response.numOfChildren;
        vm.childrenPrefDdl = response.childrenPref;
        vm.petsCntDdl = response.numOfPets;
        vm.petsPrefDdl = response.petPref;
        vm.religiousDdl = response.Religious;
        vm.traditionalDdl = response.traditional;
        vm.prefLang = response.language;
        vm.familyLang = response.language;

        if (vm.lfstyl.lstylelngPrefIds.length > 0) {
            var preflangTxt = [];
            vm.prefLang.forEach(function (data) {
                if (vm.lfstyl.lstylelngPrefIds.indexOf(data.val) != -1)
                    preflangTxt.push(data.txt);
            });
        }
        
        if (vm.lfstyl.lstylefmlyLangIds.length > 0) {
            var preflangTxt = [];
            vm.familyLang.forEach(function (data) {
                if (vm.lfstyl.lstylefmlyLangIds.indexOf(data.val) != -1) {
                    preflangTxt.push(data.txt);
                }
            });
        }

        if (vm.lfstyl.chldrnCntId == "" || vm.lfstyl.chldrnCntId == null)
            vm.lfstyl.chldrnCntId = 0;

        if (vm.lfstyl.ptsCntId == "" || vm.lfstyl.ptsCntId == null)
            vm.lfstyl.ptsCntId = 0;

        angular.forEach(vm.numOfChildren, function (data) {
            if (data.val == vm.lfstyl.chldrnCntId) {
                vm.chldrnCntIdTxt = data.txt;
            }
        });

        angular.forEach(vm.petsCntDdl, function (data) {
            if (data.val == vm.lfstyl.ptsCntId) {
                vm.ptsCntIdTxt = data.txt;
            }
        });

        //smoke slider binding starts here
        $scope.smokeTicks = [];
        $scope.smokeLabels = [];
        vm.smoke.forEach(function (data) {
            $scope.smokeTicks.push(data.val);
            $scope.smokeLabels.push(data.txt)
        });

        if (vm.lfstyl.smkId > 0)
            vm.smokeVal = vm.lfstyl.smkId;

        $scope.smokstep = "1";
        $timeout(function () {
            $('.smkSldr .slider-tick-label').removeClass("ticklblclr");
            var element = $('.smkSldr .slider-tick-label')[vm.smokeVal - 1];
            if (element)
                element.className = element.className + " ticklblclr";
        }, 100);

        $scope.smokeSlide = function (val) {
            if (!val)
                val = 1;
            $('.smkSldr .slider-tick-label').removeClass("ticklblclr");
            var element = $('.smkSldr .slider-tick-label')[val - 1];
            if (element)
                element.className = element.className + " ticklblclr";
            vm.lfstyl.smkId = val;
        };

        vm.smokeRefresh = function () {
            $('.smkSldr .slider-tick-label').removeClass("ticklblclr");
            vm.smokeVal = null;
            vm.lfstyl.smkId = null;
        };
        //smoke slider binding end

        //drink slider binding
        $scope.drinkTicks = [];
        $scope.drinkLabels = [];
        vm.drinkDdl.forEach(function (data) {
            $scope.drinkTicks.push(data.val);
            $scope.drinkLabels.push(data.txt)
        });

        if (vm.lfstyl.drnkId > 0)
            vm.drinkVal = vm.lfstyl.drnkId;
        $scope.drinkStep = "1";
        $timeout(function () {
            $('.dnkSldr .slider-tick-label').removeClass("ticklblclr");
            var element = $('.dnkSldr .slider-tick-label')[vm.drinkVal - 1];
            if (element)
                element.className = element.className + " ticklblclr";
        }, 100);

        $scope.drinkSlide = function (val) {
            if (!val)
                val = 1;
            $('.dnkSldr .slider-tick-label').removeClass("ticklblclr");
            var element = $('.dnkSldr .slider-tick-label')[val - 1];
            if (element)
                element.className = element.className + " ticklblclr";
            vm.lfstyl.drnkId = val;
        };

        vm.drinkRefresh = function () {
            $('.dnkSldr .slider-tick-label').removeClass("ticklblclr");
            vm.drinkVal = null;
            vm.lfstyl.drnkId = null;
        };
        //drink slider binding End Here.

        //child preferance slider binding
        $scope.wntchTicks = [];
        $scope.wntchLabels = [];
        vm.childrenPrefDdl.forEach(function (data) {
            $scope.wntchTicks.push(data.val);
            $scope.wntchLabels.push(data.txt)
        });

        if (vm.lfstyl.chldrnPrefId > 0)
            vm.childPrefVal = vm.lfstyl.chldrnPrefId;
        $scope.wntchdStep = "1";
        $timeout(function () {
            $('.wntChldrn .slider-tick-label').removeClass("ticklblclr");
            var element = $('.wntChldrn .slider-tick-label')[vm.childPrefVal - 1];
            if (element)
                element.className = element.className + " ticklblclr";
        }, 100);

        $scope.chldrnSlide = function (val) {
            if (!val)
                val = 1;
            $('.wntChldrn .slider-tick-label').removeClass("ticklblclr");
            var element = $('.wntChldrn .slider-tick-label')[val - 1];
            if (element)
                element.className = element.className + " ticklblclr";
            vm.lfstyl.chldrnPrefId = val;
        };

        vm.childPrefRefresh = function () {
            $('.wntChldrn .slider-tick-label').removeClass("ticklblclr");
            vm.childPrefVal = null
            vm.lfstyl.chldrnPrefId = null;
        };
        //child preferance slider binding End Here.

        //pets preferance slider binding
        $scope.wntptsTicks = [];
        $scope.wntptsLabels = [];
        vm.petsPrefDdl.forEach(function (data) {
            $scope.wntptsTicks.push(data.val);
            $scope.wntptsLabels.push(data.txt)
        });

        if (vm.lfstyl.ptsPrefId > 0)
            vm.petsPrefVal = vm.lfstyl.ptsPrefId;
        $scope.wntptsStep = "1";
        $timeout(function () {
            $('.wntPts .slider-tick-label').removeClass("ticklblclr");
            var element = $('.wntPts .slider-tick-label')[vm.petsPrefVal - 1];
            if (element)
                element.className = element.className + " ticklblclr";
        }, 100);

        $scope.petsSlide = function (val) {
            if (!val)
                val = 1;
            $('.wntPts .slider-tick-label').removeClass("ticklblclr");
            var element = $('.wntPts .slider-tick-label')[val - 1];
            if (element)
                element.className = element.className + " ticklblclr";
            vm.lfstyl.ptsPrefId = val;
        };

        vm.petsprfRefresh = function () {
            $('.wntPts .slider-tick-label').removeClass("ticklblclr");
            vm.petsPrefVal = null;
            vm.lfstyl.ptsPrefId = null;
        };
        //pets preferance slider binding End Here.

        //religious slider binding
        $scope.rlgsTicks = [];
        $scope.rlgsLabels = [];
        vm.religiousDdl.forEach(function (data) {
            $scope.rlgsTicks.push(data.val);
            $scope.rlgsLabels.push(data.txt)
        });

        if (vm.lfstyl.rlgsId > 0)
            vm.rlgsVal = vm.lfstyl.rlgsId;
        $scope.rglsStep = "1";
        $timeout(function () {
            $('.rgls .slider-tick-label').removeClass("ticklblclr");
            var element = $('.rgls .slider-tick-label')[vm.rlgsVal - 1];
            if (element)
                element.className = element.className + " ticklblclr";
        }, 100);

        $scope.rglsSlide = function (val) {
            if (!val)
                val = 1;
            $('.rgls .slider-tick-label').removeClass("ticklblclr");
            var element = $('.rgls .slider-tick-label')[val - 1];
            if (element)
                element.className = element.className + " ticklblclr";
            vm.lfstyl.rlgsId = val;
        };

        vm.relgsRefresh = function () {
            $('.rgls .slider-tick-label').removeClass("ticklblclr");
            vm.rlgsVal = null
            vm.lfstyl.rlgsId = null;
        };
        //religious slider binding End Here.

        //traditional slider binding
        $scope.trdtnlTicks = [];
        $scope.trdtnlLabels = [];
        vm.traditionalDdl.forEach(function (data) {
            $scope.trdtnlTicks.push(data.val);
            $scope.trdtnlLabels.push(data.txt)
        });
        if (vm.lfstyl.trdtnlId > 0)
            vm.trdtnlVal = vm.lfstyl.trdtnlId;
        $scope.trdtnlstep = "1";
        $timeout(function () {
            $('.trdtnl .slider-tick-label').removeClass("ticklblclr");
            var element = $('.trdtnl .slider-tick-label')[vm.trdtnlVal - 1];
            if (element)
                element.className = element.className + " ticklblclr";
        }, 100);

        $scope.trdtnlSlide = function (val) {
            if (!val)
                val = 1;
            $('.trdtnl .slider-tick-label').removeClass("ticklblclr");
            var element = $('.trdtnl .slider-tick-label')[val - 1];
            if (element)
                element.className = element.className + " ticklblclr";
            vm.lfstyl.trdtnlId = val;
        };

        vm.trdtnRefresh = function () {
            $('.trdtnl .slider-tick-label').removeClass("ticklblclr");
            vm.trdtnlVal = null;
            vm.lfstyl.trdtnlId = null;
        }
        //traditional slider binding End Here.
        hideLoader();
    });

    //diet
    vm.dietIdFunc = function (val, txt, event) {
        $(event.target).toggleClass('active');
        if (vm.lfstyl.ditId == val)
            vm.lfstyl.ditId = "";
        else
            vm.lfstyl.ditId = val;
        vm.ditIdTxt = txt;
    };
    //diet end
   
    //idealRelationship
    vm.idealRelationshipIdFunc = function (val, txt, event) {
        $(event.target).toggleClass('active');
        if (vm.lfstyl.irltnshpId == val)
            vm.lfstyl.irltnshpId = "";
        else
            vm.lfstyl.irltnshpId = val;
        vm.irltnshpTxt = txt;
    };
    //idealRelationship end

    //childrenCount
    vm.chdrnIncr = function () {
        if (vm.lfstyl.chldrnCntId < 6) {
            vm.lfstyl.chldrnCntId++;
            vm.numOfChildren.forEach(function (data) {
                if (data.val == vm.lfstyl.chldrnCntId)
                    vm.chldrnCntIdTxt = data.txt;
            })
        }
    };

    vm.chdrnDecr = function () {
        if (vm.lfstyl.chldrnCntId == 1) {
            vm.lfstyl.chldrnCntId--;
            vm.chldrnCntIdTxt = "";
            return false;
        }
        if (vm.lfstyl.chldrnCntId > 1) {
            vm.lfstyl.chldrnCntId--;
            vm.numOfChildren.forEach(function (data) {
                if (data.val == vm.lfstyl.chldrnCntId)
                    vm.chldrnCntIdTxt = data.txt;
            });
        }
    };
    //childrencount end

    //petscount
    vm.petsIncr = function () {
        if (vm.lfstyl.ptsCntId < 4) {
            vm.lfstyl.ptsCntId++;
            vm.petsCntDdl.forEach(function (data) {
                if (data.val == vm.lfstyl.ptsCntId)
                    vm.ptsCntIdTxt = data.txt;
            })
        }
    };

    vm.petsDecr = function () {
        if (vm.lfstyl.ptsCntId == 1) {
            vm.lfstyl.ptsCntId--;
            vm.ptsCntIdTxt = "";
            return false;
        }
        if (vm.lfstyl.ptsCntId > 1) {
            vm.lfstyl.ptsCntId--;
            vm.petsCntDdl.forEach(function (data) {
                if (data.val == vm.lfstyl.ptsCntId)
                    vm.ptsCntIdTxt = data.txt;
            });
        }
    };
    //petscount end

    //prefLang
    vm.langPrefIU = function (id) {
        if (vm.lfstyl.lstylelngPrefIds.indexOf(id) != -1) {
            var index = vm.lfstyl.lstylelngPrefIds.indexOf(id);
            vm.lfstyl.lstylelngPrefIds.splice(index, 1);
        }
    };

    vm.Preflangfun = function () {
        if (vm.lfstyl.lstylelngPrefIds.indexOf(vm.selectedprefLang.val) == -1)
            vm.lfstyl.lstylelngPrefIds.push(vm.selectedprefLang.val);
        vm.selectedprefLang = '';
    };
    //prefLang end

    //prefFamilyLanguage starts
    vm.fmlyLangPrefIU = function (id) {
        if (vm.lfstyl.lstylefmlyLangIds.indexOf(id) != -1) {
            var index = vm.lfstyl.lstylefmlyLangIds.indexOf(id);
            vm.lfstyl.lstylefmlyLangIds.splice(index, 1);
        }
    };

    vm.Famlangfun = function () {
        if (vm.lfstyl.lstylefmlyLangIds.indexOf(vm.selectedFamLang.val) == -1)
            vm.lfstyl.lstylefmlyLangIds.push(vm.selectedFamLang.val);
        vm.selectedFamLang = '';
    };
    //prefFamilyLanguage end
    //tradition End

    //Life style cancel
    vm.mylifestyleCancel = function () {
        $state.go('editprofile');
    };

    //Life style done
    vm.mylifestyleDone = function () {
        showLoader();
        var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
        sfData.lfstyl = vm.lfstyl;
        vm.prfPercentage = getProfilepercent(sfData);
        selfprofileSrvc.myLifeStyleU(vm.mId(), vm.lfstyl.ditId, vm.lfstyl.smkId, vm.lfstyl.drnkId, vm.lfstyl.irltnshpId, vm.lfstyl.chldrnCntId, vm.lfstyl.chldrnPrefId, vm.lfstyl.ptsCntId, vm.lfstyl.ptsPrefId, vm.lfstyl.lstylelngPrefIds.join(), vm.lfstyl.lstylefmlyLangIds.join(), vm.lfstyl.rlgsId, vm.lfstyl.trdtnlId, vm.prfPercentage, function (response, status) {
            hideLoader();
            if (status == 200) {
                $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                $state.go('editprofile');
            }
        });
    };
}]);