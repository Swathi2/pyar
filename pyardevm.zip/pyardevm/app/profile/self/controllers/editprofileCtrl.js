﻿angular.module("app").controller('editprofileCtrl', ['selfprofileSrvc', 'getSessionSrvc', 'selfmatchprefSrvc', 'msgSrvc', '$scope', '$window', '$filter', '$state', '$timeout', '$rootScope', function (selfprofileSrvc, getSessionSrvc, selfmatchprefSrvc,msgSrvc, $scope, $window, $filter, $state, $timeout, $rootScope) {
    showLoader();
    var vm = this;
    vm.prflInfo = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
    if (!vm.prflInfo) { $state.go('profile'); return; }
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.genPref = function () { return getSessionSrvc.p_gndrp() };
    vm.fn = function () { return getSessionSrvc.p_fn(); };
    vm.pp = function () { return getSessionSrvc.p_ppic(); };
    vm.gender = function () { return getSessionSrvc.p_gndr(); };
    $rootScope.dvpgVisble = false;
    vm.prflDataPic = vm.prflInfo.prflData.prfPic + "?v=" + new Date().valueOf();
    vm.gndrTxt = vm.prflInfo.prflData.gndrTxt;
    //Binding gender image
    if (vm.prflInfo.prflData.genderval == true)
        vm.Gender = "https://pccdn.pyar.com/pcimgs/m/malegray-syn.png";
    else
        vm.Gender = "https://pccdn.pyar.com/pcimgs/m/femalegray-syn.png";
    vm.locatntxtprf = [];
    vm.aboutme = [];
    vm.pTraitsSelected = [];
    vm.myApprnce = [];
    vm.lifestyle = "";
    vm.hobbiesselsected = [];
     
    vm.bindProfileInfo = function () {
        showLoader();
        vm.getAge = calculateAge(vm.prflInfo.prflData.dob);
        vm.myBio = vm.prflInfo.Bio.mybio;
        vm.cityName = vm.prflInfo.prflData.cityName;
        vm.countryName = vm.prflInfo.prflData.countryName;
        vm.stateName = vm.prflInfo.prflData.stateName;
        if (vm.cityName)
            vm.locatntxtprf.push(vm.cityName);
        if (vm.stateName)
            vm.locatntxtprf.push(vm.stateName);
        vm.locatn = vm.locatntxtprf.join(', ');
        vm.locatntxtprf = vm.locatn.toString()
        vm.locatnttxt = vm.locatntxtprf;
        //Ext1 bind data
        vm.prftInfoExt1 = { "memberId": vm.mId(), "countryId": vm.prflInfo.prflData.countryId, "stateId": vm.prflInfo.prflData.stateId, "cityId": vm.prflInfo.prflData.cityId, "ethinicityId": vm.prflInfo.abtme.etnctyId, "rsStatus": vm.prflInfo.abtme.stsId, "religionId": vm.prflInfo.abtme.rglnId, "highestEdu": vm.prflInfo.abtme.dgrId, "awId": vm.prflInfo.abtme.aOfWrkId, "htCountry": vm.prflInfo.abtme.htcntryId, "htState": vm.prflInfo.abtme.htstateId, "htCity": vm.prflInfo.abtme.htcityId, "pt": vm.prflInfo.prsnlty.join(",") };
        selfprofileSrvc.GetPrfInfoExt1(vm.mId(), vm.prftInfoExt1, GetPrfInfoExt1CallBack);
        //Ext2 bind data
        vm.prftInfoExt2 = { "eyeColor": vm.prflInfo.apprnce.eyeId, "height": vm.prflInfo.apprnce.htId, "hairColor": vm.prflInfo.apprnce.hairId, "build": vm.prflInfo.apprnce.bldId, "diet": vm.prflInfo.lfstyl.ditId, "smoke": vm.prflInfo.lfstyl.smkId, "drink": vm.prflInfo.lfstyl.drnkId, "idealRelationship": vm.prflInfo.lfstyl.irltnshp, "childrenCnt": vm.prflInfo.lfstyl.chldrnCntId, "childrenPref": vm.prflInfo.lfstyl.chldrnPrefId, "petsCnt": vm.prflInfo.lfstyl.ptsCntId, "petsPref": vm.prflInfo.lfstyl.ptsPrefId, "lang": vm.prflInfo.lfstyl.lstylelngPrefIds, "familyLangs": vm.prflInfo.lfstyl.lstylefmlyLangIds, "religious": vm.prflInfo.lfstyl.rlgsId, "traditional": vm.prflInfo.lfstyl.trdtnlId, "hobbies": vm.prflInfo.hbbys.join(",") };
        selfprofileSrvc.GetPrfInfoExt2(vm.mId(), vm.prftInfoExt2, GetPrfInfoExt2CallBack);
    };

    //Matchpreference data binding in selfprofile
    vm.matchPrefDataBind = function () {
        selfmatchprefSrvc.getmmp(function (response, status) {
            if (status == 200) {
                vm.mp = response;
                vm.mpDistanceFuncG();
            }
        });
    };

    vm.mpDistanceFuncG = function () {
        selfmatchprefSrvc.prefRadius(function (response, status) {
            if (status == 200) {
                for (var i = 0; i < response.length; i++) {
                    if (response[i].rdId == vm.mp.locRadius) {
                        vm.locRadiusTxt = "Within " + (response[i].radius == 1000 ?( response[i].radius + "+"): response[i].radius)+ " miles";
                        break;
                    }
                }
                vm.bindMtchPrefDtls();
            }
        });
    };

    vm.bindMtchPrefDtls = function () {
        if (!vm.mp.minAge && !vm.mp.maxAge && !vm.mp.locRadius && !vm.mp.locType && !vm.mp.ethinicities && !vm.mp.familyLang && !vm.mp.countryId && !vm.mp.cityId && !vm.mp.awId && !vm.mp.highestEdu && !vm.mp.htCountry && !vm.mp.htState && !vm.mp.htCity && !vm.mp.minHeight && !vm.mp.maxHeight && !vm.mp.smoke && !vm.mp.drink && !vm.mp.idealRelationship && !vm.mp.childrenCnt && !vm.mp.childrenPref && !vm.mp.petsCnt && !vm.mp.petsPref && !vm.mp.religious && !vm.mp.traditional && !vm.mp.rsStatus && !vm.mp.eyeColor && !vm.mp.hairColor && !vm.mp.build && !vm.mp.diet && !vm.mp.religions && !vm.mp.hobbies && !vm.mp.pt) {
            vm.mpAgeTxt = '';
            vm.mpRadiusTxt = '';
        }
        else {
            var gender = vm.genPref() == true ? "he" : "she";
            if (vm.mp.minAge != null && vm.mp.maxAge != null)
                vm.mpAgeTxt = "Ages " + vm.mp.minAge + "-" + vm.mp.maxAge;
            else
                vm.mpAgeTxt = "How old is " + gender + "?";

            if (vm.mp.locRadius != null)
                vm.mpRadiusTxt = vm.locRadiusTxt;
            else
                vm.mpRadiusTxt = "Where is " + gender + "?";
        }
    };

    var GetPrfInfoExt1CallBack = function (responseEx1, status) {
        showLoader();
        //About binding start
        vm.profileInfoExt1 = responseEx1;
        vm.etnctyIdTxt = vm.profileInfoExt1.ethinicityId;
        if (vm.etnctyIdTxt != '')
            vm.aboutme.push(vm.etnctyIdTxt);
        vm.rglnIdTxt = vm.profileInfoExt1.religionId;
        if (vm.rglnIdTxt != '')
            vm.aboutme.push(vm.rglnIdTxt);
        vm.aOfWrkIdTxt = vm.profileInfoExt1.awId;
        if (vm.aOfWrkIdTxt != '')
            vm.aboutme.push(vm.aOfWrkIdTxt);
        vm.stsIdTxt = vm.profileInfoExt1.rsStatus;
        if (vm.stsIdTxt != '')
            vm.aboutme.push(vm.stsIdTxt);
        vm.dgrIdTxt = vm.profileInfoExt1.highestEdu;
        if (vm.dgrIdTxt != '')
            vm.aboutme.push(vm.dgrIdTxt);
        if (vm.profileInfoExt1.htInfo) {
            if (vm.profileInfoExt1.htInfo.cityName) {
                vm.htCity = vm.profileInfoExt1.htInfo.cityName;
                vm.aboutme.push(vm.htCity);
            }
            if (vm.profileInfoExt1.htInfo.stateName) {
                vm.htState = vm.profileInfoExt1.htInfo.stateName;
                vm.aboutme.push(vm.htState);
            }
            if (vm.profileInfoExt1.htInfo.countryName) {
                if (vm.prflInfo.prflData.countryId != getSessionSrvc.p_cntryId()) {
                    vm.cntryIdTxt = vm.profileInfoExt1.htInfo.countryName;
                    vm.aboutme.push(vm.cntryIdTxt);
                }
            }
        }
        vm.abtTxt = vm.aboutme.join(', ');
        vm.aboutme = vm.abtTxt.toString();
        //About binding end

        //personality binding start
        vm.ptraits = responseEx1.pt;
        if (vm.ptraits)
            if (vm.ptraits.length == 1)
            {
                vm.pTraitsSelected.push(vm.ptraits[0].txt);
            }
            else{
                vm.ptraits.forEach(function (data) {
                    vm.pTraitsSelected.push(data.txt);
                });
            }
        vm.pTraitsSelected = vm.pTraitsSelected.join(', ');
        vm.pTraitsSelected = vm.pTraitsSelected.toString();
        if (vm.pTraitsSelected.substring(vm.pTraitsSelected.length - 2) == ", ") {
           vm.pTraitsSelected = vm.pTraitsSelected.substring(0, vm.pTraitsSelected.length - 2);//remove , in string
        }
       //personality binding end
        hideLoader();
    }

    var GetPrfInfoExt2CallBack = function (responseEx2, status) {
        showLoader();
        vm.profileInfoExt2 = responseEx2;
         //Getting My appearance block Data Starts
        vm.eyeId = vm.prflInfo.apprnce.eyeId; vm.eyeIdTxt = vm.profileInfoExt2.eyeColor;
        if (vm.eyeIdTxt != '')
           vm.myApprnce.push(vm.eyeIdTxt)
        vm.hairId = vm.prflInfo.apprnce.hairId; vm.hairIdTxt = vm.profileInfoExt2.hairColor;
        if (vm.hairIdTxt != '')
            vm.myApprnce.push(vm.hairIdTxt);
        vm.bldId = vm.prflInfo.apprnce.bldId; vm.bldIdTxt = vm.profileInfoExt2.build;
        if (vm.bldIdTxt != '')
           vm.myApprnce.push(vm.bldIdTxt);
        vm.htId = vm.prflInfo.apprnce.htId; vm.htIdTxt = vm.profileInfoExt2.height;
        if (vm.htIdTxt != '')
            vm.myApprnce.push(vm.htIdTxt);
        vm.myApprnceTxt = vm.myApprnce.join(', ');
        vm.myApprnce = vm.myApprnceTxt.toString();
        //Getting My appearance block Data End

        //Getting My lifestyle block Data Starts
        vm.ditId = vm.prflInfo.lfstyl.ditId; vm.ditIdTxt = vm.profileInfoExt2.diet;
        if (vm.ditIdTxt != '') {
            vm.lifestyle += vm.ditIdTxt + ", ";
        }
        vm.smkId = vm.prflInfo.lfstyl.smkId; vm.smkIdTxt = vm.profileInfoExt2.smoke;
        if (vm.smkIdTxt != '') {
            vm.lifestyle += vm.smkIdTxt + " smoke" + ", ";
        }
        vm.drnkId = vm.prflInfo.lfstyl.drnkId; vm.drnkIdTxt = vm.profileInfoExt2.drink;
        if (vm.drnkIdTxt != '') {
            vm.lifestyle += vm.drnkIdTxt + " drink" + ", ";
         }
        vm.irltnshp = vm.prflInfo.lfstyl.irltnshpId; vm.irltnshpTxt = vm.profileInfoExt2.idealRelationship;
        if (vm.irltnshpTxt != '') {
            vm.lifestyle += "I want a " + vm.irltnshpTxt + " relationship" + ", ";
        }
        vm.chldrnCntId = vm.prflInfo.lfstyl.chldrnCntId; vm.chldrnCntIdTxt = vm.profileInfoExt2.childrenCnt;
        if (vm.chldrnCntIdTxt != '') {
            vm.lifestyle += $filter('childCountFltr')(vm.chldrnCntIdTxt) + ", ";
        }
        vm.chldrnPrefId = vm.prflInfo.lfstyl.chldrnPrefId; vm.chldrnPrefIdTxt = vm.profileInfoExt2.childrenPref;
        if (vm.chldrnPrefIdTxt != '') {
            vm.lifestyle += $filter('childPrefFltr')(vm.chldrnPrefIdTxt) + ", ";

        }
        vm.ptsCntId = vm.prflInfo.lfstyl.ptsCntId; vm.ptsCntIdTxt = vm.profileInfoExt2.petsCnt;
        if (vm.ptsCntIdTxt != '') {
            vm.lifestyle += $filter('petCountFltr')(vm.ptsCntIdTxt) + ", ";
        }
        vm.ptsPrefId = vm.prflInfo.lfstyl.ptsPrefId; vm.ptsPrefIdTxt = vm.profileInfoExt2.petsPref;
        if (vm.ptsPrefIdTxt != '') {
            vm.lifestyle += $filter('petsPrefFltr')(vm.ptsPrefIdTxt) + ", ";
        }
        if (vm.profileInfoExt2.lang)
        if (vm.profileInfoExt2.lang.length == 1)
        {
            vm.lifestyle += "Prefers " + vm.profileInfoExt2.lang[0].txt + ", ";
        }
        else{
            angular.forEach(vm.profileInfoExt2.lang, function (data) {
           
                vm.lifestyle+="Prefers " + data.txt + "/";
            })
            vm.lifestyle = vm.lifestyle.substring(0, vm.lifestyle.length - 1) + ", ";
        }
        if (vm.profileInfoExt2.familyLangs) 
            if (vm.profileInfoExt2.familyLangs.length == 1) {
                vm.lifestyle += "Family speaks " + vm.profileInfoExt2.familyLangs[0].txt + ", ";
            }
            else {
                angular.forEach(vm.profileInfoExt2.familyLangs, function (data) {
                    vm.lifestyle+="Family speaks " + data.txt + "/";
                })
                vm.lifestyle = vm.lifestyle.substring(0, vm.lifestyle.length - 1) + ", ";
            }
        vm.rlgsId = vm.prflInfo.lfstyl.rlgsId; vm.rlgsIdTxt = vm.profileInfoExt2.religious;
        if (vm.rlgsIdTxt != '') {
            vm.lifestyle += vm.rlgsIdTxt + " Religious" + ", ";
        }
        vm.trdtnlId = vm.prflInfo.lfstyl.trdtnlId; vm.trdtnlIdTxt = vm.profileInfoExt2.traditional;
        if (vm.trdtnlIdTxt != '') {
            vm.lifestyle += vm.trdtnlIdTxt + " traditional" + ", ";
        }
        if (vm.lifestyle.substring(vm.lifestyle.length - 1) == "/" || vm.lifestyle.substring(vm.lifestyle.length - 2) == ", ") {
            vm.lifestyle = vm.lifestyle.substring(0, vm.lifestyle.length - 2);
        }
        //Getting My lifestyle block Data End

        //Getting My hobbies block Data Starts
        vm.hobbies = responseEx2.hobbies;
        if (vm.hobbies)
            if (vm.hobbies.length == 1) {
                vm.hobbiesselsected.push(vm.hobbies[0].txt);
            }
            else {
                vm.hobbies.forEach(function (data) {
                    vm.hobbiesselsected.push(data.txt);
                });

            }
        vm.hobbiesselsected = vm.hobbiesselsected.join(', ');
        vm.hobbiesselsected = vm.hobbiesselsected.toString();
       //Getting My hobbies block Data End
        vm.pgVisble();
    }

    //page unevenly loading resolve function
    vm.pgVisble = function () {
        $timeout(function () {
            if ($rootScope.srcType != 3)
                $rootScope.dvpgVisble = true;
            else
                $rootScope.dvpgVisble = false;
            hideLoader();
        }, 200, true);
    };
    //scroll functionality for edit profile
    $timeout(function () {
        if ($rootScope.edtScrollTo) {
            $("html, body").animate({
                scrollTop: $rootScope.edtScrollTo
            }, 1000);
        }
    }, 400);
    vm.navigate = function (type) {
        $rootScope.edtScrollTo = $(window).scrollTop();
        $state.go(type);
    };
 
   vm.profileEditSave = function () {
        $window.localStorage.setItem("viewprofile", getSessionSrvc.pce(JSON.stringify(1)));
        $state.go('profile');
    };
  
    vm.matchPrefDataBind();
    vm.bindProfileInfo();
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PROFILE UPLOADING  STARTS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    //Functionality started by prasanna
    var croppie;
    vm.maxWidth = 1920;
    vm.maxHeight = 1920;
    vm.minWidth = 400;
    vm.minHeight = 400;
    vm.photoPath = '';
    vm.upldPhotoType = 2;//2:profile pic upload,4:gallery pic swaping 
    vm.actionType = 1;
    vm.crpDone = false;
    var width = (window.innerWidth > 0) ? window.innerWidth : screen.width  //get screen width to set cropper width && height dynamically
    $('.crprTxt').css('top', width + 90);// Dynamic position for cropper text(Reposition Photo)
    vm.imageCDN = "https://pccdn.pyar.com";
    vm.showPhotoActions = function () {
        $("#glryActions").modal('show');
    };
    $scope.imageUpload = function (event) {
        showLoader();
        var files = event.target.files;
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var reader = new FileReader();
            var upldSuccess = false;
            $rootScope.srcType = 1;
            reader.onload = function (e) {
                $("<img/>").load(function () {
                    vm.imgRealWidth = this.width;
                    vm.imgRealHeight = this.height;
                    if (vm.imgRealWidth < vm.minWidth || vm.imgRealHeight < vm.minHeight) {
                        $("#photoSmallpop").modal('show');//need show error popup
                        hideLoader();                     
                    }
                    else {
                        $('#cropImg').croppie('destroy');
                        vm.photoPath = e.target.result;                      
                        vm.imgHeight = vm.imgRealHeight;
                        vm.imgwidth = vm.imgRealWidth;
                        if (vm.imgRealWidth > vm.imgRealHeight) {
                            if (vm.imgRealWidth > vm.maxWidth) {
                                vm.imgHeight = vm.imgRealHeight * (vm.maxWidth / vm.imgRealWidth);
                                vm.imgwidth = vm.maxWidth;
                            }
                        } else {
                            if (vm.imgRealHeight > vm.maxHeight) {
                                vm.imgwidth = vm.imgRealWidth * (vm.maxHeight / vm.imgRealHeight);
                                vm.imgHeight = vm.maxHeight;
                            }
                        }                     
                        //if browser type is an ios device the below code get executed
                        if (getBrowserType() == true) {                           
                            var options = {
                                canvas: true
                            };
                            vm.imgDataExifProp = false;
                            loadImage.parseMetaData(file, function (data) {
                                if (data.exif) {
                                    vm.imgDataExifProp = true;
                                    options.orientation = data.exif.get('Orientation');
                                    loadImage(file, getOrientImageResponse, options);
                                } else {
                                    CropPBPhoto(e.target.result, width - 35, width - 35, $timeout);
                                }
                            });
                        } else {
                            CropPBPhoto(e.target.result, width - 35, width - 35, $timeout);
                        }
                    }
                    $("#fupPhtGlry").val(null);//clear the image upload path for same image uploading.
                }).attr("src", e.target.result);
            }
            reader.readAsDataURL(file);         
        }
    };

    var getOrientImageResponse = function (img) {
        if (vm.imgDataExifProp == true) {
            vm.photoPath = img.toDataURL();
            CropPBPhoto(img.toDataURL(), width - 35, width - 35, $timeout);
        }
    };
    /************************************************************** ADD PHOTO FROM SOCIAL**************************************************************/
    vm.addPhoto = function () {
        //gallery photo module
        $rootScope.dvAlbumPhotos = false;
        $rootScope.dvpgVisble = true;
        //profile photo module
        if ($rootScope.imgPath != "" && $rootScope.realWidth >= vm.minWidth && $rootScope.realHeight >= vm.minHeight) {
            vm.photoPath = $rootScope.imgPath;
            vm.imgwidth = $rootScope.realWidth;
            vm.imgHeight = $rootScope.realHeight;
            $('#cropImg').croppie('destroy');           
            CropPBPhoto($rootScope.imgPath, width - 35, width - 35, $timeout);           
        }
    };
   
    //save image after cropping
    vm.saveCroppedImg = function () {
        showLoader();
        vm.crpDone = true;
        $rootScope.dvAlbumPhotos = false;
        $rootScope.dvpgVisble = true;
        if (vm.upldPhotoType == 2) {
            //from device uploading
            if (vm.actionType == 1 && $rootScope.srcType == 1) {
                UploadProfileImage(vm.photoPath);
            } else {
                //from instagram && facebook uploading
                convertFileToDataURLviaFileReader(vm.photoPath, function (originalImgResponse) {
                    UploadProfileImage(originalImgResponse);
                });
            }
        }    
        $rootScope.srcType = 1;
    };

    //upload profile picture
    function UploadProfileImage(originalImgResponse) {
        var data = new FormData();
        CroppedImageResult(430, 430, function (img430Response) {
            CroppedImageResult(200, 200, function (img200Response) {
                CroppedImageResult(100, 100, function (img100Response) {
                    resizingImage(originalImgResponse, function (resizeResponse) {
                        base64ToBlobFileConvertion(resizeResponse, function (originalImgBlob) {
                            base64ToBlobFileConvertion(img430Response, function (img430Blog) {
                                base64ToBlobFileConvertion(img200Response, function (img200Blog) {
                                    base64ToBlobFileConvertion(img100Response, function (img100Blog) {
                                        createBlurImage((img430Response), function (blurResponseBlob) {
                                            data.append("originalImgBlob", originalImgBlob);
                                            data.append("img430Blog", img430Blog);
                                            data.append("img200Blog", img200Blog);
                                            data.append("img100Blog", img100Blog);
                                            data.append("blurResponseBlob", blurResponseBlob);
                                            //need to set action type 1 for adding new photo 2 for update existing photo                                        
                                            selfprofileSrvc.uploadPrflImages(vm.mId(), vm.actionType, data, function (response, status) {
                                                vm.crpDone = false;
                                                if (status == 200) {
                                                    var picPath = vm.imageCDN + response.picPath + "?v=" + new Date().valueOf();
                                                    var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
                                                    sfData.prflData.isProfilePicUpld = true;
                                                    sfData.prflData.prfPic = picPath;
                                                    $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                                                    vm.prflDataPic = picPath;
                                                    $("#srcAdjustProfilePhotoPopup").modal("hide");
                                                    history.pushState(null, null, location.pathname);//change visible url with out refreshing page.
                                                    hideLoader();
                                                    var notifyType = 53;
                                                    if (msgSrvc.conId)
                                                        msgSrvc.sendMemberNWNotifications("", vm.fn(), vm.pp(), vm.gender(), notifyType, new Date());
                                                    else
                                                        $rootScope.ntfnData.push({ "sendType": 2, "tmId": "", "fn": vm.fn(), "pp": vm.pp(), "gender": vm.gender(), "type": notifyType, "date": new Date() });
                                                    
                                                }
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    };
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PROFILE UPLOADING  STARTS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
}]);