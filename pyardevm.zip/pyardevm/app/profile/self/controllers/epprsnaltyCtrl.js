﻿angular.module("app").controller('epprsnaltyCtrl', ['selfprofileSrvc', 'getSessionSrvc', '$window', '$state', function (selfprofileSrvc, getSessionSrvc, $window, $state) {
    showLoader();
    var vm = this;
    vm.prsnlty = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo"))).prsnlty;
    if (!vm.prsnlty) { $state.go('profile'); return; }
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.activetrIds = vm.prsnlty;

    selfprofileSrvc.PrsnltyTraitsListG(function (response) {
        var result = {};
        var key = 'ptcId';
        for (var i = 0; i < response.length; i++) {
            if (!result[response[i][key]]) {
                result[response[i][key]] = [];
            }
            result[response[i][key]].push(response[i])
        }
        vm.PrsnltyTraitsList = result;
        hideLoader();
    });

    //Personality check function
    vm.prsnltyChkClick = function (ptcId, ptId, event) {
        if (vm.activetrIds.length <= 5) {
            if (vm.activetrIds.length == 5) {
                if (vm.activetrIds.indexOf(ptId) != -1) {
                    var index = vm.activetrIds.indexOf(ptId);
                    vm.activetrIds.splice(index, 1);
                    vm.prsnltyError = false;
                }
                else {
                    $('html body').scrollTop(0);
                    vm.prsnltyError = true;
                }
            }
            else {
                vm.prsnltyError = false;
                if (vm.activetrIds.indexOf(ptId) == -1)
                    vm.activetrIds.push(ptId);
                else {
                    var index = vm.activetrIds.indexOf(ptId);
                    vm.activetrIds.splice(index, 1);
                }
            }
        }
        else {
            $('html body').scrollTop(0);
            vm.prsnltyError = true;
        }
    }

    //Toggle class for personality traits
    vm.toggleclassBinding = function (ptcId) {
        if (ptcId == 1)
            $(event.target).toggleClass('actvptblue');
        else if (ptcId == 2)
            $(event.target).toggleClass('actvptbsclr');
        else if (ptcId == 3)
            $(event.target).toggleClass('actvptyelw');
        else if (ptcId == 4)
            $(event.target).toggleClass('actvptprpl');
        else if (ptcId == 5)
            $(event.target).toggleClass('actvptviolt');
        else if (ptcId == 6)
            $(event.target).toggleClass('actvptltgrn');
        else if (ptcId == 7)
            $(event.target).toggleClass('actvptyash');
    }

    //Personality traits back button functionality
    vm.myPrsnltyCancel = function () {
        $state.go('editprofile');
    };

    //Personality saving functionality
    vm.myPrsnltyDone = function () {
        showLoader();
        var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
        sfData.prsnlty = vm.activetrIds;
        vm.prfPercentage = getProfilepercent(sfData);
        if (vm.activetrIds != undefined) {
            selfprofileSrvc.PrsnltyTraitsListIU(vm.mId(), vm.activetrIds.join(), vm.prfPercentage, function (response, status) {
                hideLoader();
                if (status == 200 && response == true) {
                    $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                    $state.go('editprofile');
                }
            });
        }
    };
}]);