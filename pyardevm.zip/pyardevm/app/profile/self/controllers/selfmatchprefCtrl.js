﻿angular.module("app").controller('selfmatchprefCtrl', ['selfprofileSrvc', 'selfmatchprefSrvc', 'getSessionSrvc', '$scope', '$window', '$location', '$timeout', '$rootScope', function (selfprofileSrvc, selfmatchprefSrvc, getSessionSrvc, $scope, $window, $location, $timeout, $rootScope) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.genPref = function () { return getSessionSrvc.p_gndrp() };
    vm.units = function () { return getSessionSrvc.p_uts() };
    //for header changes
    vm.header = true;
    vm.traitsHeader = false;
    vm.personalityDiv = true;
    vm.ptfooter = true;
    //getting page Number from Local storage
    vm.mpPgNo = $window.localStorage.getItem("mpPgNo");
    if (vm.mpPgNo == null) { vm.mpPgNo = 1; }
    //based on prefered gender binding the images and his/her
    if (vm.genPref() == true) {
        vm.gndrPrefTxt = "he";
        vm.gndrPrefTxt2 = "his";
    }
    else {
        vm.gndrPrefTxt = "she";
        vm.gndrPrefTxt2 = "her";
    }
    vm.lstLocRadiusDist = [];
    vm.langsObj = [];
    vm.fmlyLangsObj = [];
    vm.rsStatus = [];
    vm.eyeColor = [];
    vm.hairColor = [];
    vm.build = [];
    vm.diet = [];
    vm.ethinicities = [];
    vm.religions = [];
    vm.lang = [];
    vm.familyLang = [];
    vm.hobbies = [];
    vm.pt = [];
    //Location Distance getting function
    vm.mpDistanceFuncG = function (funCallBack) {
        selfmatchprefSrvc.prefRadius(function (response, status) {
            if (status == 200)
                vm.lstLocRadiusDist = response;
                funCallBack(response);
        });
    };

    //location bind slider functinality starts here
    vm.mpLocationBind = function (locRadius) {
        vm.mpDistanceFuncG(function (response) {
            $scope.ticks = [];
            $scope.labels = [];
            // binding distance radius data
            for (var i = 0; i < response.length; i++) {
                $scope.ticks.push(response[i].rdId);
                $scope.labels.push(response[i].radius == 1000 ? (response[i].radius + "+") : response[i].radius);
                if (response[i].rdId == locRadius)
                    vm.locRadiusTxt = "Within " + response[i].radius + " miles";
            }
            $scope.step = "1"
            $timeout(function () {
                $('.slider-tick-label').removeClass("ticklblclr");
                var element = $('.slider-tick-label')[vm.locRadius - 1];
                if (element)
                    element.className = element.className + " ticklblclr";
            }, 500);
        });
    };

    //on-slide function for slider
    $scope.slide = function (val) {
        if (!val) {
            val = 1;
            vm.locRadius = 1;
        }
        $('.slider-tick-label').removeClass("ticklblclr");
        var element = $('.slider-tick-label')[val - 1];
        if (element)
            element.className = element.className + " ticklblclr";//adding active color to slider
        if (!vm.locType)
            vm.locType = 1;
    };

    //Click functionality for location types
    vm.actvClscurLoc = function (val) {
        if (val == 1) {
            vm.countryId = vm.mp.countryId;
            vm.stateId = vm.mp.stateId;
            vm.cityId = vm.mp.cityId;
            vm.lat = vm.mp.lat;
            vm.long = vm.mp.long;
            vm.locType = 1;
            if (!vm.locRadius)
                vm.locRadius = 1;
            var element = $('.slider-tick-label')[vm.locRadius - 1];
            if (element)
                element.className = element.className + " ticklblclr";
        }
    };

    vm.locReset = function (e) {
        $('.slider-tick-label').removeClass("ticklblclr");
        vm.locRadius = null;
        vm.locType = null;
        vm.countryId = null;
        vm.cityId = null;
        vm.lat = null;
        vm.long = null;
        e.stopPropagation();
    };

    vm.htReset = function () {
        vm.htCountry = null;
        vm.htCity = null
        vm.growZipCode = null;
        vm.htStateId = null;
    };

    //about dropdowns bind
    vm.mpAboutbindDataFuncG = function () {
        selfprofileSrvc.StaticDropDownList(function (response, status) {
            if (status==200) {
                vm.ethnicitiesDdl = response.Ethnicity;
                vm.religionsDdl = response.Religion;
                vm.areaofworksDdl = response.AreaOfWork;
                vm.RSStatusDdl = response.Status;
                vm.degreeDdl = response.Degree;
                vm.countriesDdl = response.Countries;
                //Getting Area of work text
                for (var i = 0; i < response.AreaOfWork.length; i++) {
                    if (response.AreaOfWork[i].awId == vm.mp.awId) {
                        vm.awName = response.AreaOfWork[i].awName;
                        break;
                    }
                }
                //Getting Degree dropdown text
                for (var i = 0; i < response.Degree.length; i++) {
                    if (response.Degree[i].val == vm.mp.highestEdu) {
                        vm.degreeName = response.Degree[i].txt;
                        break;
                    }
                }
                //Getting hometown dropdown text
                for (var i = 0; i < response.Countries.length; i++) {
                    if (response.Countries[i].countryId == vm.mp.htCountry) {
                        vm.htCountryName = response.Countries[i].countryName;
                        break;
                    }
                }
            }
        });
    };

    //My Appearance dropdown Bind
    vm.mpAppearanceDataFuncG = function () {
        selfprofileSrvc.ddlsMyAppearence(function (response, status) {
            if (status==200) {
                vm.buildResponse = response.build;
                vm.height = response.height;
                for (var i = 0; i < response.height.length; i++) {
                    if (response.height[i].val == vm.maxHeight)
                        vm.maxHeightTxt = vm.getddlHeight(response.height[i].txt);
                    if (response.height[i].val == vm.minHeight)
                        vm.minHeightTxt = vm.getddlHeight(response.height[i].txt);
                }
                if (vm.minHeight == null && vm.maxHeight == null) {
                    vm.ddlminheight = vm.height;
                    vm.ddlmaxheight = vm.height;
                }
                else if (vm.minHeight == null && vm.maxHeight != null) {
                    vm.ddlmaxheight = vm.height;
                    vm.minHeightDdlPrepare();
                }
                else if (vm.minHeight != null && vm.maxHeight == null) {
                    vm.ddlminheight = vm.height;
                    vm.maxHeightDdlPrepare();
                }
                else {
                    vm.minHeightDdlPrepare();
                    vm.maxHeightDdlPrepare();
                }
                // binding distance radius data
                vm.eyeClr = response.eyecolor;
                vm.haircolor = response.haircolor;
            }
        });
    };

    //my Lifestye bind
    vm.mpLifeStylesDataFuncG = function () {
        selfprofileSrvc.ddlsMyLifeStyleDDlData(function (response, status) {
            if (status==200) {
                vm.dietDdl = response.diet;
                vm.smokeDdl = response.smoke;
                vm.drinkDdl = response.drink;
                vm.idealRelationshipDdl = response.IdealRelationShip;
                vm.childrenCntDdl = response.numOfChildren;
                vm.childrenPrefDdl = response.childrenPref;
                vm.petsCntDdl = response.numOfPets;
                vm.petsPrefDdl = response.petPref;
                vm.langPrefDdl = response.language;
                vm.familyLangDdl = response.language;
                vm.religiousDdl = response.Religious;
                vm.traditionalDdl = response.traditional;
                vm.bindLanguage();
                vm.bindFamLanguage();
            }
        });
    };

    //personalityTraits
    vm.mpPersonalityTraitsmpDataFuncG = function () {
        selfprofileSrvc.PrsnltyTraitsListG(function (response) {
            var result = {};
            var key = 'ptcId';
            for (var i = 0; i < response.length; i++) {
                if (!result[response[i][key]])
                    result[response[i][key]] = [];
                result[response[i][key]].push(response[i])
            }
            vm.PrsnltyTraitsList = result;
        });
    };
    
    //function for eye Images Binding
    vm.eyeImageBinding = function () {
        if (vm.genPref() == false) {
            if (!vm.eyeColor || vm.eyeColor.length == 0)
                vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-black.png';
            else {
                angular.forEach(vm.eyeColor, function (data) {
                    if (data == 1 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-black.png';
                    else if (data == 2 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-blue.png';
                    else if (data == 3 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-brown.png';
                    else if (data == 4 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-grey.png';
                    else if (data == 5 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-green.png';
                    else if (data == 6 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-hazel.png';
                    else if (data == 7 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-purple.png';
                });
            }
        }
        else {
            if (!vm.eyeColor || vm.eyeColor.length == 0)
                vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-female-black.png';
            else {
                angular.forEach(vm.eyeColor, function (data) {
                    if (data == 1 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-black.png';
                    else if (data == 2 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-blue.png';
                    else if (data == 3 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-brown.png';
                    else if (data == 4 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-grey.png';
                    else if (data == 5 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-green.png';
                    else if (data == 6 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-hazel.png';
                    else if (data == 7 && vm.eyeColor[vm.eyeColor.length - 1] == data)
                        vm.eyeImg = 'https://pccdn.pyar.com/pcimgs/m/eye-purple.png';
                });
            }
        }
    };

    //function for hair Images Binding
    vm.hairImageBinding = function () {
        if (vm.genPref() == false) {
            if (!vm.hairColor || vm.hairColor.length == 0)
                vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hblk.png';
            else {
                angular.forEach(vm.hairColor, function (data) {
                    if (data == 1 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hblk.png';
                    else if (data == 2 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hdrkbwn.png';
                    else if (data == 3 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hlgtbwn.png';
                    else if (data == 4 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hylw.png';
                    else if (data == 5 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hred.png';
                    else if (data == 6 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hgray.png';
                    else if (data == 7 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hwht.png';
                    else if (data == 8 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hbald.png';
                    else if (data == 9 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/fm-hprpl.png';
                });
            }
        }
        else {
            if (!vm.hairColor || vm.hairColor.length == 0)
                vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hblk.png';
            else {
                angular.forEach(vm.hairColor, function (data) {
                    if (data == 1 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hblk.png';
                    else if (data == 2 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hbrwn.png';
                    else if (data == 3 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hlgtbrwn.png';
                    else if (data == 4 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hylw.png';
                    else if (data == 5 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hred.png';
                    else if (data == 6 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hgray.png';
                    else if (data == 7 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hwht.png';
                    else if (data == 8 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hbald.png';
                    else if (data == 9 && vm.hairColor[vm.hairColor.length - 1] == data)
                        vm.hairImg = 'https://pccdn.pyar.com/pcimgs/m/male-hprpl.png';
                });
            }
        }
    };

    //function for hobbies loading
    vm.mpHobbieDataFuncG = function () {
        selfprofileSrvc.HobbiesList(function (response) {
            var result = {};
            var key = 'categoryName';
            for (var i = 0; i < response.length; i++) {
                if (!result[response[i][key]])
                    result[response[i][key]] = [];
                result[response[i][key]].push(response[i]);
            }
            vm.lstHobbies = result;
            vm.hobbylst = response;
        });
    };
    vm.bindMP = function () {
        showLoader();
        vm.minAge = vm.mp.minAge;
        vm.maxAge = vm.mp.maxAge;
        vm.locRadius = vm.mp.locRadius;
        vm.locType = vm.mp.locType;
        vm.countryId = vm.mp.countryId;
        vm.stateId = vm.mp.stateId;
        vm.cityId = vm.mp.cityId;
        vm.awId = vm.mp.awId;
        vm.highestEdu = vm.mp.highestEdu;
        vm.htCountry = vm.mp.htCountry;
        vm.htState = vm.mp.htState;
        vm.htCity = vm.mp.htCity;
        vm.minHeight = vm.mp.minHeight;
        vm.maxHeight = vm.mp.maxHeight;
        vm.smoke = vm.mp.smoke;
        vm.drink = vm.mp.drink;
        vm.idealRelationship = vm.mp.idealRelationship;
        vm.childrenCnt = vm.mp.childrenCnt;
        vm.childrenPref = vm.mp.childrenPref;
        vm.petsCnt = vm.mp.petsCnt;
        vm.petsPref = vm.mp.petsPref;
        vm.religious = vm.mp.religious;
        vm.traditional = vm.mp.traditional;
        if (vm.mp.rsStatus)
            vm.rsStatus = JSON.parse("[" + vm.mp.rsStatus + "]");
        if (vm.mp.eyeColor)
            vm.eyeColor = JSON.parse("[" + vm.mp.eyeColor + "]");
        if (vm.mp.hairColor)
            vm.hairColor = JSON.parse("[" + vm.mp.hairColor + "]");
        if (vm.mp.build)
            vm.build = JSON.parse("[" + vm.mp.build + "]");
        if (vm.mp.diet)
            vm.diet = JSON.parse("[" + vm.mp.diet + "]");
        if (vm.mp.ethinicities)
            vm.ethinicities = JSON.parse("[" + vm.mp.ethinicities + "]");
        if (vm.mp.religions)
            vm.religions = JSON.parse("[" + vm.mp.religions + "]");
        if (vm.mp.lang)
            vm.lang = JSON.parse("[" + vm.mp.lang + "]");
        if (vm.mp.familyLang)
            vm.familyLang = JSON.parse("[" + vm.mp.familyLang + "]");
        if (vm.mp.hobbies)
            vm.hobbies = JSON.parse("[" + vm.mp.hobbies + "]");
        if (vm.mp.pt)
        vm.pt = JSON.parse("[" + vm.mp.pt + "]");
        vm.long = vm.mp.long;
        vm.lat = vm.mp.lat;
        vm.locRadiusDistance = vm.mp.locRadiusDistance;
        //binding location slider,ethinicy,my appearance functions starts
        vm.mpLocationBind(vm.mp.locRadius);
        vm.mpAboutbindDataFuncG();
        vm.mpAppearanceDataFuncG();
        vm.mpLifeStylesDataFuncG();
        vm.mpHobbieDataFuncG();
        //binding location slider,ethinicy,my appearance functions end Here
        vm.eyeImageBinding();
        vm.hairImageBinding();
        vm.traitImgBind();
        if (vm.units() == 1)
            vm.untsTxt = "Miles"
        else
            vm.untsTxt = "Kms"
        if (vm.htCountry && vm.htCity) {
            $timeout(function () {
                $rootScope.$broadcast("GetCity", "htLoc", vm.htCountry, vm.htCity);
            }, 1000);
        }

        if (vm.countryId && vm.cityId) {
            $timeout(function () {
                $rootScope.$broadcast("GetCity", "curLoc", vm.countryId, vm.cityId);
            }, 1000);
        }
        hideLoader();
    };

    vm.checkDistActive = function () {
        $timeout(function () {
            if (vm.locRadius)
                $('.slider-tick-label').removeClass("ticklblclr");
            var element = $('.slider-tick-label')[vm.locRadius - 1];
            if (element)
                element.className = element.className + " ticklblclr";
        }, 300);
    };

    vm.getLocRadiusDist = function () {
        var dist = 0
        if (vm.locRadius) {
            for (var i = 0; i < vm.lstLocRadiusDist.length; i++) {
                if (vm.lstLocRadiusDist[i].rdId == vm.locRadius) {
                    dist = calculateRadius(vm.units(), vm.lstLocRadiusDist[i].radius);
                    break;
                }
            }
        }
        return dist;
    };

    vm.bindLanguage = function () {
        if (vm.lang) {
            for (var i = 0; i < vm.lang.length; i++) {
                for (var j = 0; j < vm.langPrefDdl.length; j++) {
                    if (vm.lang[i] == vm.langPrefDdl[j].val) {
                        vm.langsObj.push(vm.langPrefDdl[j]);
                        break;
                    }
                }
            }
        }
    };

    vm.bindFamLanguage = function () {
        if (vm.familyLang) {
            for (var i = 0; i < vm.familyLang.length; i++) {
                for (var j = 0; j < vm.familyLangDdl.length; j++) {
                    if (vm.familyLang[i] == vm.familyLangDdl[j].val) {
                        vm.fmlyLangsObj.push(vm.familyLangDdl[j]);
                        break;
                    }
                }
            }
        }
    };

    //Page Load default execute fucntions start
    selfmatchprefSrvc.getmmp(function (response, status) {
        if (status == 200) {
            vm.mp = response;
            vm.bindMP();
        }
    });
    vm.mpPersonalityTraitsmpDataFuncG();
    //Page Load default execute fucntions end 

    //Age block starts
    vm.ddloptions = [];
    var min = 18;
    var max = 131;
    for (var i = min; i < max; i++)
        vm.ddloptions.push({ "val": i, "txt": i + " " +"years old" });

    //swap the ages if minage greater than maxage
    vm.ageCheck = function () {
        if (vm.minAge && vm.maxAge && vm.minAge > vm.maxAge) {
            var tempVal = vm.minAge;
            vm.minAge = vm.maxAge;
            vm.maxAge = tempVal;
        }
    };

    //minAge deselecting function
    vm.minAgeRmv = function () {
        vm.minAge = null;
    };

    //maxAge deselecting function
    vm.maxAgeRmv = function () {
        vm.maxAge = null;
    };
    //Age block starts

    //Ethinicy block starts
    vm.ethinyChkClick = function (ethnicityId, event) {
        $(event.target).toggleClass('actvethncty');
        if (vm.ethinicities.indexOf(ethnicityId) == -1)
            vm.ethinicities.push(ethnicityId);
        else
            vm.ethinicities.splice(vm.ethinicities.indexOf(ethnicityId), 1);
    };
    //Ethinicy block end
    
    //religion block starts
    vm.regChkClick = function (religionId,event) {
        $(event.target).toggleClass('mprlgbtn');
        if (vm.religions.indexOf(religionId) == -1)
            vm.religions.push(religionId);
        else
            vm.religions.splice(vm.religions.indexOf(religionId), 1);
    };
    //religion block End Here*********

    //area of work  starts*********
    vm.ddlaOfWrkChange = function () {
        vm.awId = vm.selectedAofWrk.awId;
        vm.awName = vm.selectedAofWrk.awName;
    };

    vm.aowReset = function () {
        vm.awId = null;
        vm.selectedAofWrk = "";
    };
    //area of work End Here*********

    //relationship   Block starts*********
    vm.rsChkClick = function (val, event) {
        $(event.target).toggleClass('actve');
        if (vm.rsStatus.indexOf(val) == -1)
            vm.rsStatus.push(val);
        else
            vm.rsStatus.splice(vm.rsStatus.indexOf(val), 1);
    };
    //relationship   Block End Here*********

    //Highest Degree   Block starts*********
    vm.degreeIdFunc = function (Id) {
        $('li[id^="liHEdu"]').each(function () {
            $('li[id^="liHEdu"]').not("#liHEdu" + Id).removeClass("actvhdgre");
        });
        if ($("#liHEdu" + Id).hasClass('actvhdgre')) {
            $("#liHEdu" + Id).removeClass('actvhdgre');
            vm.highestEdu = null;
        }
        else {
            $("#liHEdu" + Id).addClass('actvhdgre');
            vm.highestEdu = Id;
        }
    };

    //Highest Degree   Block End Here*********

    //Personality Traits   Block starts*********
    vm.openPTCat = function (catId) {
        vm.ptCat = catId;
        $window.localStorage.setItem("ptIds", JSON.stringify(vm.pt));
        vm.traitsHeader = true;
        vm.personalityDiv = vm.header = vm.ptfooter = false;
        $("html, body").scrollTop(0);
    };

    vm.restorePT = function () {
        vm.pt = JSON.parse($window.localStorage.getItem("ptIds"));
        vm.closePTCat();
    };

    vm.closePTCat = function () {
        $window.localStorage.removeItem("ptIds");
        vm.ptCat = 0;
        vm.traitImgBind();
        vm.personalityDiv = vm.header = vm.ptfooter = true;
        vm.traitsHeader = false;
        $("html, body").scrollTop(0);
    };

    vm.mpPrsnltyChkClick = function (ptId) {
        if (vm.pt.indexOf(ptId) == -1)
            vm.pt.push(ptId);
        else
            vm.pt.splice(vm.pt.indexOf(ptId), 1);
    };

    vm.traitImgBind = function () {
        vm.ptCat1Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt1.png';
        vm.ptCat2Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt2.png';
        vm.ptCat3Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt3.png';
        vm.ptCat4Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt4.png';
        vm.ptCat5Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt5.png';
        vm.ptCat6Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt6.png';
        vm.ptCat7Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pt7.png';
        vm.pt.forEach(function (val) {
            if (val >= 1 & val <= 6)
                vm.ptCat1Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta1.png';
            else if (val >= 7 & val <= 12)
                vm.ptCat2Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta2.png';
            else if (val >= 13 & val <= 18)
                vm.ptCat3Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta3.png';
            else if (val >= 19 & val <= 24)
                vm.ptCat4Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta4.png';
            else if (val >= 25 & val <= 30)
                vm.ptCat5Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta5.png';
            else if (val >= 31 & val <= 36)
                vm.ptCat6Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta6.png';
            else if (val >= 37 & val <= 42)
                vm.ptCat7Img = 'https://pccdn.pyar.com/pcimgs/m/mp-pta7.png';
        });
    };
    //Personality Traits  Block End Here*********

    //Eye color   Block starts*********
    vm.selectEyeclr = function (ecId) {
        if (vm.eyeColor.indexOf(ecId) == -1)
            vm.eyeColor.push(ecId);
        else
            vm.eyeColor.splice(vm.eyeColor.indexOf(ecId), 1);
        vm.eyeImageBinding();
    };
    //Eye color  Block End Here*********

    //Hair color   Block starts*********
    vm.selectHairclr = function (Id) {
        if (vm.hairColor.indexOf(Id) == -1)
            vm.hairColor.push(Id);
        else
            vm.hairColor.splice(vm.hairColor.indexOf(Id), 1);
        vm.hairImageBinding();
    };
    //Hair color  Block End Here*********

    //Height  Block starts*********
    //function to preapare Min HeightDdl
    vm.minHeightDdlPrepare=function() {
        vm.ddlminheight = []
        for (var i = 0; i < vm.height.length; i++) {
            if (vm.height[i].val < vm.maxHeight) {
                var item = {};
                item['val'] = vm.height[i].val;
                item['txt'] = vm.height[i].txt;
                vm.ddlminheight.push(item);
            }
        }
    };

   //function to prepare Max heightDdl
    vm.maxHeightDdlPrepare = function () {
        vm.ddlmaxheight = []
        for (var i = 0; i < vm.height.length; i++) {
            if (vm.height[i].val > vm.minHeight) {
                var item = {
                };
                item['val'] = vm.height[i].val;
                item['txt'] = vm.height[i].txt;
                vm.ddlmaxheight.push(item);
            }
        }
    };

    //function to getting inches or cm text
    vm.getddlHeight = function (height) {
        var fields = height.split('or');
        var unit1 = fields[0];
        var unit2 = fields[1];
        if (vm.units() == 1) {
            unit1 = replaceInches(unit1, " feet", "'");
            unit1 = replaceInches(unit1, " inches", "''");
            return unit1;
        }
        else
            return unit2;
    };

    //function to remove selected height
    vm.heightReset = function (type) {
        if (type == 'min') {
            vm.minHeight = null;
            vm.minHeightTxt = '';
            vm.ddlmaxheight = vm.height;
        }
        else {
            vm.maxHeight = null;
            vm.maxHeightTxt = '';
            vm.ddlminheight = vm.height;
        }
    };

    vm.heightChg = function (minmaxtxt) {
        if (minmaxtxt == "min") {
            vm.minHeight = vm.selectedminheight.val;
            vm.minHeightTxt = vm.getddlHeight(vm.selectedminheight.txt);
            vm.selectedminheight = '';
            vm.maxHeightDdlPrepare();
        }
        else {
            vm.maxHeight = vm.selectedmaxheight.val;
            vm.maxHeightTxt = vm.getddlHeight(vm.selectedmaxheight.txt);
            vm.selectedmaxheight = '';
            vm.minHeightDdlPrepare();
        }
    };
    //Height  Block End Here*********

    //Build  Block starts*********
    vm.buildChkClick = function (Id) {
        if (vm.build.indexOf(Id) == -1)
            vm.build.push(Id);
        else
            vm.build.splice(vm.build.indexOf(Id), 1);
    };

    vm.getBuildImg = function (val) {
        if (val == 1)
            return "https://pccdn.pyar.com/pcimgs/m/mp-bldslim.png";
        else if (val == 2)
            return "https://pccdn.pyar.com/pcimgs/m/mp-bldavg.png";
        else if (val == 3)
            return "https://pccdn.pyar.com/pcimgs/m/mp-bldcurvy.png";
        else if (val == 4)
            return "https://pccdn.pyar.com/pcimgs/m/mp-bldalt.png";
        else if (val == 5)
            return "https://pccdn.pyar.com/pcimgs/m/mp-bldlrg.png";
        else if (val == 6)
            return "https://pccdn.pyar.com/pcimgs/m/mp-bldhvy.png";
    };
    //Build  Block End Here*********

    //Diet  Block starts*********
    vm.dietChkClick = function (val) {
        if (vm.diet.indexOf(val) == -1)
            vm.diet.push(val);
        else
            vm.diet.splice(vm.diet.indexOf(val), 1);
    };

    vm.getDietImg = function (val) {
        if (val == 1) {
            if (vm.diet.indexOf(val) != -1)
                return "https://pccdn.pyar.com/pcimgs/m/mp-vaga.png";
            else 
                return "https://pccdn.pyar.com/pcimgs/m/mp-vag.png";
        }
        else if (val == 2) {
            if (vm.diet.indexOf(val) != -1) 
                return "https://pccdn.pyar.com/pcimgs/m/mp-vega.png";
            else 
                return "https://pccdn.pyar.com/pcimgs/m/mp-veg.png";
        }
        else if (val == 3) {
            if (vm.diet.indexOf(val) != -1)
                return "https://pccdn.pyar.com/pcimgs/m/mp-nonvega.png";
            else
                return "https://pccdn.pyar.com/pcimgs/m/mp-nonveg.png";
        }
    };
    //Diet  Block End Here*********

    //Smoke  Block starts*********
    vm.setSmkHbt = function (smkHbt) {
        $('li[id^="lismke"]').each(function () {
            $('li[id^="lismke"]').not("#lismke" + smkHbt).removeClass("actvesmke");
        });
        if ($("#lismke" + smkHbt).hasClass('actvesmke')) {
            $("#lismke" + smkHbt).removeClass('actvesmke');
            vm.smoke = null;
        }
        else {
            $("#lismke" + smkHbt).addClass('actvesmke');
            vm.smoke = smkHbt;
        }
    };
    //Smoke  Block End Here*********

    //drink  Block starts*********
    vm.setDrkHbt = function (drinkHbt) {
        $('li[id^="lidrnk"]').each(function () {
            $('li[id^="lidrnk"]').not("#lidrnk" + drinkHbt).removeClass("actvdrnk");
        });
        if ($("#lidrnk" + drinkHbt).hasClass('actvdrnk')) {
            vm.drink = null;
            $("#lidrnk" + drinkHbt).removeClass('actvdrnk');
        }
        else {
            vm.drink = drinkHbt;
            $("#lidrnk" + drinkHbt).addClass('actvdrnk');
        }
    };
    //drink  Block End Here*********

    //Ideal relationship  Block starts*********
    vm.setIdealReltshp = function (idealReltshp) {
        $("li[id^='liidlrltn']").each(function () {
            $("li[id^='liidlrltn']").not("#liidlrltn" + idealReltshp).removeClass('idlreltn');
        });
        if ($("#liidlrltn" + idealReltshp).hasClass('idlreltn')) {
            vm.idealRelationship = null;
            $("#liidlrltn" + idealReltshp).removeClass('idlreltn');
        }
        else {
            vm.idealRelationship = idealReltshp;
            $("#liidlrltn" + idealReltshp).addClass('idlreltn');
        }
    };

    vm.getIRImg = function (val) {
        if (val == 1) {
            if (vm.idealRelationship == val)
                return "https://pccdn.pyar.com/pcimgs/m/mp-rslpsersa.png";
            else
                return "https://pccdn.pyar.com/pcimgs/m/mp-rslpsers.png";
        }
        else if (val == 2) {
            if (vm.idealRelationship == val)
                return "https://pccdn.pyar.com/pcimgs/m/mp-rslpcsula.png";
            else
                return "https://pccdn.pyar.com/pcimgs/m/mp-rslpcsul.png";
        }
    };
    //Ideal relationship  Block End Here*********

    //Number of children  Block starts*********
    vm.chldCntClk = function (val) {
        $("li[id^='lichldncnt']").each(function () {
            $("li[id^='lichldncnt']").not('#lichldncnt' + val).removeClass('chldrnnum');
        });
        if ($('#lichldncnt' + val).hasClass('chldrnnum')) {
            vm.childrenCnt = null;
            $('#lichldncnt' + val).removeClass('chldrnnum');
        }
        else {
            vm.childrenCnt = val;
            $('#lichldncnt' + val).addClass('chldrnnum');
        }
    };

    vm.getChldCntImg = function (val) {
        if (val == 1) {
            if (vm.childrenCnt == val)
                return "https://pccdn.pyar.com/pcimgs/m/rnd-stopr.png";
            else
                return "https://pccdn.pyar.com/pcimgs/m/rnd-stopw.png";
        }
        else if (val == 2) {
            if (vm.childrenCnt == val)
                return "https://pccdn.pyar.com/pcimgs/m/chld-r.png";
            else
                return "https://pccdn.pyar.com/pcimgs/m/chld-w.png";
        }
        else if (val == 3) {
            if (vm.childrenCnt == val)
                return "https://pccdn.pyar.com/pcimgs/m/chld2-r.png";
            else
                return "https://pccdn.pyar.com/pcimgs/m/chld2-w.png";
        }
        else if (val == 4) {
            if (vm.childrenCnt == val)
                return "https://pccdn.pyar.com/pcimgs/m/chld3-r.png";
            else
                return "https://pccdn.pyar.com/pcimgs/m/chld3-w.png";
        }
        else if (val == 5) {
            if (vm.childrenCnt == val)
                return "https://pccdn.pyar.com/pcimgs/m/chld4-w.png";
            else
                return "https://pccdn.pyar.com/pcimgs/m/chld4-w.png";
        }
        else if (val == 6) {
            if (vm.childrenCnt == val)
                return "https://pccdn.pyar.com/pcimgs/m/chld5-r.png";
            else
                return "https://pccdn.pyar.com/pcimgs/m/chld5-w.png";
        }
    };

    vm.getChldCntText = function (val) {
        if (val == 1)
            return "Zero";
        else if (val == 2)
            return "One";
        else if (val == 3)
            return "Two";
        else if (val == 4)
            return "Three";
        else if (val == 5)
            return "Four";
        else if (val == 6)
            return "More than five";
    };
    //Number of children  Block End Here*********

    //children  preference Block starts*********
    vm.setChildPref = function (childPref) {
        $('li[id^="lichldpref"]').each(function () {
            $('li[id^="lichldpref"]').not("#lichldpref" + childPref).removeClass("actvchld");
        });
        if ($("#lichldpref" + childPref).hasClass('actvchld')) {
            vm.childrenPref = null;
            $("#lichldpref" + childPref).removeClass('actvchld');
        }
        else {
            vm.childrenPref = childPref;
            $("#lichldpref" + childPref).addClass('actvchld');
        }
    };
    //children  preference Block End Here*********

    //Number of Pets Block starts*********
    vm.petCntClk = function (val) {
        $('li[id^="lipetcnt"]').each(function () {
            $('li[id^="lipetcnt"]').not("#lipetcnt" + val).removeClass("petnum");
        });
        if ($("#lipetcnt" + val).hasClass('petnum')) {
            vm.petsCnt = null;
            $("#lipetcnt" + val).removeClass('petnum');
        }
        else {
            vm.petsCnt = val;
            $("#lipetcnt" + val).addClass('petnum');
        }
    };

    vm.getPetCntImg = function (val) {
        if (val == 1) {
            if (vm.petsCnt == val)
                return "https://pccdn.pyar.com/pcimgs/m/rnd-stopr.png";
            else 
                return "https://pccdn.pyar.com/pcimgs/m/rnd-stopw.png";
        }
        else if (val == 2)
            return "https://pccdn.pyar.com/pcimgs/m/mp-pet1.png";
        else if (val == 3)
            return "https://pccdn.pyar.com/pcimgs/m/mp-pet2.png";
        else if (val == 4)
            return "https://pccdn.pyar.com/pcimgs/m/mp-pet3.png";
    };

    vm.getPetCntText = function (val) {
        if (val == 1)
            return "Zero";
        else if (val == 2)
            return "One";
        else if (val == 3)
            return "Two";
        else if (val == 4)
            return "More than three";
    };
    //Number of Pets Block End Here*********

    //pets  preference Block starts*********
    vm.setPetPref = function (val) {
        $('li[id^="lipetpref"]').each(function () {
            $('li[id^="lipetpref"]').not("#lipetpref" + val).removeClass("petPref");
        });
        if ($("#lipetpref" + val).hasClass('petPref')) {
            vm.petsPref = null;
            $("#lipetpref" + val).removeClass('petPref');
        }
        else {
            vm.petsPref = val;
            $("#lipetpref" + val).addClass('petPref');
        }
    };
    //pets  preference Block End Here*********

    //prefer Language  Block starts*********
    vm.prefLangAddEdit = function (val, event) {
        $(event.target).toggleClass('mpslbtn');
        if (vm.lang.indexOf(val) == -1)
            vm.lang.push(val);
        else
            vm.lang.splice(vm.lang.indexOf(val), 1);
    };
    //prefer Language  Block End Here*********

    //family Language  Block starts*********
    vm.fmlyLangRmv = function (fmlyLangId, txtIndex) {
        var index = vm.familyLang.indexOf(fmlyLangId);
        if (index != -1) {
            vm.familyLang.splice(index, 1);
            vm.fmlyLangsObj.splice(txtIndex, 1);
        }
    };

    vm.fmlyLangAdd = function () {
        if (vm.familyLang.indexOf(vm.selectedFmlyLang.val) == -1) {
            vm.familyLang.push(vm.selectedFmlyLang.val);
            vm.fmlyLangsObj.push(vm.selectedFmlyLang);
        }
        vm.selectedFmlyLang = "";
        $timeout(function () { window.scroll(0, document.body.scrollHeight); }, 0);
    };

    vm.fmlyLangAddEdit = function (val, event) {
        $(event.target).toggleClass('mpslbtn');
        if (vm.familyLang.indexOf(val) == -1)
            vm.familyLang.push(val);
        else
            vm.familyLang.splice(vm.familyLang.indexOf(val), 1);
    };
    //family Language  Block End Here*********

    //religious  Block starts*********
    vm.religiousId = function (val) {
        $('li[id^="lirlgs"]').each(function () {
            $('li[id^="lirlgs"]').not("#lirlgs" + val).removeClass("actvrlgs");
        });
        if ($("#lirlgs" + val).hasClass('actvrlgs')) {
            vm.religious = null;
            $("#lirlgs" + val).removeClass('actvrlgs');
        }
        else {
            vm.religious = val;
            $("#lirlgs" + val).addClass('actvrlgs');
        }
    };
    //religious  Block End Here*********

    //traditional  Block starts*********
    vm.traditionalId = function (val) {
        $('li[id^="litrdtn"]').each(function () {
            $('li[id^="litrdtn"]').not("#litrdtn" + val).removeClass("actvrlgs");
        });
        if ($("#litrdtn" + val).hasClass('actvrlgs')) {
            vm.traditional = null;
            $("#litrdtn" + val).removeClass('actvrlgs');
        }
        else {
            vm.traditional = val;
            $("#litrdtn" + val).addClass('actvrlgs');
        }
    };
    //traditional  Block End Here*********

    //hobbies  Block starts*********
    vm.hobbyChkClick = function (hbId) {
        if (vm.hobbies.indexOf(hbId) == -1)
            vm.hobbies.push(hbId);
        else
            vm.hobbies.splice(vm.hobbies.indexOf(hbId), 1);
    };
    //hobbies  Block End Here*********

    //function for common SKIP NEXT buttons starts
    vm.btnSkipNextBkCls = function (type) {
        $("html, body").scrollTop(0);
        vm.saveMPData(type);
    };

    //common function for  saving data based on page Number
    vm.saveMPData = function (type) {
        if (type) {
            //min and max age
            if (vm.mpPgNo == 1) {
                if (vm.minAge && !vm.maxAge)
                    vm.maxAge = 130;
                else if (!vm.minAge && vm.maxAge)
                    vm.minAge = 18;

                if ((vm.minAge != vm.mp.minAge) || (vm.maxAge != vm.mp.maxAge)) {
                    showLoader();
                    selfmatchprefSrvc.prefAge(vm.minAge, vm.maxAge, function (response, status) {
                        hideLoader();
                        if (response == true && status == 200) {
                            vm.mp.minAge = vm.minAge;
                            vm.mp.maxAge = vm.maxAge;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
                vm.checkDistActive();
            }
                //current location
            else if (vm.mpPgNo == 2) {
                if (vm.mp.locRadius != vm.locRadius || vm.mp.locType != vm.locType || vm.mp.countryId != vm.countryId || vm.mp.stateId != vm.stateId || vm.mp.cityId != vm.cityId || vm.mp.lat != vm.lat || vm.mp.long != vm.long) {
                    showLoader();
                    vm.locRadiusDistance = vm.getLocRadiusDist();
                    selfmatchprefSrvc.prefDistance(vm.locRadius, vm.locType, vm.countryId, vm.stateId, vm.cityId, vm.lat, vm.long, vm.locRadiusDistance, function (response, status) {
                        hideLoader();
                        if (response == true && status == 200) {
                            vm.mp.locRadius = vm.locRadius;
                            vm.mp.locType = vm.locType;
                            vm.mp.countryId = vm.countryId;
                            vm.mp.cityId = vm.cityId;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Ethnicity
            else if (vm.mpPgNo == 3) {
             if (compareArray(vm.ethinicities, JSON.parse("[" + vm.mp.ethinicities + "]"))) {
                    showLoader();
                    selfmatchprefSrvc.EthnicitiesIU(vm.mId(), vm.ethinicities.join(), function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.ethinicities = vm.ethinicities.join();
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                 vm.navigateTab(type);
             vm.checkDistActive();
  }
                //Religion
            else if (vm.mpPgNo == 4) {
                if (compareArray(vm.religions, JSON.parse("[" + vm.mp.religions + "]"))) {
                    showLoader();
                    selfmatchprefSrvc.ReligionsIU(vm.mId(), vm.religions.join(), function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.religions = vm.religions.join();
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Area of work
            else if (vm.mpPgNo == 5) {
                if (vm.awId != vm.mp.awId) {
                    showLoader();
                    selfmatchprefSrvc.prefAreaOfWork(vm.awId, function (response, status) {
                        hideLoader();
                        if (response == true && status == 200) {
                            vm.mp.awId = vm.awId;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Relationship status
            else if (vm.mpPgNo == 6) {
                if (compareArray(vm.rsStatus, JSON.parse("[" + vm.mp.rsStatus + "]"))) {
                    showLoader();
                    selfmatchprefSrvc.RSStatusIU(vm.mId(), vm.rsStatus.join(), function (response, status) {
                        hideLoader();
                        if (status = 200 && response == true) {
                            vm.mp.rsStatus = vm.rsStatus.join();
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Highest Degree
            else if (vm.mpPgNo == 7) {
                if (vm.highestEdu != vm.mp.highestEdu) {
                    showLoader();
                    selfmatchprefSrvc.prefEducation(vm.highestEdu, function (response, status) {
                        hideLoader();
                        if (response == true && status == 200) {
                            vm.mp.highestEdu = vm.highestEdu;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Hometown
            else if (vm.mpPgNo == 8) {
                if (vm.htCountry != vm.mp.htCountry || vm.htStateId != vm.mp.htState || vm.htCity != vm.mp.htCity && vm.growZipCode || vm.mp.htZipCode) {
                    showLoader();
                    selfmatchprefSrvc.prefHometown(vm.htCountry, vm.htStateId, vm.htCity, vm.growZipCode, function (response, status) {
                        hideLoader();
                        if (response == true && status == 200) {
                            vm.mp.htCountry = vm.htCountry;
                            vm.mp.htCity = vm.htCity;
                            vm.mp.htZipCode = vm.growZipCode;
                            vm.mp.htState = vm.htStateId;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Personality Traits
            else if (vm.mpPgNo == 9) {
                if (compareArray(vm.pt, JSON.parse("[" + vm.mp.pt + "]"))) {
                    showLoader();
                    selfmatchprefSrvc.PersonalityTraitsIU(vm.mId(), vm.pt.join(), function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.pt = vm.pt.join();
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Eye Color
            else if (vm.mpPgNo == 10) {
                if (compareArray(vm.eyeColor, JSON.parse("[" + vm.mp.eyeColor + "]"))) {
                    showLoader();
                    selfmatchprefSrvc.EyeColourIU(vm.mId(), vm.eyeColor.join(), function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.eyeColor = vm.eyeColor.join();
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Hair color
            else if (vm.mpPgNo == 11) {
                if (compareArray(vm.hairColor, JSON.parse("[" + vm.mp.hairColor + "]"))) {
                    showLoader();
                    selfmatchprefSrvc.HairColourIU(vm.mId(), vm.hairColor.join(), function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.hairColor = vm.hairColor.join();
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Min and Max height
            else if (vm.mpPgNo == 12) {
                if (vm.mp.minHeight != vm.minHeight || vm.mp.maxHeight != vm.maxHeight) {
                    showLoader();
                    selfmatchprefSrvc.prefHeight(vm.minHeight, vm.maxHeight, function (response, status) {
                        hideLoader();
                        if (status == 200) {
                            vm.mp.minHeight = vm.minHeight;
                            vm.mp.maxHeight = vm.maxHeight;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Build
            else if (vm.mpPgNo == 13) {
                if (compareArray(vm.build, JSON.parse("[" + vm.mp.build + "]"))) {
                    showLoader();
                    selfmatchprefSrvc.BuildIU(vm.mId(), vm.build.join(), function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.build = vm.build.join();
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Diet
            else if (vm.mpPgNo == 14) {
                if (compareArray(vm.diet, JSON.parse("[" + vm.mp.diet + "]"))) {
                    showLoader();
                    selfmatchprefSrvc.DietIU(vm.mId(), vm.diet.join(), function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.diet = vm.diet.join();
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Smoke
            else if (vm.mpPgNo == 15) {
                if (vm.smoke != vm.mp.smoke) {
                    showLoader();
                    selfmatchprefSrvc.prefSmoking(vm.smoke, function (response, status) {
                        hideLoader();
                        if (status == 200) {
                            vm.mp.smoke = vm.smoke;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Drink
            else if (vm.mpPgNo == 16) {
                if (vm.drink != vm.mp.drink) {
                    showLoader();
                    selfmatchprefSrvc.prefDrinking(vm.drink, function (response, status) {
                        hideLoader();
                        if (status == 200) {
                            vm.mp.drink = vm.drink;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Ideal relationship
            else if (vm.mpPgNo == 17) {
                if (vm.idealRelationship != vm.mp.idealRelationship) {
                    showLoader();
                    selfmatchprefSrvc.prefRelationship(vm.idealRelationship, function (response, status) {
                        hideLoader();
                        if (status == 200) {
                            vm.mp.idealRelationship = vm.idealRelationship;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Children Count
            else if (vm.mpPgNo == 18) {
                if (vm.childrenCnt != vm.mp.childrenCnt) {
                    showLoader();
                    selfmatchprefSrvc.prefChildrenCnt(vm.childrenCnt, function (response, status) {
                        hideLoader();
                        if (status == 200) {
                            vm.mp.childrenCnt = vm.childrenCnt;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Children Preferences
            else if (vm.mpPgNo == 19) {
                if (vm.childrenPref != vm.mp.childrenPref) {
                    showLoader();
                    selfmatchprefSrvc.prefChildren(vm.childrenPref, function (response, status) {
                        hideLoader();
                        if (status == 200) {
                            vm.mp.childrenPref = vm.childrenPref;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Pets count
            else if (vm.mpPgNo == 20) {
                if (vm.petsCnt != vm.mp.petsCnt) {
                    showLoader();
                    selfmatchprefSrvc.prefPets(vm.petsCnt, function (response, status) {
                        hideLoader();
                        if (status == 200) {
                            vm.mp.petsCnt = vm.petsCnt;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Pets Preferences
            else if (vm.mpPgNo == 21) {
                if (vm.petsPref != vm.mp.petsPref) {
                    showLoader();
                    selfmatchprefSrvc.prefPetPref(vm.petsPref, function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.petsPref = vm.petsPref;
                            vm.navigateTab(type);
                        }
                    });
            }
            else
                vm.navigateTab(type);
        }
            //Languages Pref
            else if (vm.mpPgNo == 22) {
                if (compareArray(vm.lang, JSON.parse("[" + vm.mp.lang + "]"))) {
                    showLoader();
                    selfmatchprefSrvc.LanguagesIU(vm.mId(), vm.lang.join(), function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.lang = vm.lang.join();
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Family language Pref
            else if (vm.mpPgNo == 23) {
                if (compareArray(vm.familyLang, JSON.parse("[" + vm.mp.familyLang + "]"))) {
                    showLoader();
                    selfmatchprefSrvc.FamLanguagesIU(vm.mId(), vm.familyLang.join(), function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.familyLang = vm.familyLang.join();
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Religious
            else if (vm.mpPgNo == 24) {
                if (vm.religious != vm.mp.religious) {
                    showLoader();
                    selfmatchprefSrvc.prefReligious(vm.religious, function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.religious = vm.religious;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Traditional
            else if (vm.mpPgNo == 25) {
                if (vm.traditional != vm.mp.traditional) {
                    showLoader();
                    selfmatchprefSrvc.prefCultural(vm.traditional, function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.traditional = vm.traditional;
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Hobbies
            else if (vm.mpPgNo == 26) {
                if (compareArray(vm.hobbies, JSON.parse("[" + vm.mp.hobbies + "]"))) {
                    showLoader();
                    selfmatchprefSrvc.HobbiesIU(vm.mId(), vm.hobbies.join(), function (response, status) {
                        hideLoader();
                        if (status == 200 && response == true) {
                            vm.mp.hobbies = vm.hobbies.join();
                            vm.navigateTab(type);
                        }
                    });
                }
                else
                    vm.navigateTab(type);
            }
                //Done button click
            else if (vm.mpPgNo == 27) {
                $window.localStorage.removeItem("mpPgNo");
                if ($rootScope.otherPrflReffer) {
                    $location.path($rootScope.otherPrflReffer);
                    $rootScope.otherPrflReffer = "";
                }
                else
                    $location.path('/editprofile.html');
            }
        }
    };

    //function to navigation
    vm.navigateTab = function (type) {
        if (type == 'NS')
            vm.mpPgNo++;
        else if (type == 'B')
            vm.mpPgNo--;
        else if (type == 'E' || type == 'X') {
            if (type == 'E')
                vm.mpPgNo = 1;
            $window.localStorage.setItem("mpPgNo", vm.mpPgNo);
            if ($rootScope.otherPrflReffer) {
                $location.path($rootScope.otherPrflReffer);
                $rootScope.otherPrflReffer = "";
            }
            else
                $location.path('/editprofile.html');
        }
        if (vm.mpPgNo <= 0)
            vm.mpPgNo = 1;
    };
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( Location service function start ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
    /*******************************************************************************************************************************************************************/
    //vm.countryId = null;
    vm.showloc = false;
    vm.selectLoc = function (locId) {
        $rootScope.$broadcast("showLocation", locId);
    };

    //city intelligence module
    vm.GetCity = function (locId, countryId, cityId) {
        $rootScope.$broadcast("GetCity", locId, countryId, cityId);
    };
    
    $scope.$on("BindCity", function (e, locId, data) {
        vm.bindLocation(locId, data);
    });

    vm.bindLocation = function (locId, data) {
        if (locId == "curLoc") {
            vm.curLocation = [];
            if (data.cityName)
                vm.curLocation.push(data.cityName);
            if (data.stateShortName)
                vm.curLocation.push(data.stateShortName);
            else
                vm.curLocation.push(data.stateName);
            if (data.countryName)
                if (data.countryId != getSessionSrvc.p_cntryId())
                    vm.curLocation.push(data.countryName);
            vm.curLocation = vm.curLocation.join(', ');
            vm.curLocation = vm.curLocation.toString();
        }
        else {
            vm.htLocation = [];
            if (data.cityName)
                vm.htLocation.push(data.cityName);
            if (data.stateShortName)
                vm.htLocation.push(data.stateShortName);
            else
                vm.htLocation.push(data.stateName);
            if (data.countryName)
                if (data.countryId != getSessionSrvc.p_cntryId())
                    vm.htLocation.push(data.countryName);
            vm.htLocation = vm.htLocation.join(', ');
            vm.htLocation = vm.htLocation.toString();
        }
    };

    $scope.$on("countryBind", function (e, locId, countryId, data) {
        vm.bindLocation(locId, data);
        vm.locType = 3;
        if (locId == "curLoc") {
            vm.countryId = data.countryId;
            vm.cityId = data.cityId;
            vm.long = data.long;
            vm.lat = data.lat;
            if (!vm.locRadius)
                vm.locRadius = 1;
            var element = $('.slider-tick-label')[vm.locRadius - 1];
            if (element)
                element.className = element.className + " ticklblclr";
        }
        else {
            vm.htCountry = data.countryId;
            vm.htCity = data.cityId;
            vm.growZipCode = data.zipCode;
            vm.htStateId = data.stateId;
        }
    });
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( Location service function end ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
    /*******************************************************************************************************************************************************************/
}]);