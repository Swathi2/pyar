﻿angular.module("app").controller('epgallryCtrl', ['selfprofileSrvc', 'getSessionSrvc', '$scope', '$window', '$rootScope', '$state', '$timeout', 'msgSrvc', function (selfprofileSrvc, getSessionSrvc, $scope, $window, $rootScope, $state, $timeout, msgSrvc) {
    showLoader();
    var vm = this;
    if (!$window.localStorage.getItem("profileInfo")) { $state.go('profile'); return; }
    $rootScope.dvpgVisble = true;
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.fn = function () { return getSessionSrvc.p_fn(); };
    vm.pp = function () { return getSessionSrvc.p_ppic(); };
    vm.gender = function () { return getSessionSrvc.p_gndr(); };
    vm.prflData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo"))).prflData;
    vm.TotglryImgs = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo"))).gallery;
    vm.imageCDN = "https://pccdn.pyar.com";
    vm.maxWidth = 1920;
    vm.maxHeight = 1920;
    vm.minWidth = 400;
    vm.minHeight = 400;
    vm.imgwidth = 0;
    vm.imgHeight = 0;
    vm.photoPath = '';
    var croppie;
    vm.crpDone = false;
    vm.phtUplPrcCmt = true;
    var width = (window.innerWidth > 0) ? window.innerWidth : screen.width  //get screen width to set cropper width && height dynamically
    $('.crprTxt').css('top', width + 90);// Dynamic position for cropper text(Reposition Photo)
    vm.photoIndex = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("photoIndex")));//pic index maintained for instagram when page reloaded. 

    /************************************************************** Binding Gallery Images**************************************************************/
    $scope.$on("pfGallerySwiper", function () {
        vm.bindGallerySwiper();
    });
    vm.bindGallerySwiper = function () {
        vm.galleryswiper = new Swiper('.gimg', {
            slidesPerView: 1,
            paginationClickable: true,
            centeredSlides: true,
            loop: vm.glryImgs.length > 1 ? true : false,          
            observer: true,
            observeParents: true,
            onSlideNextStart: function (swiper) {
                vm.realIndex = swiper.realIndex;
                if (vm.glryImgs.length == 1) 
                    swiper.destroyLoop();                                 
                if (vm.gpIndex >= vm.glryImgs.length)
                    vm.gpIndex = 1;
                else
                    vm.gpIndex += 1;
                vm.pfSlidetxt = "Make Profile Photo";
                $scope.$digest();
            },
            onSlidePrevStart: function (swiper) {
                vm.realIndex = swiper.realIndex;
                if (vm.glryImgs.length == 1) {
                    swiper.destroyLoop();                   
                }
                if (vm.gpIndex <= 1)
                    vm.gpIndex = vm.glryImgs.length;
                else
                    vm.gpIndex -= 1;
                vm.pfSlidetxt = "Make Profile Photo";
                $scope.$digest();
            }
        });
    };

    vm.bindingGlryImgs = function () {
        var glryThumbnails = [];
        var glryImgs = [];
        for (var i = 1; i < 9; i++) {
            var hasVaue = false;
            for (var j = 0; j < vm.TotglryImgs.length; j++) {
                if (vm.TotglryImgs[j].picType == 1) {
                    if (i == vm.TotglryImgs[j].picOrder) {
                        glryThumbnails.push({ mpId: vm.TotglryImgs[j].mpId, picPath: vm.imageCDN + vm.TotglryImgs[j].picPath, picOrder: vm.TotglryImgs[j].picOrder, picCreateDT: vm.TotglryImgs[j].picCreateDT });
                        glryImgs.push({ mpId: vm.TotglryImgs[j].mpId, picPath: vm.imageCDN + vm.TotglryImgs[j].picPath.replace("/tn/", "/"), picOrder: vm.TotglryImgs[j].picOrder, picCreateDT: vm.TotglryImgs[j].picCreateDT });
                        hasVaue = true;
                    }
                }
                else if (vm.TotglryImgs[j].picType == 2)
                    vm.orgPath = vm.TotglryImgs[j].picPath;
            }
            if (!hasVaue)
                glryThumbnails.push({ mpId: 0, picPath: "", picOrder: i, picCreateDT: '' });
        }
        vm.glryThumbnails = glryThumbnails;
        vm.glryImgs = glryImgs;
        if (vm.glryImgs.length == 0)
        vm.bindGallerySwiper();
        hideLoader();
    };
    vm.bindingGlryImgs();

    //bind gallery image insert
    vm.galleryPhotosI = function (data) {
        if (data != null) {
            showLoader();
            var index = vm.photoIndex + 1;
            selfprofileSrvc.uploadGlryImages(vm.mId(), index, data, function (response, status) {
                if (status == 200) {
                    vm.dateCreated = response.picCreateDT;
                    for (var i = 0; i < vm.glryThumbnails.length; i++) {
                        if (vm.glryThumbnails[i].picOrder == index) {
                            vm.glryThumbnails[i].mpId = response.mpId;
                            vm.glryThumbnails[i].picPath = vm.imageCDN + response.picPath;
                            vm.glryThumbnails[i].picOrder = response.picOrder;
                            vm.glryThumbnails[i].picCreateDT = response.picCreateDT;
                            vm.TotglryImgs.push(response)
                            var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
                            sfData.gallery.push(response);
                            $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                        }
                    }
                    vm.phtUplPrcCmt = true;
                    vm.glryImgs.push({ mpId: response.mpId, picPath: vm.imageCDN + response.picPath.replace("/tn/", "/"), picOrder: response.picOrder, picCreateDT: response.picCreateDT });
                    vm.galleryswiper.updateSlidesSize(true);
                    $window.localStorage.removeItem("photoIndex");
                    history.pushState(null, null, location.pathname);//change visible url with out refreshing page.                
                    var notifyType = 54;//gallery photo upload
                    if (msgSrvc.conId)
                        msgSrvc.sendMemberNWNotifications("", vm.fn(), vm.pp(), vm.gender(), notifyType, new Date());
                    else
                        $rootScope.ntfnData.push({ "sendType": 2, "tmId": "", "fn": vm.fn(), "pp": vm.pp(), "gender": vm.gender(), "type": notifyType, "date": new Date() });
                }
                hideLoader();
            });
        }
    };

    //gallery cancel function
    vm.mygallryCancel = function () {
        $state.go('editprofile');
    };

    //My Photo gallery click on image note:" type 1 for add photo 2 for slide photo"
    vm.imgGalleryClick = function (index, type, mpuId, dateCreated, picorder, picpath) {
        if (vm.phtUplPrcCmt == true) {
            vm.upldPhotoType = 1;
            vm.dateCreated = dateCreated;
            vm.photoIndex = index;
            $window.localStorage.setItem("photoIndex", getSessionSrvc.pce(JSON.stringify(vm.photoIndex)));
            vm.mpuId = mpuId;
            vm.picOrder = picorder;
            vm.actionType = type;
            if (type == 1)
                $("#glryActions").modal('show');
            else if (type == 2) {
                vm.showSlider = true;
                vm.galleryswiper.update(true);
                for (var i = 0; i < vm.glryImgs.length; i++) {
                    if (vm.glryImgs[i].picOrder == vm.picOrder) {
                        vm.gpIndex = i + 1;
                        break;
                    }
                }

                $timeout(function () { vm.galleryswiper.slideTo(vm.gpIndex, 0, false); }, 10);
                vm.realIndex = vm.gpIndex - 1;
                vm.pfSlidetxt = "Make Profile Photo";
            }
        }
    };
    /************************************************************** Binding Gallery Images**************************************************************/

    /**************************************************************image UPLOAD And DELETE END **************************************************************/
    vm.hideSlider = function () {
        vm.showSlider = false;
    };

    //make gallery image to profile photo conform popup
    vm.makeprflPhoto = function (mpid, imgsrc, order) {
        vm.photoPath = imgsrc;
        vm.mpuId = mpid;
        vm.picOrder = order;
        $("#makePrflPop").modal("show");
    };
    //Make profile pic conform popup Ok Action.
    vm.CropMkPrflPic = function () {
        $("#makePrflPop").modal("hide");
        //FOR SWAP IMAGE
        vm.upldPhotoType = 4;
        vm.showSlider = false;
        $('#cropImg').croppie('destroy');
        CropPBPhoto(vm.photoPath, width - 35, width - 35, $timeout);
    };

    //deltete gallery image popup click 
    vm.btnShowDltPopUp = function (mpId, picType, picOrder, index) {
        vm.mpuId = mpId;
        if (vm.glryImgs.length >= index + 1)
            vm.gpIndex = 1;
        $("#srcdeletePopup").modal("show");
    };

    //delete photo from gallery
    vm.btnDltGlryPhoto = function () {
        showLoader();
        $("#srcdeletePopup").modal("hide");
        if (vm.mId() && vm.mpuId) {
            selfprofileSrvc.GalleryPhotoD(vm.mId(), vm.mpuId, function (response, status) {
                if (status == 200 && response == true) {
                    for (var i = 0; i < vm.glryThumbnails.length; i++) {
                        if (vm.glryThumbnails[i].mpId == vm.mpuId) {
                            vm.glryThumbnails[i].mpId = 0;
                            vm.glryThumbnails[i].picPath = "";
                            vm.glryThumbnails[i].picCreateDT = '';
                            break;
                        }
                    }

                    for (var i = 0; i < vm.glryImgs.length; i++) {
                        if (vm.glryImgs[i].mpId == vm.mpuId) {
                            vm.glryImgs.splice(i, 1);
                            break;
                        }
                    }

                    for (var i = 0; i < vm.TotglryImgs.length; i++) {
                        if (vm.TotglryImgs[i].mpId == vm.mpuId) {
                            vm.TotglryImgs.splice(i, 1);
                            break;
                        }
                    }
                    vm.galleryswiper.removeSlide(vm.realIndex);
                    vm.galleryswiper.updateSlidesSize(true);
                    var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
                    sfData.gallery = vm.TotglryImgs;
                    $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                    if (vm.glryImgs.length == 0)
                        vm.showSlider = false;
                        hideLoader();
                }
                else {
                    alert("unable to delete photo");
                    hideLoader();
                }
            });
        }
    };
  

    $scope.imageUpload = function (event) {
        showLoader();
        vm.phtUplPrcCmt = false;
        var files = event.target.files;
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var reader = new FileReader();
            var upldSuccess = false;
            $rootScope.srcType = 1;
            reader.onload = function (e) {
                $("<img/>").load(function () {
                    vm.imgRealWidth = this.width;
                    vm.imgRealHeight = this.height;
                    if (vm.imgRealWidth < vm.minWidth || vm.imgRealHeight < vm.minHeight) {
                        $("#photoSmallpop").modal('show');
                        hideLoader();
                    }
                    else {
                        $('#cropImg').croppie('destroy');
                        vm.photoPath = e.target.result;
                        vm.imgHeight = vm.imgRealHeight;
                        vm.imgwidth = vm.imgRealWidth;

                        if (vm.imgRealWidth > vm.imgRealHeight) {
                            if (vm.imgRealWidth > vm.maxWidth) {
                                vm.imgHeight = vm.imgRealHeight * (vm.maxWidth / vm.imgRealWidth);
                                vm.imgwidth = vm.maxWidth;
                            }
                        } else {
                            if (vm.imgRealHeight > vm.maxHeight) {
                                vm.imgwidth = vm.imgRealWidth * (vm.maxHeight / vm.imgRealHeight);
                                vm.imgHeight = vm.maxHeight;
                            }
                        }
                        //if browser type is an ios device the below code get executed
                        if (getBrowserType() == true) {
                            var options = {
                                canvas: true
                            };
                            vm.imgDataExifProp = false;
                            loadImage.parseMetaData(file, function (data) {
                                if (data.exif) {
                                    vm.imgDataExifProp = true;
                                    options.orientation = data.exif.get('Orientation');
                                    loadImage(file, getOrientImageResponse, options);
                                } else {
                                    vm.uploadImageFromLocalPC(e.target.result);
                                }
                            });
                        } else {
                            vm.uploadImageFromLocalPC(e.target.result);
                        }
                    }
                    $("#fupPhtGlry").val(null);//clear the image upload path for same image uploading.
                }).attr("src", e.target.result);
            }
            reader.readAsDataURL(file);     
        }
    };

    var getOrientImageResponse = function (img) {
        if (vm.imgDataExifProp == true)
            vm.uploadImageFromLocalPC(img.toDataURL());
    };

    vm.uploadImageFromLocalPC = function (oreintResultImg) {
        vm.photoPath = oreintResultImg;
        //GALLERY PHOTO UPLOAD FROM LOCAL PC
        if (vm.upldPhotoType == 1) {
            var data = new FormData();                                                        
            CreateGlryThumbNail(oreintResultImg, vm.imgRealWidth, vm.imgRealHeight, function () {
                resizingImage(oreintResultImg, function (resizeResponse) {
                    base64ToBlobFileConvertion(resizeResponse, function (originalImgBlob) {
                        GetGalleryTnResponse(430, 430,$timeout, function (img430Img) {
                            GetGalleryTnResponse(200, 200,$timeout, function (img200Img) {
                                base64ToBlobFileConvertion(img430Img, function (img430Blog) {
                                    base64ToBlobFileConvertion(img200Img, function (img200Blog) {
                                        data.append("originalImgBlob", originalImgBlob);
                                        data.append("img430Blog", img430Blog);
                                        data.append("img200Blog", img200Blog);
                                        vm.galleryPhotosI(data);
                                    });
                                });
                            });
                        });
                    });
                });
            });
        }
    }
    /**************************************************************image UPLOAD And DELETE END **************************************************************/ 
    //save image after cropping
    vm.saveCroppedImg = function () {
        //SWAP PHOTOs
        showLoader();
        vm.crpDone = true;
        $rootScope.dvAlbumPhotos = false;
        $rootScope.dvpgVisble = true;
        if (vm.upldPhotoType == 4) {
            $("<img/>").load(function () {
                var glImgWidth = this.width;
                var glImgHeight = this.height;
                var data = new FormData();
                convertFileToDataURLviaFileReader(vm.photoPath, function (originalImgResponse) {
                    CroppedImageResult(430, 430, function (img430Response) {
                        CroppedImageResult(200, 200, function (img200Response) {
                            CroppedImageResult(100, 100, function (img100Response) {
                                resizingImage(originalImgResponse, function (resizeResponse) {
                                    base64ToBlobFileConvertion(resizeResponse, function (originalImgBlob) {
                                        base64ToBlobFileConvertion(img430Response, function (img430Blog) {
                                            base64ToBlobFileConvertion(img200Response, function (img200Blog) {
                                                base64ToBlobFileConvertion(img100Response, function (img100Blog) {
                                                    createBlurImage((img430Response), function (blurResponseBlob) {
                                                        data.append("originalImgBlob", originalImgBlob);
                                                        data.append("img430Blog", img430Blog);
                                                        data.append("img200Blog", img200Blog);
                                                        data.append("img100Blog", img100Blog);
                                                        data.append("blurResponseBlob", blurResponseBlob);
                                                        selfprofileSrvc.swapImages(vm.mId(), vm.mpuId, data, function (response, status) {
                                                            if (status == 200) {
                                                                var dtn = new Date().valueOf();
                                                                $("#srcAdjustProfilePhotoPopup").modal("hide");
                                                                for (var i = 0; i < vm.glryThumbnails.length; i++) {
                                                                    if (vm.glryThumbnails[i].picOrder == vm.picOrder) {
                                                                        if (vm.prflData.isProfilePicUpld == false) {
                                                                            vm.glryThumbnails[i].mpId = 0;
                                                                            vm.glryThumbnails[i].picPath = "";
                                                                            vm.glryThumbnails[i].picCreateDT = '';
                                                                        }
                                                                        else
                                                                            vm.glryThumbnails[i].picPath = vm.glryThumbnails[i].picPath + "?v=" + dtn;
                                                                        break;
                                                                    }
                                                                }

                                                                for (var i = 0; i < vm.glryImgs.length; i++) {
                                                                    if (vm.glryImgs[i].picOrder == vm.picOrder) {
                                                                        vm.glryImgs[i].picPath = vm.glryImgs[i].picPath + "?v=" + dtn;
                                                                        $scope.$emit("refreshHdrPP", vm.glryImgs[i].picPath);
                                                                        var notifyType = 53;
                                                                        if (msgSrvc.conId)
                                                                            msgSrvc.sendMemberNWNotifications("", vm.fn(), vm.pp(), vm.gender(), notifyType, new Date());
                                                                        else
                                                                            $rootScope.ntfnData.push({ "sendType": 2, "tmId": "", "fn": vm.fn(), "pp": vm.pp(), "gender": vm.gender(), "type": notifyType, "date": new Date() });
                                                                        break;
                                                                    }
                                                                }
                                                                vm.galleryswiper.updateSlidesSize(true);
                                                            }
                                                            vm.crpDone = false;
                                                            hideLoader();
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            }).attr("src", vm.photoPath);
        }
    };
    /************************************************************** ADD PHOTO FROM SOCIAL**************************************************************/
    vm.addPhoto = function () {
        //gallery photo module
        vm.phtUplPrcCmt = false;
        $rootScope.dvAlbumPhotos = false;
        $rootScope.dvpgVisble = true;
        var data = new FormData();
        convertFileToDataURLviaFileReader($rootScope.imgPath, function (originalImgResponse) {
            CreateGlryThumbNail(originalImgResponse, $rootScope.realWidth, $rootScope.realHeight, function (img430Img) {
                resizingImage(originalImgResponse, function (resizeResponse) {
                    base64ToBlobFileConvertion(resizeResponse, function (originalImgBlob) {
                        GetGalleryTnResponse(430, 430, $timeout, function (img430Img) {
                            GetGalleryTnResponse(200, 200, $timeout, function (img200Img) {
                                base64ToBlobFileConvertion(img430Img, function (img430Blog) {
                                    base64ToBlobFileConvertion(img200Img, function (img200Blog) {
                                        data.append("originalImgBlob", originalImgBlob);
                                        data.append("img430Blog", img430Blog);
                                        data.append("img200Blog", img200Blog);
                                        vm.galleryPhotosI(data);
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    };
    /************************************************************** ADD PHOTO FROM SOCIAL**************************************************************/
}]);