﻿angular.module("app").controller('selfprofileCtrl', ['selfprofileSrvc', 'selfmatchprefSrvc', 'getSessionSrvc', 'msgSrvc', '$scope', '$rootScope', '$window', '$state', '$filter', '$timeout', '$interval', 'cmnSrvc', function (selfprofileSrvc, selfmatchprefSrvc, getSessionSrvc, msgSrvc, $scope, $rootScope, $window, $state, $filter, $timeout, $interval, cmnSrvc) {
    var vm = this;
    // Getting memberId from session    
    vm.mId = function () { return getSessionSrvc.p_mId(); }
    vm.fn = function () { return getSessionSrvc.p_fn(); };
    vm.genPref = function () { return getSessionSrvc.p_gndrp(); };
    vm.pp = function () { return getSessionSrvc.p_ppic(); };
    vm.gender = function () { return getSessionSrvc.p_gndr(); };
    setFooterIcon("prfl");
    //removing localstorage if exists
    $window.localStorage.removeItem("profileInfo");
    $rootScope.dvpgVisble = false;
    vm.imageCDN = "https://pccdn.pyar.com";
    vm.PPindex = 0;
    vm.mpId = "";
    vm.ptArray = [];
    vm.hbArray = [];
    vm.locatntxtprf = [];
    vm.lang = [];
    vm.aboutlocation = [];
    vm.familyLangs = [];
    vm.showSlider = false;
    vm.profileResponse = [];
    vm.hideBioRead = true;
    vm.myBioPlaceHolder = "How would you describe yourself?";
    vm.galleryImgs = [];
    showLoader();

    vm.getPrfInfoCallBack = function (response, status) {
        showLoader();
        vm.profileInfo = response;
        vm.htCity = response.htCity;
        vm.profilePic = $filter("PrflPicFltr")(vm.profileInfo.profilePic, vm.profileInfo.gender);
        $scope.$emit("refreshHdrPP", vm.profilePic);//update profile  in toggle
        vm.matchPrefDataBind();
        vm.Gender = $filter('GenderPicFltr')(vm.profileInfo.gender);
        vm.gndrTxt = $filter('gndrTxtFltr')(vm.profileInfo.genderPref);
        vm.gndrPrefImg = $filter('smGndrImgFltr')(vm.profileInfo.genderPref);
        vm.gndrPrefLrgImg = $filter('lrgGndrImgFltr')(vm.profileInfo.genderPref);
        if (vm.profileInfo.pt)
            vm.ptArray = JSON.parse("[" + vm.profileInfo.pt + "]");
        if (vm.profileInfo.lang)
            vm.lang = JSON.parse("[" + vm.profileInfo.lang + "]");
        if (vm.profileInfo.familyLangs)
        vm.familyLangs = JSON.parse("[" + vm.profileInfo.familyLangs + "]");
        vm.myLifeStyleDdls();
        if (vm.profileInfo.hobbies)
        vm.hbArray = JSON.parse("[" + vm.profileInfo.hobbies + "]");
        vm.myBioData = vm.profileInfo.abtDesc;
        vm.getAge = calculateAge(response.dob);
        vm.cityName = vm.profileInfo.cityName;
        vm.countryName = vm.profileInfo.countryName;
        vm.stateName = vm.profileInfo.stateName;
        if (vm.profileInfo.trophies)
            trophiesResult = (vm.profileInfo.trophies).split('#');
        trophiesLoad(trophiesResult);
        ShowTrophyFTPOP();
        selfprofileSrvc.GetPrfInfoExt1(vm.mId(), vm.profileInfo, GetPrfInfoExt1CallBack);
        selfprofileSrvc.GetPrfInfoExt2(vm.mId(), vm.profileInfo, GetPrfInfoExt2CallBack);
        if (vm.cityName)
            vm.locatntxtprf.push(vm.cityName);
        if (vm.stateName)
            vm.locatntxtprf.push(vm.stateName);
        var locatnprftxt = vm.locatntxtprf.join(', ');
        vm.locatntxtprf = locatnprftxt.toString()
        vm.locatnttxt = vm.locatntxtprf;       
        if (vm.profileInfo.gender == true) {
            vm.genderImg = "https://pccdn.pyar.com/pcimgs/m/hairm-b.png";
            vm.myBioImg = "https://pccdn.pyar.com/pcimgs/m/male.png";
        }
        else {
            vm.genderImg = "https://pccdn.pyar.com/pcimgs/m/hairfm.png";
            vm.myBioImg = "https://pccdn.pyar.com/pcimgs/m/female.png";
        }
        vm.pgVisble();
    };

    var GetPrfInfoExt1CallBack = function (responseEx1, status) {
        vm.profileInfoExt1 = responseEx1;
        //Getting About Me block Data Starts
        vm.etnctyId = vm.profileInfo.ethinicityId;
        vm.etnctyIdTxt = vm.profileInfoExt1.ethinicityId;
        vm.rglnId = vm.profileInfo.religionId;
        vm.rglnIdTxt = vm.profileInfoExt1.religionId;
        vm.aOfWrkId = vm.profileInfo.awId;
        vm.aOfWrkIdTxt = vm.profileInfoExt1.awId;
        vm.stsId = vm.profileInfo.rsStatus;
        vm.stsIdTxt = vm.profileInfoExt1.rsStatus;
        vm.dgrId = vm.profileInfo.highestEdu;
        vm.dgrIdTxt = vm.profileInfoExt1.highestEdu;
        vm.htcityId = vm.profileInfo.htCity;
        vm.htstateId = vm.profileInfo.htState;
        vm.countryName = vm.profileInfo.cntryName;
        vm.htcntryId = vm.profileInfo.htCountry;
        vm.countryId = vm.profileInfo.countryId;
        if (vm.profileInfoExt1.htInfo) {
            if (vm.profileInfoExt1.htInfo.cityName) {
                vm.htCity = vm.profileInfoExt1.htInfo.cityName;
                vm.aboutlocation.push(vm.htCity);
            }
            if (vm.profileInfoExt1.htInfo.stateName) {
                vm.htState = vm.profileInfoExt1.htInfo.stateName;
                vm.aboutlocation.push(vm.htState);
            }
            if (vm.profileInfoExt1.htInfo.countryName) {
                vm.htCountryName = vm.profileInfoExt1.htInfo.countryName;
                if (vm.htCountryName != vm.countryName)
                    vm.aboutlocation.push(vm.htCountryName);
            }
        }
        vm.aboutlocationTxt = vm.aboutlocation.join(', ');
        vm.aboutlocation = vm.aboutlocationTxt.toString();
        //Getting About Me block Data End
    };

    var GetPrfInfoExt2CallBack = function (responseEx2, status) {
        vm.profileInfoExt2 = responseEx2;
        var snEx2 = vm.profileInfoExt2;
        vm.chldCntLst = $filter('childCountFltr')(snEx2.childrenCnt);
        vm.chldPref = $filter('childPrefFltr')(snEx2.childrenPref);
        vm.ptsCntLst = $filter('petCountFltr')(snEx2.petsCnt);
        vm.ptsPref = $filter('petsPrefFltr')(snEx2.petsPref);
        //Getting My appearance block Data Starts
        vm.eyeId = vm.profileInfo.eyeColor; vm.eyeIdTxt = vm.profileInfoExt2.eyeColor;
        vm.hairId = vm.profileInfo.hairColor; vm.hairIdTxt = vm.profileInfoExt2.hairColor;
        vm.bldId = vm.profileInfo.build; vm.bldIdTxt = vm.profileInfoExt2.build;
        vm.htId = vm.profileInfo.height; vm.htIdTxt = vm.profileInfoExt2.height;
        //Getting My lifestyle block Data Starts
        vm.ditId = vm.profileInfo.diet; vm.ditIdTxt = vm.profileInfoExt2.diet;
        vm.smkId = vm.profileInfo.smoke; vm.smkIdTxt = vm.profileInfoExt2.smoke;
        vm.drnkId = vm.profileInfo.drink; vm.drnkIdTxt = vm.profileInfoExt2.drink;
        vm.irltnshp = vm.profileInfo.idealRelationship; vm.irltnshpTxt = vm.profileInfoExt2.idealRelationship;
        vm.chldrnCntId = vm.profileInfo.childrenCnt; vm.chldrnCntIdTxt = vm.profileInfoExt2.childrenCnt;
        vm.chldrnPrefId = vm.profileInfo.childrenPref; vm.chldrnPrefIdTxt = vm.profileInfoExt2.childrenPref;
        vm.ptsCntId = vm.profileInfo.petsCnt; vm.ptsCntIdTxt = vm.profileInfoExt2.petsCnt;
        vm.ptsPrefId = vm.profileInfo.petsPref; vm.ptsPrefIdTxt = vm.profileInfoExt2.petsPref;
        vm.rlgsId = vm.profileInfo.religious; vm.rlgsIdTxt = vm.profileInfoExt2.religious;
        vm.trdtnlId = vm.profileInfo.traditional; vm.trdtnlIdTxt = vm.profileInfoExt2.traditional;
        vm.getAllimages();
    };

    selfprofileSrvc.profileInfo(vm.mId(), vm.getPrfInfoCallBack);

    //Matchpreference data binding in selfprofile
    vm.matchPrefDataBind = function () {
        selfmatchprefSrvc.getmmp(function (response, status) {
            if (status == 200) {
                vm.mp = response;
                vm.mpDistanceFuncG();
            }
        });
    };

    vm.mpDistanceFuncG = function () {
        selfmatchprefSrvc.prefRadius(function (response, status) {
            if (status == 200) {
                for (var i = 0; i < response.length; i++) {
                    if (response[i].rdId == vm.mp.locRadius) {
                        vm.locRadiusTxt = "Within " + (response[i].radius == 1000 ? (response[i].radius + "+") : response[i].radius) + " miles";
                        break;
                    }
                }
                vm.bindMtchPrefDtls();
            }
        });
    };

    vm.bindMtchPrefDtls = function () {
        if (!vm.mp.minAge && !vm.mp.maxAge && !vm.mp.locRadius && !vm.mp.locType && !vm.mp.ethinicities && !vm.mp.familyLang && !vm.mp.countryId && !vm.mp.cityId && !vm.mp.awId && !vm.mp.highestEdu && !vm.mp.htCountry && !vm.mp.htState && !vm.mp.htCity && !vm.mp.minHeight && !vm.mp.maxHeight && !vm.mp.smoke && !vm.mp.drink && !vm.mp.idealRelationship && !vm.mp.childrenCnt && !vm.mp.childrenPref && !vm.mp.petsCnt && !vm.mp.petsPref && !vm.mp.religious && !vm.mp.traditional && !vm.mp.rsStatus && !vm.mp.eyeColor && !vm.mp.hairColor && !vm.mp.build && !vm.mp.diet && !vm.mp.religions && !vm.mp.hobbies&& !vm.mp.pt) {
            vm.emptystateQns = "What is your ideal match like?";
            vm.mpAgeTxt = '';
            vm.mpRadiusTxt = '';
        }
        else {
            vm.emptystateQns = '';
            var gender = vm.genPref() == true ? "he" : "she";
            if (vm.mp.minAge != null && vm.mp.maxAge != null)
                vm.mpAgeTxt = "Ages " + vm.mp.minAge + "-" + vm.mp.maxAge;
            else
                vm.mpAgeTxt = "How old is " + gender + "?";

            if (vm.mp.locRadius != null)
                vm.mpRadiusTxt = vm.locRadiusTxt;
            else
                vm.mpRadiusTxt = "Where is " + gender + "?";
        }
    };
  
    //page unevenly loading resolve function
    vm.pgVisble = function () {
        $timeout(function () {
            if ($rootScope.srcType != 3)
                $rootScope.dvpgVisble = true;
            else
                $rootScope.dvpgVisble = false;
            hideLoader();
        }, 0, true);
    };
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  GALLERY , PROFILE , COVER PHOTO MODULE   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.thumbnailSlider = [];
    vm.profileSlider = [];

    //bind gallery image on page load
    vm.getAllimages = function () {
        vm.bindAllImages(function () {
            vm.thumbnailSlider.unshift({ mpId: vm.profileResponse[0].mpId, picPath: vm.profileResponse[0].picPath + "?v=" + new Date().valueOf(), picOrder: 0, picCreateDT: vm.profileResponse[0].picCreateDT, picType: 2 });
            vm.profileSlider.unshift({ mpId: vm.profileResponse[0].mpId, picPath: vm.profileResponse[0].picPath.replace("/p/tnb/", "/p/") + "?v=" + new Date().valueOf(), picOrder: 0, picCreateDT: vm.profileResponse[0].picCreateDT, picType: 2 });
            vm.prflDataBinding();
            vm.prfPercentage = getProfilepercent(vm.profileObj);
            //showing profile complete trophie reached to 100%
            if ($window.localStorage.getItem("viewprofile")) {               
                if (getSessionSrvc.p_pprntg() == 100) { $("#trophyPopProfileE").modal("hide"); }
                else if(vm.prfPercentage == 100) {                   
                    $("#trophyPopProfileE").modal('show');
                    vm.trpyPopProfile = true;
                    vm.trpyPopProfileE = false;
                    $window.localStorage.removeItem("viewprofile");
                }
            }
            //Updating profile % in member login cookie
            getSessionSrvc.u_ssnd("profileCmplnPrcnt", vm.prfPercentage);            
        });
    };

    //default slide image after loading  all the images
    vm.onPtImgLoadFinish = function () {
        var ptswiper = new Swiper('.trts', {
            slidesPerView: 3,
        });
    };

    vm.onTrophyImgLoadFinish = function () {
        var Trphswiper = new Swiper('.swiperTrph', {
            slidesPerView: 3
        });
    };

    $scope.$on("pfSliderSwiper", function () {
        vm.bindProfileSwiper(1);
    });

    vm.bindProfileSwiper = function (index) {
        vm.pfswiper = new Swiper('.pfslde', {
            slidesPerView: 1,
            paginationClickable: true,
            centeredSlides: true,
            loop: vm.profileSlider.length > 1 ? true : false,                    
            observer: true,
            observeParents: true,
            onSlideNextStart: function (swiper) {
                vm.realIndex = swiper.realIndex;
                if (vm.profileSlider.length == 1) {
                    swiper.destroyLoop();               
                }
                if (vm.PPindex >= vm.profileSlider.length)
                    vm.PPindex = 1;
                else
                    vm.PPindex += 1;
                $scope.$digest();
            },
            onSlidePrevStart: function (swiper) {
                vm.realIndex = swiper.realIndex;
                if (vm.profileSlider.length == 1) {
                    swiper.destroyLoop();            
                }
                if (vm.PPindex == 1)
                    vm.PPindex = vm.profileSlider.length;
                else
                    vm.PPindex -= 1;
                $scope.$digest();
            },
            onClick: function (swiper) {
                vm.realIndex = swiper.realIndex;
                vm.showSlider = true;
                $scope.$digest();
                vm.galleryswiper.update(true);
                vm.gpIndex = vm.PPindex;
                $timeout(function () { vm.galleryswiper.slideTo(vm.gpIndex, 0, false); }, 10);
                if (vm.gpIndex == 1) {
                    if (vm.profileInfo.isProfilePicUpld == true) {
                        vm.pfSlidetxt = "Edit";
                        $("#pimg1").css("display", "");
                    }
                    else {
                        vm.pfSlidetxt = "";
                        $("#pimg1").css("display", "none");
                    }
                }
                else
                    vm.pfSlidetxt = "Make Profile Photo";
            },
        });
        vm.PPindex = index;
        vm.pfswiper.update(true);
    };

    $scope.$on("pfGallerySwiper", function () {
        vm.bindGallarySwiper(1);
    });

    vm.bindGallarySwiper = function (index) {
        vm.galleryswiper = new Swiper('.gimg', {
            slidesPerView: 1,
            paginationClickable: true,
            centeredSlides: true,
            loop: vm.profileSlider.length > 1 ? true : false,
            runCallbacksOnInit: true,
            observer: true,
            observeParents: true,
            onSlideNextStart: function (swiper) {
                vm.realIndex = swiper.realIndex;
                if (vm.profileSlider.length == 1)                 
                    swiper.destroyLoop();                                 
                if (vm.gpIndex >= vm.profileSlider.length) {
                    vm.gpIndex = 1;
                    if (vm.profileInfo.isProfilePicUpld == true) {
                        vm.pfSlidetxt = "Edit";
                        $("#pimg1").css("display", "");
                    }
                    else {
                        vm.pfSlidetxt = "";
                        $("#pimg1").css("display", "none");
                    }
                    $scope.$digest();
                }
                else {
                    vm.gpIndex += 1;
                    vm.pfSlidetxt = "Make Profile Photo";
                }
                $scope.$digest();
            },
            onSlidePrevStart: function (swiper) {
                vm.realIndex = swiper.realIndex;
                if (vm.profileSlider.length == 1) 
                    swiper.destroyLoop();                  
                if (vm.gpIndex == 1) {
                    vm.gpIndex = vm.profileSlider.length;
                    vm.pfSlidetxt = "Make Profile Photo";
                }
                else {
                    vm.gpIndex -= 1;
                    vm.pfSlidetxt = "Make Profile Photo";
                    if (vm.gpIndex == 1) {
                        if (vm.profileInfo.isProfilePicUpld == true) {
                            vm.pfSlidetxt = "Edit";
                            $("#pimg1").css("display", "");
                        }
                        else {
                            vm.pfSlidetxt = "";
                            $("#pimg1").css("display", "none");
                        }
                    }
                }
                $scope.$digest();
            },
        });
        vm.gpIndex = index;
    };

    vm.hideSlider = function () {
        vm.showSlider = false;
    };

    //deltete gallery image popup click 
    vm.btnShowDltPopUp = function (mpId, picType, index) {
        vm.mpId = mpId;
        vm.picType = picType;
        $("#srcdeletePopup").modal("show");
    };

    //delete photo from gallery
    vm.btnDltGlryPhoto = function () {
        $("#srcdeletePopup").modal("hide");
        if (vm.picType == 2) {
            selfprofileSrvc.ProfilePhotoD(vm.mId(), vm.profileResponse[0].mpId, function (response, status) {
                if (status == 200 && response) {
                    trophiesResult[2] = 0;
                    vm.tropPP = 'https://pccdn.pyar.com/pcimgs/m/trpy-photo-e.png';//change the profile trophie image
                    vm.profileInfo.isProfilePicUpld = false;
                    for (var i = 0; i < vm.thumbnailSlider.length; i++) {
                        if (vm.thumbnailSlider[i].mpId == vm.profileResponse[0].mpId) {
                            vm.thumbnailSlider[i].picPath = vm.thumbnailSlider[i].picPath + "?v=" + new Date().valueOf();
                            $scope.$emit("refreshHdrPP", vm.thumbnailSlider[i].picPath);
                        }
                    }

                    for (var i = 0; i < vm.profileSlider.length; i++) {
                        if (vm.profileSlider[i].mpId == vm.profileResponse[0].mpId) {
                            vm.profileSlider[i].picPath = vm.profileSlider[i].picPath + "?v=" + new Date().valueOf();
                            vm.profileSlider[i].picCreateDT = "";
                            vm.pfSlidetxt = "";
                            $("#pimg1").css("display", "none");
                        }
                    }
                    if (vm.PPindex >= vm.profileSlider.length)
                        vm.PPindex = 1;
                    else
                        vm.PPindex += 1;
                    vm.galleryswiper.updateSlidesSize(true);
                    vm.pfswiper.updateSlidesSize(true);
                    var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
                    sfData.prflData.isProfilePicUpld = false;
                    $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                } else
                    alert("unable to  delete profile photo");
            });
        }
        else if (vm.picType == 1) {
            selfprofileSrvc.GalleryPhotoD(vm.mId(), vm.mpId, function (response, status) {
                if (status == 200 && response) {
                    vm.galleryswiper.removeSlide(vm.realIndex);
                    vm.pfswiper.removeSlide(vm.realIndex);
                    
                    for (var i = 0; i < vm.thumbnailSlider.length; i++) {
                        if (vm.thumbnailSlider[i].mpId == vm.mpId) {
                            vm.thumbnailSlider.splice(i, 1);
                            vm.pfswiper.updateSlidesSize(true);
                            break;
                        }
                    }
                    for (var i = 0; i < vm.profileSlider.length; i++) {
                        if (vm.profileSlider[i].mpId == vm.mpId) {
                            vm.profileSlider.splice(i, 1);
                            vm.galleryswiper.updateSlidesSize(true);
                            break;
                        }
                    }
                    for(var i=0;i<vm.galleryImgs.length;i++)
                    {
                        if (vm.galleryImgs[i].mpId == vm.mpId) {
                            vm.galleryImgs.splice(i, 1);                          
                            break;
                        }
                    }
                    if (vm.PPindex >= vm.profileSlider.length)
                        vm.PPindex = 1;
                    else
                        vm.PPindex += 1;
                    var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
                    sfData.gallery = vm.galleryImgs;
                    $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                }
                else
                    alert("unable to delete photo");
            });
        }
        
    };

    //bind gallery images 
    vm.bindAllImages = function (callBackFunc) {
        selfprofileSrvc.getAllImages(vm.mId(), function (response, status) {
            if (status == 200) {
                if (response.length > 0) {
                    vm.galleryImgs = response;
                    if (vm.profileInfo.isProfilePicUpld == true) {
                        angular.forEach(response, function (data) {
                            if (data.picType == 2)
                                vm.profileResponse[0] = { mpId: data.mpId, picPath: vm.imageCDN + data.picPath, picCreateDT: data.picCreateDT };
                        });
                    }
                    else
                        vm.profileResponse[0] = { mpId: 0, picPath: vm.imageCDN + vm.profileInfo.profilePic, picCreateDT: "" };

                    for (var i = 1; i < 9; i++) {
                        for (var j = 0; j < response.length; j++) {
                            if (response[j].picType == 1) {
                                if (i == response[j].picOrder) {
                                    vm.thumbnailSlider.push({
                                        mpId: response[j].mpId, picPath: vm.imageCDN + response[j].picPath.replace("/gl/tn/", "/gl/tnb/"), picOrder: response[j].picOrder, picCreateDT: response[j].picCreateDT, picType: response[j].picType
                                    });

                                    vm.profileSlider.push({
                                        mpId: response[j].mpId, picPath: vm.imageCDN + response[j].picPath.replace("/gl/tn/", "/gl/"), picOrder: response[j].picOrder, picCreateDT: response[j].picCreateDT, picType: response[j].picType
                                    });
                                    break;
                                }
                            }
                        }
                    }
                }
                else
                    vm.profileResponse[0] = { mpId: 0, picPath: vm.imageCDN + vm.profileInfo.profilePic, picCreateDT: "" };
                callBackFunc();
            }
        });
    };

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  GALLERY , PROFILE , COVER PHOTO MODULE  END HERE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY TROPHIES BLOCK STARTS   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    //My Trophies starts (Tatish)
    vm.trophyPopEml = false;
    vm.trophyPopsocE = false;
    vm.trophyPopPPE = false;
    vm.trophyPopPPEmpty = false;
    vm.trophyPopPP = false;
    vm.trophyPopMobE = false;
    vm.trophyPopMobCode = false;
    vm.trophyPopMob = false;
    vm.MoberrMsg = false;
    vm.vrfyOtp = true;
    var trophiesResult = [];
    //Firtst Time trophies Popups Loading starts
    var ShowTrophyFTPOP = function () {
        vm.ftPopupCount = 0;
        if (cmnSrvc.ftPOPCheck(1)) {
            if (cmnSrvc.ftPOPCheckTrophy(vm.profileInfo.trophies, 1)) {
                vm.ftPopupCount++;
                vm.dvEmailComp = true;
            }
            if (cmnSrvc.ftPOPCheckTrophy(vm.profileInfo.trophies, 2)) {
                vm.ftPopupCount++;
                vm.dvSocialComp = true;
            }
            if (cmnSrvc.ftPOPCheckTrophy(vm.profileInfo.trophies, 3)) {
                vm.ftPopupCount++;
                vm.dvprofilePicComp = true;
            }
            if (cmnSrvc.ftPOPCheckTrophy(vm.profileInfo.trophies, 4)) {
                vm.ftPopupCount++;
                vm.dvMobileComp = true;
            }
            $("#ftTrophyPop").modal('show');
            cmnSrvc.ftPOPUpdate(1);
        }
    };
    //Firtst Time trophies Popups Loading End Here
    function trophiesLoad(trophiesResult) {
        if (trophiesResult[0] == 1)
            vm.tropEml = 'https://pccdn.pyar.com/pcimgs/m/trpy-eml.png';
        else
            vm.tropEml = 'https://pccdn.pyar.com/pcimgs/m/trpy-eml.png';
        if (trophiesResult[1] == 1)
            vm.tropSoc = 'https://pccdn.pyar.com/pcimgs/m/trpy-soc.png';
        else
            vm.tropSoc = 'https://pccdn.pyar.com/pcimgs/m/trpy-soc-e.png';
        if (trophiesResult[2] == 1)
            vm.tropPP = 'https://pccdn.pyar.com/pcimgs/m/trpy-photo.png';
        else
            vm.tropPP = 'https://pccdn.pyar.com/pcimgs/m/trpy-photo-e.png';
        if (trophiesResult[3] == 1)
            vm.tropMob = 'https://pccdn.pyar.com/pcimgs/m/trpy-mbl.png';
        else
            vm.tropMob = 'https://pccdn.pyar.com/pcimgs/m/trpy-mbl-e.png';
        if (trophiesResult[4] == 1)
            vm.ProfComplete = 'https://pccdn.pyar.com/pcimgs/m/trpy-prfl.png';
        else
            vm.ProfComplete = 'https://pccdn.pyar.com/pcimgs/m/trpy-prfl-e.png';
    };

    vm.socVerifyPopup = function () {
        if (trophiesResult[1] == 0)
            vm.trophyPopsocE = true;
        else
            vm.trophyPopsocE = false;
    };

    vm.trophyPopSoc = function () {
        trophiesResult[1] = 1;
        trophiesLoad(trophiesResult);
        $("#trophyPopsocE").modal('hide');
    };

    vm.picVerifyPopup = function () {
        if (trophiesResult[2] == 0) {
            vm.trophyPopPPE = true;
            vm.trophyPopPPEmpty = true;
        }
        else
            vm.trophyPopPPE = false;
    };

    vm.picVerifyPopupC = function () {
        trophiesResult[2] = 1;
        trophiesLoad(trophiesResult);
        $("#trophyPopPPE").modal('hide');
    };

    vm.PComVerifyPopup = function () {
        if (trophiesResult[4] == 0) {
            $("#trophyPopProfileE").modal('show');
            vm.trpyPopProfileE = true;
            vm.trpyPopProfile = false;
        }
    };

    vm.countryCode = "+";
    vm.cntryCode = "";
    vm.mblNum = "";
    vm.otpId = "";
    vm.errorOtpMsg = "";

    vm.resetMblTrpyFields = function () {
        vm.countryCode = "";
        vm.cntryCode = "";
        vm.mblNum = "";
    };

    vm.resetOTPFields = function () {
        vm.OtpDigit1 = vm.OtpDigit2 = vm.OtpDigit3 = vm.OtpDigit4 = vm.OtpDigit5 = vm.OtpDigit6 = "";
        vm.errorOtpMsg = "";
    };

    vm.countryCodeChg = function () {
        if (vm.countryCode) {
            vm.cntryCode = getOnlyNumber(vm.countryCode);
            vm.countryCode = "+" + vm.cntryCode;
        }
    };

    vm.mobVerifyPopup = function () {
        vm.errMsg = "";
        if (trophiesResult[3] == 0) {
            vm.mblNum = '';
            vm.trophyPopMobE = vm.trophyPopMobEnter = true;
            vm.trophyPopMobCode = vm.trophyPopMob = false;
            showLoader();
            selfprofileSrvc.getCountryCode(vm.profileInfo.countryId, function (response, status) {
                if (status == 200 && response) {
                    vm.mblCntryCode = response;
                    vm.countryCode = "+" + response;
                    vm.countryCodeChg();
                }
                hideLoader();
            });
        }
        else
            vm.trophyPopMobE = false;
    };

    vm.trophyPopMobSendCode = function () {
        if (vm.cntryCode && vm.mblNum && vm.mblNum.length > 6) {
            vm.resetOTPFields();
            vm.resendEmailVal = true;//for resend otp
            showLoader();
            selfprofileSrvc.sendOtp(vm.mId(),vm.cntryCode, vm.mblNum, function (response, status) {
                if (status == 200) {
                    if (response == 0)
                        vm.errMsg = "Number in use"
                    else if (response) {
                        vm.otpId = response;
                        vm.trophyPopMobEnter = false;
                        vm.trophyPopMobCode = true;
                    }
                }
                else {
                    vm.MoberrMsg = true;
                    vm.mblNum = "";
                }
                hideLoader();
            });
        }
    };

    vm.resendOtp = function () {
        if (vm.cntryCode && vm.mblNum && vm.mblNum.length > 6) {
            vm.resetOTPFields();
            showLoader();
            selfprofileSrvc.resendOtp(vm.mId(), vm.cntryCode, vm.mblNum, function (response, status) {
                if (status == 200) {
                    startInterval(vm, $interval);
                    vm.otpId = response;
                }
                hideLoader();
            });
        }
    };

    vm.keyPress = function (txtIndexId, event) {
        if (event.keyCode == 13)
            vm.keyUp(txtIndexId, event);
    };

    vm.keyUp = function (txtIndexId, event) {
        if (vm.vrfyOtp == true) //avoid multiple api calls
        {
            vm.errorOtpMsg = "";
            var keyCode = event.keyCode;
            if ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105) || keyCode == 13) {             
                vm.otpVerify();
                //focus next elements
                txtIndexId++;
                $('input[tabindex=' + (txtIndexId) + ']').focus();
            }
        }
    };
    vm.otpVerify = function () {
        if (vm.otpId && vm.mId() && vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4 && vm.OtpDigit5 && vm.OtpDigit6) {
            showLoader();
            vm.vrfyOtp = false;
            var otpCode = vm.OtpDigit1 + vm.OtpDigit2 + vm.OtpDigit3 + vm.OtpDigit4 + vm.OtpDigit5 + vm.OtpDigit6;
            selfprofileSrvc.verifyOtp(vm.mId(), vm.otpId, otpCode, function (response, status) {
                vm.vrfyOtp = true;
                if (response) {
                    vm.trophyPopMobCode = false;
                    vm.trophyPopMob = true;
                    trophiesResult[3] = 1;
                    trophiesLoad(trophiesResult);
                    updateMblVrfySession(response, getSessionSrvc, $rootScope);
                }
                else {
                    vm.resetOTPFields();
                    vm.errorOtpMsg = "That’s incorrect. Please try again.";
                }
                hideLoader();
            });
        }
    };

    vm.showBnr = function () {
        $rootScope.$broadcast("showBnrMsg", 1);
    };
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY TROPHIES BLOCK END   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY LIFESTYLE BLOCK STARTS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    vm.langPref = [];
    vm.familyLang = [];
    vm.myLifeStyleDdls = function () {
        //my life style ddls service called
        selfprofileSrvc.ddlsMyLifeStyleDDlData(function (response, status) {
            vm.dietDdl = response.diet;
            vm.smokeDdl = response.smoke;
            vm.drinkDdl = response.drink;
            vm.idealRelationshipDdl = response.IdealRelationShip;
            vm.childrenCntDdl = response.numOfChildren;
            vm.childrenPrefDdl = response.childrenPref;
            vm.petsCntDdl = response.numOfPets;
            vm.petsPrefDdl = response.petPref;
            vm.langPrefDdl = response.language;
            vm.langPrefDdl.forEach(function (data) {
                if (vm.lang.indexOf(data.val) != -1)
                    vm.langPref.push(data.txt);
                vm.langPrefTxt = vm.langPref.join(', ');
            });
            vm.familyLangDdl = response.language;
            vm.familyLangDdl.forEach(function (data) {
                if (vm.familyLangs.indexOf(data.val) != -1)
                    vm.familyLang.push(data.txt);
                vm.familyLangTxt = vm.langPref.join(', ');
            });
            vm.religiousDdl = response.Religious;
            vm.traditionalDdl = response.traditional;
        });
    };
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  MY LIFESTYLE BLOCK ENDS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/

    vm.editProfile = function () {
        $state.go('editprofile');
        $rootScope.edtScrollTo = 0;
    };

    vm.prflDataBinding = function () {
        //passing profile data to editpage in localstorage
        vm.profileObj = {
            prflData: {
                "prfPic": vm.imageCDN + vm.profileInfo.profilePic,
                "firstName": vm.profileInfo.firstName,
                "genderval": vm.profileInfo.gender,
                "genderprefval": vm.profileInfo.genderPref,
                "Gender": vm.profileInfo.gender,
                "dob": vm.profileInfo.dob,
                "gndrTxt": vm.gndrTxt,
                "stateId": vm.profileInfo.stateId,
                "countryId": vm.profileInfo.countryId,
                "htCity": vm.htCity,
                "cityId": vm.profileInfo.cityId,
                "cntryName": vm.profileInfo.cntryName,
                "stateName": vm.profileInfo.stateName,
                "cityName": vm.profileInfo.cityName,
                "isProfilePicUpld": vm.profileInfo.isProfilePicUpld,
            },
            abtme: {
                "etnctyId": vm.etnctyId,
                "rglnId": vm.rglnId,
                "aOfWrkId": vm.aOfWrkId,
                "stsId": vm.stsId,
                "dgrId": vm.dgrId,
                "htcntryId": vm.htcntryId,
                "htstateId": vm.htstateId,
                "htcityId": vm.htcityId,
            },
            prsnlty: vm.ptArray,
            Bio: { "mybio": vm.myBioData },
            apprnce: {
                "eyeId": vm.eyeId,
                "hairId": vm.hairId,
                "htId": vm.htId,
                "bldId": vm.bldId,
            },
            lfstyl: {
                "ditId": vm.ditId,
                "smkId": vm.smkId,
                "drnkId": vm.drnkId,
                "irltnshpId": vm.irltnshp,
                "chldrnCntId": vm.chldrnCntId,
                "chldrnPrefId": vm.chldrnPrefId,
                "ptsCntId": vm.ptsCntId,
                "ptsPrefId": vm.ptsPrefId,
                "lstylelngPrefIds": vm.lang,
                "lstylefmlyLangIds": vm.familyLangs,
                "rlgsId": vm.rlgsId,
                "trdtnlId": vm.trdtnlId,
            },
            hbbys: vm.hbArray,
            gallery: vm.galleryImgs
        };
        $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(vm.profileObj)));
    };
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PROFILE UPLOADING  STARTS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    //Functionality started by prasanna
    var croppie;
    vm.maxWidth = 1920;
    vm.maxHeight = 1920;
    vm.minWidth = 400;
    vm.minHeight = 400;
    vm.photoPath = '';
    vm.upldPhotoType = 2;//2:profile pic upload,4:gallery pic swaping 
    vm.actionType = 1;
    vm.crpDone = false;
    var width = (window.innerWidth > 0) ? window.innerWidth : screen.width  //get screen width to set cropper width && height dynamically  
    $('.crprTxt').css('top', width + 90);// Dynamic position for cropper text(Reposition Photo)
    vm.showPhotoActions = function () {
        vm.trophyPopPPEmpty = false;
        $("#trophyPopPPE").modal('hide');//hiding trophy profile pic popup
        $("#glryActions").modal('show');
        vm.upldPhotoType = 2;
        vm.actionType = 1;//adding new profile image
    };

    $("#fupPhtGlry").click(function () {
        $("#fupPhtGlry").val(null);
    });
    $scope.imageUpload = function (event) {
        showLoader();        
        var files = event.target.files;
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var reader = new FileReader();
            var upldSuccess = false;
            $rootScope.srcType = 1;
            reader.onload = function (e) {
                $("<img/>").load(function () {
                    vm.imgRealWidth = this.width;
                    vm.imgRealHeight = this.height;
                    if (vm.imgRealWidth < vm.minWidth || vm.imgRealHeight < vm.minHeight) {
                        $("#photoSmallpop").modal('show');//need show error popup
                        hideLoader();
                    }
                    else {
                        $('#cropImg').croppie('destroy');
                        vm.photoPath = e.target.result;                        
                        //if browser type is an ios device the below code get executed
                        if (getBrowserType() == true) {
                            var options = {
                                canvas: true
                            };
                            vm.imgDataExifProp = false;
                            loadImage.parseMetaData(file, function (data) {
                                if (data.exif) {
                                    vm.imgDataExifProp = true;
                                    options.orientation = data.exif.get('Orientation');
                                    loadImage(file, getOrientImageResponse, options);
                                } else {
                                    CropPBPhoto(e.target.result, width - 35, width - 35, $timeout);
                                }
                            });
                        } else {
                            CropPBPhoto(e.target.result, width - 35, width - 35, $timeout);
                        }                       
                    }
                    //reset the file upload control for uploading same file on onchange event 
                    $("#fupPhtGlry").val(null);
                }).attr("src", e.target.result);
            }
            reader.readAsDataURL(file);
        }
    };

    var getOrientImageResponse = function (img) {
        if (vm.imgDataExifProp == true) {
            vm.photoPath = img.toDataURL();
            CropPBPhoto(img.toDataURL(), width - 35, width - 35, $timeout);
        }
    };
    /************************************************************** ADD PHOTO FROM SOCIAL**************************************************************/
    vm.addPhoto = function () {
        //gallery photo module
        $rootScope.dvAlbumPhotos = false;
        $rootScope.dvpgVisble = true;
        //profile photo module
        if ($rootScope.imgPath != "" && $rootScope.realWidth >= vm.minWidth && $rootScope.realHeight >= vm.minHeight) {
            vm.photoPath = $rootScope.imgPath;
            vm.imgwidth = $rootScope.realWidth;
            vm.imgHeight = $rootScope.realHeight;
            $('#cropImg').croppie('destroy');
            CropPBPhoto($rootScope.imgPath, width - 35, width - 35, $timeout);            
        }
    };

    //save image after cropping
    vm.saveCroppedImg = function () {
        showLoader();
        vm.crpDone = true;
        $rootScope.dvAlbumPhotos = false;
        $rootScope.dvpgVisble = true;
        $("#pcFtr").show();
        $("#dvtoggle").show();
        if (vm.upldPhotoType == 2) {
            //from device uploading
            if (vm.actionType == 1 && $rootScope.srcType == 1) {
                UploadProfileImage(vm.photoPath);
            } else {
                //from instagram && facebook uploading
                convertFileToDataURLviaFileReader(vm.photoPath, function (originalImgResponse) {
                    UploadProfileImage(originalImgResponse);
                });
            }
        }
        else if (vm.upldPhotoType == 4) {
            $("<img/>").load(function () {
                var glImgWidth = this.width;
                var glImgHeight = this.height;
                var data = new FormData();
                convertFileToDataURLviaFileReader(vm.photoPath, function (originalImgResponse) {                  
                    CroppedImageResult(430, 430, function (img430Response) {
                        CroppedImageResult(200, 200, function (img200Response) {
                            CroppedImageResult(100, 100, function (img100Response) {
                                resizingImage(originalImgResponse, function (resizeResponse) {
                                    base64ToBlobFileConvertion(resizeResponse, function (originalImgBlob) {
                                        base64ToBlobFileConvertion(img430Response, function (img430Blog) {
                                            base64ToBlobFileConvertion(img200Response, function (img200Blog) {
                                                base64ToBlobFileConvertion(img100Response, function (img100Blog) {
                                                    createBlurImage((img430Response), function (blurResponseBlob) {
                                                        data.append("originalImgBlob", originalImgBlob);
                                                        data.append("img430Blog", img430Blog);
                                                        data.append("img200Blog", img200Blog);
                                                        data.append("img100Blog", img100Blog);
                                                        data.append("blurResponseBlob", blurResponseBlob);
                                                        selfprofileSrvc.swapImages(vm.mId(), vm.mpuId, data, function (response, status) {
                                                            vm.crpDone = false;
                                                            if (status == 200) {
                                                                trophiesResult[2] = 1;
                                                                vm.profileInfo.isProfilePicUpld = true;
                                                                vm.tropPP = 'https://pccdn.pyar.com/pcimgs/m/trpy-photo.png';//change the profile trophie image
                                                                vm.thumbnailSlider[0].picPath = vm.thumbnailSlider[0].picPath + "?v=" + new Date().valueOf();
                                                                vm.profileSlider[0].picPath = vm.profileSlider[0].picPath + "?v=" + new Date().valueOf();
                                                                for (var i = 0; i < vm.thumbnailSlider.length; i++) {
                                                                    if (vm.thumbnailSlider[i].picOrder == vm.picOrder) {
                                                                        vm.thumbnailSlider[i].picPath = vm.thumbnailSlider[i].picPath + "?v=" + new Date().valueOf();
                                                                        break;
                                                                    }
                                                                }

                                                                for (var i = 0; i < vm.profileSlider.length; i++) {
                                                                    if (vm.profileSlider[i].picOrder == vm.picOrder) {
                                                                        vm.profileSlider[i].picPath = vm.profileSlider[i].picPath + "?v=" + new Date().valueOf();
                                                                        break;
                                                                    }
                                                                    var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
                                                                    sfData.prflData.isProfilePicUpld = true;
                                                                    $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                                                                    vm.pfswiper.updateSlidesSize(true);
                                                                    vm.galleryswiper.updateSlidesSize(true);
                                                                    $scope.$emit("refreshHdrPP", vm.thumbnailSlider[0].picPath);
                                                                    $("#srcAdjustProfilePhotoPopup").modal("hide");
                                                                }
                                                                var notifyType = 53;
                                                                if (msgSrvc.conId)
                                                                    msgSrvc.sendMemberNWNotifications("", vm.fn(), vm.pp(), vm.gender(), notifyType, new Date());
                                                                else
                                                                    $rootScope.ntfnData.push({ "sendType": 2, "tmId": "", "fn": vm.fn(), "pp": vm.pp(), "gender": vm.gender(), "type": notifyType, "date": new Date() });                                                               
                                                                hideLoader();
                                                            }
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            }).attr("src", vm.photoPath);
        }
        $rootScope.srcType = 1;
    };

    //upload profile picture
    function UploadProfileImage(originalImgResponse) {
        var data = new FormData();                   
        CroppedImageResult(430, 430, function (img430Response) {
            CroppedImageResult(200, 200, function (img200Response) {
                CroppedImageResult(100, 100, function (img100Response) {
                    resizingImage(originalImgResponse, function (resizeResponse) {
                        base64ToBlobFileConvertion(resizeResponse, function (originalImgBlob) {
                            base64ToBlobFileConvertion(img430Response, function (img430Blog) {
                                base64ToBlobFileConvertion(img200Response, function (img200Blog) {
                                    base64ToBlobFileConvertion(img100Response, function (img100Blog) {
                                        createBlurImage((img430Response), function (blurResponseBlob) {
                                            data.append("originalImgBlob", originalImgBlob);
                                            data.append("img430Blog", img430Blog);
                                            data.append("img200Blog", img200Blog);
                                            data.append("img100Blog", img100Blog);
                                            data.append("blurResponseBlob", blurResponseBlob);
                                            //need to set action type 1 for adding new photo 2 for update existing photo                                        
                                            selfprofileSrvc.uploadPrflImages(vm.mId(), vm.actionType, data, function (response, status) {
                                                vm.crpDone = false;
                                                if (status == 200) {
                                                    trophiesResult[2] = 1;
                                                    vm.profileInfo.isProfilePicUpld = true;
                                                    vm.tropPP = 'https://pccdn.pyar.com/pcimgs/m/trpy-photo.png';//change the profile trophie image
                                                    var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));
                                                    sfData.prflData.isProfilePicUpld = true;
                                                    sfData.prflData.prfPic = vm.imageCDN + response.picPath + "?v=" + new Date().valueOf();
                                                    $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                                                    var picPath = vm.imageCDN + response.picPath;
                                                    var thpicpath = picPath.replace("/p/tnb/", "/p/");
                                                    vm.profileResponse[0] = { mpId: response.mpId, picPath: picPath, picCreateDT: response.picCreateDT };
                                                    vm.thumbnailSlider[0].picPath = picPath + "?v=" + new Date().valueOf();
                                                    vm.thumbnailSlider[0].mpId = response.mpId;
                                                    vm.thumbnailSlider[0].picCreateDT = response.picCreateDT;
                                                    $scope.$emit("refreshHdrPP", picPath);
                                                    vm.profileSlider[0].picPath = thpicpath;
                                                    vm.profileSlider[0].mpId = response.mpId;;
                                                    vm.profileSlider[0].picCreateDT = response.picCreateDT;
                                                    $("#prflPic0").attr("src", picPath + "?v=" + new Date().valueOf());
                                                    $("#prflPicedit0").attr("src", thpicpath + "?v=" + new Date().valueOf());
                                                    vm.pfswiper.updateSlidesSize(true);
                                                    vm.galleryswiper.updateSlidesSize(true);
                                                    $("#srcAdjustProfilePhotoPopup").modal("hide");
                                                    history.pushState(null, null, location.pathname);//change visible url with out refreshing page.
                                                    hideLoader();
                                                    var notifyType = 53;
                                                    if (msgSrvc.conId)
                                                        msgSrvc.sendMemberNWNotifications("", vm.fn(), vm.pp(), vm.gender(), notifyType, new Date());
                                                    else
                                                        $rootScope.ntfnData.push({ "sendType": 2, "tmId": "", "fn": vm.fn(), "pp": vm.pp(), "gender": vm.gender(), "type": notifyType, "date": new Date() });
                                                }

                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    };

    //make gallery image to profile photo
    vm.makeprflPhoto = function (mpid, imgsrc, order) {
        if (vm.pfSlidetxt) {
            vm.photoPath = imgsrc;
            vm.mpuId = mpid;
            vm.picOrder = order;
            if (vm.pfSlidetxt == "Edit") {
                vm.actionType = 2;//updating existring image 
                vm.upldPhotoType = 2;

                $("<img/>").load(function () {
                    vm.imgwidth = this.width;
                    vm.imgHeight = this.height;
                }).attr("src", vm.photoPath);
                vm.CropMkPrflPic();
            }
            else {
                vm.actionType = 1;//adding new image 
                vm.upldPhotoType = 4;
                $("#makePrflPop").modal("show");
            }
        }
    };

    //Make profile pic conform popup Ok Action.
    vm.CropMkPrflPic = function () {
        $("#makePrflPop").modal("hide");
        //FOR SWAP IMAGE
        vm.showSlider = false;
        $('#cropImg').croppie('destroy');    
        CropPBPhoto(vm.photoPath, width - 35, width - 35, $timeout);
    };
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  PROFILE UPLOADING  ENDS   )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
}]);