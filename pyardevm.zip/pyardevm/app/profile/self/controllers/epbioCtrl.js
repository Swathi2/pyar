﻿angular.module("app").controller('epbioCtrl', ['selfprofileSrvc', 'getSessionSrvc', '$window', '$state', function (selfprofileSrvc, getSessionSrvc, $window, $state) {
    var vm = this;
    vm.bio = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo"))).Bio;
    if (!vm.bio) { $state.go('profile'); return; }
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.myBio = vm.bio.mybio;
    vm.limitNum = 2000;
    vm.myBioErrMsg = "";
    vm.myBioPlaceHolder = "How would you describe yourself?";

    //Bio cancel function
    vm.mybioCancel = function () {
        $state.go('editprofile');
    };

    //Restrict bio text function
    vm.bioLimit = function () {
        vm.descNbrCls = "biernm";
        if (vm.myBio && vm.myBio.length > vm.limitNum) {
            vm.myBioErrMsg = "Bio must be at or below 2000 characters";
            vm.descNbrCls = "bioernum";
            vm.myBio = "";
        }
        else {
            vm.myBioErrMsg = "";
            vm.descNbrCls = "biernm";
        }
    };

    //Service call for updating bio-text
    vm.mybioDone = function () {
        if (vm.myBio.length <= 2000) {
            showLoader();
            var sfData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("profileInfo")));           
            vm.prfPercentage = getProfilepercent(sfData);
            selfprofileSrvc.myBioU(vm.mId(), vm.myBio, vm.prfPercentage, function (response, status) {
                hideLoader();
                if (status == 200) {
                    sfData.Bio = { "mybio": response },
                    $window.localStorage.setItem("profileInfo", getSessionSrvc.pce(JSON.stringify(sfData)));
                    $state.go('editprofile');
                };
            });
        }
    };
}]);