﻿macomp = function (mp, op,cntyId, callback) {
    var vm = this;
    vm.pt = [];
    vm.ptdata = [];
    vm.hobbiesdata = [];
    vm.mAnalysis = [];
    //age
    if ((mp.minAge != null && mp.minAge != "") || (mp.maxAge != null && mp.maxAge != "")) {
        if (op.age != null && op.age != "") {
            vm.icon = "https://pccdn.pyar.com/pcimgs/bday.png";
            if (mp.minAge != null && mp.minAge != "" && mp.maxAge != null && mp.maxAge != "") {
                if (op.age >= mp.minAge && op.age <= mp.maxAge) {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                    var mpAge = "Ages " + mp.minAge + "-" + mp.maxAge;
                }
                else {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
                    var mpAge = "Ages " + mp.minAge + "-" + mp.maxAge;
                }
            }
            else if (mp.minAge == null || mp.minAge == "") {
                if (op.age >= 18 && op.age <= mp.maxAge) {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                    var mpAge = "Ages 18-" + mp.maxAge;
                }
                else {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
                    var mpAge = "Ages 18-" + mp.maxAge;
                }
            }
            else if (mp.maxAge == null || mp.maxAge == "") {
                if (op.age >= mp.minAge && op.age <= 130) {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                    var mpAge = "Ages " + mp.minAge + "-130";
                }
                else {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
                    var mpAge = "Ages " + mp.minAge + "-130";
                }
            }
            vm.mAnalysis.push({ "Id": "Age", "mpd": mpAge, "opd": "Age " + op.age, "icon": vm.icon, "check": vm.compimg });
        }
    }
    //location
    if (mp.profilelong != null && mp.profilelong != "" && mp.profilelat != null && mp.profilelat != "" && mp.mplong != null && mp.mplong != "" && mp.mplat != null && mp.mplat != "" && mp.locRadius != null) {
        if (op.countryId != "" && op.countryId != null) {
            if (op.cityId != null && op.cityId != "") {
                vm.icon = "https://pccdn.pyar.com/pcimgs/location.png";
                var dist = distance(mp.mplat, mp.mplong, mp.profilelat, mp.profilelong, "");

                for (var i = 0; i < op.locrad.length; i++) {
                    if (op.locrad[i].priority == mp.locRadius) {
                        vm.locdist = op.locrad[i].radius;
                        break;
                    }
                }

                if (op.stateId != null && op.stateId != "" && op.countryId != cntyId)
                    vm.locdisp = op.cityId + ", " + op.stateId + ", " + op.countryId;
                else
                    vm.locdisp = op.cityId + ", " + op.stateId;

                if (dist <= vm.locdist) {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                    vm.mAnalysis.push({ "Id": "cityId", "mpd": "Within " + vm.locdist + "miles/km of My Location", "opd": vm.locdisp, "icon": vm.icon, "check": vm.compimg });
                }
                else {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
                    vm.mAnalysis.push({ "Id": "cityId", "mpd": "Within " + vm.locdist + "miles/km of My Location", "opd": vm.locdisp, "icon": vm.icon, "check": vm.compimg });
                }
            }
        }
    }

    //ethnicity
    if (mp.ethinicities != null && op.ethinicityId != null && mp.ethinicities != "" && op.ethinicityId != "") {

        vm.icon = "https://pccdn.pyar.com/pcimgs/hme.png";
        vm.count = 0;
        for (i = 0; i < mp.ethinicities.length; i++) {
            if (op.ethinicityId == mp.ethinicities[i].txt) {
                vm.opethinicity = op.ethinicityId;
                vm.mpethinicity = op.ethinicityId;
                vm.count = 1;
                vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                break;
            }
        }
        if (vm.count == 0) {
            vm.ethnicities = mp.ethinicities;
            var EthnicitiesArr = []; getJSonActiveDataText(vm.ethnicities, EthnicitiesArr);
            if (typeof (vm.ethnicities) == "object") { vm.ethnicities = EthnicitiesArr.join(); }
            vm.mpethinicity = vm.ethnicities;
            vm.opethinicity = op.ethinicityId;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "ethinicityId", "mpd": vm.mpethinicity, "opd": vm.opethinicity, "icon": vm.icon, "check": vm.compimg });
    }

    //Religion
    if (mp.religions != null && op.religionId != null && mp.religions != "" && op.religionId != "") {

        vm.icon = "https://pccdn.pyar.com/pcimgs/myreligion.png";
        vm.count = 0;
        for (i = 0; i < mp.religions.length; i++) {
            if (op.religionId == mp.religions[i].txt) {
                vm.opreligion = op.religionId;
                vm.mpreligion = op.religionId;
                vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                vm.count = 1;
                break;
            }
        }
        if (vm.count == 0) {
            vm.religions = mp.religions;
            var ReligionsArr = []; getJSonActiveDataText(vm.religions, ReligionsArr);
            if (typeof (vm.religions) == "object") { vm.religions = ReligionsArr.join(); }
            vm.mpreligion = vm.religions;
            vm.opreligion = op.religionId;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "religionId", "mpd": vm.mpreligion, "opd": vm.opreligion, "icon": vm.icon, "check": vm.compimg });

    }
    //area of work
    if (mp.AreaOfWork != null && op.awId != null && mp.AreaOfWork != "" && op.awId != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/myjob.png";
        if (mp.AreaOfWork == op.awId) {
            vm.opaw = op.awId;
            vm.mpaw = op.awId;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        }
        else {
            vm.opaw = op.awId;
            vm.mpaw = mp.AreaOfWork;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "awId", "mpd": vm.mpaw, "opd": vm.opaw, "icon": vm.icon, "check": vm.compimg });
    }
    //Marital status
    if (mp.rsStatus != null && op.rsStatus != null && mp.rsStatus != "" && op.rsStatus != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/myrship.png";
        vm.count = 0;
        for (i = 0; i < mp.rsStatus.length; i++) {
            if (op.rsStatus == mp.rsStatus[i].txt) {
                vm.oprsStatus = op.rsStatus;
                vm.mprsStatus = op.rsStatus;
                vm.count = 1;
                vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                break;
            }
        }
        if (vm.count == 0) {
            vm.rsstatus = mp.rsStatus;
            var RSStatusArr = []; getJSonActiveDataText(vm.rsstatus, RSStatusArr);
            if (typeof (vm.rsstatus) == "object") { vm.rsstatus = RSStatusArr.join(); }
            vm.mprsStatus = vm.rsstatus;
            vm.oprsStatus = op.rsStatus;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "rsStatus", "mpd": vm.mprsStatus, "opd": vm.oprsStatus, "icon": vm.icon, "check": vm.compimg });
    }
    //Education
    if (mp.HighestEduc != null && op.highestEdu != null && mp.HighestEduc != "" && op.highestEdu != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/myedu.png";
        if (mp.HighestEduc == op.highestEdu) {
            vm.opEdu = op.highestEdu;
            vm.mpEdu = op.highestEdu;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        }
        else {
            vm.opEdu = op.highestEdu;
            vm.mpEdu = mp.HighestEduc;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "highestEdu", "mpd": vm.mpEdu, "opd": vm.opEdu, "icon": vm.icon, "check": vm.compimg });
    }

    //HomeTown
    if ((mp.HTCountry != null && mp.HTCountry != "") || (mp.HTCity != null && mp.HTCity != "")) {
        if (op.htInfo != null && op.htInfo != "") {
            vm.count = 0;
            vm.icon = "https://pccdn.pyar.com/pcimgs/location.png";
            if (mp.HTCountry != null && op.htInfo.countryName != null && mp.HTCountry != "" && op.htInfo.countryName != "") {
                if (mp.HTCountry == op.htInfo.countryName) {
                    if (mp.HTCity != null && op.htInfo.cityName != null && mp.HTCity != "" && op.htInfo.cityName != "") {
                        if (mp.HTCity == op.htInfo.cityName) {
                            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                            vm.count = 1;
                            if (op.htInfo.stateName != null && op.htInfo.stateName != "")
                                vm.lochtdisp = "Grew up in " + op.htInfo.cityName + "," + op.htInfo.stateName + "," + op.htInfo.countryName;
                            else 
                                vm.lochtdisp = "Grew up in " + op.htInfo.cityName + "," + op.htInfo.countryName;
                            vm.mAnalysis.push({ "Id": "htCountry", "mpd": vm.lochtdisp, "opd": vm.lochtdisp, "icon": vm.icon, "check": vm.compimg });
                        }
                    }
                }
            }
            if (vm.count == 0) {
                vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png"
                if (op.htInfo.stateName != null && op.htInfo.stateName != "")
                    vm.lochtdisp = "Grew up in " + op.htInfo.cityName + "," + op.htInfo.stateName + "," + op.htInfo.countryName;
                else
                    vm.lochtdisp = "Grew up in " + op.htInfo.cityName + "," + op.htInfo.countryName;
                if (mp.HTState != null && mp.HTState != "")
                    vm.locmhtdisp = "Grew up in " + mp.HTCity + "," + mp.HTState + "," + mp.HTCountry;
                else
                    vm.locmhtdisp = "Grew up in " + mp.HTCity + "," + mp.HTCountry;
                vm.mAnalysis.push({ "Id": "htCountry", "mpd": vm.locmhtdisp, "opd": vm.lochtdisp, "icon": vm.icon, "check": vm.compimg });
            }
        }
    }
    //Personality seperate
    if (mp.pt != null && op.pt != null && mp.pt != "" && op.pt != "") {
        vm.count = 0;
        for (i = 0; i < mp.pt.length; i++) {
            for (j = 0; j < op.pt.length; j++) {
                if (mp.pt[i].txt == op.pt[j].txt) {
                    vm.pt.push(op.pt[j]);
                    vm.count = 1;
                    break;
                }
            }
        }
        if (vm.count == 1) {
            var ptArr = []; getJSonActiveDataText(vm.pt, ptArr);
            if (typeof (vm.pt) == "object") { vm.pt = ptArr.join(); }
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
            vm.ptdata.push({ "text": "pt", "mpd": vm.pt, "opd": vm.pt, "check": vm.compimg });
        }
    }
    //Eye Color
    if (mp.eyeColor != null && op.eyeColor != null && mp.eyeColor != "" && op.eyeColor != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/myeyeclr.png";
        vm.count = 0;
        for (i = 0; i < mp.eyeColor.length; i++) {
            if (op.eyeColor == mp.eyeColor[i].txt) {
                vm.opeyeColor = op.eyeColor;
                vm.mpeyeColor = op.eyeColor;
                vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                vm.count = 1;
                break;
            }
        }
        if (vm.count == 0) {
            vm.eyeColor = mp.eyeColor;
            var eyeColourArr = []; getJSonActiveDataText(vm.eyeColor, eyeColourArr);
            if (typeof (vm.eyeColor) == "object") { vm.eyeColor = eyeColourArr.join(); }
            vm.mpeyeColor = vm.eyeColor;
            vm.opeyeColor = op.eyeColor;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "eyeColor", "mpd": vm.mpeyeColor, "opd": vm.opeyeColor, "icon": vm.icon, "check": vm.compimg });
    }

    //Haircolor
    if (mp.hairColor != null && op.hairColor != null && mp.hairColor != "" && op.hairColor != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/myHairClrF.png";
        vm.count = 0;
        for (i = 0; i < mp.hairColor.length; i++) {
            if (op.hairColor == mp.hairColor[i].txt) {
                vm.ophairColor = op.hairColor;
                vm.mphairColor = op.hairColor;
                vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                vm.count = 1;
                break;
            }
        }
        if (vm.count == 0) {
            vm.hairColor = mp.hairColor;
            var hairColourArr = []; getJSonActiveDataText(vm.hairColor, hairColourArr);
            if (typeof (vm.hairColor) == "object") { vm.hairColor = hairColourArr.join(); }
            vm.mphairColor = vm.hairColor;
            vm.ophairColor = op.hairColor;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "hairColor", "mpd": vm.mphairColor, "opd": vm.ophairColor, "icon": vm.icon, "check": vm.compimg });
    }
    //Height
    if ((mp.MinHeight != null && mp.MinHeight != "") || (mp.MaxHeight != null && mp.MaxHeight != "")) {
        if (op.height != null && op.height != "") {
            var hgt = op.height.split("or ").pop();
            vm.icon = "https://pccdn.pyar.com/pcimgs/myheight.png";
            if (mp.MinHeight != null && mp.MinHeight != "")
                var minhgt = mp.MinHeight.split("or ").pop();
            else
                var minhgt = null;
            if (mp.MaxHeight != null && mp.MaxHeight != "")
                var maxhgt = mp.MaxHeight.split("or ").pop();
            else
                var maxhgt = null;
            if (maxhgt != null && minhgt != null) {
                if (minhgt <= hgt && hgt <= maxhgt) {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                    var mpheight = "between " + mp.MinHeight + " and " + mp.MaxHeight;
                }
                else {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
                    var mpheight = "between " + mp.MinHeight + " and " + mp.MaxHeight;
                }
            }
            else if (minhgt == null) {
                if (hgt <= maxhgt) {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                    var mpheight = "At most " + mp.MaxHeight;
                }
                else {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
                    var mpheight = "At most " + mp.MaxHeight;
                }
            }
            else if (maxhgt == null) {
                if (hgt >= minhgt) {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                    var mpheight = "At least " + mp.MinHeight;
                }
                else {
                    vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
                    var mpheight = "At least " + mp.MinHeight;
                }
            }  
            vm.mAnalysis.push({ "Id": "height", "mpd": mpheight + " tall", "opd": op.height + " tall", "icon": vm.icon, "check": vm.compimg });
        }
    }
    //build
    if (mp.build != null && op.build != null && mp.build != "" && op.build != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/mybuild.png";
        vm.count = 0;
        for (i = 0; i < mp.build.length; i++) {
            if (op.build == mp.build[i].txt) {
                vm.opbuild = op.build;
                vm.mpbuild = op.build;
                vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                vm.count = 1;
                break;
            }
        }
        if (vm.count == 0) {
            vm.build = mp.build;
            var buildArr = []; getJSonActiveDataText(vm.build, buildArr);
            if (typeof (vm.build) == "object") { vm.build = buildArr.join(); }
            vm.mpbuild = vm.build;
            vm.opbuild = op.build;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "build", "mpd": vm.mpbuild, "opd": vm.opbuild, "icon": vm.icon, "check": vm.compimg });
    }
    //Diet
    if (mp.diet != null && op.diet != null && mp.diet != "" && op.diet != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/mydiet.png";
        vm.count = 0;
        for (i = 0; i < mp.diet.length; i++) {
            if (op.diet == mp.diet[i].txt) {
                vm.opdiet = op.diet;
                vm.mpdiet = op.diet;
                vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
                vm.count = 1;

                break;
            }
        }
        if (vm.count == 0) {
            vm.diet = mp.diet;
            var DietArr = []; getJSonActiveDataText(vm.diet, DietArr);
            if (typeof (vm.diet) == "object") { vm.diet = DietArr.join(); }
            vm.mpdiet = vm.diet;
            vm.opdiet = op.diet;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";

        }
        vm.mAnalysis.push({ "Id": "diet", "mpd": vm.mpdiet, "opd": vm.opdiet, "icon": vm.icon, "check": vm.compimg });
    }
    //smoking habbits
    if (mp.Smoke != null && op.smoke != null && mp.Smoke != "" && op.smoke != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/mysmoking.png";
        if (mp.Smoke == op.smoke) {
            vm.opsmoke = op.smoke;
            vm.mpsmoke = op.smoke;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        }
        else {
            vm.opsmoke = op.smoke;
            vm.mpsmoke = mp.Smoke;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "smoke", "mpd": vm.mpsmoke + " smokes", "opd": vm.opsmoke + " smokes", "icon": vm.icon, "check": vm.compimg });
    }

    //Drinking Habbits
    if (mp.Drink != null && op.drink != null && mp.Drink != "" && op.drink != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/mydrink.png";
        if (mp.Drink == op.drink) {
            vm.opdrink = op.drink;
            vm.mpdrink = op.drink;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        }
        else {
            vm.opdrink = op.drink;
            vm.mpdrink = mp.Drink;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "drink", "mpd": vm.mpdrink + " drinks", "opd": vm.opdrink + " drinks", "icon": vm.icon, "check": vm.compimg });
    }

    //Relationship type
    if (mp.IdealRelationship != null && op.idealRelationship != null && mp.IdealRelationship != "" && op.idealRelationship != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/myrship.png";
        if (mp.IdealRelationship == op.idealRelationship) {
            vm.oprtype = op.idealRelationship;
            vm.mprtype = op.idealRelationship;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        }
        else {
            vm.oprtype = op.idealRelationship;
            vm.mprtype = mp.IdealRelationship;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "idealRelationship", "mpd": "Wants a " + vm.mprtype + " relationship", "opd": "Wants a " + vm.oprtype + " relationship", "icon": vm.icon, "check": vm.compimg });
    }
    //children count
    if (mp.ChildrenCount != null && op.childrenCnt != null && mp.ChildrenCount != "" && op.childrenCnt != "") {
        if (op.childrenCnt == "0")
            op.childrenCnt = "No";
        if (mp.ChildrenCount == "Null" || mp.ChildrenCount == undefined) {
            mp.ChildrenCount = "No";
        }
        vm.icon = "https://pccdn.pyar.com/pcimgs/mychildren.png";
        if (mp.ChildrenCount == op.childrenCnt) {
            vm.mpchildrenCnt = op.childrenCnt;
            vm.opchildrenCnt = op.childrenCnt;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        }
        else {
            vm.mpchildrenCnt = mp.ChildrenCount;
            vm.opchildrenCnt = op.childrenCnt;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        function getChldCount(val, type) {
            if (type == "mpd" || type == "opd") {
                if (val == null || val == "Null" || val == undefined || val == "" || val == "No") { return "Has No children"; }
                else if (val == 1 || val == "1") { return "Has " + val + " child"; }
                else { return "Has " + val + " children"; }
            }            
        }
        vm.mAnalysis.push({ "Id": "childrenCnt", "mpd": getChldCount(vm.mpchildrenCnt, "mpd"), "opd": getChldCount(vm.opchildrenCnt, "opd"), "icon": vm.icon, "check": vm.compimg });
    }
    //Children Pref
    if (mp.ChildrenPref != null && op.childrenPref != null && mp.ChildrenPref != "" && op.childrenPref != "") {
        if (op.childrenPref == "Yes")
            op.childrenPref = "Wants children";
        else if (op.childrenPref == "No")
            op.childrenPref = "Doesn't want children";
        else if (op.childrenPref == "Unsure")
            op.childrenPref = "May want children";

        vm.icon = "https://pccdn.pyar.com/pcimgs/mychildren.png";
        if (mp.ChildrenPref == op.childrenPref) {
            vm.opchildrenPref = op.childrenPref;
            vm.mpchildrenPref = op.childrenPref;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        }
        else {
            vm.opchildrenPref = op.childrenPref;
            vm.mpchildrenPref = mp.ChildrenPref;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "childrenPref", "mpd": vm.mpchildrenPref, "opd": vm.opchildrenPref, "icon": vm.icon, "check": vm.compimg });
    }

    //Pets Count
    if (mp.PetsCount != null && op.petsCnt != null && mp.PetsCount != "" && op.petsCnt != "") {
        if (op.petsCnt == "0")
            op.petsCnt = "No";
        vm.icon = "https://pccdn.pyar.com/pcimgs/mypets.png";
        if (mp.PetsCount == op.petsCnt) {
            vm.oppetsCnt = op.petsCnt;
            vm.mppetsCnt = op.petsCnt;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        }
        else {
            vm.oppetsCnt = op.petsCnt;
            vm.mppetsCnt = mp.PetsCount;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        function getPetsCount(val, type) {
            if (type == "mpd" || type == "opd") {
                if (val == null || val == "Null" || val == undefined || val == "" || val == "No") { return "Has No pets"; }
                else if (val == 1 || val == "1") { return "Has " + val + " pet"; }
                else { return "Has " + val + " pets"; }
            }          
        }
        vm.mAnalysis.push({ "Id": "petsCnt", "mpd": getPetsCount(vm.mppetsCnt, "mpd"), "opd": getPetsCount(vm.oppetsCnt, "opd"), "icon": vm.icon, "check": vm.compimg });
    }
    //pets pref
    if (mp.PetsPref != null && op.petsPref != null && mp.PetsPref != "" && op.petsPref != "") {
        if (op.petsPref == "Yes")
            op.petsPref = "Wants pets";
        else if (op.petsPref == "No")
            op.petsPref = "Doesn't want pets";
        else if (op.petsPref == "Unsure")
            op.petsPref = "May want pets";
        vm.icon = "https://pccdn.pyar.com/pcimgs/mypets.png";
        if (mp.PetsPref == op.petsPref) {
            vm.oppetsPref = op.petsPref;
            vm.mppetsPref = op.petsPref;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        }
        else {
            vm.oppetsPref = op.petsPref;
            vm.mppetsPref = mp.PetsPref;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "petsPref", "mpd": vm.mppetsPref, "opd": vm.oppetsPref, "icon": vm.icon, "check": vm.compimg });
    }
    //Prefrd Laguage
    if (mp.lang != null && op.lang != null && mp.lang != "" && op.lang != "") {
        vm.count = 0;
        vm.icon = "https://pccdn.pyar.com/pcimgs/mylanguage.png";
        for (i = 0; i < mp.lang.length; i++) {
            for (j = 0; j < op.lang.length; j++) {
                if (mp.lang[i].txt == op.lang[j].txt) {
                    vm.count = 1;
                    break;
                }
            }
            if (vm.count == 1)
                break;
        }
        if (count == 1)
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        else
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        vm.mplang = mp.lang;
        vm.oplang = op.lang;
        var LangArr = []; getJSonActiveDataText(vm.mplang, LangArr);
        var LangsArr = []; getJSonActiveDataText(vm.oplang, LangsArr);
        if (typeof (vm.mplang) == "object") { vm.mplang = LangArr.join(); }
        if (typeof (vm.oplang) == "object") { vm.oplang = LangsArr.join(); }
        vm.mAnalysis.push({ "Id": "lang", "mpd": "Prefers " + vm.mplang, "opd": "Prefers " + vm.oplang, "icon": vm.icon, "check": vm.compimg });
    }
    //family languages
    if (mp.familyLang != null && op.familyLangs != null && mp.familyLang != "" && op.familyLangs != "") {
        vm.count = 0;
        vm.icon = "https://pccdn.pyar.com/pcimgs/mylanguage.png";
        for (i = 0; i < mp.familyLang.length; i++) {
            for (j = 0; j < op.familyLangs.length; j++) {
                if (mp.familyLang[i].txt == op.familyLangs[j].txt) {
                    vm.count = 1;
                    break;
                }
            }
            if (vm.count == 1)
                break;
        }
        if (count == 1)
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        else
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        vm.mpfamilyLang = mp.familyLang;
        vm.opfamilyLang = op.familyLangs;
        var FmlyLangArr = []; getJSonActiveDataText(vm.mpfamilyLang, FmlyLangArr);
        var FmlyLangsArr = []; getJSonActiveDataText(vm.opfamilyLang, FmlyLangsArr);
        if (typeof (vm.mpfamilyLang) == "object") { vm.mpfamilyLang = FmlyLangArr.join(); }
        if (typeof (vm.opfamilyLang) == "object") { vm.opfamilyLang = FmlyLangsArr.join(); }
        vm.mAnalysis.push({ "Id": "familyLang", "mpd": "Family speaks " + vm.mpfamilyLang, "opd": "Family speaks " + vm.opfamilyLang, "icon": vm.icon, "check": vm.compimg });
    }

    //religious Habbits
    if (mp.Religious != null && op.religious != null && mp.Religious != "" && op.religious != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/myreligion.png";
        if (mp.Religious == op.religious) {
            vm.opreligious = op.religious;
            vm.mpreligious = op.religious;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        }
        else {
            vm.opreligious = op.religious;
            vm.mpreligious = mp.Religious;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "religious", "mpd": vm.mpreligious + " religious", "opd": vm.opreligious + " religious", "icon": vm.icon, "check": vm.compimg });
    }

    //cultural habbits
    if (mp.Traditional != null && op.traditional != null && mp.Traditional != "" && op.traditional != "") {
        vm.icon = "https://pccdn.pyar.com/pcimgs/myculture.png";
        if (mp.Traditional == op.traditional) {
            vm.optraditional = op.traditional;
            vm.mptraditional = op.traditional;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
        }
        else {
            vm.optraditional = op.traditional;
            vm.mptraditional = mp.Traditional;
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/crs-rndlgt.png";
        }
        vm.mAnalysis.push({ "Id": "traditional", "mpd": vm.mptraditional + " traditional", "opd": vm.optraditional + " traditional", "icon": vm.icon, "check": vm.compimg });
    }

    //hobbies
    if (mp.hobbies != null && op.hobbies != null && mp.hobbies != "" && op.hobbies != "") {
        vm.count = 0;
        vm.hobbies = [];
        for (i = 0; i < mp.hobbies.length; i++) {
            for (j = 0; j < op.hobbies.length; j++) {
                if (mp.hobbies[i].txt == op.hobbies[j].txt) {
                    vm.count = 1;
                    vm.hobbies.push(op.hobbies[j]);
                    break;
                }
            }
        }
        if (count == 1) {
            var hobbiesArr = []; getJSonActiveDataText(vm.hobbies, hobbiesArr);
            if (typeof (vm.hobbies) == "object") { vm.hobbies = hobbiesArr.join(); }
            vm.compimg = "https://pccdn.pyar.com/pcimgs/m/tick-rnd.png";
            vm.hobbiesdata.push({ "Id": "hobbies", "mpd": vm.hobbies, "opd": vm.hobbies, "check": vm.compimg });
        }
    }
    vm.data = [];
    vm.data.push({ "madata": vm.mAnalysis, "ptdata": vm.ptdata, "hobbiesdata": vm.hobbiesdata });
    callback(vm.data);
};

distance = function (lat1, lon1, lat2, lon2, unit) {
    var radlat1 = Math.PI * lat1 / 180
    var radlat2 = Math.PI * lat2 / 180
    var theta = lon1 - lon2
    var radtheta = Math.PI * theta / 180
    var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
    dist = Math.acos(dist)
    dist = dist * 180 / Math.PI
    dist = dist * 60 * 1.1515
    if (unit == "K") { dist = dist * 1.609344 }
    if (unit == "N") { dist = dist * 0.8684 }
    return dist
};