﻿app.service('othersprofileSrvc', ['$http', function ($http) {
    this.memberProfileView = function (viewedBy, memberId, memInvBrsng, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/mpi/" + viewedBy + "/" + memberId + "/" + memInvBrsng;
        GetServiceByURL($http, url, funCallBack);
    };

    this.memberPyarPerc = function (viewedBy, memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/pyrprcnt/" + viewedBy + "/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.matchanalysis = function (viewedBy, memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/getmtch/" + viewedBy + "/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.profileReminderSend = function (memberId, reminderSentTo, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/pfrs/" + memberId + "/" + reminderSentTo;
        GetServiceByURL($http, url, funCallBack);
    };

    this.profileReminderchk = function (memberId, reminderSentTo, funCallBack) {
        var url = "https://pcapi.pyar.com/api/profile/pfrc/" + memberId + "/" + reminderSentTo;
        GetServiceByURL($http, url, funCallBack);
    };

    this.MemberHideCheck = function (memberId, memHideId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/hdchk/" + memberId + "/" + memHideId;
        GetServiceByURL($http, url, funCallBack);
    };
}]);