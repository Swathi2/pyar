﻿angular.module("app").controller('matchCtrl', ['othersprofileSrvc', 'selfprofileSrvc', 'getSessionSrvc', 'selfmatchprefSrvc', 'mbrActSrvc', 'hbySearchFact', 'msgSrvc', '$scope', '$window', '$filter', '$timeout', '$rootScope', '$state', '$location', function (othersprofileSrvc, selfprofileSrvc, getSessionSrvc, selfmatchprefSrvc, mbrActSrvc, hbySearchFact, msgSrvc, $scope, $window, $filter, $timeout, $rootScope, $state, $location) {
    var vm = this;
    vm.invBrw = function () { return getSessionSrvc.p_ib(); };
    vm.ppm = "https://pccdn.pyar.com/pcmbr/defaults/profilemtnb.jpg";
    vm.ppf = "https://pccdn.pyar.com/pcmbr/defaults/profileftnb.jpg";
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.country = function () { return getSessionSrvc.p_cntry() };
    vm.sId = function () { return getSessionSrvc.p_sub() };
    vm.firstName = function () { return getSessionSrvc.p_fn() };
    vm.prflPic = function () { return getSessionSrvc.p_ppic() };
    vm.ppblr = function () { return getSessionSrvc.p_ppicblr(); };
    vm.gender = function () { return getSessionSrvc.p_gndr() };
    vm.units = function () { return getSessionSrvc.p_uts(); };
    vm.imageCDN = "https://pccdn.pyar.com";
    vm.showMatch = false;

    $scope.$on("openMatch", function (e, tmId, refPgType) {
        showLoader();
        vm.initVariable();
        vm.refPgType = refPgType;
        vm.omId = getSessionSrvc.pcd(tmId);
        if (vm.omId == null)
            vm.closeMatch();
        else {
            vm.showMatch = true;
            vm.getMatchInfo();
            vm.getPyarPercent();
            vm.bindMatchScroll();
        }
    });

    vm.closeMatch = function () {
        vm.showMatch = false;
        vm.omId = null;
        $rootScope.$broadcast("closeMatch", vm.refPgType);
    };

    vm.initVariable = function () {
        vm.profileInfoExt1 = null;
        vm.profileInfoExt2 = null;
        vm.refPgType = "";
        vm.showSlider = false;
        vm.dvpgVisble = false;
        vm.dvErrMsg = false;
        vm.otherpgvisible = true;
        vm.prcntSgn = true;
        vm.pyrQnsmrk = false;
        vm.pyarpercent = true;
        vm.mapg = false;
        vm.mapg1 = false;
        vm.mapg2 = false;
        vm.mapg3 = false;
        vm.mapg4 = false;
        vm.mtchAnlsysData = [];
        vm.loctxt = [];
        vm.matchmmc = false;
        vm.scrollTo = 0;
        //trophies
        vm.trophiesRsltArry = [];
        //photo gallerty 
        vm.galleryPhotos = [];
        vm.profileResponse = [];
        //swiper
        vm.profileSlider = [];
        vm.pfswiper = null;
        vm.galleryswiper = null;
        vm.mpId = "";
        //Variables declaration for actions
        vm.curMemTileIndex = 0;
        vm.favType = null;
        vm.PPindex = 0;
    };

    vm.getMatchInfo = function () {
        //Service for getting member info
        if (vm.mId() && vm.omId) {
            showLoader();
            othersprofileSrvc.memberProfileView(vm.mId(), vm.omId, vm.invBrw(), function (response, status) {
                if (status == 200) {
                    if (response == false) {
                        vm.dvpgVisble = false;
                        vm.dvErrMsg = true;
                        hideLoader();
                    }
                    else {
                        vm.dvErrMsg = false;
                        vm.pgVisble();
                        vm.getPrflInfoCallBack(response);
                        //send only live notifications when invisible browse is false and last viewd not today
                        if ((vm.sId() == 1 || (vm.sId == 2 && vm.invBrw() == false)) && isCurrentDate(response.lastViewedOn) == false) {
                            mbrActSrvc.MemberHideCheck(vm.omId, vm.mId(), function (response, status) {
                                if (status == 200 && response == false) {
                                    //send profile view based on basic and premium
                                    var notifyType = 63, fn = "", pp = "", gender = null;
                                    if (response.sId == 2) {
                                        notifyType = 61;
                                        fn = vm.firstName();
                                        pp = vm.prflPic();
                                        gender = vm.gender();
                                    }
                                    else
                                        pp = vm.ppblr();
                                    //if service available we will send,oatherwise push to rootscope it will auto send when service avaliable
                                    if (msgSrvc.conId)
                                        msgSrvc.sendMemberNotifications(vm.omId, fn, pp, gender, notifyType, new Date());
                                    else
                                        $rootScope.ntfnData.push({ "sendType": 1, "tmId": vm.omId, "fn": fn, "pp": pp, "gender": gender, "type": notifyType, "date": new Date() });
                                }
                            });
                        }
                    }
                }
            });
        }
        else {
            vm.dvpgVisble = false;
            vm.dvErrMsg = true;
            return false;
        }
    };

    //Page load services Called starts
    vm.getPrflInfoCallBack = function (response) {
        showLoader();
        vm.profileInfo = response;
        vm.getAllimages();
        vm.locjoinTxt = bindHtLocation(vm.profileInfo.cityName, vm.profileInfo.stateName, vm.profileInfo.cntryName, vm.country(), vm.units(), vm.profileInfo.distance);
        if (vm.locjoinTxt.length > 23)
            vm.locjoinTxt = vm.locjoinTxt.substring(0, 20) + "...";
        vm.profilePic = $filter("PrflPicFltr")(vm.profileInfo.profilePic, vm.profileInfo.gender);
        vm.profilePicPyarper = $filter("otherPrflPicFltr")(vm.profileInfo.profilePic, vm.profileInfo.gender);
        vm.Gender = $filter('GenderPicFltr')(vm.profileInfo.gender);
        vm.gndrHisOrHer = $filter('gndrHerOrHisSFltr')(vm.profileInfo.gender);
        vm.gndrHimOrHer = $filter('gndrHerOrHimSFltr')(vm.profileInfo.gender);
        vm.trophiesResult = (vm.profileInfo.trophies).split('#');
        vm.trophiesLoad();
        selfprofileSrvc.GetPrfInfoExt1(vm.omId, vm.profileInfo, vm.getPrfInfoExt1CallBack);
        selfprofileSrvc.GetPrfInfoExt2(vm.omId, vm.profileInfo, vm.getPrfInfoExt2CallBack);
        selfmatchprefSrvc.prefRadius(function (response, status) {
            if (status == 200) {
                vm.locrad = response;
            }
        });
        vm.memAge = calculateAge(vm.profileInfo.dob);
    };

    //Function for return grew up location
    function lctnInfoDlts() {
        var htInfo = vm.profileInfoExt1.htInfo;
        if (htInfo) {
            if (vm.country() == htInfo.countryName) { return "Grew up in " + htInfo.cityName + ", " + htInfo.stateName; }
            else { return "Grew up in " + htInfo.cityName + ", " + htInfo.stateName + ", " + htInfo.countryName; }
        }
    }

    vm.getPrfInfoExt1CallBack = function (responseEx1, status) {
        vm.profileInfoExt1 = responseEx1;
        var Ex1 = vm.profileInfoExt1;
        //About me block Data starts
        vm.aboutMeJsonData = AboutMeMSFunc(Ex1.ethinicityId, Ex1.religionId, Ex1.awId, Ex1.rsStatus, Ex1.highestEdu, lctnInfoDlts());
        vm.aboutMeData = [];
        getJSonActiveData(vm.aboutMeJsonData, vm.aboutMeData);
        hideLoader();
    };

    vm.getPrfInfoExt2CallBack = function (responseEx2, status) {
        vm.profileInfoExt2 = responseEx2;
        var Ex2 = vm.profileInfoExt2;
        //My Appearence Data Starts
        vm.myApprnceJsonData = MyApprnceMSFunc(Ex2.eyeColor, Ex2.hairColor, Ex2.height, Ex2.build, vm.profileInfo.gender)
        vm.myApprnceData = [];
        getJSonActiveData(vm.myApprnceJsonData, vm.myApprnceData);
        //My Life Styles Data Starts
        vm.lifeStyleJsonData = LifeStyleMSFunc($filter, Ex2.diet, Ex2.smoke, Ex2.drink, Ex2.idealRelationship, Ex2.childrenCnt, Ex2.childrenPref, Ex2.petsCnt, Ex2.petsPref, Ex2.lang, Ex2.familyLangs, Ex2.religious, Ex2.traditional);
        vm.lifeStyleData = [];
        getJSonActiveData(vm.lifeStyleJsonData, vm.lifeStyleData);
        hideLoader();
    };

    //page unevenly loading resolve function
    vm.pgVisble = function () {
        $timeout(function () {
            vm.dvpgVisble = true;
            hideLoader();
        }, 300, true);
    };

    //Pyarpercent service call
    vm.getPyarPercent = function () {
        othersprofileSrvc.memberPyarPerc(vm.mId(), vm.omId, function (response, status) {
            if (status == 200) {
                vm.pyrPerc = response;
                if (vm.pyrPerc == "-2" || vm.pyrPerc == "-1") {
                    vm.prcntSgn = false;
                    vm.pyrQnsmrk = true;
                    vm.pyarpercent = false;
                }
            }
        });
    };

    //Trophies load Block
    vm.getTrophyStatus = function (val) {
        if (vm.trophiesResult[val] == 1)
            return true;
        else
            return false;
    };

    vm.trophiesLoad = function () {
        vm.trophiesLst = [];
        vm.trophiesLstJSON = [
            { status: vm.getTrophyStatus(0) == true ? vm.tropEml = 'https://pccdn.pyar.com/pcimgs/m/trpy-eml.png' : vm.tropEml = 'https://pccdn.pyar.com/pcimgs/m/trpy-eml.png', img: '', txt: "Verified<br>email" },
            { status: vm.getTrophyStatus(1), img: '', txt: "Connected<br>Via social" },
            { status: vm.getTrophyStatus(2), img: '', txt: "Uploaded<br>profile photo" },
            { status: vm.getTrophyStatus(3), img: '', txt: "Verified<br>mobile phone" },
            { status: vm.getTrophyStatus(4), img: '', txt: "Completed<br>profile" }
        ];
        //getJSonActiveData(vm.trophiesLstJSON, vm.trophiesLst);
        if (vm.getTrophyStatus(0))
            vm.trophiesLstJSON[0].img = vm.tropEml = 'https://pccdn.pyar.com/pcimgs/m/trpy-eml.png'
        else
            vm.trophiesLstJSON[0].img = vm.tropEml = 'https://pccdn.pyar.com/pcimgs/m/trpy-eml.png';
        if (vm.getTrophyStatus(1))
            vm.trophiesLstJSON[1].img = vm.tropEml = 'https://pccdn.pyar.com/pcimgs/m/trpy-soc.png'
        else
            vm.trophiesLstJSON[1].img = vm.tropEml = 'https://pccdn.pyar.com/pcimgs/m/trpy-soc-e.png';
        if (vm.getTrophyStatus(2))
            vm.trophiesLstJSON[2].img = vm.tropEml = 'https://pccdn.pyar.com/pcimgs/m/trpy-photo.png'
        else
            vm.trophiesLstJSON[2].img = vm.tropEml = 'https://pccdn.pyar.com/pcimgs/m/trpy-photo-e.png';
        if (vm.getTrophyStatus(3))
            vm.trophiesLstJSON[3].img = vm.tropEml = 'https://pccdn.pyar.com/pcimgs/m/trpy-mbl.png'
        else
            vm.trophiesLstJSON[3].img = vm.tropeml = 'https://pccdn.pyar.com/pcimgs/m/trpy-mbl-e.png';
        if (vm.getTrophyStatus(4))
            vm.trophiesLstJSON[4].img = vm.tropeml = 'https://pccdn.pyar.com/pcimgs/m/trpy-prfl.png'
        else
            vm.trophiesLstJSON[4].img = vm.tropeml = 'https://pccdn.pyar.com/pcimgs/m/trpy-prfl-e.png';

    };

    //Photo gallery Block Start
    //upldPhotoType 1 for gallery photo 2 for profile photo 3 for cover photo
    vm.getAllimages = function () {
        vm.bindAllImages(function (response) {
            showLoader();
            vm.profileSlider = response;
            if (vm.profileResponse.length != 0)
                vm.profileSlider.unshift({ mpId: vm.profileResponse[0].mpId, picPath: vm.profileResponse[0].picPath, picOrgPath: vm.profileResponse[0].picOrgPath, picOrder: 0, picCreateDT: vm.profileResponse[0].picCreateDT, picType: 2 });//with profile pic 
            else
                vm.profileSlider.push({ mpId: 0, picPath: vm.profilePic, picOrgPath: vm.profilePic, picCreateDT: "", picType: 2 })//with out profile pic
            hideLoader();
        });
    };

    vm.onPtImgLoadFinish = function () {
        var ptswiper = new Swiper('.swiperpt', {
            slidesPerView: 3,
        });
    };

    vm.onTrophyImgLoadFinish = function () {
        var trphyswiper = new Swiper('.swiperTrphy', {
            slidesPerView: 3
        });
    };

    // used for profile slider
    $scope.$on("pfSliderSwiper", function () {
        vm.pfswiper = new Swiper('.pfslde', {
            slidesPerView: 1,
            paginationClickable: true,
            centeredSlides: true,
            loop: vm.profileSlider.length > 1 ? true : false,
            runCallbacksOnInit: true,
            onSlideNextStart: function (swiper) {
                if (vm.PPindex >= vm.profileSlider.length)
                    vm.PPindex = 1;
                else
                    vm.PPindex += 1;
                $scope.$digest();
            },
            onSlidePrevStart: function (swiper) {
                if (vm.PPindex == 1)
                    vm.PPindex = vm.profileSlider.length;
                else
                    vm.PPindex -= 1;
                $scope.$digest();
            },
            onClick: function (swiper) {
                vm.showSlider = true;
                $scope.$digest();
                vm.galleryswiper.update();
                vm.gpIndex = vm.PPindex;
                $timeout(function () {
                    vm.galleryswiper.slideTo(vm.gpIndex, 0, false);
                }, 10);
                if (vm.gpIndex == 1) {
                    if (vm.profileInfo.isProfilePicUpld == true) {
                        vm.pfSlidetxt = "Report Photo";
                    }
                    else
                        vm.pfSlidetxt = "";
                }
                else
                    vm.pfSlidetxt = "Report Photo";
            }
        });
        vm.PPindex = 1;
    });

    //used for gallary images swiper
    $scope.$on("pfGallerySwiper", function () {
        vm.galleryswiper = new Swiper('.gimg', {
            slidesPerView: 1,
            paginationClickable: true,
            centeredSlides: true,
            loop: vm.profileSlider.length > 1 ? true : false,
            runCallbacksOnInit: true,
            onSlideNextStart: function (swiper) {
                if (vm.gpIndex == vm.profileSlider.length) {
                    vm.gpIndex = 1;
                    if (vm.profileInfo.isProfilePicUpld == true)
                        vm.pfSlidetxt = "Report Photo";
                    else
                        vm.pfSlidetxt = "";
                }
                else {
                    vm.gpIndex += 1;
                    vm.pfSlidetxt = "Report Photo";
                }
                $scope.$digest();
            },
            onSlidePrevStart: function (swiper) {
                if (vm.gpIndex == 1)
                    vm.gpIndex = vm.profileSlider.length;
                else
                    vm.gpIndex -= 1;

                if (vm.gpIndex == 1) {
                    if (vm.profileInfo.isProfilePicUpld == true)
                        vm.pfSlidetxt = "Report Photo";
                    else
                        vm.pfSlidetxt = "";
                }
                else
                    vm.pfSlidetxt = "Report Photo";
                $scope.$digest();
            },
        });
    });

    //used for hide gallary image swiper slider
    vm.hideSlider = function () {
        vm.showSlider = false;
    };

    vm.bindAllImages = function (callBackFunc) {
        selfprofileSrvc.getAllImages(vm.omId, function (response, status) {
            if (status == 200 && response) {
                if (vm.profileInfo.isProfilePicUpld == true) {
                    angular.forEach(response, function (data) {
                        if (data.picType == 2) {
                            vm.profileResponse.push({ mpId: data.mpId, picPath: vm.imageCDN + data.picPath, picOrgPath: vm.imageCDN + data.picPath.replace("/p/tnb/", "/p/"), picCreateDT: data.picCreateDT });
                            return false; //break
                        }
                    });
                }
                else {
                    var pp = "";
                    if (vm.profileInfo.profilePic)
                        pp = vm.imageCDN + vm.profileInfo.profilePic;
                    else if (vm.profileInfo.gender)
                        pp = vm.ppm;
                    else
                        pp = vm.ppf;
                    vm.profileResponse.push({ mpId: 0, picPath: pp, picOrgPath: pp, picCreateDT: "" });
                }
                for (var j = 0; j < response.length; j++) {
                    if (response[j].picType == 1)
                        vm.galleryPhotos.push({ mpId: response[j].mpId, picPath: vm.imageCDN + response[j].picPath.replace("/gl/tn/", "/gl/tnb/"), picOrgPath: vm.imageCDN + response[j].picPath.replace("/gl/tn/", "/gl/"), picCreateDT: response[j].picCreateDT });
                }
                callBackFunc(vm.galleryPhotos);
            }
        });
    };
    /*********************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( ACTIONS FOR OTHERS PROFILE STARTS HERE  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    //Favourite actions starts here
    //setting the favourite image(active/inactive)
    vm.setFavIcnImg = function (favType) {
        if (favType == 1)
            return "https://pccdn.pyar.com/pcimgs/m/favract.png";
        else
            return "https://pccdn.pyar.com/pcimgs/m/favremty.png";
    };

    //setting the flirt image(active/inactive)
    vm.setFlirtIcnImg = function (flirttype) {
        if (flirttype == 1)
            return "https://pccdn.pyar.com/pcimgs/m/flirtract.png";
        else
            return "https://pccdn.pyar.com/pcimgs/m/flirtremty.png";
    };

    //Favourite action click
    vm.favIcnClk = function (memId, Name, favType, Gender) {
        $rootScope.$broadcast("FavMbrAct", memId, Name, favType, Gender, "otherprofilepage");
    };

    $scope.$on("favRemoveDone", function (e) {
        if (vm.omId) {
            vm.profileInfo.fav = 2
            $("#mtchImgFav").attr("src", "https://pccdn.pyar.com/pcimgs/m/favremty.png");
        }
    });

    $scope.$on("favAddDone", function (e) {
        if (vm.omId) {
            vm.profileInfo.fav = 1
            $("#mtchImgFav").attr("src", "https://pccdn.pyar.com/pcimgs/m/favract.png");
        }
    });

    //Flirt action click
    vm.flirtIcnClk = function (memId, Name, favType, Gender, flirtType) {
        $rootScope.$broadcast("FlirtMbrAct", memId, Name, favType, Gender, flirtType);
    };

    $scope.$on("FlirtAddDone", function (e) {
        if (vm.omId) {
            vm.profileInfo.flirt = 1
            $("#imgFlirt" + vm.curMemTileIndex).attr("src", "https://pccdn.pyar.com/pcimgs/m/flirtact.png");
        }
    });

    vm.memHideCheck = function (memHideId, firstName, gender) {
        $rootScope.$broadcast("MbrOtherAct", memHideId, firstName, gender);
    };

    //Block member
    $scope.$on("blockDone", function (e, tmId) {
        if (vm.omId == tmId)
            vm.closeMatch();
    });
    // //Favourite actions ends here
    /*********************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( ACTIONS FOR OTHERS PROFILE ENDS HERE  )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    // Binding pyarpercent text
    vm.getPyarPercntTxt = function (val) {
        if (val > 0 && val <= 29) { return "NOT A MATCH"; }
        else if (val >= 30 && val <= 59) { return "GOOD MATCH"; }
        else if (val >= 60 && val <= 79) { return "GREAT MATCH"; }
        else if (val >= 80 && val <= 100) { return "PERFECT MATCH"; }
        else if (val == "-2" || val == "-1") { return "NOT ENOUGH INFO"; }
    };

    //Getting matchanalysis page
    vm.getMatchAnalysis = function (val) {
        vm.scrollTo = $("#dvMatch").scrollTop();
        $timeout(function () { $("#dvMatch").animate({ scrollTop: 0 }, 0); }, 0);
        vm.otherpgvisible = false;
        vm.mapg = true;
        if (val > 0 && val <= 29) //not a good match
            vm.mapg1 = true;
        else if (val == -2) { // sending remainder for others profile empty state
            showLoader();
            vm.mapg3 = true;
            vm.empSteRmdr = null;
            othersprofileSrvc.profileReminderchk(vm.mId(), vm.omId, function (response, status) {
                hideLoader();
                if (response == true)
                    vm.empSteRmdr = false;
                else
                    vm.empSteRmdr = true
            });
        }
        else if (val == -1)//redirecting to matchpref for empty state preferences
            vm.mapg2 = true;
        else {
            showLoader();
            vm.profiledata = angular.merge({}, vm.profileInfoExt1, vm.profileInfoExt2, { "age": vm.memAge }, { "locrad": vm.locrad }, { "countryId": vm.profileInfo.cntryName }, { "cityId": vm.profileInfo.cityName }, { "stateId": vm.profileInfo.stateName});
            othersprofileSrvc.matchanalysis(vm.mId(), vm.omId, function (response, status) {
                macomp(response, vm.profiledata, vm.country(), function (response) {
                    vm.hobbies = response[0].hobbiesdata[0];
                    vm.mAnalysis = response[0].madata;
                    vm.mtchAnlsysData = vm.mAnalysis.filter(function (item) { return item.opd != ''; });
                    vm.ptdata = response[0].ptdata[0];
                    if (vm.ptdata != null)
                        vm.ptdisplay = true;
                    else
                        vm.ptdisplay = false;
                    if (vm.hobbies != null)
                        vm.hobbiesdisplay = true;
                    else
                        vm.hobbiesdisplay = false;
                });
            });
            vm.mapg4 = true;
            hideLoader();
        }
    };

    //Send remonder for "-2" state
    vm.empSteRmdrSnd = function () {
        othersprofileSrvc.profileReminderSend(vm.mId(), vm.omId, function (response, status) {
            if (response == true) {
                vm.empSteRmdr = false;
                $("#rmdrPopup").modal('show');
                $timeout(function () {
                    $('.modal-backdrop').remove();
                    $("#rmdrPopup").modal('hide');
                }, 3000);
                var notifyType = 52;
                if (msgSrvc.conId)
                    msgSrvc.sendMemberNotifications(vm.omId, vm.firstName(), vm.prflPic(), vm.gender(), notifyType, new Date());
                else
                    $rootScope.ntfnData.push({ "sendType": 1, "tmId": vm.omId, "fn": vm.firstName(), "pp": vm.prflPic(), "gender": vm.gender(), "type": notifyType, "date": new Date() });
            };
        });
    };

    //Back button functionality for others profile
    vm.othersPrfleBckBtnClk = function () {
        vm.mapg = false;
        vm.otherpgvisible = true;
        $timeout(function () { $("#dvMatch").animate({ scrollTop: vm.scrollTo }, 0); }, 0);
    };

    //Redirect to matchpreference page
    vm.matchPrefFillClk = function () {
        $rootScope.otherPrflReffer = $location.path();
        $state.go('matchpref');
        $window.localStorage.setItem("mpPgNo", 1);
    };

    //photo report
    vm.btnShowReprtPopUp = function (photoId) {
        $rootScope.$broadcast("rptOnMbrPhotoAction", vm.omId, photoId);
    };

    //Click functionality for hobbies,redirects to search page
    vm.gotoSearch = function (getHbs) {
        $rootScope.tabtype = "";//clear dashboard tab type.
        var hbySearch = { "refId": getHbs.refId, "refType": 2, "sugName": getHbs.txt };
        hbySearchFact.sethbySearchData(JSON.stringify(hbySearch));
        if (vm.refPgType != "BS" && vm.refPgType != "AS") {
            clearSearch($window);
            if (vm.sId() == 1)
                $state.go("basicsearch");
            else
                $state.go("advancedsearch");
        }
        else {
            vm.showMatch = false;
            vm.omId = null;
            $rootScope.$broadcast("srchSugns");
        }
    };

    vm.bindMatchScroll = function () {
        $timeout(function () {
            $("#dvMatch").on('scroll', function () {
                if ($(this).scrollTop() > $("#pp").height() && $("#dvstrp").css("display") == "none")
                    $("#dvstrp").show();
                else if ($(this).scrollTop() <= $("#pp").height() && $("#dvstrp").css("display") != "none")
                    $("#dvstrp").hide();
            });
        }, 1000);
    };
    //open messanger
    vm.openChat = function (tmId, fn) {
        try {
            if (vm.sId() == 2) {
                vm.showMatch = false;
                vm.scrollTo = $("#dvMatch").scrollTop();
                if (vm.refPgType == "MMC")
                    vm.closeMatch();
                else
                    $rootScope.$broadcast("openMMC", tmId, fn, "Match");
            }
            else
                $rootScope.$broadcast("showPremiumPopup", "RM");
        } catch (e) {
            console.log("profile openChat  --  " + e.message);
            alert("profile openChat  --  " + e.message);
        }
    };

    $scope.$on("closeMMC", function (e, refPgType) {
        if (refPgType == "Match") {
            vm.showMatch = true;
            $timeout(function () { $("#dvMatch").animate({ scrollTop: vm.scrollTo }, 0); }, 0);
        }
    });
}]);