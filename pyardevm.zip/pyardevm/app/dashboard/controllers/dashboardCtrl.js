﻿angular.module("app").controller('dashboardCtrl', ['dashboardSrvc', 'getSessionSrvc', 'cmnSrvc', '$scope', '$state', '$location', '$rootScope', '$timeout', '$window', function (dashboardSrvc, getSessionSrvc, cmnSrvc, $scope, $state, $location, $rootScope, $timeout, $window) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.country = function () { return getSessionSrvc.p_cntry(); };
    vm.sId = function () { return getSessionSrvc.p_sub(); };
    vm.units = function () { return getSessionSrvc.p_uts(); };
    vm.subtm = function () { return getSessionSrvc.p_subtm(); };
    vm.subExp = function () { return getSessionSrvc.p_subex(); };
    vm.recMatch;
    vm.recMatchData = [];
    vm.myFavData = [];
    vm.tabtype = "matches";
    vm.noMatchdata = false;
    vm.pgNo = 1;
    vm.pgSize = 20;
    vm.dvpgVisble = false;
    vm.scrollable = true;
    vm.rmPgNo = 1;
    vm.rmPgSize = 50;
    vm.rmSortBy = 1;
    vm.rmDataExist = false;
    vm.rmReqCmplt = true;
    vm.sortBy = 1;
    vm.calculateAge = function (val) { return calculateAge(val); }
    vm.mmc = false;
    vm.mmcScrollTo = 0;

    //get Rec Matches
    vm.getRecMatches = function () {
        if (vm.rmReqCmplt) {
            vm.rmReqCmplt = false;
            showLoader();
            dashboardSrvc.getRM(vm.mId(), vm.rmPgNo, vm.rmPgSize, vm.rmSortBy, false, function (response, status) {
                vm.rmReqCmplt = true;
                if (status == 200) {
                    vm.rmDataExist = false;
                    if (response.length > 0) {
                        if (response.length == vm.rmPgSize)
                            vm.rmDataExist = true;
                        vm.noMatchdata = false;
                        vm.recMatchData = response;
                        vm.setMatchData();
                    }
                    else {
                        //set empty state visible
                        vm.noMatchdata = true;
                        vm.recMatchData = [];
                    }
                    vm.pgVisble();
                }
            });
        }
    };

    vm.getProfilePic = function (profilepic, gender) {
        if (!profilepic) {
            if (gender == true) return "https://pccdn.pyar.com/pcmbr/defaults/profilemtnb.jpg";
            else if (gender == false) return "https://pccdn.pyar.com/pcmbr/defaults/profileftnb.jpg";
        }
        else return "https://pccdn.pyar.com" + profilepic;
    };

    vm.nextMatch = function () {
        vm.recMatchData.splice(0, 1);//Remove current match
        if (vm.recMatchData.length == 0) {
            if (vm.rmReqCmplt) {
                if (vm.rmDataExist) {
                    vm.dvpgVisble = false;
                    vm.rmPgNo++;
                    vm.getRecMatches();
                }
                else
                    vm.noMatchdata = true;
            }
        }
        else
            vm.setMatchData();
    };

    vm.setMatchData = function () {
        vm.recMatch = vm.recMatchData[0];
        vm.locationBinding(vm.recMatch);
        vm.setFavIcnImg(vm.recMatch.fav);
        vm.ageVal = vm.calculateAge(vm.recMatch.dob);
        vm.profilePic = vm.getProfilePic(vm.recMatch.profilePic, vm.recMatch.gender);
        vm.setTrphyImg(vm.recMatch.trophies);
    };

    vm.recMatchTabClk = function () {
        if (vm.recMatchData.length == 0 && vm.noMatchdata == false)
           showLoader();
        vm.tabtype = "matches";
        vm.dvpgVisble = true;
    };

    vm.favTabClk = function () {
        showLoader();
        vm.dvpgVisble = false;
        vm.tabtype = "favorite";
        vm.pgNo = 1;
        $(window).scrollTop(0);//set scroll to top
        dashboardSrvc.getMyFav(vm.mId(), vm.pgNo, vm.pgSize, vm.sortBy, false, function (response, status) {
            if (status == 200) {
                if (response.length > 0) {
                    vm.noFavdata = false;
                    vm.myFavData = response;
                    if (response.length < vm.pgSize)
                        vm.scrollable = false;
                }
                else  //set empty state visible
                    vm.noFavdata = true;
                vm.pgVisble();
            }
        });
    };

    vm.locationBinding = function (locObj) {
        return vm.locatntxt = bindHtLocation(locObj.city, locObj.state, locObj.country, vm.country(), vm.units(), locObj.distance);
    };

    $scope.scrollLoad = function () {
        if ($(window).scrollTop() >= (($(document).height() - $("#pcFtr").outerHeight() - 20) - $(window).height())) {
            if (vm.scrollable == true) {
                vm.pgNo++;
                dashboardSrvc.getMyFav(vm.mId(), vm.pgNo, vm.pgSize, vm.sortBy, true, function (response, status) {
                    if (status == 200) {
                        if (response.length > 0) {
                            for (var i = 0; i < response.length; i++)
                                vm.myFavData.push(response[i]);
                            if (response.length < vm.pgSize)
                                vm.scrollable = false;
                        }
                        else
                            vm.scrollable = false;
                    }
                });
            }
        }
    };

    vm.gotoProfile = function (mId, index) {
        vm.curMemTileIndex = index;
        vm.curMemId = mId;
        $rootScope.tabtype = vm.tabtype;
        vm.mmcScrollTo = $(window).scrollTop();
        vm.mmc = true;
        $rootScope.$broadcast("openMatch", getSessionSrvc.pce(mId), "DB");
    };

    $scope.$on("closeMatch", function (e, refPgType) {
        if (refPgType == "DB") {
            vm.mmc = false;
            $timeout(function () { window.scrollTo(0, vm.mmcScrollTo); }, 0);
        }
    });

    //redirect to  search page when click on search button in matches empty state
    vm.matchSearchclk = function () {
        if (vm.sId() == 1)
            var searchpage = "basicsearch";
        else if (vm.sId() == 2)
            var searchpage = "advancedsearch";
        //activate selected tab in footer
        $("#nvbrimg li:nth-child(5)").click();
        $state.go(searchpage);
    };

    //page unevenly loading resolve function
    vm.pgVisble = function () {
        $timeout(function () {
            vm.dvpgVisble = true;
            hideLoader();
        }, 250, true);
    };

    vm.getPyarPernt = function (val) {
        if (val == -1 || val == -2)
            return "?"
        else
            return val;
    };

    vm.getMatchQ = function (val) {
        if (val == -1 || val == -2)
            return "";
        else
            return "%";
    };

    vm.setTrphyImg = function (trophies) {
        return vm.trphyImg = getTrophies(trophies);
    };

    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT DASHBOARD MEMBER ACTIONS ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    vm.curMemId = "";
    vm.curMemTileIndex = 0;
    vm.curName = "";
    vm.curGender = null;
    vm.curProfilePic = "";
    vm.favType = null;
    vm.flrtType = null;
    //FAVARITE MODULE START
    vm.setFavIcnImg = function (favType) {
        $("#imgFav").attr("src", "https://pccdn.pyar.com/pcimgs/m/fav.png");
    };

    vm.setFlirtIcnImg = function (flirttype) {
        return flirttype == 1 ? "https://pccdn.pyar.com/pcimgs/m/flirtact.png" : "https://pccdn.pyar.com/pcimgs/m/flirt.png";
    };

    //FAVARITE MODULE Starts
    vm.favIcnClk = function (memId, Name, favType, Gender, index) {
        vm.curMemTileIndex = index;
        $rootScope.$broadcast("FavMbrAct", memId, Name, favType, Gender, "dashboard");
    };

    $scope.$on("favRemoveDone", function (e) {
        vm.myFavData.splice(vm.curMemTileIndex, 1);
        if (vm.myFavData.length == 0) {
            vm.pgNo = 1;
            vm.favTabClk();//Load favorite Data.
        }
    });
    $scope.$on("favAddDone", function (e) {
        if ($rootScope.dashboardFav) {
            $("#imgFav").attr("src", "https://pccdn.pyar.com/pcimgs/m/favact.png");
            $rootScope.dashboardFav = false;
        } else {
            $("#imgFav").attr("src", "https://pccdn.pyar.com/pcimgs/m/favact.png");
            $timeout(function () {
                vm.nextMatch();
            }, 400)
        }
    });

    //function used to remove the favorite tile when click on cancel button
    $scope.$on("favClose", function (e) {
        vm.nextMatch();
    });

    //FLIRT MODULE START  
    vm.FlirtIcnClk = function (memId, Name, favType, Gender, flirtType, index) {
        vm.curMemId = memId;
        vm.curMemTileIndex = index;
        $rootScope.$broadcast("FlirtMbrAct", memId, Name, favType, Gender, flirtType);
        vm.profilePic = vm.getProfilePic(vm.myFavData.profilePic, vm.myFavData.gender);
    };

    $scope.$on("FlirtAddDone", function (e) {
        vm.modifySearchObjFlrt(vm.curMemTileIndex, vm.curMemId);
        $("#imgFlirt" + vm.curMemTileIndex).attr("src", "https://pccdn.pyar.com/pcimgs/m/flirtact.png");  //Changing flirt icon            
    });

    //modifyType 1 for add flirt and 2 for remove flirt
    vm.modifySearchObjFlrt = function (index, memId) {
        if (vm.tabtype == "matches")//Check Tabtype.
            vm.recMatchData[0].flirt = 1;
        else {
            var memTile = vm.myFavData[index];
            if (memTile.memId == memId) {
                vm.myFavData[index].flirt = 1;
            }
        }
    };
    //FLIRT MODULE  END

    //Actions MODULE START
    //Hide Member Start
    vm.memHideCheck = function (memHideId, firstName, gender, index) {
        vm.curMemTileIndex = index;
        $rootScope.$broadcast("MbrOtherAct", memHideId, firstName, gender);
    };
    $scope.$on("hideDone", function (e) {
        if (vm.tabtype == "matches") {
            vm.nextMatch();
        }
    });
    // BLOCK MEMBER START
    $scope.$on("blockDone", function (e, tmId) {
        if (vm.tabtype == "favorite") {
            vm.myFavData.splice(vm.curMemTileIndex, 1);
            if (vm.myFavData.length == 0) {
                //set empty state visible
                vm.pgNo = 1;
                vm.favTabClk();
            }
        }
        else
            vm.nextMatch();
    });
    //BLOCK MEMBER END
    //Actions MODULE END
    /*********************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  RESULT DASHBOARD MEMBER ACTIONS END )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*********************************************************************************************************************************************************************/
    //Page Load
    vm.getRecMatches();
    if ($rootScope.tabtype == "favorite") {
        vm.tabtype = "favorite";
        vm.favTabClk();
        $rootScope.tabtype = "";
    }
    else
        vm.tabtype = "matches";       
    
    //open messanger
    vm.openChat = function (tmId, fn) {
        try {
            if (vm.sId() == 2) {
                vm.mmc = true;
                vm.mmcScrollTo = $(window).scrollTop();
                $rootScope.$broadcast("openMMC", tmId, fn, "DB");
            }
            else
                $rootScope.$broadcast("showPremiumPopup", "RM");
        } catch (e) {
            console.log("Dashboard openChat  --  " + e.message);
            alert("Dashboard openChat  --  " + e.message);
        }
    }

    $scope.$on("closeMMC", function (e, pgRefType) {
        if (pgRefType == "DB") {
            vm.mmc = false;
            $timeout(function () { window.scrollTo(0, vm.mmcScrollTo); }, 0);
        }
    });
}]);