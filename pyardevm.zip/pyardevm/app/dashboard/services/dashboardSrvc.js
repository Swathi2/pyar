﻿angular.module("app").service('dashboardSrvc', ['$http', '$window', function ($http, $window) {
    //Service for getting member Recommended Matches
    this.getRM = function (memberId, pgNo, pgSize, sortBy, sorttype, funCallBack) {
        var url = "https://pcapi.pyar.com/api/dashboard/recmatma/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        GetServiceByURL($http, url, funCallBack);
    };
    //Service for getting member favorites
    this.getMyFav = function (memberId, pgNo, pgSize, sortBy, sorttype, funCallBack) {
        var url = "https://pcapi.pyar.com/api/dashboard/fav/" + memberId + "/" + pgNo + "/" + pgSize + "/" + sortBy + "/" + sorttype;
        GetServiceByURL($http, url, funCallBack);
    };
    //Service to refer a friend for signup
    this.saveReferelEmails = function (mId, email, funCallBack) {
        var data = { "val": email };
        var url = "https://pcapi.pyar.com/api/dashboard/frdref/" + mId;
        PostServiceByURL($http, url, data, funCallBack);
    };
}]);