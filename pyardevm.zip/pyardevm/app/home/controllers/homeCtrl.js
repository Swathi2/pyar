﻿angular.module('app').controller('homeCtrl', ['$window', '$state', function ($window, $state) {
    var vm = this;
    vm.signoutMsg = "";
    if ($window.localStorage.getItem("pgType") != null) {
        var pgType = $window.localStorage.getItem("pgType");

        if (pgType == 1)
            vm.signoutMsg = "You are now signed out. See you soon!";
        else if (pgType == 2 || pgType == 3)
            vm.signoutMsg = "Password successfully reset";
        $window.localStorage.removeItem("pgType");
    }

    vm.signIn = function () {
        showLoader();
        $state.go("signin");
    };
}]);