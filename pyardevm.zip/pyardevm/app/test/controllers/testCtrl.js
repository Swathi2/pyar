﻿angular.module("app").controller('testCtrl', ['getSessionSrvc', '$state', '$interval', '$window', '$filter', function (getSessionSrvc, $state, $interval, $window, $filter) {
    var vm = this;
    //vm.timedifference = getCurrentGMT();
    //alert(getTZIdbyGMT(5.5));


    vm.citytz = "America/Los_Angeles";
    //$interval(function () {
    //vm.time = new Date();
    //vm.time = moment.utc("2017-09-27T08:33:08.22");
    //    vm.time = moment.utc(new Date());
    //    vm.UTC = moment.tz(vm.time, "UTC").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT = moment.tz(vm.time, "Africa/Ouagadougou").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT1 = moment.tz(vm.time, "Europe/Jersey").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT2 = moment.tz(vm.time, "Europe/Budapest").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT3 = moment.tz(vm.time, "Europe/Vilnius").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT4 = moment.tz(vm.time, "Europe/Samara").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT5 = moment.tz(vm.time, "Asia/Karachi").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT530 = moment.tz(vm.time, "Asia/Calcutta").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT6 = moment.tz(vm.time, "Asia/Thimbu").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT7 = moment.tz(vm.time, "Asia/Bangkok").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT8 = moment.tz(vm.time, "Asia/Hong_Kong").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT9 = moment.tz(vm.time, "Asia/Tokyo").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT930 = moment.tz(vm.time, "Australia/North").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT10 = moment.tz(vm.time, "Australia/Lindeman").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT11 = moment.tz(vm.time, "Australia/Sydney").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMT12 = moment.tz(vm.time, "Asia/Kamchatka").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMTMinus11 = moment.tz(vm.time, "Pacific/Midway").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMTMinus10 = moment.tz(vm.time, "Pacific/Honolulu").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMTMinus9 = moment.tz(vm.time, "America/Adak").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMTMinus8 = moment.tz(vm.time, "America/Anchorage").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMTMinus7 = moment.tz(vm.time, "America/Los_Angeles").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMTMinus6 = moment.tz(vm.time, "America/Managua").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMTMinus5 = moment.tz(vm.time, "America/Mexico_City").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMTMinus4 = moment.tz(vm.time, "America/La_Paz").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMTMinus3 = moment.tz(vm.time, "America/Fortaleza").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMTMinus2 = moment.tz(vm.time, "America/Noronha").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //    vm.GMTMinus1 = moment.tz(vm.time, "Atlantic/Cape_Verde").format('MMMM Do YYYY, h:mm:ss a', 'Z');
    //}, 1000);
    vm.curZone = moment.tz.guess();
    //vm.setTimeZone = 1;
    debugger;
    var test = getTimeZones();
    vm.TimeZoneLst = $filter("orderBy")(test,'GMT');
    vm.tzId = getTimeZoneById(120);
    vm.zone = getTZIdByZone("America/New_York");
}]);