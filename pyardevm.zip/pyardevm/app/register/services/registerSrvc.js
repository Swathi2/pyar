﻿app.service('registerSrvc', ['$http', '$window', function ($http, $window) {
    // Email cheking
    this.RegEmailCheck = function (fn, eml, Pwd, funCallBack) {
        var data = { fn: fn, eml: eml, Pwd: Pwd }
        var url = "https://pcapi.pyar.com/api/registersignin/regs";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //registering member
    this.Register = function (memberId, secQ, secA, funCallBack) {
        var data = { id: memberId, secQ: secQ, secA: secA }
        var url = "https://pcapi.pyar.com/api/registersignin/regss";
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.ResendEmlLinkMbl = function (id, funCallBack) {
        var url = "https://pcapi.pyar.com/api/registersignin/regotprs/" + id;
        GetServiceByURL($http, url, funCallBack);
    };

    //pyrregactlnkchk   bool
    this.detailsValidChk = function (memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/registersignin/regsslnkc/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    //email verification and signin member
    this.emlVerificationSignin = function (memberId, gender, genderPref, dob, countryId, cityId, timeZone, funCallBack) {
        if (gender == 1)
            gender = true;
        else
            gender = false;
        if (genderPref == 1)
            genderPref = true;
        else
            genderPref = false;
        var data = { memberId: memberId, gender: gender, genderPref: genderPref, dob: dob, countryId: countryId, cityId: cityId, timeZone: timeZone };
        var url = "https://pcapi.pyar.com/api/registersignin/regact";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //upload blur image
    this.uploadBlrImages = function (memberId, formData, funCallBack) {
        var request = {
            method: 'POST',
            url: 'https://pcapi.pyar.com/api/mbrphotos/prfblrImg/' + memberId,
            data: formData,
            headers: {
                'Content-Type': undefined
            }
        };
        $http(request).success(function (response, status) { funCallBack(response, status); }).error(function () { });
    }

}]);