﻿angular.module("app").controller('registerCtrl', ['getSessionSrvc', 'registerSrvc','$scope', '$window', '$state', function (getSessionSrvc, registerSrvc,$scope, $window, $state) {
    var vm = this;
    vm.name = "";
    vm.nameErr = false;
    vm.nameErrMsg = "";
    vm.email = "";
    vm.emailErr = false;
    vm.emailErrMsg = "";
    vm.password = "";
    vm.pwdErr = false;
    vm.pwdErrMsg = "";
    vm.confirmPassword = "";
    vm.cpwdErr = false;
    vm.cpwdErrMsg = "";
    vm.emailRegexs = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    vm.pwdRegexs = '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,16}$';

    vm.namekeyPress = function () {
        vm.nameErr = false;
    if (vm.name && vm.name.length > 30) {
            vm.name = null;
            vm.nameErr = true;
            vm.nameErrMsg = 'Must be < 30 characters';
        }};
    vm.emailChange = function () {
        vm.emailErr = false;
        if (vm.email) {
            if (vm.email.length > 75) {
                vm.emailErrMsg = "Must be < 75 characters";
                vm.emailErr = true;
                vm.email = "";
            }
        }
    };
    vm.pwdChange = function () {
        vm.pwdErr = false;
        var pwdReg = new RegExp(vm.pwdRegexs);
        vm.pwdVal= pwdReg.test(vm.password);
        if (!vm.pwdVal) 
            vm.pwd = false;         
        else {
            vm.pwd = true;
            vm.pwdErrMsg = "";
        }
        if (vm.password && vm.password.length > 16) {
            vm.password = null;
            vm.pwdErr = true;
            vm.pwdErrMsg = "Must be < 16 characters";
        }
    };
    vm.CnfPwdChange = function () {
        vm.cpwdErr = false;
        if (vm.confirmPassword && vm.confirmPassword.length > 16) {
            vm.confirmPassword = null;
            vm.cpwdErr = true;
            vm.cpwdErrMsg = 'Must be < 16 characters';          
        }
    };

    //password textbox focus event for showing guidlines
    vm.pwdGuidLines = function () {
        $("#pwdgl").css("display", "").css("position", "relative");
    };

    //firstName textbox blur event
    vm.fNameCheck = function () {
        if (vm.name)
            vm.name = vm.name.charAt(0).toUpperCase() + vm.name.slice(1);
        if (!vm.name || vm.name.length == 1) {
            vm.nameErr = true;
            vm.nameErrMsg = 'Please enter a valid first name';
        }
        else
            vm.nameErr = false;
    };

    //Email textbox blur event
    vm.emailCheck = function () {
        if (vm.emailRegexs.test(vm.email)) {
            if (vm.email) {
                vm.email = vm.email.toLowerCase();
                vm.emailErr = false;
                vm.emailErrMsg = '';
            }
        }
        else {
            vm.emailErr = true;
            vm.emailErrMsg = 'Invalid email';
        }
    };

    //password textbox blur event
    vm.pwdCheck = function () {
        if (!vm.pwd) {
            vm.pwdErr = true;
            vm.cpwdErr = false;
            vm.pwdErrMsg = 'Please follow password guidelines';
            vm.password = "";
        }
        else if (vm.password != "" && vm.password != undefined) {
            vm.pwdErr = false;
            if (vm.password == vm.confirmPassword)
                vm.cpwdErr = false;
            else {
                vm.cpwdErr = true;
                if(vm.confirmPassword)
                    vm.cpwdErrMsg = 'Password does not match';
            }
        }
        $("#pwdgl").css("display", "none");
    };

    //confirm password textbox blur event
    vm.cnfPwdCheck = function () {
        if (vm.pwd)
            if (vm.confirmPassword == undefined || vm.password != vm.confirmPassword) {
                vm.cpwdErr = true;
                vm.cpwdErrMsg = 'Password does not match';
            }
            else if (vm.password == vm.confirmPassword)
                vm.cpwdErr = false;
    };

    //function to display error message  after getting api response
    vm.errMsg = function (emailErr, email, emailErrMsg) {
        vm.emailErr = emailErr;
        vm.email = email;
        vm.emailErrMsg = emailErrMsg;
    };

    // function to submit the form after all validation has occurred
    vm.RegisterNext = function () {
        if ($scope.frmRegister.$valid) {
            showLoader();
            registerSrvc.RegEmailCheck(vm.name, vm.email, vm.password, function (response, status) {
                hideLoader();
                if (status == 200) {
                    if (response == 1) 
                        vm.errMsg(true, null, "Email already registered");
                    else if (response) {
                        vm.memreg = { "mid": response, "LoginType": 1 };
                        $window.localStorage.setItem("memreg", getSessionSrvc.pce(JSON.stringify(vm.memreg)));
                        //for security page selected values afer pp && tc redirect
                        $window.localStorage.removeItem("secObj");
                        $state.go('register/security');
                    }
                }
            });
        }
    };

    vm.signClk = function () {
        showLoader();
        $state.go("signin");
    };
}]);