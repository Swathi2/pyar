﻿angular.module("app").controller('registersecCtrl', ['registerSrvc', 'secqnsSrvc', 'socialLgnSrvc', 'getSessionSrvc', '$scope', '$window', '$location', '$state', '$interval', function (registerSrvc, secqnsSrvc, socialLgnSrvc, getSessionSrvc, $scope, $window, $location, $state, $interval) {
    var vm = this;
    vm.lclstrgValues = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("memreg")));
    if (!vm.lclstrgValues) {
        $state.go("register");
        return false;
    }

    vm.dvpgVisble = true;
    vm.dvErrMsg500 = false;
    vm.dvErrMsg404 = false;
    vm.memberId = vm.lclstrgValues.mid;

    /**********************************************************
                    pyar email security page start
    **********************************************************/
    vm.selQstion = "";
    vm.selQstionval = "";
    vm.secAns = "";
    vm.ageCnfrm = false;
    vm.agree = false;
    vm.secAnsErr = false;
    vm.resendEmailVal = true;
    vm.vrfyOtp = true;
    //function for get security questions
    vm.getSecQns = function () {
        secqnsSrvc.securityQuns(function (response, status) {
            vm.secQnsRes = response;
        });
    };
    vm.getSecQns();

    //Enble Anser text box
    vm.selQtn = function () {
        vm.selQstion = vm.secQtnval.txt;
        vm.selQstionval = vm.secQtnval.val;
    };

    //Security answer length check
    vm.secAnsChk = function () {
        vm.secAnsErrMsg = "";
        if (vm.secAns.length > 75) {
            vm.secAnsErr = true;
            vm.secAnsErrMsg = "Must be <75 characters";
            vm.secAns = "";
        }

    };
    //reset security question and empty answer
    vm.resetQstion = function () {
        vm.secAns = "";
        vm.secQtnval = "";
        vm.selQstion = "";
        vm.selQstionval = "";
        vm.secAnsErrMsg = "";
    };

    //show privacy policy and terms of use
    // type - 1 for privacy-policy
    // type - 2 for terms of use
    vm.showPolicies = function (type) {
        var secObj = { "secQ": vm.selQstion, "secQVal": vm.selQstionval, "secA": vm.secAns, "ageCnfrm": vm.ageCnfrm, "agree": vm.agree };
        $window.localStorage.setItem("secObj", getSessionSrvc.pce(JSON.stringify(secObj)));
        if (type == 1)
            $state.go("privacy-policy");
        else
            $state.go("terms-conditions");
    };

    //used to check if he redirect to policy pages and came back bind selected values
    vm.checkPolicies = function () {
        if ($window.localStorage.getItem("secObj")) {
            var secObj = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("secObj")))
            vm.selQstion = secObj.secQ;
            vm.selQstionval = secObj.secQVal;
            vm.secAns = secObj.secA;
            vm.ageCnfrm = secObj.ageCnfrm;
            vm.agree = secObj.agree;
            $window.localStorage.removeItem("secObj");
        }
    };
    vm.checkPolicies();

    //submit form click function
    vm.submitForm = function () {
        if ($scope.frmSecurity.$valid) {
            showLoader();
            registerSrvc.Register(vm.memberId, vm.selQstionval, vm.secAns, function (response, status) {
                hideLoader();
                //1: invalid id, 2: no recored found (or) loginType mismatch ,3: email sent fail
                if (status == 200) {
                    if (response == 1 || response == 2) {
                        $window.localStorage.removeItem("memreg");
                        vm.dvpgVisble = false;
                        vm.dvErrMsg404 = true;
                    }
                    else if (response == 3) {
                        $window.localStorage.removeItem("memreg");
                        vm.dvpgVisble = false;
                        vm.dvErrMsg500 = true;
                    }
                    else {
                        vm.memreg = { "mid": response, "LoginType": 1 };
                        $window.localStorage.setItem("memreg", getSessionSrvc.pce(JSON.stringify(vm.memreg)));
                        $state.go('register/security/email');
                    }
                }
            });
        }
    };
    /**********************************************************
                    pyar email security page end
    **********************************************************/

    /**********************************************************
                        otp verify page start
    **********************************************************/
    //back button click function
    vm.backPage = function () {
        if (vm.lclstrgValues.LoginType == 1)
            $state.go("register/security");
        else
            $state.go("register/social/security");
    }

    //keyPress function when user click on enter
    vm.keyPress = function (txtIndexId, event) {
        if (event.keyCode == 13)
            vm.keyUp(txtIndexId, event);
    };  
    //key Up function when code enters in textboxes auto verify
    vm.keyUp = function (txtIndexId, event) {                                  
            var keyCode = event.keyCode;
            if ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105) || keyCode == 13) {
                vm.errorOtpMsg = "";
                vm.otpVerify();              
                //focus next elements
                txtIndexId++;
                $('input[tabindex=' + (txtIndexId) + ']').focus();
            }      
    };
    vm.otpVerify = function () {
        if (vm.vrfyOtp == true && vm.OtpDigit1 && vm.OtpDigit2 && vm.OtpDigit3 && vm.OtpDigit4) {
            showLoader();
            vm.vrfyOtp = false;
            var regData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("memreg")));
            if (regData != null) {
                vm.memberId = regData.mid;
                var code = vm.OtpDigit1 + vm.OtpDigit2 + vm.OtpDigit3 + vm.OtpDigit4;
                var otpCheckObj = { id: vm.memberId, otpCode: code };
                socialLgnSrvc.otpverify(otpCheckObj, function (response, status) {
                    if (status == 200) {
                        vm.vrfyOtp = true;
                        if (response == 1 || response == 2 || response == 5)// invalid id or member
                        {
                            $window.localStorage.removeItem("memreg");
                            vm.dvpgVisble = false;
                            vm.dvErrMsg404 = true;
                        }
                        else if (response == "3")//otp expired
                        {
                            vm.otpErr = true;
                            vm.errorOtpMsg = "This code expired. Please fill in the code within 24 hours.";
                            vm.OtpDigit1 = vm.OtpDigit2 = vm.OtpDigit3 = vm.OtpDigit4 = "";
                            $("#OtpDigit1").focus();
                        }
                        else if (response == "4")//wrong otp
                        {
                            vm.otpErr = true;
                            vm.errorOtpMsg = "That’s incorrect. Please try again.";
                            vm.OtpDigit1 = vm.OtpDigit2 = vm.OtpDigit3 = vm.OtpDigit4 = "";
                            $("#OtpDigit1").focus();
                        }
                        else if (response) { //otp verfied success
                            //vm.memreg = { "mid": response, "LoginType": 1 };
                            vm.memreg = { "mid": response };
                            $window.localStorage.setItem("memreg", getSessionSrvc.pce(JSON.stringify(vm.memreg)));
                            $state.go('register/security/details');
                        }
                        hideLoader();
                    }
                });
            }
        }
    };

    //function for resending otp 
    vm.resendEmail = function () {
        showLoader();       
        //wait 30 sec after first click on resend email
        startInterval(vm, $interval);
        var regData = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("memreg")));
        if (regData != null) {
            vm.memberId = regData.mid;
            registerSrvc.ResendEmlLinkMbl(vm.memberId, function (response, status) {
                if (status == 200) {
                    if (response == 1 || response == 2) {
                        alert("Invalid Request");
                        $window.localStorage.removeItem("memreg");
                        $location.path("/register.html");
                    }
                    else if (response == 3) {
                        vm.dvpgVisble = false;
                        vm.dvErrMsg500 = true;
                    }
                    else if (response) {
                        vm.memreg = { "mid": response };
                        $window.localStorage.setItem("memreg", getSessionSrvc.pce(JSON.stringify(vm.memreg)));
                    }
                }
                hideLoader();
            });
        }
    };
    /**********************************************************
                        otp verify page end
    **********************************************************/
}]);