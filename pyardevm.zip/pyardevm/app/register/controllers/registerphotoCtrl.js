﻿angular.module("app").controller('registerphotoCtrl', ['selfprofileSrvc', 'getSessionSrvc', '$scope', '$window', '$http', '$location', '$filter', '$rootScope', '$state', '$timeout', '$rootScope', function (selfprofileSrvc, getSessionSrvc, $scope, $window, $http, $location, $filter, $rootScope, $state, $timeout, $rootScope) {
    //Functionality started by prasanna
    vm = this;                  
    vm.addPhtodtls = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("addPhtodtls")));
    if (!vm.addPhtodtls) {
        $location.path("/register.html");
        return false;
    }   
    vm.mId = function () { return getSessionSrvc.p_mId(); };
    vm.gender = function() { return getSessionSrvc.p_gndr();};
    vm.fname = function () { return getSessionSrvc.p_fn(); };
    vm.profilePicExist = function () { return getSessionSrvc.p_ppicexst(); }
    $rootScope.dvpgVisble = true;
    vm.imageStorage = "https://pccdn.pyar.com";
    vm.profilePic = vm.imageStorage + getSessionSrvc.p_ppic();
    vm.dob = calculateAge(vm.addPhtodtls.dob);
    vm.location = vm.addPhtodtls.location;
    vm.profileText = "Let's add a profile picture.";
    if (vm.gender() == true) {
        vm.genSymbol = "https://pccdn.pyar.com/pcimgs/m/male-syn.png";
        vm.profileText = "Well, hellooo handsome!"
    } else {
        vm.genSymbol = "https://pccdn.pyar.com/pcimgs/m/female-syn.png";
        vm.profileText = "Well, hellooo gorgeous!";
    }
    if (vm.profilePicExist() == true) {
        vm.emptyprofile = false;
        vm.redSymbol = true;
    }
    else
        vm.emptyprofile = true;

    var croppie;
    vm.maxWidth = 1920;
    vm.maxHeight = 1920;
    vm.minWidth = 400;
    vm.minHeight = 400;
    vm.crpDone = false;
    var width = (window.innerWidth > 0) ? window.innerWidth : screen.width  //get screen width to set cropper width && height dynamically
    $('.crprTxt').css('top', width + 90);// Dynamic position for cropper text(Reposition Photo)
    vm.showPhotoActions = function () {
        $("#glryActions").modal('show');
    };

    vm.skipClk = function () {
        $state.go("freetrail");
    };

    vm.navtoDashboard = function () {
        $window.localStorage.removeItem("addPhtodtls");
        $state.go("freetrail");
    };
  
    vm.profileRemove = function () {
        showLoader();
        if (vm.mpId) {
            selfprofileSrvc.ProfilePhotoD(vm.mId(), vm.mpId, function (response, status) {
                vm.emptyprofile = true;
                vm.redSymbol = false;
                vm.profilePic = vm.profilePic + "?v=" + new Date().valueOf();
                hideLoader();
            });
        }
        else {
            selfprofileSrvc.mbrProfilePhotoD(vm.mId(), function (response, status) {
                vm.emptyprofile = true;
                vm.redSymbol = false;
                vm.profilePic = vm.profilePic + "?v=" + new Date().valueOf();
                hideLoader();
            });
        }
    };

    $scope.imageUpload = function (event) {
        showLoader();
        var files = event.target.files;
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var reader = new FileReader();
            var upldSuccess = false;
            $rootScope.srcType = 1;
            reader.onload = function (e) {
                $("<img/>").load(function () {
                    vm.imgRealWidth = this.width;
                    vm.imgRealHeight = this.height;

                    if (vm.imgRealWidth < vm.minWidth || vm.imgRealHeight < vm.minHeight) {
                        $("#photoSmallpop").modal('show'); //need show error popup
                        hideLoader();
                    }
                    else {
                        $('#cropImg').croppie('destroy');
                        vm.photoPath = e.target.result;                        
                        vm.imgHeight = vm.imgRealHeight;
                        vm.imgwidth = vm.imgRealWidth;

                        if (vm.imgRealWidth > vm.imgRealHeight) {
                            if (vm.imgRealWidth > vm.maxWidth) {
                                vm.imgHeight = vm.imgRealHeight * (vm.maxWidth / vm.imgRealWidth);
                                vm.imgwidth = vm.maxWidth;
                            }
                        } else {
                            if (vm.imgRealHeight > vm.maxHeight) {
                                vm.imgwidth = vm.imgRealWidth * (vm.maxHeight / vm.imgRealHeight);
                                vm.imgHeight = vm.maxHeight;
                            }
                        }                                          
                        //if browser type is an ios device the below code get executed
                        if (getBrowserType() == true) {                          
                            var options = {
                                canvas: true
                            };
                            vm.imgDataExifProp = false;
                            loadImage.parseMetaData(file, function (data) {
                                if (data.exif) {
                                    vm.imgDataExifProp = true;
                                    options.orientation = data.exif.get('Orientation');
                                    loadImage(file, getOrientImageResponse, options);
                                } else {
                                    CropPBPhoto(e.target.result, width - 35, width - 35, $timeout);
                                }
                            });
                        } else {
                            CropPBPhoto(e.target.result, width - 35, width - 35, $timeout);
                        }
                    }
                    $("#fupPhtGlry").val(null);//clear the image upload path for same image uploading.
                }).attr("src", e.target.result);
            }
            reader.readAsDataURL(file);
        
        }
    };

    var getOrientImageResponse = function (img) {
        if (vm.imgDataExifProp == true)
            CropPBPhoto(img.toDataURL(), width - 35, width - 35, $timeout);
    };
    /************************************************************** ADD PHOTO FROM SOCIAL**************************************************************/
    vm.addPhoto = function () {
        //gallery photo module
        $rootScope.dvAlbumPhotos = false;
        $rootScope.dvpgVisble = true;
        //profile photo module
        if ($rootScope.imgPath != "" && $rootScope.realWidth >= vm.minWidth && $rootScope.realHeight >= vm.minHeight) {
            $("#dvAlbumPhotos").css("display", "none");
            $("#photosPopup").modal("hide");
            vm.photoPath = $rootScope.imgPath;
            vm.imgwidth = $rootScope.realWidth;
            vm.imgHeight = $rootScope.realHeight;
            $('#cropImg').croppie('destroy');
            CropPBPhoto($rootScope.imgPath, width - 35, width - 35, $timeout);            
        }
    };

    //save image after cropping
    vm.saveCroppedImg = function () {
        showLoader();
        vm.crpDone = true;
        $rootScope.dvAlbumPhotos = false;
        $rootScope.dvpgVisble = true;
        if ($rootScope.srcType == 1) {
            UploadProfileImage(vm.photoPath);
        } else {
            //from instagram && facebook uploading
            convertFileToDataURLviaFileReader(vm.photoPath, function (originalImgResponse) {
                UploadProfileImage(originalImgResponse);
            });
        }
    };

    function UploadProfileImage(originalImgResponse) {
        var data = new FormData();
        CroppedImageResult(430, 430, function (img430Response) {
            CroppedImageResult(200, 200, function (img200Response) {
                CroppedImageResult(100, 100, function (img100Response) {
                    resizingImage(originalImgResponse, function (resizeResponse) {
                        base64ToBlobFileConvertion(resizeResponse, function (originalImgBlob) {
                            base64ToBlobFileConvertion(img430Response, function (img430Blog) {
                                base64ToBlobFileConvertion(img200Response, function (img200Blog) {
                                    base64ToBlobFileConvertion(img100Response, function (img100Blog) {
                                        createBlurImage((img430Response), function (blurResponseBlob) {
                                            data.append("originalImgBlob", originalImgBlob);
                                            data.append("img430Blog", img430Blog);
                                            data.append("img200Blog", img200Blog);
                                            data.append("img100Blog", img100Blog);
                                            data.append("blurResponseBlob", blurResponseBlob);
                                            //need to set action type 1 for adding new photo 2 for update existing photo                                        
                                            selfprofileSrvc.uploadPrflImages(vm.mId(), 1, data, function (response, status) {
                                                vm.crpDone = false;
                                                if (status == 200) {
                                                    vm.profilePic = vm.imageStorage + response.picPath + "?v=" + new Date().valueOf();
                                                    $("#srcAdjustProfilePhotoPopup").modal("hide");
                                                    vm.emptyprofile = false;
                                                    vm.redSymbol = true;
                                                    vm.mpId = response.mpId;
                                                    history.pushState(null, null, location.pathname);//change visible url with out refreshing page.                                                   
                                                    hideLoader();
                                                }
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    };
}]);