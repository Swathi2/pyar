﻿angular.module("app").controller('registerdtlsCtrl', ['getSessionSrvc', 'registerSrvc', '$scope', '$location', '$window', '$rootScope', '$state', '$timeout', function (getSessionSrvc, registerSrvc, $scope, $location, $window, $rootScope, $state, $timeout) {
    var vm = this;
    vm.lclstrgValues = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("memreg")));
    if (!vm.lclstrgValues) {
        $location.path("/register.html");
        return false;
    }
    vm.memberId = vm.lclstrgValues.mid;
    vm.timeZone = getTZIdByZone(null);
    vm.dtlsScrollTo = 0;
    // Details page Link cheking service calling starts
    vm.pgAccessChk = function () {
        registerSrvc.detailsValidChk(vm.memberId, function (response, status) {
            if (response == 1 || response == 2 || response == 4) {
                $window.localStorage.removeItem("memreg");//Remove add photo details.
                vm.dvpgVisble = false;
                vm.dvErrMsg404 = true;
            }
            else if (response == 3) {
                alert("Already Registered");
                $location.path("/");
                return false;
            }
        });
    };
    vm.pgAccessChk();

    vm.showloc = false;
    vm.dvpgVisble = true;
    vm.dvErrMsg500 = false;
    vm.dvErrMsg404 = false;
    vm.DOBPlaceHolder = "MM/DD/YYYY";
    vm.countryId = "";
    vm.cityId = "";

    //Dynamic binding for the date picker(restricting ages from 18 to 130 years)
    vm.setDefaultDate = function () {
        var today = new Date();
        var maxAge = 18;
        var minAge = 130;
        vm.maxAge = new Date(today.getFullYear() - maxAge, today.getMonth(), today.getDate());
        vm.minAge = new Date(today.getFullYear() - minAge, today.getMonth(), today.getDate());
        //vm.dateOfBirth = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
    };
    vm.setDefaultDate();

    //Date of birth change function
    vm.dobChange = function (val) {
        var today = new Date();
        var dateOfBirth = new Date(val);
        var age = today.getFullYear() - dateOfBirth.getFullYear();
        var m = today.getMonth() - dateOfBirth.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < dateOfBirth.getDate())) {
            age--;
        }
        return age;
    };

    //button disabled if all fields are not entered 
    vm.dobValidation = function (val) {
        var enteredAge = vm.dobChange(val);
        if (enteredAge < 18 || enteredAge > 130) {
            vm.dobErr = true;
            vm.dobErrmsg = "Age must be 18 - 130";
        }
        else {
            vm.dobErr = false;
            vm.dobErrmsg = "";
        }
    };
    vm.dobValidation(vm.dateOfBirth);

    //button disabled if all fields are not entered 
    vm.btnDisabled = function (val) {
        if ((vm.dobErr != false) ||(!vm.dateOfBirth) || (!vm.matchA) || (!vm.matchB) || (!vm.countryId)) {
            return true;
        }
        else {
            return false;
        }
    };

    //set Default location
    vm.resetLoc = function () {
        vm.countryId = "";
        vm.cityId = "";
    };

    //Next button click function
    vm.Register = function () {
        showLoader();
        registerSrvc.emlVerificationSignin(vm.memberId, parseInt(vm.matchA), parseInt(vm.matchB), vm.dateOfBirth, vm.countryId, vm.cityId, vm.timeZone, function (response, status) {
            hideLoader();
            if (status == 200) {
                $window.localStorage.removeItem("memreg");
                if (response == 1 || response == 2 || response == 3 || response == 4) {
                    vm.dvpgVisble = false;
                    vm.dvErrMsg404 = true;
                }
                else if (response == 5) {
                    alert("Already Registered");
                    $location.path("/");
                    return false;
                }
                else if (getSessionSrvc.validateSessionInfo(response)) {
                    getSessionSrvc.setLoginData(response);
                    var mId = getSessionSrvc.p_mId();
                    var loginType = getSessionSrvc.p_lt();
                    var profilePicExist = getSessionSrvc.p_ppicexst();
                    if (mId && profilePicExist && (loginType == 2 || loginType == 3)) {
                        var profilePicPath = "https://pccdn.pyar.com" + getSessionSrvc.p_ppic();
                        convertFileToDataURLviaFileReader(profilePicPath, function (img430Response) {
                            createBlurImage((img430Response), function (blurResponseBlob) {
                                var data = new FormData();
                                data.append("blurResponseBlob", blurResponseBlob);
                                registerSrvc.uploadBlrImages(mId, data, function (response, status) {
                                    processLogin();
                                });
                            });
                        });
                    } else
                        processLogin();
                }
            }
            else
                alert("unable to process request");
        });
    };

    function processLogin() {
        var pfData = { "dob": vm.dateOfBirth, "location": vm.location };
        $window.localStorage.setItem("addPhtodtls", getSessionSrvc.pce(JSON.stringify(pfData)));//for add photo details.                  
        $window.localStorage.setItem("P_ftrl", 1);// for freetrail access
        $state.go("registerAddPhoto");
    }

    vm.selectLoc = function () {
        vm.dtlsScrollTo = $(window).scrollTop();
        vm.showloc = true;
        $rootScope.$broadcast("showLocation", "regLoc");
    };

    $scope.$on("countryBind", function (e, locId, countryId, data) {
        vm.showloc = false;
        vm.bindLocation(data);
        $timeout(function () { window.scrollTo(0, vm.dtlsScrollTo); }, 0);
    });

    $scope.$on("countryUnBind", function (locId) {
        vm.showloc = false;
        $timeout(function () { window.scrollTo(0, vm.dtlsScrollTo); }, 0);
    });

    //Bind Location
    vm.bindLocation = function (data) {
        vm.countryId = data.countryId;
        vm.cityId = data.cityId;
        vm.location = data.cityName + ", " + data.stateName;
    };

    function convertFileToDataURLviaFileReader(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.onload = function () {
            var reader = new FileReader();
            reader.onloadend = function () {
                callback(reader.result);
            }
            reader.readAsDataURL(xhr.response);
        };
        xhr.open('GET', url);
        xhr.responseType = 'blob';
        xhr.send();
    }

    function createBlurImage(imgSrc, callBackFun) {
        var canvas = document.createElement('canvas');
        canvas.setAttribute('id', "backgroud_div");
        $(canvas).blurIt(imgSrc, 20, function (resonse) {
            callBackFun(resonse);
        });
    }

}]);