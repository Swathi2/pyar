//Controllers Section
var homeCtrl = '/app/home/controllers/homeCtrl.js';
var registerCtrl = '/app/register/controllers/registerCtrl.js'
var registersecCtrl = '/app/register/controllers/registersecCtrl.js';
var registerdtlsCtrl = '/app/register/controllers/registerdtlsCtrl.js';
var registerphotoCtrl = '/app/register/controllers/registerphotoCtrl.js';
var freetrailCtrl = '/app/register/controllers/freetrailCtrl.js';
var signinCtrl = '/app/signin/controllers/signinCtrl.js';
var forgotpwdCtrl = '/app/signin/controllers/forgotpwdCtrl.js';
var sociallgnCtrl = '/app/social/controllers/sociallgnCtrl.js';
var registersocialsecCtrl = '/app/social/controllers/registersocialsecCtrl.js';
var registersocialemlCtrl = '/app/social/controllers/registersocialemlCtrl.js';
var registerdSocialCtrl = '/app/social/controllers/registerdSocialCtrl.js';
var dashboardCtrl = '/app/dashboard/controllers/dashboardCtrl.js';
var abthlpCtrl = '/app/aboutHelp/controllers/abthlpCtrl.js';
var ppCtrl = '/app/policies/controllers/ppCtrl.js';
var tcCtrl = '/app/policies/controllers/tcCtrl.js';
var helpfaqsCtrl = '/app/aboutHelp/controllers/helpfaqsCtrl.js';
var refrfrndCtrl = '/app/referAfriend/controllers/refrfrndCtrl.js';
var abtusCtrl = '/app/aboutus/controllers/abtusCtrl.js';
var accountCtrl = '/app/account/controllers/accountCtrl.js';
var blockUsersCtrl = '/app/account/controllers/blockUsersCtrl.js';
var chgEmailCtrl = '/app/account/controllers/chgEmailCtrl.js';
var chgPwdCtrl = '/app/account/controllers/chgPwdCtrl.js';
var chgNameCtrl = '/app/account/controllers/chgNameCtrl.js';
var delActEmlCtrl = '/app/account/controllers/delActEmlCtrl.js';
var delActCtrl = '/app/account/controllers/delActCtrl.js';
var matchCtrl = "/app/profile/others/controllers/matchCtrl.js";
var selfprofileCtrl = '/app/profile/self/controllers/selfprofileCtrl.js';
var selfmatchprefCtrl = '/app/profile/self/controllers/selfmatchprefCtrl.js';
var msgcenterCtrl = '/app/messages/controllers/msgcenterCtrl.js';
var msgcentereditCtrl = '/app/messages/controllers/msgcentereditCtrl.js';
var chatConversationCtrl = '/app/messages/controllers/chatConversationCtrl.js';
var newMessageCtrl = '/app/messages/controllers/newMessageCtrl.js';
var notificationsCtrl = '/app/notifications/controllers/notificationsCtrl.js';
var advsrchCtrl = '/app/search/controllers/advsrchCtrl.js';
var advsrchbasicsCtrl = '/app/search/controllers/advsrchbasicsCtrl.js';
var advsrchaboutCtrl = '/app/search/controllers/advsrchaboutCtrl.js';
var advsrchaprnceCtrl = '/app/search/controllers/advsrchaprnceCtrl.js';
var editprofileCtrl = '/app/profile/self/controllers/editprofileCtrl.js';
var advsrchlifestyleCtrl = '/app/search/controllers/advsrchlifestyleCtrl.js';
var advsrchhobbiesCtrl = '/app/search/controllers/advsrchhobbiesCtrl.js';
var advsrchsavedCtrl = '/app/search/controllers/advsrchsavedCtrl.js';
var advsrchresultsCtrl = '/app/search/controllers/advsrchresultsCtrl.js';
var advsrchprsnltyECtrl = '/app/search/controllers/advsrchprsnltyECtrl.js';
var othersactionreportCtrl = '/app/profile/others/controllers/othersactionreportCtrl.js';
var dashboardSrvc = '/app/dashboard/services/dashboardSrvc.js';
var basicsrchCtrl = '/app/search/controllers/basicsrchCtrl.js';
var searchactionreportCtrl = '/app/search/controllers/searchactionreportCtrl.js';
var dashboardactionreportCtrl = '/app/dashboard/controllers/dashboardactionreportCtrl.js';
var basicsearchactionreportCtrl = '/app/search/controllers/basicsearchactionreportCtrl.js';
var countryIntlCtrl = "/app/common/controllers/countryIntlCtrl.js";
var epAbtCtrl = '/app/profile/self/controllers/epAbtCtrl.js';
var epprsnaltyCtrl = '/app/profile/self/controllers/epprsnaltyCtrl.js';
var epbioCtrl = '/app/profile/self/controllers/epbioCtrl.js';
var epApprnceCtrl = '/app/profile/self/controllers/epApprnceCtrl.js';
var eplfstylCtrl = '/app/profile/self/controllers/eplfstylCtrl.js';
var eplhbysCtrl = '/app/profile/self/controllers/eplhbysCtrl.js';
var epgallryCtrl = '/app/profile/self/controllers/epgallryCtrl.js';
var socialPhotosCtrl = '/app/social/controllers/socialPhotosCtrl.js';
var mbrActCtrl = "/app/common/controllers/mbrActCtrl.js";
var mpVrfyCtrl = "/app/mpvrfy/controllers/mpVrfy.js";
//Controllers Section End

//Services Section
var registerSrvc = '/app/register/services/registerSrvc.js';
var secqnsSrvc = '/app/common/services/secqnsSrvc.js';
var ppSrvc = '/app/policies/services/ppSrvc.js';
var signinSrvc = 'app/signin/services/signinSrvc.js';
var forgotpwdSrvc = '/app/signin/services/forgotpwdSrvc.js';
var tcSrvc = '/app/policies/services/tcSrvc.js';
var socialLgnSrvc = '/app/social/services/socialLgnSrvc.js';
var accountSrvc = '/app/account/services/accountSrvc.js';
var helpfaqsSrvc = '/app/aboutHelp/services/helpfaqsSrvc.js';
var selfprofileSrvc = '/app/profile/self/services/selfprofileSrvc.js';
var selfmatchprefSrvc = '/app/profile/self/services/selfmatchprefSrvc.js';
var prflphotodataSrvc = '/app/profile/self/services/prflphotodataSrvc.js';
var othersprofileSrvc = '/app/profile/others/services/othersprofileSrvc.js';
var advsrchSrvc = '/app/search/services/advsrchSrvc.js';
var basicsrchSrvc = '/app/search/services/basicsrchSrvc.js';
var countryIntlSrvc = "/app/common/services/countryIntlSrv.js";
var socialphotosSrvc = '/app/social/services/socialphotosSrvc.js';
var mbrActSrvc = "/app/common/services/mbrActSrvc.js";
//Services Section End

//Directives Section
var sliderDrctve = "/app/profile/self/directives/slider.js";
//Directives Section end

//Filters section 
var selfprofileFltr = "/app/profile/self/filters/selfprofileFltr.js";
//Filters section end

//CSS section
var swiperCss = "/styles/swiper.css";
var imgCropCss = "/styles/croppie.css";
var slicksliderCss = '/styles/slick-theme.css';
var calendarCss = '/styles/calendar.css';
//CSS section end

//Scripts section
var fblgn = '/app/social/scripts/fblgn.js';
var matchAnalysis = '/app/profile/others/scripts/matchAnalysis.js';
var calendarJs = '/scripts/calendar.js';
var infinitescroll = '/scripts/ng-infinite-scroll.min.js';
var selfprofileSrpt = '/app/profile/self/scripts/selfprofileSrpt.js';
var imgCropSrpt = "app/profile/self/scripts/croppie.js";
var blurIt = "app/profile/self/scripts/blurIt.js";
var resizeIt = "app/profile/self/scripts/resizeit.js";
var imgOrient = "/app/profile/self/scripts/orient.js";
var swiperSrpt = "/scripts/swiper.min.js";
var slicksliderJS = '/scripts/slick.min.js';
var braintreeWeb = "https://js.braintreegateway.com/js/braintree-2.32.1.min.js";
var braintreeClient = "https://js.braintreegateway.com/web/3.22.2/js/client.min.js";
//Scripts section end

var app = angular.module("app", ["ui.router", "oc.lazyLoad", "ngSanitize", "angularjs-crypto", "ngCookies"]);

////for session encryption and ecryption.
app.run(['cfCryptoHttpInterceptor', '$rootScope', '$interval', '$document', '$window', '$location', 'abndnSrvc', 'msgSrvc', function (cfCryptoHttpInterceptor, $rootScope, $interval, $document, $window, $location, abndnSrvc, msgSrvc) {
    $rootScope.base64Key = CryptoJS.enc.Hex.parse('0123456789abcdef0123456789abcdef')
    $rootScope.iv = CryptoJS.enc.Hex.parse('abcdef9876543210abcdef9876543210');
    $rootScope.ntfnData = [];

    msgSrvc.connectServer(false);

    //to check if user has internet connection
    $rootScope.online = navigator.onLine;
    $window.addEventListener("offline", function () {
        $rootScope.$apply(function () {
            $rootScope.online = false;           
            $(".psfixdbtm").css({ 'z-index': '0' });
            $(".nvtgle").css({ 'z-index': '0' });
            $rootScope.$broadcast("offline");
        });
    }, false);

    $window.addEventListener("online", function () {
        $rootScope.$apply(function () {
            $rootScope.online = true;
            $(".psfixdbtm").css({ 'z-index': '1' });
            $(".nvtgle").css({ 'z-index': '11' });
            $rootScope.$broadcast("online");
        });
    }, false);
}]);

app.config(function ($stateProvider, $locationProvider, $urlRouterProvider, $urlMatcherFactoryProvider) {
    $urlRouterProvider.otherwise('/'); // default route
    $urlMatcherFactoryProvider.caseInsensitive(true); // Remove casesensitive from urls
    $locationProvider.html5Mode(true); // Remove # from url

    $stateProvider
         //This state contains header & footer
        .state("masterpage", {
            url: "",
            templateUrl: "/app/common/templates/masterpage.html",
            abstract: true,
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app' }]); }]
            }
        })

		.state("home", {
		    url: "/",
		    templateUrl: "app/home/templates/home.html",
		    controller: 'homeCtrl',
		    controllerAs: 'homeCtrlAs',
		    resolve: {
		        lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
		            getSessionSrvc.checkPgSec('outpg', event);
		            return $ocLazyLoad.load([{ name: 'app', files: [homeCtrl, fblgn, socialLgnSrvc, sociallgnCtrl, selfprofileSrvc] }]);
		        }]
		    }
		})

		.state("register", {
		    url: "/register.html",
		    templateUrl: "app/register/templates/register.html",
		    controller: 'registerCtrl',
		    controllerAs: 'registerCtrlAs',
		    resolve: {
		        lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
		            getSessionSrvc.checkPgSec('outpg', event);
		            return $ocLazyLoad.load([{ name: 'app', files: [registerCtrl, registerSrvc] }]);
		        }]
		    }
		})

        .state("register/security", {
            url: "/register/security.html",
            templateUrl: "app/register/templates/registersec.html",
            controller: 'registersecCtrl',
            controllerAs: 'registersecCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{
                        name: 'app', files: [registersecCtrl, registerSrvc, secqnsSrvc, socialLgnSrvc]
                    }]);
                }]
            }
        })

        .state("register/security/social/email", {
            url: "/register/security/social/email.html",
            templateUrl: "app/register/templates/registersocialeml.html",
            controller: 'registersocialemlCtrl',
            controllerAs: 'registersocialemlCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [registersocialemlCtrl, socialLgnSrvc] }]); }]
            }
        })
        .state("registerd/social/user", {
            url: "/register/social/registered.html",
            templateUrl: "app/register/templates/registerdsocial.html",
            controller: 'registerdSocialCtrl',
            controllerAs: 'registerdSocialCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) { return $ocLazyLoad.load([{ name: 'app', files: [registerdSocialCtrl] }]); }]
            }
        })

        .state('register/social/security', {
            url: '/register/social/security.html',
            templateUrl: 'app/register/templates/registersocialsec.html',
            controller: 'registersocialsecCtrl',
            controllerAs: 'registersocialsecCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{ name: 'app', files: [registersocialsecCtrl, socialLgnSrvc] }]);
                }]
            }
        })

        .state('register/security/email', {
            url: '/register/security/email.html',
            templateUrl: 'app/register/templates/registeracteml.html',
            controller: 'registersecCtrl',
            controllerAs: 'registersecCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{ name: 'app', files: [registersecCtrl, registerSrvc, secqnsSrvc, socialLgnSrvc] }]);
                }]
            }
        })

        .state("register/security/details", {
            url: "/register/security/details.html",
            templateUrl: "app/register/templates/registerdtls.html",
            controller: 'registerdtlsCtrl',
            controllerAs: 'registerdtlsCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{
                        name: 'app', files: [registerdtlsCtrl, registerSrvc, socialLgnSrvc, signinSrvc, countryIntlCtrl, countryIntlSrvc, blurIt]
                    }]);
                }]
            }
        })

        .state("freetrail", {
            url: "/freetrail.html",
            templateUrl: "app/register/templates/freetrail.html",
            controller: 'freetrailCtrl',
            controllerAs: 'freetrailCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$window', '$location', function ($ocLazyLoad, getSessionSrvc, $window, $location, enent) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    if ($window.localStorage.getItem("P_ftrl") != 1)
                        $location.path('/dashboard.html');
                    return $ocLazyLoad.load([{ name: 'app', files: [freetrailCtrl] }]);
                }]
            }
        })

        .state("registerAddPhoto", {
            url: "/registeraddphoto.html",
            templateUrl: "app/register/templates/registerAddPhoto.html",
            controller: 'registerphotoCtrl',
            controllerAs: 'registerphotoCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [imgCropSrpt, resizeIt,imgOrient, imgCropCss, selfprofileSrvc, registerphotoCtrl, socialPhotosCtrl, socialphotosSrvc, prflphotodataSrvc, blurIt, fblgn] }]);
                }]
            }
        })

        .state("signin", {
            url: "/signin.html",
            templateUrl: "app/signin/templates/signin.html",
            controller: 'signinCtrl',
            controllerAs: 'signinCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [signinCtrl, signinSrvc] }]);
                }]
            }
        })

        .state("signinpwdrotation", {
            url: "/signinpwdrotation.html",
            templateUrl: "app/signin/templates/signinpwdrotation.html",
            controller: 'signinCtrl',
            controllerAs: 'signinCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', '$location', '$window', function ($ocLazyLoad, $location, $window) {
                    if ($window.sessionStorage.getItem("8B3414FB") == null)
                        $location.path('/signin.html');
                    return $ocLazyLoad.load([{ name: 'app', files: [signinCtrl, signinSrvc] }])
                }]
            }
        })

        .state("forgotpwd", {
            url: "/forgotpwd.html",
            templateUrl: "app/signin/templates/forgotpwd.html",
            controller: 'forgotpwdCtrl',
            controllerAs: 'forgotpwdCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [forgotpwdSrvc, forgotpwdCtrl, calendarCss, calendarJs] }]);
                }]
            }
        })

        .state('forgotpwdsec', {
            url: '/forgotpwdsec.html',
            templateUrl: 'app/signin/templates/forgotpwdsec.html',
            controller: 'forgotpwdCtrl',
            controllerAs: 'forgotpwdCtrlAs',
            resolve: {
                "lazy": ['$ocLazyLoad', 'getSessionSrvc', '$location', '$window', function ($ocLazyLoad, getSessionSrvc, $location, $window) {
                    if ($window.localStorage.getItem("ssnSec") == null)
                        $location.path('/forgotpwd.html');
                    else
                        getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [forgotpwdSrvc, forgotpwdCtrl] }])
                }]
            }
        })

        .state("forgotpwdreseteml", {
            url: "/forgotpwdreseteml.html",
            templateUrl: "app/signin/templates/forgotpwdreseteml.html",
            controller: 'forgotpwdCtrl',
            controllerAs: 'forgotpwdCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$window', function ($ocLazyLoad, getSessionSrvc, $location, $window, event) {
                    if ($window.localStorage.getItem("memfpw") == null)
                        $location.path('/forgotpwd.html');
                    else
                        getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [forgotpwdSrvc, forgotpwdCtrl] }])
                }]
            }
        })

        .state("forgotpwdreset", {
            url: "/forgotpwdreset.html",
            templateUrl: "app/signin/templates/forgotpwdreset.html",
            controller: 'forgotpwdCtrl',
            controllerAs: 'forgotpwdCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$window', function ($ocLazyLoad, getSessionSrvc, $location, $window, event) {
                    if ($window.localStorage.getItem("memfpw") == null)
                        $location.path('/forgotpwd.html');
                    else
                        getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [forgotpwdSrvc, forgotpwdCtrl] }])
                }]
            }
        })

        .state("profilehide", {
            url: "/profilehide.html",
            templateUrl: "app/signin/templates/profilehide.html",
            controller: 'signinCtrl',
            controllerAs: 'signinCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$location', '$window', function ($ocLazyLoad, getSessionSrvc, $location, $window, event) {
                    if ($window.sessionStorage.getItem("8B3414FB") == null)
                        $location.path('/signin.html');
                    else
                        getSessionSrvc.checkPgSec('outpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [signinCtrl, signinSrvc] }])
                }]
            }
        })

        .state("contactus", {
            url: '/contactus.html',
            templateUrl: "/app/aboutHelp/templates/about-help.html",
            controller: "abthlpCtrl",
            controllerAs: "abthlpCtrlAs",
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [abthlpCtrl, helpfaqsSrvc] }]);
                }]
            }
        })

        .state("help-faqs", {
            url: '/help-faqs.html',
            templateUrl: "/app/aboutHelp/templates/help-faqs.html",
            controller: "helpfaqsCtrl",
            controllerAs: "helpfaqsCtrlAs",
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [helpfaqsCtrl, helpfaqsSrvc] }]);
                }]
            }
        })

        .state("privacy-policy", {
            url: '/privacy-policy.html',
            templateUrl: "/app/policies/templates/pp.html",
            controller: "ppCtrl",
            controllerAs: "ppCtrlAs",
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{ name: 'app', files: [ppCtrl, ppSrvc] }]);
                }]
            }
        })

        .state("privacy-policy-pop", {
            url: '/privacy-policy-pop.html',
            templateUrl: "/app/policies/templates/ppPop.html",
            controller: "ppCtrl",
            controllerAs: "ppCtrlAs",
            resolve: {
                lazy: ['$ocLazyLoad', '$location', '$window', function ($ocLazyLoad, $location, $window) {
                    if ($window.sessionStorage.getItem("8B3414FB") == null)
                        $location.path('/signin.html');
                    return $ocLazyLoad.load([{ name: 'app', files: [ppCtrl, ppSrvc] }])
                }]
            }
        })

        .state("terms-conditions", {
            url: '/terms-conditions.html',
            templateUrl: "/app/policies/templates/tc.html",
            controller: "tcCtrl",
            controllerAs: "tcCtrlAs",
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{ name: 'app', files: [tcCtrl, tcSrvc] }]);
                }]
            }
        })

        .state("terms-conditionspop", {
            url: '/terms-conditionspop.html',
            templateUrl: "/app/policies/templates/tcPop.html",
            controller: "tcCtrl",
            controllerAs: "tcCtrlAs",
            resolve: {
                lazy: ['$ocLazyLoad', '$location', '$window', function ($ocLazyLoad, $location, $window) {
                    if ($window.sessionStorage.getItem("8B3414FB") == null)
                        $location.path('/signin.html');
                    return $ocLazyLoad.load([{ name: 'app', files: [tcCtrl, tcSrvc] }])
                }]
            }
        })

        .state("aboutus", {
            url: '/aboutus.html',
            templateUrl: "/app/aboutus/templates/aboutus.html",
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                }]
            }
        })

        .state("mpVrfy", {
            url: "/mpVrfy.html",
            templateUrl: "/app/mpvrfy/templates/mpVrfy.html",
            controller: 'mpVrfyCtrl',
            controllerAs: 'mpVrfyCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, enent) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{ name: 'app', files: [mpVrfyCtrl] }]);
                }]
            }
        })

        .state('passwordreset', {
            url: '/passwordreset.html',
            templateUrl: 'app/signin/templates/passwordReset.html',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{ name: 'app' }]);
                }]
            }
        })

       .state('dashboard', {
           url: '/dashboard.html',
           parent: "masterpage",
           templateUrl: 'app/dashboard/templates/dashboard.html',
           controller: 'dashboardCtrl',
           controllerAs: 'dashboardCtrlAs',
           resolve: {
               lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                   getSessionSrvc.checkPgSec('inpg', event);
                   return $ocLazyLoad.load([{ name: 'app', files: [dashboardCtrl, dashboardSrvc, chatConversationCtrl, mbrActCtrl, mbrActSrvc, infinitescroll, matchCtrl, othersprofileSrvc, selfmatchprefSrvc, selfprofileSrvc, swiperSrpt, swiperCss, selfprofileFltr, selfprofileSrpt, matchAnalysis] }]);
               }]
           }
       })

        .state('profile', {
            url: '/profile.html',
            parent: "masterpage",
            templateUrl: 'app/profile/self/templates/selfprofile.html',
            controller: 'selfprofileCtrl',
            controllerAs: 'selfprofileCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [swiperSrpt, swiperCss, imgCropSrpt, resizeIt, imgOrient, imgCropCss, selfprofileCtrl, selfprofileSrvc, prflphotodataSrvc, socialLgnSrvc, sociallgnCtrl, selfmatchprefSrvc, selfprofileFltr, selfprofileSrpt, socialPhotosCtrl, socialphotosSrvc, blurIt, fblgn]
                    }]);
                }]
            }
        })

        .state('editprofile', {
            url: '/editprofile.html',
            templateUrl: 'app/profile/self/templates/editprofile.html',
            controller: 'editprofileCtrl',
            controllerAs: 'editprofileCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [editprofileCtrl, selfprofileSrvc, selfmatchprefSrvc, selfprofileFltr, imgCropSrpt, resizeIt,imgOrient, imgCropCss, fblgn, prflphotodataSrvc, socialPhotosCtrl, socialphotosSrvc, blurIt]
                    }]);
                }]
            }
        })

        .state('aboutme', {
            url: '/aboutme.html',
            templateUrl: 'app/profile/self/templates/aboutme.html',
            controller: 'epAbtCtrl',
            controllerAs: 'epAbtCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [epAbtCtrl, selfprofileSrvc, selfprofileSrpt, countryIntlCtrl, countryIntlSrvc]
                    }]);
                }]
            }
        })

        .state('mypersonality', {
            url: '/mypersonality.html',
            templateUrl: 'app/profile/self/templates/my-personality.html',
            controller: 'epprsnaltyCtrl',
            controllerAs: 'epprsnaltyCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [epprsnaltyCtrl, selfprofileSrvc, selfprofileSrpt]
                    }]);
                }]
            }
        })

        .state('mybio', {
            url: '/mybio.html',
            templateUrl: 'app/profile/self/templates/mybio.html',
            controller: 'epbioCtrl',
            controllerAs: 'epbioCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [epbioCtrl, selfprofileSrvc, selfprofileSrpt]
                    }]);
                }]
            }
        })
         .state('mygallery', {
             url: '/mygallery.html',
             templateUrl: 'app/profile/self/templates/mygallery.html',
             controller: 'epgallryCtrl',
             controllerAs: 'epgallryCtrlAs',
             resolve: {
                 lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                     getSessionSrvc.checkPgSec('inpg', event);
                     return $ocLazyLoad.load([{
                         name: 'app', files: [swiperSrpt, swiperCss, imgCropSrpt, resizeIt,imgOrient, imgCropCss, epgallryCtrl, selfprofileSrvc, selfprofileSrpt, socialPhotosCtrl, socialphotosSrvc, prflphotodataSrvc, blurIt, fblgn]
                     }]);
                 }]
             }
         })

        .state('myappearance', {
            url: '/myappearance.html',
            templateUrl: 'app/profile/self/templates/my-appearance.html',
            controller: 'epApprnceCtrl',
            controllerAs: 'epApprnceCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [epApprnceCtrl, selfprofileSrvc, selfprofileSrpt]
                    }]);
                }]
            }
        })

        .state('mylifestyle', {
            url: '/mylifestyle.html',
            templateUrl: 'app/profile/self/templates/my-lifestyle.html',
            controller: 'eplfstylCtrl',
            controllerAs: 'eplfstylCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [eplfstylCtrl, selfprofileSrvc, selfprofileSrpt, sliderDrctve]
                    }]);
                }]
            }
        })

        .state('myhobbies', {
            url: '/myhobbies.html',
            templateUrl: 'app/profile/self/templates/my-hobbies.html',
            controller: 'eplhbysCtrl',
            controllerAs: 'eplhbysCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [eplhbysCtrl, selfprofileSrvc, selfprofileSrpt]
                    }]);
                }]
            }
        })

        .state('matchpref', {
            url: '/matchpref.html',
            templateUrl: 'app/profile/self/templates/selfmatchprefae.html',
            controller: 'selfmatchprefCtrl',
            controllerAs: 'selfmatchprefCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [selfmatchprefCtrl, selfmatchprefSrvc, selfprofileSrvc, countryIntlCtrl, countryIntlSrvc, sliderDrctve]
                    }]);
                }]
            }
        })

        .state('account', {
            url: '/account.html',
            templateUrl: '/app/account/templates/account.html',
            controller: 'accountCtrl',
            controllerAs: 'accountCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [accountCtrl, accountSrvc, infinitescroll, countryIntlCtrl, countryIntlSrvc]
                    }]);
                }]
            }
        })

        .state("pwdchange", {
            url: "/pwdchange.html",
            templateUrl: "app/account/templates/pwdchange.html",
            controller: 'chgPwdCtrl',
            controllerAs: 'chgPwdCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [chgPwdCtrl, accountSrvc]
                    }]);
                }]
            }
        })

        .state("emailchange", {
            url: "/emailchange.html",
            templateUrl: "app/account/templates/emailchange.html",
            controller: 'chgEmailCtrl',
            controllerAs: 'chgEmailCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [chgEmailCtrl, accountSrvc]
                    }]);
                }]
            }
        })

        .state("namechange", {
            url: "/namechange.html",
            templateUrl: "app/account/templates/namechange.html",
            controller: 'chgNameCtrl',
            controllerAs: 'chgNameCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [chgNameCtrl, accountSrvc]
                    }]);
                }]
            }
        })

        .state("blockusers", {
            url: "/blockusers.html",
            templateUrl: "app/account/templates/blockusers.html",
            controller: 'blockUsersCtrl',
            controllerAs: 'blockUsersCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [blockUsersCtrl, accountSrvc, infinitescroll]
                    }]);
                }]
            }
        })

        .state("delactemlvrfy", {
            url: "/delactemlvrfy.html",
            templateUrl: "app/account/templates/delactemlvrfy.html",
            controller: 'delActEmlCtrl',
            controllerAs: 'delActEmlCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$window', '$location', function ($ocLazyLoad, getSessionSrvc, $window,$location, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    if (!$window.localStorage.getItem("del_Act"))
                        $location.path('/account.html');
                    return $ocLazyLoad.load([{
                        name: 'app', files: [delActEmlCtrl, accountSrvc]
                    }]);
                }]
            }
        })

        .state("deleteaccount", {
            url: "/deleteaccount.html",
            templateUrl: "app/account/templates/deleteaccount.html",
            controller: 'delActCtrl',
            controllerAs: 'delActCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', '$window', '$location', function ($ocLazyLoad, getSessionSrvc, $window, $location, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    if (!$window.localStorage.getItem("del_Act"))
                        $location.path('/account.html');
                    return $ocLazyLoad.load([{
                        name: 'app', files: [delActCtrl, accountSrvc]
                    }]);
                }]
            }
        })

        .state('basicsearch', {
            url: '/basicsearch.html',
            parent: "masterpage",
            templateUrl: '/app/search/templates/basicsrch.html',
            controller: 'basicsrchCtrl',
            controllerAs: 'basicsrchCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [basicsrchCtrl, basicsrchSrvc, countryIntlCtrl, countryIntlSrvc, sliderDrctve, mbrActCtrl, mbrActSrvc, chatConversationCtrl, infinitescroll, matchCtrl, othersprofileSrvc, selfprofileSrvc, selfmatchprefSrvc, swiperSrpt, swiperCss, selfprofileFltr, selfprofileSrpt, matchAnalysis]
                    }]);
                }]
            }
        })

        .state('advancedsearch', {
            url: '/advancedsearch.html',
            parent: "masterpage",
            templateUrl: '/app/search/templates/advsrch.html',
            controller: 'advsrchCtrl',
            controllerAs: 'advsrchCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [advsrchCtrl, advsrchSrvc, countryIntlCtrl, countryIntlSrvc, selfprofileSrvc, selfmatchprefSrvc, infinitescroll, mbrActCtrl, mbrActSrvc, chatConversationCtrl, matchCtrl, othersprofileSrvc, selfprofileSrvc, swiperSrpt, swiperCss, selfprofileFltr, selfprofileSrpt, matchAnalysis]
                    }]);
                }]
            }
        })

        .state('advsrchbasics', {
            url: '/advsrchbasics.html',
            templateUrl: '/app/search/templates/advsrchbasics.html',
            controller: 'advsrchbasicsCtrl',
            controllerAs: 'advsrchbasicsCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [advsrchbasicsCtrl, advsrchSrvc, countryIntlCtrl, countryIntlSrvc, sliderDrctve]
                    }]);
                }]
            }
        })

        .state('advsrchabout', {
            url: '/advsrchabout.html',
            templateUrl: '/app/search/templates/advsrchabout.html',
            controller: 'advsrchaboutCtrl',
            controllerAs: 'advsrchaboutCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [advsrchaboutCtrl, selfprofileSrvc, countryIntlCtrl, countryIntlSrvc]
                    }]);
                }]
            }
        })

        .state('advsrchprsnltyE', {
            url: '/advsrchprsnltyE.html',
            templateUrl: '/app/search/templates/advsrchprsnltyE.html',
            controller: 'advsrchprsnltyECtrl',
            controllerAs: 'advsrchprsnltyECtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [advsrchprsnltyECtrl, advsrchSrvc]
                    }]);
                }]
            }
        })

        .state('advsrchaprnce', {
            url: '/advsrchaprnce.html',
            templateUrl: '/app/search/templates/advsrchaprnce.html',
            controller: 'advsrchaprnceCtrl',
            controllerAs: 'advsrchaprnceCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [advsrchaprnceCtrl, selfprofileSrvc]
                    }]);
                }]
            }
        })

        .state('advsrchlifestyle', {
            url: '/advsrchlifestyle.html',
            templateUrl: '/app/search/templates/advsrchlifestyle.html',
            controller: 'advsrchlifestyleCtrl',
            controllerAs: 'advsrchlifestyleCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([{
                        name: 'app', files: [advsrchlifestyleCtrl, advsrchSrvc, selfprofileSrvc, sliderDrctve]
                    }]);
                }]
            }
        })

        .state('advsrchhobbies', {
            url: '/advsrchhobbies.html',
            templateUrl: '/app/search/templates/advsrchhobbies.html',
            controller: 'advsrchhobbiesCtrl',
            controllerAs: 'advsrchhobbiesCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [advsrchhobbiesCtrl, selfprofileSrvc]
                    }]);
                }]
            }
        })

        .state('advsrchsaved', {
            url: '/advsrchsaved.html',
            templateUrl: '/app/search/templates/advsrchsaved.html',
            controller: 'advsrchsavedCtrl',
            controllerAs: 'advsrchsavedCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [advsrchsavedCtrl, advsrchSrvc]
                    }]);
                }]
            }
        })

        .state('msgcenter', {
            url: '/msgcenter.html',
            parent: "masterpage",
            templateUrl: '/app/messages/templates/msgcenter.html',
            controller: 'msgcenterCtrl',
            controllerAs: 'msgcenterCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [swiperCss, swiperSrpt, msgcenterCtrl, newMessageCtrl, chatConversationCtrl, infinitescroll, matchCtrl, selfmatchprefSrvc, othersprofileSrvc, selfprofileSrvc, selfprofileFltr, selfprofileSrpt, matchAnalysis, mbrActCtrl, mbrActSrvc]
                    }]);
                }]
            }
        })

        .state('newMessages', {
            url: '/newmessage.html',
            templateUrl: '/app/messages/templates/newmessage.html',
            controller: 'newMessageCtrl',
            controllerAs: 'newMessageCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [newMessageCtrl]
                    }]);
                }]
            }
        })

        .state('chatConversation', {
            url: '/chatConversation.html',
            templateUrl: '/app/messages/templates/chatConversation.html',
            controller: 'chatConversationCtrl',
            controllerAs: 'chatConversationCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [chatConversationCtrl]
                    }]);
                }]
            }
        })

        .state('notifications', {
            url: '/notifications.html',
            parent: "masterpage",
            templateUrl: '/app/notifications/templates/notifications.html',
            controller: 'notificationsCtrl',
            controllerAs: 'notificationsCtrlAs',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    getSessionSrvc.checkPgSec('inpg', event);
                    return $ocLazyLoad.load([{
                        name: 'app', files: [notificationsCtrl, infinitescroll, mbrActCtrl, mbrActSrvc, chatConversationCtrl, matchCtrl, selfmatchprefSrvc, othersprofileSrvc, selfprofileSrvc, swiperSrpt, swiperCss, selfprofileFltr, selfprofileSrpt, matchAnalysis]
                    }]);
                }]
            }
        })

        .state('test', {
            url: '/test.html',
            controller: 'testCtrl',
            controllerAs: 'testCtrlAs',
            templateUrl: '/app/test/templates/test.html',
            resolve: {
                lazy: ['$ocLazyLoad', 'getSessionSrvc', function ($ocLazyLoad, getSessionSrvc, event) {
                    return $ocLazyLoad.load([{
                        name: 'app', files: ["/app/test/controllers/testCtrl.js"]
                    }]);
                }]
            }
        })
});