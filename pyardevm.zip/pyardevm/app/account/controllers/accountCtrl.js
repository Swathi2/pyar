﻿angular.module("app").controller('accountCtrl', ['accountSrvc', 'getSessionSrvc', 'abndnSrvc', '$scope', '$window', '$rootScope', '$state', '$filter', function (accountSrvc, getSessionSrvc, abndnSrvc, $scope, $window, $rootScope, $state, $filter) {
    var vm = this;
    vm.unitsList = [{ "val": 1, "txt": "Imperial (USA, Myanmar, Liberia)" }, { "val": 2, "txt": "Metric (Everywhere else)" }]
    vm.genderLst = [{ "val": true, "txt": "Male" }, { "val": false, "txt": "Female" }]
    vm.zones = getTimeZones();
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.loginType = function () { return getSessionSrvc.p_lt() };
    vm.genderPref = function () { return getSessionSrvc.p_gndrp() };
    vm.toatlBlockList = 0;

    //setting default tab as General Setting 
    if ($rootScope.acTabType)
        vm.tab = $rootScope.acTabType;
    else
        vm.tab = "GS";
    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BIND THE USER DETAILS  STARTS  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    vm.getProfileInfo = function (callBackFun) {
        showLoader();
        accountSrvc.profileInfo(vm.mId(), function (response, status) {
            callBackFun(response, status);
        });
    };

    vm.getDaysDiff = function (nameCD) {
        CurDate = new Date();
        cNmDt = new Date(nameCD);
        cNmDt.setDate(cNmDt.getDate() + 90);
        return Math.floor((Date.UTC(cNmDt.getFullYear(), cNmDt.getMonth(), cNmDt.getDate()) - Date.UTC(CurDate.getFullYear(), CurDate.getMonth(), CurDate.getDate())) / (1000 * 60 * 60 * 24));
    };

    vm.bindNotificationSettings = function () {
        if (vm.memPrflResponse != null) {
            vm.EmlRecMatchs = vm.memPrflResponse.NotificationSettings.rmEml;
            vm.EmlViewsMe = vm.memPrflResponse.NotificationSettings.pvEml;
            vm.EmlFlirtsMe = vm.memPrflResponse.NotificationSettings.flirtEml;
            vm.EmlMsgMe = vm.memPrflResponse.NotificationSettings.msgEml;
            vm.EmlPyrPrmtn = vm.memPrflResponse.NotificationSettings.promoEml;
            vm.EmlPyrTps = vm.memPrflResponse.NotificationSettings.tipEml;
        }
    };

    vm.getBlckdMemCnt = function () {
        accountSrvc.GetBlockedMembesCnt(vm.mId(), function (response, status) {
            vm.toatlBlockList = response;
            vm.blckUsrTxt = vm.toatlBlockList == 1 ? "User" : "Users";
        });
    }
    vm.getBlckdMemCnt();

    vm.getProfileInfo(function (response, status) {
        if (status == 200) {
            response = response.Result;
            vm.memPrflResponse = response;
            //General
            //vm.TimeZoneLst = response.TimeZoneLst;
            vm.TimeZoneLst = $filter("orderBy")(vm.zones, 'GMT');
            vm.setTimeZone = response.timeZone;
            vm.units = response.units;
            //Profile
            vm.selGender = response.gender;
            vm.gender = response.gender ? "Male" : "FeMale";
            vm.selPrefGender = response.genderPref;
            vm.genderPref = response.genderPref ? "Male" : "Female";
            vm.dateOfBirth = vm.setDOB(response.dob);
            vm.dobOrg = vm.setDOB(response.dob);
            vm.cityId = response.cityId;
            vm.cntryId = response.countryId;
            vm.profileImageSrc = "https://pccdn.pyar.com"+response.profilePic;
            //location binding
            $rootScope.$broadcast("GetCity", "bindCty", response.countryId, response.cityId);
            //days count for change name
            vm.memName = response.firstName;
            vm.fNameAltrDt = vm.getDaysDiff(response.fNameAltrDt);
            if (vm.fNameAltrDt <= 0)
                vm.chgNmeTxtclr = true;
            else
                vm.chgNmeTxtclr = false;
            vm.dayTxt = vm.fNameAltrDt == 1 ? "day" : "days";
            //binding notifications
            vm.bindNotificationSettings();
        }
        hideLoader();
    });
    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BIND TEH USER DETAILS END   ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
    //Change email and password blocks hiding for social users
    vm.pwdChnghdeFrSclLgn = false;
    vm.emlChnghdeFrSclLgn = false;
    if (vm.loginType() == 1) {
        vm.emlChnghdeFrSclLgn = true;
        vm.pwdChnghdeFrSclLgn = true;
    }
    else {
        vm.emlChnghdeFrSclLgn = false;
        vm.pwdChnghdeFrSclLgn = false;
    }

    vm.chgTab = function (tab) {
        $window.scrollTo(0, 0);
        vm.tab = tab;
    };

    vm.setDOB = function (dob) {
        return dob ? new Date(dob) : "";
    };

    vm.dobValidation = function (val) {
        if (vm.mId() && vm.setDOB(vm.memPrflResponse.dob) != vm.dateOfBirth) {
            var enteredAge = vm.calAge(val);
            if (enteredAge > 18 && enteredAge < 130) {
                vm.dateOfBirth = new Date(vm.dateOfBirth.getTime() + Math.abs(vm.dateOfBirth.getTimezoneOffset() * 60000));
                accountSrvc.saveDOB(vm.mId(), vm.dateOfBirth, function (response, status) {
                    if (status == 200 && response == true) {
                        vm.memPrflResponse.dateOfBirth = new Date(vm.dateOfBirth);
                    }
                });
            }
        }
    };

    //on date of birth blur event check dob valid or not if not valid original dob date
    vm.dobBlur = function () {
        var age = vm.calAge(vm.dateOfBirth);
        if (age < 18 || age > 130)
            vm.dateOfBirth = vm.dobOrg;
    };

    vm.calAge = function (val) {
        if (val) {
            var today = new Date();
            var dateOfBirth = new Date(val);
            var age = today.getFullYear() - dateOfBirth.getFullYear();
            var m = today.getMonth() - dateOfBirth.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < dateOfBirth.getDate()))
                age--;
            return age;
        }
        return 0;
    };

    vm.chgEmailClk = function () {
        $rootScope.acTabType = "GS";
        $state.go("emailchange");
    };

    vm.chgPwdClk = function () {
        $rootScope.acTabType = "GS";
        $state.go("pwdchange");
    };
    vm.openChngeNmePopup = function () {
        $rootScope.acTabType = "GS";
        if (vm.fNameAltrDt <= 0)
            $state.go("namechange");
        else
            $("#alertChgNme").modal("show");
    };

    vm.chkBlockUsers = function () {
        if (vm.toatlBlockList > 0)
            $state.go("blockusers");
    };

    $("#hideAcntPopup").modal("hide");
    vm.dbleAcntPopup = function () {
        $("#hideAcntPopup").modal("show");
    };
    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  AUTO SERVICES CALLING MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
    /*******************************************************************************************************************************************************************/
    vm.timeZoneSaveFunc = function () {
        if (vm.mId() && vm.memPrflResponse.timeZone != vm.setTimeZone) {
            accountSrvc.saveTimezone(vm.mId(), vm.setTimeZone, function (response, status) {
                if (status == 200 && response == true) {
                    vm.memPrflResponse.timeZone = vm.setTimeZone;
                    getSessionSrvc.u_ssnd("timeZone", vm.setTimeZone);
                }
            });
        }
    };

    vm.unitsSaveFunc = function () {
        if (vm.mId() && vm.memPrflResponse.units != vm.units) {
            accountSrvc.saveUnits(vm.mId(), vm.units, function (response, status) {
                if (status == 200 && response == true) {
                    vm.memPrflResponse.units = vm.units;
                    getSessionSrvc.u_ssnd("units", vm.units);
                }
            });
        }
    };

    vm.genderSaveFunc = function () {
        if (vm.mId() && vm.memPrflResponse.gender != vm.selGender) {
            accountSrvc.saveGender(vm.mId(), vm.selGender, function (response, status) {
                if (status == 200 && response == true) {
                    vm.memPrflResponse.gender = vm.selGender;
                    getSessionSrvc.u_ssnd("gender", vm.selGender);
                    $scope.$emit("refreshHdrPP", vm.profileImageSrc);;//update profile  in toggle                  
                }
            });
        }
    };

    vm.genderPrefSaveFunc = function () {
        if (vm.mId() && vm.memPrflResponse.genderPref != vm.selPrefGender) {
            accountSrvc.saveGenderPref(vm.mId(), vm.selPrefGender, function (response, status) {
                if (status == 200 && response == true) {
                    vm.memPrflResponse.genderPref = vm.selPrefGender;
                    getSessionSrvc.u_ssnd("genderPref", vm.selPrefGender);
                }
            });
        }
    };

    vm.hideProfile = function () {
        accountSrvc.saveProfileHide(vm.mId(), true, function (response, status) {
            if (status == 200 && response == true) {
                vm.tempProfileHide = true;
                $('body').removeClass().removeAttr('style');
                $('.modal-backdrop').remove();
                abndnSrvc.rmvSsn();
                $state.go('home');
            }
        });
    };

    vm.delActCnfrm = function () {
        $("#deleteAcntPopup").modal("show");
    };

    vm.delAcnt = function () {
        showLoader();
        accountSrvc.deleteAccountSendOtp(vm.mId(), function (response, status) {
            if (status == 200 && response) {             
                $window.localStorage.setItem("del_Act",getSessionSrvc.pce(JSON.stringify({"otpId": response})));
                $("#deleteAcntPopup").modal("hide");
                $('body').removeClass().removeAttr('style');
                $('.modal-backdrop').remove();
                $rootScope.acTabType = "PS";
                $state.go("delactemlvrfy");
            }
            else {
                $("#ApiErrMsg").text("unable to send email");
                $("#ErrAlert").modal("show");
            }
            hideLoader();
        });
    };
    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  SERVICE CALLING MODULE END))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  NOTIFICATION SETTING MODULE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
    /*******************************************************************************************************************************************************************/
    vm.chkEmlRecMatchs = function (event) {
        event.preventDefault();
        if (vm.mId() && vm.EmlRecMatchs != null) {
            vm.EmlRecMatchs = !vm.EmlRecMatchs;
            accountSrvc.saveSettingsEmlrecmatch(vm.mId(), vm.EmlRecMatchs, function (response, status) {
                if (status == 200 && response == true)
                    vm.memPrflResponse.NotificationSettings.rmEml = vm.EmlRecMatchs;
            });
        }
    };

    vm.chkEmlViewsMe = function (event) {
        event.preventDefault();
        if (vm.mId() && vm.EmlViewsMe != null) {
            vm.EmlViewsMe = !vm.EmlViewsMe;
            accountSrvc.saveSettingsEmlviewme(vm.mId(), vm.EmlViewsMe, function (response, status) {
                if (status == 200 && response == true)
                    vm.memPrflResponse.NotificationSettings.pvEml = vm.EmlViewsMe;
            });
        }
    };

    vm.chkEmlFlirtsMe = function (event) {
        event.preventDefault();
        if (vm.mId() && vm.EmlFlirtsMe != null) {
            vm.EmlFlirtsMe = !vm.EmlFlirtsMe;
            accountSrvc.saveSettingsEmlflirtme(vm.mId(), vm.EmlFlirtsMe, function (response, status) {
                if (status == 200 && response == true)
                    vm.memPrflResponse.NotificationSettings.flirtEml = vm.EmlFlirtsMe;
            });
        }
    };

    vm.chkEmlMsgMe = function (event) {
        event.preventDefault();
        if (vm.mId() && vm.EmlMsgMe != null) {
            vm.EmlMsgMe = !vm.EmlMsgMe;
            accountSrvc.saveSettingsEmlmsgme(vm.mId(), vm.EmlMsgMe, function (response, status) {
                if (status == 200 && response == true)
                    vm.memPrflResponse.NotificationSettings.msgEml = vm.EmlMsgMe;
            });
        }
    };

    vm.chkEmlPyrPrmtn = function (event) {
        event.preventDefault();
        if (vm.mId() && vm.EmlPyrPrmtn != null) {
            vm.EmlPyrPrmtn = !vm.EmlPyrPrmtn;
            accountSrvc.saveSettingsEmlpyrprmtn(vm.mId(), vm.EmlPyrPrmtn, function (response, status) {
                if (status == 200 && response == true)
                    vm.memPrflResponse.NotificationSettings.promoEml = vm.EmlPyrPrmtn;
            });
        }
    };

    vm.chkEmlPyrTps = function (event) {
        event.preventDefault();
        if (vm.mId() && vm.EmlPyrTps != null) {
            vm.EmlPyrTps = !vm.EmlPyrTps;
            accountSrvc.saveSettingsEmlpyrtips(vm.mId(), vm.EmlPyrTps, function (response, status) {
                if (status == 200 && response == true)
                    vm.memPrflResponse.NotificationSettings.tipEml = vm.EmlPyrTps;
            });
        }
    };
    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  NOTIFICATION SETTING MODULE END ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
    /*******************************************************************************************************************************************************************/

    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( LOCATION BINDING STARTS HERE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
    /*******************************************************************************************************************************************************************/
    vm.showloc = false;
    vm.selectLoc = function () {
        $rootScope.$broadcast("showLocation", "bindCty");
    };

    $scope.$on("countryBind", function (e, locId, countryId, data) {
        vm.cntryId = data.countryId;
        vm.cntryName = data.countryName;
        vm.cityId = data.cityId;
        if (vm.mId() && vm.cntryId && vm.cityId) {
            accountSrvc.saveLocation(vm.mId(), vm.cntryId, vm.cityId, function (response, status) {
                if (status == 200 && response == true) {
                    vm.memPrflResponse.countryId = vm.cntryId;
                    getSessionSrvc.u_ssnd("countryId", vm.cntryId);
                    getSessionSrvc.u_ssnd("country", vm.cntryName);
                    vm.memPrflResponse.cityId = vm.cityId;
                    vm.location = data.cityName + ", " + data.stateName;
                }
            });
        }
    });

    $scope.$on("BindCity", function (e, locId, citObj) {
        vm.location = citObj.cityName + ", " + citObj.stateName;
    });
    /*******************************************************************************************************************************************************************/
    /*((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( LOCATION BINDING ENDS HERE ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
    /*******************************************************************************************************************************************************************/
}]);