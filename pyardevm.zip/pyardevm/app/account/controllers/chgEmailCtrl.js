﻿angular.module("app").controller('chgEmailCtrl', ['accountSrvc', 'getSessionSrvc', 'abndnSrvc', '$scope', '$rootScope', function (accountSrvc, getSessionSrvc, abndnSrvc, $scope, $rootScope) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.emlErr = false;
    vm.cnfemlErr = false;
    vm.pwdErr = false;
    vm.doneBtnEml = false;
    vm.cancelBtnEml = false;
    vm.bckBtnEml = true;
    vm.errorPwdMsg = "";
    vm.newEmail = "";
    vm.emlErrMsg = "";
    vm.confirmEmail = "";
    vm.cnfemlErrMsg = "";
    vm.emailRegexs = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    vm.pwdRegexs = '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,16}$';

    vm.showHideBckBtn = function (val1, val2, val3, type) {
        vm.cnfemlErr = false;
        if (val1 && val2 && val3) {
            vm.doneBtnEml = true;
            vm.cancelBtnEml = true;
            vm.bckBtnEml = false;
        }
        else {
            vm.doneBtnEml = false;
            vm.cancelBtnEml = false;
            vm.bckBtnEml = true;
        }
        //validations
        if (type == "pwd")
            if (vm.currentPassword && vm.currentPassword.length > 16) {
                vm.currentPassword = null;
                vm.pwdErr = true;
                vm.errorPwdMsg = "Must be < 16 characters";
            }
        if (type = "email")
            vm.isMatcheRex = vm.emailRegexs.test(vm.newEmail);
        if (vm.newEmail && vm.newEmail.length > 75) {
            vm.newEmail = null;
            vm.emlErr = true;
            vm.emlErrMsg = "Must be < 75 characters";
        }
        if (type = "conform email")
            if (vm.confirmEmail && vm.confirmEmail.length > 75) {
                vm.confirmEmail = null;
                vm.cnfemlErr = true;
                vm.cnfemlErrMsg = "Must be < 75 characters";
            }
    };

    //validations for change email starts here
    vm.emailCheck = function () {   
        if (!vm.isMatcheRex) {
            vm.emlErr = true;
            vm.emlErrMsg = 'Invalid email';
            vm.newEmail = "";
        }
        else {
            if (vm.confirmEmail && vm.newEmail != vm.confirmEmail) {
                vm.cnfemlErr = true;
                vm.cnfemlErrMsg = 'Email does not match';
                vm.confirmEmail = "";
            }
        }
    };

    //confirm password textbox blur event
    vm.cnfEmlCheck = function () {
        if (vm.newEmail && vm.isMatcheRex)
            if (vm.newEmail != vm.confirmEmail) {
                vm.cnfemlErr = true;
                vm.cnfemlErrMsg = 'Email does not match';
                vm.confirmEmail = "";
            }
            else {
                vm.cnfemlErr = false;
                vm.emlvld = true;
            }
    };
    
    vm.PwdKeyPress = function () { vm.pwdErr = false; };

    vm.emailkeyPress = function () {vm.emlErr = false;};

    vm.cnfmEmlKeyPress = function () { vm.cnfemlErr = false; };
    //validations for change email ends here

    //change email popup show on click
    vm.chngEmailPopUp = function () {
        $("#emlPopup").modal("show");
    };

    //Change email service starts here
    vm.changeEmail = function () {
        if ($scope.frmChngEml.$valid) {
            showLoader();
            accountSrvc.changeEml(vm.mId(), vm.currentPassword, vm.newEmail, function (response, status) {
                $("#emlPopup").modal("hide");
                $('body').removeClass().removeAttr('style');
                $('.modal-backdrop').remove();
                hideLoader();
                if (status == 200) {
                    var strResponse = response.toString();
                    if (strResponse == "1") {
                        vm.newEmail = null;
                        vm.confirmEmail = null;
                        vm.emlErr = true;
                        vm.emlErrMsg = 'Email already registered';
                    }
                    else if (strResponse == "2") {
                        vm.currentPassword = null;
                        vm.pwdErr = true;
                        vm.errorPwdMsg = 'Incorrect Password';
                    }
                    else if (strResponse == "true")
                        abndnSrvc.rmvSsn();
                }
            });
        }
    };
}]);