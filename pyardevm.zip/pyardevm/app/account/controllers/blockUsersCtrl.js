﻿angular.module("app").controller('blockUsersCtrl', ['accountSrvc', 'getSessionSrvc', '$scope', '$rootScope', '$state', function (accountSrvc, getSessionSrvc, $scope, $rootScope, $state) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.pgNo = 1;
    vm.pgSize = 15;
    vm.scrollable = true;
    vm.blockedMems = [];
    vm.busy = true;

    vm.getBlockedMembs = function () {
        if (!vm.scrollable) return;
        showLoader();
        vm.busy = true;        
        accountSrvc.GetBlockedMembes(vm.mId(), vm.pgNo, vm.pgSize, function (response, status) {
            vm.busy = false;
            if (status == 200) {
                vm.pgNo++;
                if (response.length > 0) {
                    for (var i = 0; i < response.length; i++) {
                        vm.blockedMems.push(response[i]);
                         vm.blckUsrTxt = vm.blockedMems.length == 1 ? "User" : "Users";
                   }
                }
                if (response.length < vm.pgSize)
                    vm.scrollable = false;
          }
           
         hideLoader();
        });
    };

    vm.getBlockedMembs();
    
    vm.scrollLoad = function () {
        if (vm.blockedMems.length > 0 && ($(window).scrollTop() >= (($(document).height() - $("#pcFtr").outerHeight()) - $(window).height()))) {
            vm.getBlockedMembs()
        }
    };

    //Showing blocked users popup on-click
    vm.blockUserPopUp = function (name, memBlockedId) {
        vm.memBlkId = memBlockedId;
        $("#blkusrmodal").modal("show");
        vm.firstName = name;
    };

    //Unblocking the blocked users
    vm.unBlkMember = function () {
        showLoader();
        accountSrvc.UnBlockMember(vm.mId(), vm.memBlkId, function (response, status) {
            $("#blkusrmodal").modal("hide");
            hideLoader();
            if (status == 200) {
                for (var i = 0; i < vm.blockedMems.length; i++) {
                    if (vm.blockedMems[i].memId == vm.memBlkId)
                        vm.blockedMems.splice(i, 1);
                    vm.blckUsrTxt = vm.blockedMems.length == 1 ? "User" : "Users";
                    if (vm.blockedMems.length == 0) {
                        $('body').removeClass().removeAttr('style');
                        $('.modal-backdrop').remove();
                        $state.go("account");
                    }
                

                }
                if (vm.blockedMems.length == 0) {
                    vm.pgNo = 1;
                    vm.getBlockedMembs()
                }
            }
        });
    };

    //Binding the profile dynamically for blocked users
    vm.bindProfilePic = function (profilepic, gender) {
        if (profilepic == null || profilepic == "" || profilepic == undefined) {
            if (gender == true)
                return "https://pccdn.pyar.com/pcmbr/defaults/profilemtns.jpg";
            else if (gender == false)
                return "https://pccdn.pyar.com/pcmbr/defaults/profileftns.jpg";
        }
        else return "https://pccdn.pyar.com" + profilepic;
    };

    vm.bckNav = function () {
        $rootScope.acTabType = "PS";
        $state.go('account');
    };
    /*******************************************************************************************************************************************************************/
    /*(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((  BLOCK USERS END  ))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))*/
    /*******************************************************************************************************************************************************************/
}]);