﻿angular.module("app").controller('delActEmlCtrl', ['getSessionSrvc', 'accountSrvc', '$state', '$interval', '$window', function (getSessionSrvc, accountSrvc, $state, $interval, $window) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.g_ssnd("mId") };
    vm.btnResend = true;
    vm.resendTime = false;
    vm.vrfyOtp = true;
    vm.otpId = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("del_Act"))).otpId;
    vm.bckNav = function () {
        $state.go('account');
    };  

    vm.keyPress = function (txtIndexId, event) {
        if (event.keyCode == 13)
            vm.keyUp(txtIndexId, event);
    };

    vm.keyUp = function (txtIndexId, event) {       
            var keyCode = event.keyCode;
            if ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105) || keyCode == 13) {
                vm.otpErr = "";
                vm.errorOtpMsg = "";
                vm.otpVerify();
                //focus next elements
                txtIndexId++;
                $('input[tabindex=' + (txtIndexId) + ']').focus();
            }       
    };
    vm.otpVerify = function ()
    {
        if (vm.vrfyOtp == true && vm.otpId && vm.mId() && vm.otpDigit1 && vm.otpDigit2 && vm.otpDigit3 && vm.otpDigit4) {
            showLoader();
            vm.vrfyOtp = false;
            var code = vm.otpDigit1 + vm.otpDigit2 + vm.otpDigit3 + vm.otpDigit4;
            accountSrvc.verifyOTPCode(vm.mId(), vm.otpId, code, function (response, status) {
                if (status == 200) {
                    vm.vrfyOtp = true;
                    //1:invalid otp;2:invalid member;3:otp expired; 4:wrong otp entered;5:sucess
                    if (response == 1 || response == 2)// invalid id or member
                    {
                        $window.localStorage.removeItem("del_Act");
                        $("#ApiErrMsg").text("Unable to process, please try again."); $("#ErrAlert").modal("show");
                    }
                    else if (response == "3")//otp expired
                    {
                        vm.otpErr = true;
                        vm.errorOtpMsg = "This code expired. Please fill in the code within 24 hours.";
                        vm.otpDigit1 = vm.otpDigit2 = vm.otpDigit3 = vm.otpDigit4 = "";
                        $("#OtpDigit1").focus();
                    }
                    else if (response == "4")//wrong otp
                    {
                        vm.otpErr = true;
                        vm.errorOtpMsg = "That’s incorrect. Please try again.";
                        vm.otpDigit1 = vm.otpDigit2 = vm.otpDigit3 = vm.otpDigit4 = "";
                        $("#OtpDigit1").focus();
                    }
                    else if (response) {
                        $state.go("deleteaccount");
                    }
                }
                hideLoader();
            });
        }
    }

    vm.resendDelActEml = function () {
        if (vm.btnResend) {
            showLoader();
            accountSrvc.deleteAccountSendOtp(vm.mId(), function (response, status) {
                if (status == 200 && response) {
                    $window.localStorage.setItem("del_Act", getSessionSrvc.pce(JSON.stringify({ "otpId": response })));
                    vm.otpId = response;
                    vm.startTimer();
                }
                else {
                    $("#ApiErrMsg").text("unable to send email");
                    $("#ErrAlert").modal("show");
                }
                hideLoader();
            });
        }
    };
    vm.startTimer = function () {
        vm.btnResend = false;
        vm.resendTimer = true;
        vm.startTime = 30;
        vm.intrvl = $interval(function () {
            vm.startTime = vm.startTime - 1
            if (vm.startTime.toString().length < 2)
                vm.startTime = "0" + vm.startTime;
            if (vm.startTime == "00") {
                vm.btnResend = true;
                vm.resendTimer = false;
                $interval.cancel(vm.intrvl);
                return false;
            }
        }, 1000);
    };
}]);