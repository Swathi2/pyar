﻿angular.module("app").controller('chgPwdCtrl', ['accountSrvc', 'getSessionSrvc', 'abndnSrvc', '$scope', '$window', function (accountSrvc, getSessionSrvc, abndnSrvc, $scope, $window) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.pwdErr = false;
    vm.npwdErr = false;
    vm.cnfpwdErr = false;
    vm.doneBtnEml = false;
    vm.cancelBtnEml = false;
    vm.bckBtnEml = true;
    vm.errorPwdMsg = "";
    vm.npwdErrMsg = "";
    vm.cnfpwdErrMsg = "";
    vm.newPassword = "";
    vm.confirmPassword = "";
    vm.pwdRegexs = '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,16}$';

    vm.showHideBckBtn = function (val1, val2, val3, type) {
        if (val1 != '' && val2 != '' && val3 != '') {
            vm.doneBtnEml = true;
            vm.cancelBtnEml = true;
            vm.bckBtnEml = false;
        }
        else {
            vm.doneBtnEml = false;
            vm.cancelBtnEml = false;
            vm.bckBtnEml = true;
        }
        if (type == "cpwd")
            if (vm.currentPassword && vm.currentPassword.length > 16) {
                vm.currentPassword = "";
                vm.pwdErr = true;
                vm.errorPwdMsg = "Must be < 16 characters";
            }
        if (type == "npwd")
            vm.pwdVal = new RegExp(vm.pwdRegexs).test(vm.newPassword);
        if (!vm.pwdVal)
            vm.newpasswordval = undefined;
        else
            vm.newpasswordval = vm.newPassword;
        if (vm.newPassword && vm.newPassword.length > 16) {
            vm.newPassword = "";
            vm.npwdErr = true;
            vm.npwdErrMsg = "Must be < 16 characters";
        }
        if (type == "cnfrmpwd")
            if (vm.confirmPassword && vm.confirmPassword.length > 16) {
                vm.confirmPassword = "";
                vm.cnfpwdErr = true;
                vm.cnfpwdErrMsg = "Must be < 16 characters";
            }
    };

    vm.PwdKeyPress = function () { vm.pwdErr = false; };

    //validations for password change starts here
    vm.pswdCheck = function () {
        if (vm.newpassword == "") {
            vm.npwdErr = true;
            vm.cnfpwdErrMsg = "";
            vm.npwdErrMsg = 'Please Enter Password';          
        }
        if (vm.newpasswordval == undefined) {
            vm.npwdErr = true;
            vm.cnfpwdErrMsg = "";
            vm.npwdErrMsg = 'Please follow password guide lines';
        }
        else if (vm.currentPassword && vm.currentPassword == vm.newPassword)
        {
            vm.npwdErr = true;
            vm.npwdErrMsg = "Password should not match current";
        }
       else if(vm.confirmPassword)
         if (vm.confirmPassword != vm.newPassword) {
            vm.cnfpwdErr = true;
            vm.cnfpwdErrMsg = 'Password does not match';
        }
        else if (vm.newPassword != "" && vm.newpasswordval != undefined) {
            vm.npwdErr = false;
            vm.cnfpwdErr = false;
        }
    };

    vm.cnfPwdCheck = function () {
        if (vm.newPassword && vm.newPassword != vm.confirmPassword) {
            vm.cnfpwdErr = true;
            vm.cnfpwdErrMsg = 'Password does not match';
        }
        else
            vm.cnfpwdErr = false;
    };

    vm.nPwdkeyPress = function () { vm.npwdErr = false; vm.cnfpwdErr = false; };

    vm.cnfmPwdKeyPress = function () { vm.cnfpwdErr = false; };
    //validations for password change ends here

    //change password modal show on click
    vm.chngPwdPopUp = function () {
        $("#chgPwdPopup").modal("show");
    };

    //change password 
    vm.changePassword = function () {
        if ($scope.frmChngPwd.$valid) {
            showLoader();
            accountSrvc.changePwd(vm.mId(), vm.currentPassword, vm.confirmPassword, function (response, status) {
                $("#chgPwdPopup").modal("hide");
                $('body').removeClass().removeAttr('style');
                $('.modal-backdrop').remove();
                hideLoader();
                if (status == 200) {
                    if (response == 2) {
                        vm.currentPassword = null;
                        vm.newPassword = null;
                        vm.errorPwdMsg = 'Incorrect password';
                        vm.pwdErr = true;
                        vm.confirmPassword = null;
                    }
                    else if (response == 3) {
                        vm.currentPassword = null;
                        vm.newPassword = null;
                        vm.npwdErrMsg = 'Previous password can’t be used';
                        vm.npwdErr = true;
                        vm.confirmPassword = null;
                    }
                    else if (response == false) {
                        vm.pwdErr = true;
                        vm.errorPwdMsg = "unable to update password, please try again later";
                    }
                    else if (response == true) {
                        $window.localStorage.setItem("pgType", 3);
                        abndnSrvc.rmvSsn();
                    }
                }
            });
        }
    };
}]);