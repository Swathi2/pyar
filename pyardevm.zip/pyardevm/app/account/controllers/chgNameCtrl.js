﻿angular.module("app").controller('chgNameCtrl', ['accountSrvc', 'getSessionSrvc', '$state', function (accountSrvc, getSessionSrvc, $state) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.p_mId() };
    vm.memName = getSessionSrvc.p_fn();
    vm.nameErr = false;
    vm.nameErrMsg = "";
    //validations for change name starts here
    vm.showcancelBtn = false;
    vm.doneBtnShow = false;
    vm.backBtn = true;

    vm.changeName = function () {
        if (vm.editedName && vm.editedName.length > 30) {
            vm.nameErr = true;
            vm.nameErrMsg = 'Must be < 30 characters';
            vm.editedName = '';
        }
       else if (!vm.editedName || vm.editedName.length == 1) {
            vm.nameErr = true;
            vm.nameErrMsg = 'Please enter a valid first name';
            vm.doneBtnShow = false;
            vm.showcancel = false;
            vm.backBtn = true;
        }
         else if (vm.editedName && vm.editedName.toUpperCase() != vm.memName.toUpperCase()) {
            vm.editedName = vm.editedName.charAt(0).toUpperCase() + vm.editedName.slice(1);
            vm.doneBtnShow = true;
            vm.showcancel = true;
            vm.backBtn = false;
            vm.nameErr = false;
         }
         else {
             vm.doneBtnShow = false;
             vm.showcancel = false;
             vm.backBtn = true;
         }
    };
    vm.fNameCheck = function () {
        if (!vm.editedName || vm.editedName.length == 1) {
            vm.nameErr = true;
            vm.nameErrMsg = 'Please enter a valid first name';
        }
        else
            vm.nameErr = false;
    };

    //Showing changename popup on-click
    vm.chngNamePopUp = function (editedName) {
        if (vm.editedName != '')
            $("#namePopup").modal("show");
    };

    //Change name service starts here
    vm.chngfName = function () {
        $("#namePopup").modal("hide");
        accountSrvc.PrfChangeName(vm.mId(), vm.editedName, function (response, status) {
            if (status == 200 && response == true) {
                getSessionSrvc.u_ssnd("firstName", vm.editedName);
                $state.go("account");
            }
        });
    };
}]);