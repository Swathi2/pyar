﻿angular.module("app").controller('delActCtrl', ['getSessionSrvc', 'accountSrvc', 'abndnSrvc', '$state', '$window', '$timeout', function (getSessionSrvc, accountSrvc,abndnSrvc, $state, $window, $timeout) {
    var vm = this;
    vm.mId = function () { return getSessionSrvc.g_ssnd("mId") };
    vm.otpId = JSON.parse(getSessionSrvc.pcd($window.localStorage.getItem("del_Act"))).otpId;
    vm.delJson = [{ name: "Found my match on Pyar.com", value: "1" }, { name: "Found my match elsewhere", value: "2" }, { name: "Services were unsatisfactory", value: "3" }, { name: "Other (please explain)", value: "4" }];
    vm.delErrMsg = "";
    var limitNum = 250;
    vm.frmDel = false;
    vm.delexplanation = "";
    vm.delPlaceHolder = "Any more comments you have for us will be greatly appreciated!";
    vm.agree = false;
    vm.deleteAcnt = true;
    vm.delCnfrmFunc = function () {
        if (vm.agree)
            vm.agree = false;
        else
            vm.agree = true;
    };
  
    vm.bckNav = function () {
        $state.go('account');
    };

    vm.delRsnClk = function (reasonText,val) {
        vm.delRsnVal = val;
        vm.delreasonText = reasonText;
        vm.frmDel = true;     
        vm.txtCls = "";
    };
    //Showing Delete  text error message.    
    vm.delTxtLimit = function () {
        if (vm.delexplanation) {
            if (vm.delexplanation.length > limitNum) {
                vm.delErrMsg = "Please ensure that your Details do not exceed 250 characters..";
                vm.delexplanation = "";
                vm.txtCls = "";
            }
            else
                vm.delErrMsg = "";
        }
        else 
            vm.txtCls = "";       
    };
    vm.deleteAccntPerm = function () {
        if (vm.deleteAcnt == true) {
            showLoader();
            vm.deleteAcnt = false;
            //need to check vm.delRsnVal shood not be empty/null
            if (vm.delRsnVal == 4 && !vm.delexplanation) {
                vm.txtCls = "txteror";
                vm.delPlaceHolder = 'Since you selected "Other" as your reason, please give us some details.';
                vm.delErrMsg = "";
                hideLoader();
            }
            else {
                if (vm.mId() && vm.otpId && vm.delreasonText && vm.agree) {
                    accountSrvc.deleteAccntFnl(vm.mId(), vm.otpId, vm.delreasonText, vm.delexplanation, function (response, status) {
                        if (status == 200) {
                            //1:invalid otp;2:invalid member;3:unable to delete; 4:sucess
                            $window.localStorage.removeItem("del_Act");
                            if (response == 1 || response == 2 || response == 3) {
                                $("#ApiErrMsg").text("unable to process your request...! Please again try later.");
                                $("#ErrAlert").modal("show"); hideLoader();
                            }
                            else if (response == 4) {
                                $timeout(function () { abndnSrvc.rmvSsn(); }, 100);
                            }
                        }
                        hideLoader();
                    });
                }
                else {
                    hideLoader();
                }
            }
        }
    };
}]);