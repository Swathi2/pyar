﻿app.service('accountSrvc', ['$http', function ($http) {
    this.profileInfo = function (memberId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/privacysettings/" + memberId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Change pswrd
    this.changePwd = function (memberId, currentpassword, newpassword, funCallBack) {
        var data = { memberId: memberId, currentpassword: currentpassword, newpassword: newpassword }
        var url = "https://pcapi.pyar.com/api/account/changepassword";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //Change email
    this.changeEml = function (memberId, password, newEmail, funCallBack) {
        var data = { memberId: memberId, password: password, newEmail: newEmail }
        var url = "https://pcapi.pyar.com/api/account/changeemail";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //Change Name
    this.PrfChangeName = function (memberId, firstname, funCallBack) {
        var data = { memberId: memberId, firstname: firstname }
        var url = "https://pcapi.pyar.com/api/account/changename";
        PostServiceByURL($http, url, data, funCallBack);
    };

    //Disable/hide profile
    this.saveProfileHide = function (memId, isHide, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/ptmphd/" + memId + "/" + isHide;
        GetServiceByURL($http, url, funCallBack);
    };

    //Get call for blocked members
    this.GetBlockedMembes = function (memId, pgNo, PgSize, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/block/" + memId + "/" + pgNo + "/" + PgSize;
        GetServiceByURL($http, url, funCallBack);
    };

    //Get for blocked members count
    this.GetBlockedMembesCnt = function (membrerId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/blkcnt/" + membrerId;
        GetServiceByURL($http, url, funCallBack);
    };

    //Unblocking the blocked users
    this.UnBlockMember = function (memId, memBlkId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/actions/rmblk/" + memId + "/" + memBlkId;
        GetServiceByURL($http, url, funCallBack);
    };

   //auto save services start
    this.saveTimezone = function (memId, timezone, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/tmzn/" + memId + "/" + timezone;
        GetServiceByURL($http, url, funCallBack);
    };

    this.saveUnits = function (memId, units, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/unts/" + memId + "/" + units;
        GetServiceByURL($http, url, funCallBack);
    };

    this.saveLocation = function (memId, countryId, cityId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/lctn/" + memId + "/" + countryId + "/" + cityId;
        GetServiceByURL($http, url, funCallBack);
    };

    this.saveDOB = function (memId, dob, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/dob/" + memId;
        var data = { dt: dob }
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.saveGender = function (memId, gender, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/gender/" + memId + "/" + gender;
        GetServiceByURL($http, url, funCallBack);
    };

    this.saveGenderPref = function (memId, genderPref, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/genderpref/" + memId + "/" + genderPref;
        GetServiceByURL($http, url, funCallBack);
    };
    //auto save services end

    //notification settings services start
    this.saveSettingsEmlrecmatch = function (memId, Emlrecmatch, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/emlrecmatch/" + memId + "/" + Emlrecmatch;
        GetServiceByURL($http, url, funCallBack);
    };

    this.saveSettingsEmlviewme = function (memId, Emlviewme, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/emlviewme/" + memId + "/" + Emlviewme;
        GetServiceByURL($http, url, funCallBack);
    };

    this.saveSettingsEmlflirtme = function (memId, Emlflirtme, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/emlflirtme/" + memId + "/" + Emlflirtme;
        GetServiceByURL($http, url, funCallBack);
    };

    this.saveSettingsEmlmsgme = function (memId, Emlmsgme, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/emlmsgme/" + memId + "/" + Emlmsgme;
        GetServiceByURL($http, url, funCallBack);
    };

    this.saveSettingsEmlpyrprmtn = function (memId, Emlpyrprmtn, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/emlpyrprmtn/" + memId + "/" + Emlpyrprmtn;
        GetServiceByURL($http, url, funCallBack);
    };

    this.saveSettingsEmlpyrtips = function (memId, Emlpyrtips, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/emlpyrtips/" + memId + "/" + Emlpyrtips;
        GetServiceByURL($http, url, funCallBack);
    };
    //notification setting module end

    //Delete Account
    this.deleteAccountSendOtp = function (mId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/delmemcls/" + mId;
        GetServiceByURL($http, url, funCallBack);
    }

    this.verifyDelActEmlCode = function (mId, code, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/delmemvrfy/" + mId + "/" + code;
        GetServiceByURL($http, url, funCallBack);
    };

    this.verifyOTPCode = function (mId, otpId, otpCode, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/delmemchkmbl";
        var data = { mId: mId, otpId: otpId, otpCode: otpCode };
        PostServiceByURL($http, url,data, funCallBack);
    };

    this.deleteAccntFnl = function (mId, otpId, reasonType, reasonExplantion, funCallBack) {
        var url = "https://pcapi.pyar.com/api/account/delmemmbl";
        var data = { mId: mId, otpId: otpId, statusCause: reasonType, reason: reasonExplantion };       
        PostServiceByURL($http, url, data, funCallBack);
    };  
    //Delete Account End
}]);