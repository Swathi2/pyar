﻿app.service('helpfaqsSrvc', ['$http', function ($http) {
    this.faqCategories = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/helpcontact/faqcat";
        GetServiceByURL($http, url, funCallBack);
    };

    this.faqCategoryById = function (categoryId, funCallBack) {
        var url = "https://pcapi.pyar.com/api/helpcontact/catfaq/" + categoryId + "";
        GetServiceByURL($http, url, funCallBack);
    };

    this.faqSearch = function (srchTxt, funCallBack) {
        var data = { srchTxt: srchTxt }
        var url = "https://pcapi.pyar.com/api/helpcontact/faqSrch";
        PostServiceByURL($http, url, data, funCallBack);
    };

    this.memberTktCategory = function (funCallBack) {
        var url = "https://pcapi.pyar.com/api/helpcontact/memberTktcat";
        GetServiceByURL($http, url, funCallBack);
    };

    this.memberTkt = function (memberId, mtcId, title, desc, funCallBack) {
        var data = { memberId: memberId, mtcId: mtcId, title: title, desc: desc }
        var url = "https://pcapi.pyar.com/api/helpcontact/memberTkt";
        PostServiceByURL($http, url, data, funCallBack);
    };
}]);