﻿angular.module("app").controller('abthlpCtrl', ['getSessionSrvc', 'helpfaqsSrvc', '$timeout', '$state', '$filter', function (getSessionSrvc, helpfaqsSrvc, $timeout, $state, $filter) {
    var vm = this;
    if ($("body").attr("class"))
        $("body").attr("class", $("body").attr("class") + " faqbg");
    else
        $("body").attr("class", "faqbg");

    //binding variabls for ticket
    vm.title = "";
    vm.mtcId = [];
    vm.desc = "";
    vm.descMaxLen = 1000;
    //used for show hide headers
    vm.ticketHeader = false;
    vm.abtHlpHeader = true;
    //used for show pop visible true or false
    vm.sendTicket = false;
    vm.ticketValid = false;
    //used for send memberId
    vm.mId = function () { return getSessionSrvc.p_mId(); };

    //validate ticket for enable or disable Send button for ticket submition
    vm.validateTckt = function (type) {
        if (type == 'D') {
            if (vm.desc && vm.desc.length > vm.descMaxLen) {
                vm.descErrMsg = "Must be <=" + vm.descMaxLen + " characters";
                vm.desc = "";
            }
            else
                vm.descErrMsg = "";
        }
        vm.errorTitleMsg = "";
        if (vm.title && vm.title.length > 50) {
            vm.ticketValid = false;
            vm.errorTitleMsg = "Must be < 50 characters";
            vm.title = "";
        }
        if (vm.title && vm.mtcId.mtcId && vm.desc)
            vm.ticketValid = true;
        else
            vm.ticketValid = false;
    };

    //bind ticket categories
    vm.getTicketCategories = function () {
        helpfaqsSrvc.memberTktCategory(function (response, status) {
            if (status == 200) {
                vm.memTktCat = $filter("orderBy")(response, "priority");
                for (var i = 0; i < vm.memTktCat.length; i++) {
                    if (vm.memTktCat[i].tcName == "Advertising")
                        vm.memTktCat.splice(i, 1);                                           
                    if (vm.memTktCat[i].tcName == "Business Inquiry")
                        vm.memTktCat.splice(i, 1);                        
                }
            }
        });
    };
    vm.getTicketCategories();

    //showing cancel and send button and hide header for ticket
    vm.chgHdr = function () {
        vm.ticketHeader = true;
        vm.abtHlpHeader = false;
    };

    //ticket submit cancl button click event
    vm.cancel = function () {
        vm.ticketHeader = false;
        vm.abtHlpHeader = true;
        vm.clear();
    };

    //submit ticket to api
    vm.submitTicket = function () {
        if (vm.ticketValid && vm.mId()) {
            //send ticket to api for saving and show result to user that we are received
            helpfaqsSrvc.memberTkt(vm.mId(), vm.mtcId.mtcId, vm.title, vm.desc, function (response, status) {
                if (response == true && status == 200) {
                    vm.sendTicket = true;
                    $timeout(function () { vm.sendTicket = false; }, 1500);
                    vm.cancel();
                }
                else 
                    alert("something went wrong, plese try again later");
            });
        }
    };

    //clear ticket fields
    vm.clear = function () {
        vm.title = "";
        vm.mtcId = [];
        vm.desc = "";
        vm.ticketValid = false;
    };

    vm.abthlpnaviagate = function (pagetype) {
        if (pagetype == 1)
            $state.go("help-faqs");
        else if (pagetype == 2)
            $state.go("aboutus");
        else if (pagetype == 3)
            $state.go("privacy-policy");
        else if (pagetype == 4)
            $state.go("terms-conditions");
    };

    vm.removecat = function () {
        vm.mtcId = [];
        vm.validateTckt();
    };
}]);