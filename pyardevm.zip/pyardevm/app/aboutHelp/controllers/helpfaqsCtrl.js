﻿angular.module("app").controller('helpfaqsCtrl', ['helpfaqsSrvc', '$state', function (helpfaqsSrvc, $state) {
    var vm = this;
    showLoader();
    vm.srchResults = false;
    vm.catFAQS = [];
    vm.questions = [];
    vm.txtSrchCls = "form-control";
    vm.faqSrchSave = [];

    if ($("body").attr("class"))
        $("body").attr("class", $("body").attr("class") + " faqbg");
    else
        $("body").attr("class", "faqbg");

    vm.GetFAQCategories = function () {
        vm.pgType = "1";
        vm.pgHead = "Help FAQs";
        helpfaqsSrvc.faqCategories(function (response, status) {
            if (status == 200)
                vm.categories = response;
            hideLoader();
        });
    };
    vm.GetFAQCategories();

    vm.GetFAQByCatId = function (faqCatId, faqCatName) {
        vm.questions = [];
        showLoader();
        vm.pgType = "2";
        vm.pgHead = faqCatName;
        var faqExist = false;
        for (var i = 0; i < vm.catFAQS.length; i++) {
            if (faqCatId == vm.catFAQS[i].faqcId) {
                vm.questions = vm.catFAQS[i].response;
                faqExist = true;
                hideLoader();
                break;
            }
        }

        if (!faqExist) {
            helpfaqsSrvc.faqCategoryById(faqCatId, function (response) {
                var faqcId = vm.faqCatId;
                var faqs = { faqcId: faqcId, "response": response };
                vm.catFAQS.push(faqs);
                vm.questions = response;
                hideLoader();
            });
        }
        $("body").scrollTop(0);
    };

    vm.GetFAQByfaqId = function (faqhId) {
        if (vm.pgType == "2")
            vm.pgType = "3";
        else
            vm.pgType = "5";
        for (i = 0; i < vm.questions.length; i++) {
            if (vm.questions[i].faqhId == faqhId) {
                vm.faq = vm.questions[i].faq;
                vm.faqans = vm.questions[i].faqans;
                break;
            }
        }
        $("body").scrollTop(0);
    };

    vm.GoBack = function () {
        vm.clearIcn = false;
        if (vm.pgType == "1")
            $state.go("contactus");
        else if (vm.pgType == "2" || vm.pgType == "4") {
            vm.pgType = "1";
            vm.pgHead = "Help FAQs";
            vm.srchTxt = "";
            $("body").scrollTop(0);
            vm.txtSrchCls = "form-control ";
        }
        else if (vm.pgType == "3") {
            vm.pgType = "2";
            $("body").scrollTop(0);
        }
        else if (vm.pgType == "5") {
            vm.pgType = "4";
            $("body").scrollTop(0);
            vm.clearIcn = true;
        }
    };

    vm.chgFaqSrchTxt = function (type) {
        if (!vm.srchTxt)
            vm.questions = [];
        if (type == 1) {
            vm.pgType = 4;
            vm.txtSrchCls = "form-control faqsrch cancelBtn srchImghde ";
            if (vm.srchTxt != "") {
                vm.clearIcn = true;
            }
        }
        else if (type == 2) {
            vm.clearIcn = false;
            vm.pgType = 1;
            vm.txtSrchCls = "form-control";
        }
    };

    vm.faqSearch = function () {
        vm.errorSrchMsg = "";
        if (vm.srchTxt && vm.srchTxt.length > 100) {
            vm.srchResults = false;
            vm.errorSrchMsg = "Must be < 100 characters";
            vm.srchTxt = "";
            return;
        }
        if (!vm.srchTxt || vm.srchTxt.length < 3) {
            vm.srchResults = false;
            vm.questions = [];
            return;
        }
        else {
            showLoader();
            if (vm.srchTxt.length == 3 && !vm.checkFAQSrch(vm.srchTxt)) {
                var keyword = vm.srchTxt;
                helpfaqsSrvc.faqSearch(vm.srchTxt, function (response, status) {
                    if (status == 204 && response.length == 0) 
                        vm.srchResults = true;
                    if (status == 200 && response.length > 0) {
                        vm.srchResults = false;
                        vm.pgType = "4";
                        vm.faqSrchSave.push({ "keyword": keyword, "response": response });
                    }
                    vm.bindfaqSrch(keyword);
                });
            }
            else
                vm.bindfaqSrch(vm.srchTxt);
        }
    };

    vm.bindfaqSrch = function (keyword) {
        var questions = [];
        var faqs = vm.getFAQSrch(keyword)
        angular.forEach(faqs, function (faqObj) {
            if (faqObj.faq.toLowerCase().indexOf(keyword.toLowerCase()) != -1 || faqObj.faqans.toLowerCase().indexOf(keyword.toLowerCase()) != -1)
                questions.push(faqObj);
        });
        hideLoader();
        vm.pgType = 4;
        vm.questions = questions;
        $("body").scrollTop(0);
    };

    vm.checkFAQSrch = function (keyword) {
        var exist = false;
        for (var i = 0; i < vm.faqSrchSave.length; i++) {
            if (keyword.toLowerCase().startsWith(vm.faqSrchSave[i].keyword.toLowerCase())) {
                exist = true;
                break;
            }
        }
        return exist;
    };

    vm.getFAQSrch = function (keyword) {
        var faqs = [];
        for (var i = 0; i < vm.faqSrchSave.length; i++) {
            if (keyword.toLowerCase().startsWith(vm.faqSrchSave[i].keyword.toLowerCase())) {
                faqs = vm.faqSrchSave[i].response;
                break;
            }
        }
        return faqs;
    };

    vm.srchTextKeyUp = function (srchTxt) {
        if (srchTxt.length > 0)
            vm.clearIcn = true;
        else
            vm.clearIcn = false;
    };

    vm.hideClrImg = function () {
        vm.srchTxt = null;
        if (vm.srchTxt == null) {
            vm.clearIcn = false;
            vm.questions = [];
        }
        else
            vm.clearIcn = true;
    };
}]);